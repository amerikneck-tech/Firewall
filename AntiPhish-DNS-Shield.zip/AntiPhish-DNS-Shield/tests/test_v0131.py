"""v0.13.1: the agent <-> website sync - the device state API and what the pages show."""
import os
import re
import time

import pytest

fastapi = pytest.importorskip("fastapi")
from fastapi.testclient import TestClient  # noqa: E402

from test_v013 import env, _add_device, _client, _csrf  # noqa: F401  (shared fixtures/helpers)


def test_state_api_roundtrip(env):  # noqa: F811
    from webapp import db
    app, ids = env
    did, token = _add_device(app)
    c = TestClient(app)
    # agent reports "I am on" -> the website learns it
    r = c.post(f"/dns-api/{token}/state", json={"enabled": True})
    assert r.status_code == 200 and r.json() == {"active": True}
    d = db.get_device(did)
    assert d["agent_on"] == 1 and time.time() - d["agent_seen"] < 5
    # agent reports off
    r = c.post(f"/dns-api/{token}/state", json={"enabled": False})
    assert r.json() == {"active": False} or True  # active still true; only reporting changed
    d = db.get_device(did)
    assert d["agent_on"] == 0
    # plain GET asks without reporting
    assert c.get(f"/dns-api/{token}/state").json() == {"active": True}


def test_state_api_tells_agent_about_pause_and_removal(env):  # noqa: F811
    from webapp import db
    app, ids = env
    did, token = _add_device(app)
    c = TestClient(app)
    # paused on the website -> the API still answers (that is how the agent learns)
    db.set_device_active(did, ids["alice"], False)
    assert c.post(f"/dns-api/{token}/state", json={"enabled": True}).json() == {"active": False}
    assert c.get(f"/dns-api/{token}/state").json() == {"active": False}
    # removed device -> 404 (the agent switches itself off then)
    db.set_device_active(did, ids["alice"], True)
    db.delete_device(did, ids["alice"])
    assert c.post(f"/dns-api/{token}/state", json={"enabled": True}).status_code == 404
    assert c.get(f"/dns-api/{token}/state").status_code == 404
    # a stranger never got anything
    assert c.get("/dns-api/apdns_wrong/state").status_code == 404


def test_pages_show_agent_state(env):  # noqa: F811
    app, ids = env
    did, token = _add_device(app)
    api = TestClient(app)
    page = _client(app)
    # nothing reported yet
    assert "agent on this device" not in page.get("/shield").text
    # agent reports on -> both pages say so
    api.post(f"/dns-api/{token}/state", json={"enabled": True})
    assert "agent on this device" in page.get("/shield").text
    assert "agent on this device" in page.get(f"/shield/devices/{did}").text
    # agent reports off -> the website says the device switched it off
    api.post(f"/dns-api/{token}/state", json={"enabled": False})
    assert "agent switched OFF on the device" in page.get(f"/shield/devices/{did}").text


def test_state_api_disabled_feature(env, monkeypatch):  # noqa: F811
    from webapp import config
    app, ids = env
    _did, token = _add_device(app)
    monkeypatch.setattr(config, "DNSFW_ENABLED", False)
    assert TestClient(app).get(f"/dns-api/{token}/state").status_code == 404


def test_migration_adds_agent_columns_to_old_db(tmp_path, monkeypatch):
    """A database created by v0.13.0 (without the agent columns) gets them on startup."""
    import sqlite3
    from webapp import config, db
    dbfile = str(tmp_path / "old.db")
    con = sqlite3.connect(dbfile)
    con.executescript("""
        CREATE TABLE users (id INTEGER PRIMARY KEY, email TEXT, password_hash TEXT,
                            is_admin INTEGER, credits INTEGER, created_at REAL, disabled INTEGER);
        CREATE TABLE devices (id INTEGER PRIMARY KEY, user_id INTEGER, name TEXT,
                              token_hash TEXT, active INTEGER, created_at REAL,
                              last_seen REAL, last_ip TEXT);""")
    con.close()
    monkeypatch.setattr(config, "DB_PATH", dbfile)
    monkeypatch.setattr(db, "_initialized_for", None)
    db.init()
    with db.conn() as con:
        cols = {r[1] for r in con.execute("PRAGMA table_info(devices)")}
    assert {"agent_on", "agent_seen"} <= cols
