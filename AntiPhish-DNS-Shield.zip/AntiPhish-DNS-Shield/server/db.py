"""DNS shield storage - extracted from webapp/db.py (AntiPhish v0.13.1).

The three tables below are appended to the app's _SCHEMA string (they self-create on
startup); v0.13.1 also adds two columns to `devices` through the _MIGRATIONS list:
    ("devices", "agent_on", "INTEGER"),
    ("devices", "agent_seen", "REAL"),
The functions go at the end of db.py. They use the app's conn()/tx() helpers:
conn() = a read connection (sqlite3, WAL), tx() = an exclusive write transaction.
"""

# --- schema (part of _SCHEMA in db.py) -------------------------------------------
SCHEMA_SQL = """
CREATE TABLE IF NOT EXISTS devices (        -- DNS shield: a device the user protects
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id     INTEGER NOT NULL REFERENCES users(id),
    name        TEXT NOT NULL,
    token_hash  TEXT NOT NULL UNIQUE,       -- sha256 of the DoH token (never the token)
    active      INTEGER NOT NULL DEFAULT 1,
    created_at  REAL NOT NULL,
    last_seen   REAL,
    last_ip     TEXT NOT NULL DEFAULT ''
);
CREATE TABLE IF NOT EXISTS dns_rules (      -- per-user block/allow lists
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id     INTEGER NOT NULL REFERENCES users(id),
    pattern     TEXT NOT NULL,              -- "example.com" or "*.example.com"
    scope       TEXT NOT NULL,              -- exact | suffix
    action      TEXT NOT NULL,              -- block | allow
    created_at  REAL NOT NULL,
    UNIQUE(user_id, pattern)
);
CREATE TABLE IF NOT EXISTS dns_events (     -- the live per-device query log
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    device_id   INTEGER NOT NULL REFERENCES devices(id),
    domain      TEXT NOT NULL,
    qtype       INTEGER NOT NULL DEFAULT 1,
    action      TEXT NOT NULL,              -- allowed | blocked | error
    rule        TEXT NOT NULL DEFAULT '',
    created_at  REAL NOT NULL
);
CREATE INDEX IF NOT EXISTS ix_dns_events_dev ON dns_events(device_id, created_at DESC);
"""

# ------------------------------------------------------------------ DNS shield
def create_device(user_id: int, name: str, token_hash: str) -> int:
    with tx() as con:
        cur = con.execute(
            "INSERT INTO devices(user_id,name,token_hash,created_at) VALUES (?,?,?,?)",
            (user_id, name[:80], token_hash, time.time()))
        return cur.lastrowid


def get_device(device_id: int, user_id: int | None = None):
    with conn() as con:
        if user_id is None:
            return con.execute("SELECT * FROM devices WHERE id=?", (device_id,)).fetchone()
        return con.execute("SELECT * FROM devices WHERE id=? AND user_id=?",
                           (device_id, user_id)).fetchone()


def get_device_by_token(token_hash: str):
    with conn() as con:
        return con.execute("SELECT * FROM devices WHERE token_hash=?", (token_hash,)).fetchone()


def list_devices(user_id: int):
    """Devices with counters for the dashboard (last 24 h)."""
    since = time.time() - 86400
    with conn() as con:
        return con.execute(
            "SELECT d.*, "
            "(SELECT COUNT(*) FROM dns_events e WHERE e.device_id=d.id AND e.created_at>=?) "
            "AS queries_24h, "
            "(SELECT COUNT(*) FROM dns_events e WHERE e.device_id=d.id AND e.created_at>=? "
            "AND e.action='blocked') AS blocked_24h "
            "FROM devices d WHERE d.user_id=? ORDER BY d.id", (since, since, user_id)).fetchall()


def count_devices(user_id: int) -> int:
    with conn() as con:
        return con.execute("SELECT COUNT(*) FROM devices WHERE user_id=?", (user_id,)).fetchone()[0]


def set_device_active(device_id: int, user_id: int, active: bool) -> bool:
    with tx() as con:
        cur = con.execute("UPDATE devices SET active=? WHERE id=? AND user_id=?",
                          (int(active), device_id, user_id))
        return cur.rowcount == 1


def delete_device(device_id: int, user_id: int) -> bool:
    with tx() as con:
        cur = con.execute("SELECT id FROM devices WHERE id=? AND user_id=?",
                          (device_id, user_id)).fetchone()
        if not cur:
            return False
        con.execute("DELETE FROM dns_events WHERE device_id=?", (device_id,))
        con.execute("DELETE FROM devices WHERE id=?", (device_id,))
        return True


def report_agent_state(device_id: int, on: bool):
    """The agent's heartbeat: is protection switched on on the device itself."""
    with tx() as con:
        con.execute("UPDATE devices SET agent_on=?, agent_seen=? WHERE id=?",
                    (int(on), time.time(), device_id))


def touch_device(device_id: int, ip: str):
    with tx() as con:
        con.execute("UPDATE devices SET last_seen=?, last_ip=? WHERE id=?",
                    (time.time(), (ip or "")[:45], device_id))


def add_dns_rule(user_id: int, pattern: str, scope: str, action: str) -> bool:
    """False if the same pattern already exists for this user."""
    with tx() as con:
        cur = con.execute(
            "INSERT OR IGNORE INTO dns_rules(user_id,pattern,scope,action,created_at) "
            "VALUES (?,?,?,?,?)", (user_id, pattern, scope, action, time.time()))
        return cur.rowcount == 1


def delete_dns_rule(rule_id: int, user_id: int) -> bool:
    with tx() as con:
        cur = con.execute("DELETE FROM dns_rules WHERE id=? AND user_id=?", (rule_id, user_id))
        return cur.rowcount == 1


def list_dns_rules(user_id: int):
    with conn() as con:
        return con.execute("SELECT * FROM dns_rules WHERE user_id=? ORDER BY pattern",
                           (user_id,)).fetchall()


def log_dns_event(device_id: int, domain: str, qtype: int, action: str, rule: str = ""):
    with tx() as con:
        con.execute(
            "INSERT INTO dns_events(device_id,domain,qtype,action,rule,created_at) "
            "VALUES (?,?,?,?,?,?)",
            (device_id, domain[:253], int(qtype), action, (rule or "")[:253], time.time()))


def list_dns_events(device_id: int, limit: int = 100, action: str | None = None):
    with conn() as con:
        if action in ("allowed", "blocked", "error"):
            return con.execute(
                "SELECT * FROM dns_events WHERE device_id=? AND action=? "
                "ORDER BY id DESC LIMIT ?", (device_id, action, limit)).fetchall()
        return con.execute(
            "SELECT * FROM dns_events WHERE device_id=? ORDER BY id DESC LIMIT ?",
            (device_id, limit)).fetchall()


def dns_stats(user_id: int, since: float) -> dict:
    """Totals across all of the user's devices (for the shield overview)."""
    with conn() as con:
        row = con.execute(
            "SELECT COUNT(*) AS total, SUM(e.action='blocked') AS blocked "
            "FROM dns_events e JOIN devices d ON d.id=e.device_id "
            "WHERE d.user_id=? AND e.created_at>=?", (user_id, since)).fetchone()
        top = con.execute(
            "SELECT e.domain, COUNT(*) AS n FROM dns_events e JOIN devices d ON d.id=e.device_id "
            "WHERE d.user_id=? AND e.created_at>=? AND e.action='blocked' "
            "GROUP BY e.domain ORDER BY n DESC LIMIT 10", (user_id, since)).fetchall()
    return {"total": row["total"] or 0, "blocked": row["blocked"] or 0,
            "top_blocked": [dict(r) for r in top]}


def purge_old_dns_events(days: int) -> int:
    if days <= 0:
        return 0
    with tx() as con:
        cur = con.execute("DELETE FROM dns_events WHERE created_at < ?",
                          (time.time() - days * 86400,))
        return cur.rowcount
