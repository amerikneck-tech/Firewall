"""DNS shield routes - extracted from webapp/main.py (AntiPhish v0.13.1).

These live inside the main FastAPI app. Dependencies that come from the main app:
  - app, Request, HTTPException, Response, JSONResponse, RedirectResponse, HTMLResponse
  - Depends, Form, render(), flash(), check_csrf(), current_user, client_ip(), log
  - modules: config, db, dnsfw
Paste point in main.py: right before the "misc" section (/privacy, /healthz).
"""

# ------------------------------------------------------------------ DNS shield
def _dnsfw_on():
    if not config.DNSFW_ENABLED:
        raise HTTPException(status_code=404, detail="DNS shield is not enabled.")


def _doh_answer(raw: bytes, device, ip: str) -> Response:
    try:
        answer = dnsfw.handle_wire_query(raw, device)
    except dnsfw.QueryError:
        raise HTTPException(status_code=400, detail="Not a DNS query.")
    dnsfw.touch_seen(device["id"], ip)
    return Response(answer, media_type="application/dns-message",
                    headers={"Cache-Control": "no-store"})


def _doh_device(token: str, request: Request):
    """Token auth for the DoH endpoint: no session, no CSRF - the token IS the login.
    Unknown or switched-off devices get a plain 404, so the endpoint never behaves
    like an open resolver."""
    _dnsfw_on()
    device = db.get_device_by_token(dnsfw.token_hash(token))
    if not device or not device["active"]:
        raise HTTPException(status_code=404, detail="Not found.")
    if dnsfw.rate_limited(device["id"]):
        raise HTTPException(status_code=429, detail="Too many queries.")
    db_user = db.get_user(device["user_id"])
    if not db_user or db_user["disabled"]:
        raise HTTPException(status_code=404, detail="Not found.")
    return device


@app.post("/dns-query/{token}")
async def doh_post(token: str, request: Request):
    device = _doh_device(token, request)
    if request.headers.get("content-type", "").split(";")[0].strip() != "application/dns-message":
        raise HTTPException(status_code=415, detail="Expected application/dns-message.")
    raw = await request.body()
    if not raw or len(raw) > dnsfw.MAX_QUERY_BYTES:
        raise HTTPException(status_code=400, detail="Bad DNS message size.")
    from starlette.concurrency import run_in_threadpool
    return await run_in_threadpool(_doh_answer, raw, device, client_ip(request))


@app.get("/dns-query/{token}")
async def doh_get(token: str, request: Request, dns: str = ""):
    """RFC 8484 GET form: ?dns=<base64url query, no padding>."""
    device = _doh_device(token, request)
    try:
        raw = dnsfw.b64url_decode(dns) if dns else b""
    except Exception:
        raw = b""
    if not raw or len(raw) > dnsfw.MAX_QUERY_BYTES:
        raise HTTPException(status_code=400, detail="Bad DNS message.")
    from starlette.concurrency import run_in_threadpool
    return await run_in_threadpool(_doh_answer, raw, device, client_ip(request))


def _api_device(token: str):
    """Token auth for the agent's status API. Unlike the DoH endpoint, a PAUSED device
    still gets an answer ({"active": false}) - that is how the agent learns about the pause."""
    _dnsfw_on()
    device = db.get_device_by_token(dnsfw.token_hash(token))
    if not device:
        raise HTTPException(status_code=404, detail="Not found.")
    return device


@app.get("/dns-api/{token}/state")
def dns_api_state(token: str):
    device = _api_device(token)
    return JSONResponse({"active": bool(device["active"])})


@app.post("/dns-api/{token}/state")
async def dns_api_report(token: str, request: Request):
    """The agent reports its own on/off and gets the website's pause state back."""
    device = _api_device(token)
    on = False
    try:
        body = await request.json()
        on = bool(body.get("enabled"))
    except Exception:
        pass
    db.report_agent_state(device["id"], on)
    return JSONResponse({"active": bool(device["active"])})


def _agent_label(device) -> str:
    """What the website knows about the agent on the device (from its heartbeats)."""
    try:
        seen, on = device["agent_seen"], device["agent_on"]
    except (KeyError, IndexError):
        return ""
    if not seen or time.time() - seen > 90:
        return "agent not running"
    return "agent on this device" if on else "agent switched OFF on the device"


# -------------------------------------------------------------- DNS shield pages
def _shield_ctx(request: Request, user, **extra):
    devices = [dict(d, agent_label=_agent_label(d)) for d in db.list_devices(user["id"])]
    return dict({"user": user, "nav": "shield", "devices": devices,
                 "rules": db.list_dns_rules(user["id"]),
                 "stats": db.dns_stats(user["id"], time.time() - 7 * 86400),
                 "can_add": db.count_devices(user["id"]) < config.DNSFW_DEVICES_PER_USER,
                 "test_domain": dnsfw.TEST_BLOCKED_DOMAIN}, **extra)


@app.get("/shield", response_class=HTMLResponse)
def shield_page(request: Request, user=Depends(current_user)):
    _dnsfw_on()
    return render(request, "shield.html", _shield_ctx(request, user))


@app.post("/shield/devices")
def shield_add_device(request: Request, user=Depends(current_user), csrf: str = Form(""),
                      name: str = Form("")):
    check_csrf(request, csrf)
    _dnsfw_on()
    name = name.strip()[:80]
    if not name:
        flash(request, "Give the device a name (e.g. 'My laptop').", "error")
        return RedirectResponse("/shield", status_code=303)
    if db.count_devices(user["id"]) >= config.DNSFW_DEVICES_PER_USER:
        flash(request, f"You already have {config.DNSFW_DEVICES_PER_USER} devices, the maximum "
                       f"per account. Remove one to add a new one.", "error")
        return RedirectResponse("/shield", status_code=303)
    token, thash = dnsfw.new_device_token()
    db.create_device(user["id"], name, thash)
    log.info("user %s added a DNS shield device '%s'", user["id"], name)
    # the only place and the only moment the token is shown - the server stores its hash
    flash(request, f"Device added. DoH address for the agent: "
                   f"{config.BASE_URL}/dns-query/{token}", "ok")
    return RedirectResponse("/shield", status_code=303)


@app.get("/shield/devices/{device_id}", response_class=HTMLResponse)
def shield_device_page(request: Request, device_id: int, user=Depends(current_user),
                       f: str = ""):
    _dnsfw_on()
    device = db.get_device(device_id, user["id"])
    if not device:
        raise HTTPException(status_code=404, detail="Device not found.")
    return render(request, "shield_device.html", {
        "user": user, "nav": "shield", "d": device, "agent_label": _agent_label(device),
        "events": db.list_dns_events(device_id, 100, f or None), "filter": f,
        "test_domain": dnsfw.TEST_BLOCKED_DOMAIN})


@app.post("/shield/devices/{device_id}/toggle")
def shield_device_toggle(request: Request, device_id: int, user=Depends(current_user),
                         csrf: str = Form("")):
    check_csrf(request, csrf)
    _dnsfw_on()
    device = db.get_device(device_id, user["id"])
    if not device:
        raise HTTPException(status_code=404, detail="Device not found.")
    db.set_device_active(device_id, user["id"], not device["active"])
    flash(request, "Protection switched on." if not device["active"]
          else "Protection paused – the device no longer gets answers from this server.",
          "ok" if not device["active"] else "info")
    return RedirectResponse(f"/shield/devices/{device_id}", status_code=303)


@app.post("/shield/devices/{device_id}/delete")
def shield_device_delete(request: Request, device_id: int, user=Depends(current_user),
                         csrf: str = Form("")):
    check_csrf(request, csrf)
    _dnsfw_on()
    device = db.get_device(device_id, user["id"])
    if not device:
        raise HTTPException(status_code=404, detail="Device not found.")
    db.delete_device(device_id, user["id"])
    flash(request, f"Device '{device['name']}' removed; its token stops working immediately.", "ok")
    return RedirectResponse("/shield", status_code=303)


@app.post("/shield/rules")
def shield_add_rule(request: Request, user=Depends(current_user), csrf: str = Form(""),
                    pattern: str = Form(""), action: str = Form("block")):
    check_csrf(request, csrf)
    _dnsfw_on()
    pat, scope = dnsfw.normalize_pattern(pattern)
    if not pat or action not in ("block", "allow"):
        flash(request, "Enter a domain like 'example.com' or '*.example.com'.", "error")
    elif not db.add_dns_rule(user["id"], pat, scope, action):
        flash(request, f"The rule {pat} already exists.", "info")
    else:
        flash(request, f"Rule added: {pat} → {'block' if action == 'block' else 'allow'}.", "ok")
    return RedirectResponse("/shield", status_code=303)


@app.post("/shield/rules/{rule_id}/delete")
def shield_delete_rule(request: Request, rule_id: int, user=Depends(current_user),
                       csrf: str = Form("")):
    check_csrf(request, csrf)
    _dnsfw_on()
    db.delete_dns_rule(rule_id, user["id"])
    flash(request, "Rule removed.", "ok")
    return RedirectResponse("/shield", status_code=303)
