"""DNS shield settings - extracted from webapp/config.py (AntiPhish v0.13.1).
All are environment variables (.env). `os` import comes from the main config."""

# ------------------------------------------------------------------ DNS shield
# A DNS firewall for the user's devices. An agent on the device (or any DoH client)
# sends queries to <BASE_URL>/dns-query/<device-token> (DNS-over-HTTPS, RFC 8484);
# blocked domains get NXDOMAIN straight away, the rest is forwarded to the upstream
# resolver. Without a valid device token the server answers nothing - it is never
# an open resolver.
DNSFW_ENABLED = os.getenv("DNSFW_ENABLED", "1") == "1"
DNSFW_UPSTREAM = os.getenv("DNSFW_UPSTREAM", "1.1.1.1")      # resolver for allowed queries
DNSFW_UPSTREAM_PORT = int(os.getenv("DNSFW_UPSTREAM_PORT", "53"))
DNSFW_TIMEOUT = float(os.getenv("DNSFW_TIMEOUT", "5"))       # upstream wait, seconds
DNSFW_DEVICES_PER_USER = int(os.getenv("DNSFW_DEVICES_PER_USER", "5"))
DNSFW_QUERIES_PER_MIN = int(os.getenv("DNSFW_QUERIES_PER_MIN", "600"))   # per device
DNSFW_LOG_RETENTION_DAYS = int(os.getenv("DNSFW_LOG_RETENTION_DAYS", "14"))
