# AntiPhish DNS Shield

A DNS firewall: an agent on a Windows PC points the system's DNS at a tiny local listener
and forwards every query over HTTPS (DNS-over-HTTPS, RFC 8484) to the server, which blocks
domains by the user's rules and logs everything. The user manages devices, rules and the
live query log on the web dashboard.

This package contains **only the DNS shield feature**, extracted from the AntiPhish app
(v0.13.1) so it can be worked on independently.

## Layout

| Path | What it is |
|---|---|
| `agent/` | The Windows agent — **fully standalone**, stdlib only. `shield_agent.py` runs it (`build-agent.bat` packs a single .exe with PyInstaller). |
| `server/dnsfw.py` | The server core: DNS wire parsing, NXDOMAIN/SERVFAIL synthesis, upstream forwarding (UDP + TCP retry), rule matching, device tokens, rate limiting. Imports only `config` and `db` from the main app. |
| `server/routes.py` | The FastAPI routes: the DoH endpoint (`/dns-query/<token>`, POST+GET), the agent state API (`/dns-api/<token>/state`), and the dashboard pages (`/shield`, devices, rules). |
| `server/db.py` | The three tables (`devices`, `dns_rules`, `dns_events`) and their functions. |
| `server/config.py` | The `DNSFW_*` settings (env vars). |
| `server/templates/` | The two dashboard pages (Jinja2). |
| `tests/` | The pytest suites for the feature (server side). |

## The protocol (agent ↔ server)

1. **DoH query** — `POST /dns-query/<token>` with body = raw DNS wire message
   (`Content-Type: application/dns-message`). Answer = raw DNS wire message.
   Blocked domain → NXDOMAIN, no upstream call. Allowed → forwarded to the upstream
   resolver (`DNSFW_UPSTREAM`, default 1.1.1.1) and passed through untouched.
   Also supports the RFC 8484 GET form (`?dns=<base64url>`).
2. **State sync (every 25 s)** — `POST /dns-api/<token>/state` with `{"enabled": bool}`;
   answer: `{"active": bool}`. `active: false` = the device is paused on the website
   (agent then fails open and says so). `404` = unknown/removed token (agent switches
   itself off and restores the user's DNS).
3. **Tokens** — created on the website, shown once, stored server-side as SHA-256.
   Unknown tokens always get a plain 404: the server is never an open resolver.
   Everything runs on the HTTPS port (443) the site already uses — never open UDP/TCP 53.

## Design invariants (please keep)

- **Fail-open above all:** if the server is unreachable, the agent must keep the PC's
  internet working (plain DNS fallback + periodic shield re-probe every 30 s).
- **Restore what you touch:** the agent saves the original DNS settings before changing
  them and restores them on disable/exit.
- **Privacy by design:** the server parses only the DNS *question* (the domain), never
  the payload of any connection; the query log auto-expires
  (`DNSFW_LOG_RETENTION_DAYS`, default 14 days).
- `dns-shield-test.invalid` is always blocked — the built-in end-to-end test.

## Known limitations / ideas for improvement

- Browsers with their own "Secure DNS" (Chrome/Firefox DoH) bypass the system resolver —
  the agent can't see those queries. Possible directions: detect & warn, or guide the user.
- Windows-only agent so far; macOS/Linux/Android would share the same protocol.
- Rules are per-user; per-device rules, category blocklists (trackers, adult, malware
  feeds) and scheduled rules are natural next steps.
- The query log is per-query in SQLite — fine for hundreds of devices, would need
  aggregation/sampling for thousands.
- The agent is a plain tkinter window (no system tray yet) and the .exe is unsigned
  (Windows SmartScreen will warn; a code-signing certificate fixes that).
