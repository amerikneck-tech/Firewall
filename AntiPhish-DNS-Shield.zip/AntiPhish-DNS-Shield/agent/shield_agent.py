#!/usr/bin/env python3
"""AntiPhish DNS Shield - Windows agent.

What it does, in one breath: points the PC's DNS at a tiny local listener
(127.0.0.1:53), forwards every query over HTTPS (DNS-over-HTTPS) to the user's
personal AntiPhish address, and hands the answer back. Blocked domains simply
"do not exist" for every program on the PC.

Safety rails:
  * fail-open - if the server does not answer a few times in a row, queries go
    straight to a public resolver until it comes back (the internet never dies
    because of the shield);
  * the previous DNS settings are saved before anything is touched and restored
    when protection is switched off or the window is closed;
  * standard library only - no pip installs, nothing to break.

Run from source:  python shield_agent.py        (as Administrator)
Build an .exe:    build-agent.bat               (makes dist\\AntiPhishShield.exe)
"""
from __future__ import annotations

import ctypes
import json
import os
import socket
import struct
import subprocess
import sys
import threading
import time
import urllib.request

APP_NAME = "AntiPhish DNS Shield"
CONFIG_DIR = os.path.join(os.environ.get("APPDATA") or os.path.expanduser("~"),
                          "AntiPhishShield")
CONFIG_FILE = os.path.join(CONFIG_DIR, "config.json")
PREV_DNS_FILE = os.path.join(CONFIG_DIR, "previous-dns.json")
LISTEN_ADDR = ("127.0.0.1", 53)
FALLBACK_DNS = "1.1.1.1"          # used only while the shield server is unreachable
DOH_TIMEOUT = 4.0
PLAIN_TIMEOUT = 3.0
FAILS_BEFORE_FALLBACK = 3
RETRY_SHIELD_AFTER = 30.0       # while in fallback, re-try the shield this often
_TEST_DOMAIN = "dns-shield-test.invalid"     # the server always blocks this one

NO_WINDOW = getattr(subprocess, "CREATE_NO_WINDOW", 0)


# ------------------------------------------------------------------ config
def load_config() -> dict:
    try:
        with open(CONFIG_FILE, "r", encoding="utf-8") as f:
            cfg = json.load(f)
            return cfg if isinstance(cfg, dict) else {}
    except (OSError, ValueError):
        return {}


def save_config(cfg: dict):
    os.makedirs(CONFIG_DIR, exist_ok=True)
    with open(CONFIG_FILE, "w", encoding="utf-8") as f:
        json.dump(cfg, f, indent=2)


def valid_doh_url(url: str) -> bool:
    return url.startswith("https://") and "/dns-query/apdns_" in url


def state_url(doh_url: str) -> str:
    return doh_url.replace("/dns-query/", "/dns-api/").rstrip("/") + "/state"


class DeviceGone(Exception):
    """The token is unknown to the server - the device was removed on the website."""


def report_state(doh_url: str, enabled: bool) -> dict:
    """Tell the website whether protection is on here; learn whether it is paused there."""
    body = json.dumps({"enabled": bool(enabled)}).encode()
    req = urllib.request.Request(state_url(doh_url), data=body,
                                 headers={"Content-Type": "application/json"})
    try:
        with urllib.request.urlopen(req, timeout=DOH_TIMEOUT) as resp:
            return json.loads(resp.read().decode())
    except urllib.error.HTTPError as e:
        if e.code == 404:
            raise DeviceGone()
        raise OSError(f"HTTP {e.code}")


# ------------------------------------------------------------------ Windows DNS settings
def _ps(command: str) -> str:
    r = subprocess.run(["powershell", "-NoProfile", "-Command", command],
                       capture_output=True, text=True, creationflags=NO_WINDOW, timeout=30)
    if r.returncode != 0:
        raise RuntimeError(r.stderr.strip() or "PowerShell command failed")
    return r.stdout


def current_dns() -> list[dict]:
    """[{alias, servers:[...]}] for every active physical adapter (empty servers = DHCP)."""
    out = _ps(
        "Get-NetAdapter -Physical | Where-Object Status -eq 'Up' | ForEach-Object "
        "{ Get-DnsClientServerAddress -InterfaceAlias $_.Name -AddressFamily IPv4 } | "
        "Select-Object InterfaceAlias, ServerAddresses | ConvertTo-Json -Compress")
    out = out.strip()
    if not out:
        return []
    data = json.loads(out)
    if isinstance(data, dict):
        data = [data]
    return [{"alias": d["InterfaceAlias"], "servers": list(d.get("ServerAddresses") or [])}
            for d in data]


def set_dns(alias: str, servers: list[str] | None):
    a = alias.replace("'", "''")
    if servers:
        _ps(f"Set-DnsClientServerAddress -InterfaceAlias '{a}' "
            f"-ServerAddresses {','.join(servers)}")
    else:
        _ps(f"Set-DnsClientServerAddress -InterfaceAlias '{a}' -ResetServerAddresses")


def flush_dns():
    try:
        _ps("Clear-DnsClientCache")
    except Exception:
        pass


# ------------------------------------------------------------------ the forwarder
class Forwarder:
    """DNS wire in, DNS wire out - via the shield, or (fail-open) plain DNS."""

    def __init__(self, doh_url: str):
        self.doh_url = doh_url
        self.fails = 0
        self._last_shield_try = 0.0
        self.lock = threading.Lock()
        self.n_queries = 0
        self.n_blocked = 0
        self.n_fallback = 0
        self.last_error = ""
        self.paused = False             # set by the website (Pause protection)

    @property
    def degraded(self) -> bool:
        return self.fails >= FAILS_BEFORE_FALLBACK

    def _via_shield(self, wire: bytes) -> bytes:
        req = urllib.request.Request(
            self.doh_url, data=wire,
            headers={"Content-Type": "application/dns-message",
                     "Accept": "application/dns-message"})
        with urllib.request.urlopen(req, timeout=DOH_TIMEOUT) as resp:
            if resp.status != 200:
                raise OSError(f"HTTP {resp.status}")
            return resp.read()

    def _via_plain(self, wire: bytes) -> bytes:
        with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as s:
            s.settimeout(PLAIN_TIMEOUT)
            s.sendto(wire, (FALLBACK_DNS, 53))
            data, _ = s.recvfrom(65535)
            return data

    def resolve(self, wire: bytes) -> bytes | None:
        with self.lock:
            self.n_queries += 1
        if self.paused:
            return self._via_plain_quiet(wire)
        # degraded = serving plain DNS, but keep probing the shield so protection
        # comes back by itself once the server is reachable again
        try_shield = not self.degraded or (time.time() - self._last_shield_try) > RETRY_SHIELD_AFTER
        if try_shield:
            self._last_shield_try = time.time()
            try:
                answer = self._via_shield(wire)
                with self.lock:
                    self.fails = 0
                    if len(answer) >= 4 and (struct.unpack("!H", answer[2:4])[0] & 0xF) == 3:
                        self.n_blocked += 1
                return answer
            except Exception as e:
                with self.lock:
                    self.fails += 1
                    self.last_error = str(e)[:120]
        return self._via_plain_quiet(wire)

    def _via_plain_quiet(self, wire: bytes) -> bytes | None:
        try:
            with self.lock:
                self.n_fallback += 1
            return self._via_plain(wire)
        except Exception:
            return None                     # the client will retry on its own


# ------------------------------------------------------------------ local DNS listeners
class DnsServer:
    def __init__(self, forwarder: Forwarder):
        self.forwarder = forwarder
        self.running = False
        self._udp = None
        self._tcp = None

    def start(self):
        self.running = True
        self._udp = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self._udp.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        self._udp.bind(LISTEN_ADDR)
        self._udp.settimeout(1.0)
        self._tcp = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self._tcp.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        self._tcp.bind(LISTEN_ADDR)
        self._tcp.listen(16)
        self._tcp.settimeout(1.0)
        threading.Thread(target=self._serve_udp, daemon=True).start()
        threading.Thread(target=self._serve_tcp, daemon=True).start()

    def stop(self):
        self.running = False
        for s in (self._udp, self._tcp):
            try:
                s.close()
            except Exception:
                pass

    def _serve_udp(self):
        while self.running:
            try:
                data, addr = self._udp.recvfrom(4096)
            except socket.timeout:
                continue
            except OSError:
                return
            threading.Thread(target=self._answer_udp, args=(data, addr), daemon=True).start()

    def _answer_udp(self, data: bytes, addr):
        answer = self.forwarder.resolve(data)
        if answer:
            try:
                self._udp.sendto(answer, addr)
            except OSError:
                pass

    def _serve_tcp(self):
        while self.running:
            try:
                con, _ = self._tcp.accept()
            except socket.timeout:
                continue
            except OSError:
                return
            threading.Thread(target=self._answer_tcp, args=(con,), daemon=True).start()

    def _answer_tcp(self, con: socket.socket):
        try:
            con.settimeout(PLAIN_TIMEOUT)
            head = self._recv(con, 2)
            if not head:
                return
            (size,) = struct.unpack("!H", head)
            query = self._recv(con, size)
            if not query:
                return
            answer = self.forwarder.resolve(query)
            if answer:
                con.sendall(struct.pack("!H", len(answer)) + answer)
        except OSError:
            pass
        finally:
            try:
                con.close()
            except OSError:
                pass

    @staticmethod
    def _recv(con: socket.socket, n: int) -> bytes:
        out = b""
        while len(out) < n:
            chunk = con.recv(n - len(out))
            if not chunk:
                return b""
            out += chunk
        return out


# ------------------------------------------------------------------ protection on/off
class Shield:
    def __init__(self, doh_url: str):
        self.forwarder = Forwarder(doh_url)
        self.server = DnsServer(self.forwarder)
        self.enabled = False

    def enable(self):
        if self.enabled:
            return
        state = current_dns()
        if not state:
            raise RuntimeError("No active network adapter found.")
        # after a crash the DNS may already point at us - keep the ORIGINAL saved state
        if not all(s["servers"] == ["127.0.0.1"] for s in state):
            os.makedirs(CONFIG_DIR, exist_ok=True)
            with open(PREV_DNS_FILE, "w", encoding="utf-8") as f:
                json.dump(state, f)
        self.server.start()
        for s in state:
            set_dns(s["alias"], ["127.0.0.1"])
        flush_dns()
        self.enabled = True

    def disable(self):
        if not self.enabled:
            return
        self.server.stop()
        try:
            with open(PREV_DNS_FILE, "r", encoding="utf-8") as f:
                state = json.load(f)
        except (OSError, ValueError):
            state = current_dns()
        for s in state:
            try:
                set_dns(s["alias"], s["servers"] or None)
            except Exception:
                pass
        flush_dns()
        try:
            os.remove(PREV_DNS_FILE)
        except OSError:
            pass
        self.enabled = False

    def self_test(self) -> str:
        """Ask the shield for the always-blocked test domain."""
        labels = b"".join(bytes([len(p)]) + p.encode() for p in _TEST_DOMAIN.split(".")) + b"\x00"
        wire = struct.pack("!HHHHHH", 0x4242, 0x0100, 1, 0, 0, 0) + labels + struct.pack("!HH", 1, 1)
        try:
            answer = self.forwarder._via_shield(wire)
        except Exception as e:
            return f"Cannot reach the server: {e}"
        if len(answer) >= 4 and (struct.unpack("!H", answer[2:4])[0] & 0xF) == 3:
            return "OK - the shield answers and blocking works."
        return "The server answers, but the test domain was NOT blocked - unexpected."


def is_admin() -> bool:
    try:
        return bool(ctypes.windll.shell32.IsUserAnAdmin())
    except Exception:
        return False


def set_autostart(on: bool):
    import winreg
    key_path = r"Software\Microsoft\Windows\CurrentVersion\Run"
    with winreg.OpenKey(winreg.HKEY_CURRENT_USER, key_path, 0, winreg.KEY_SET_VALUE) as k:
        if on:
            exe = sys.executable
            winreg.SetValueEx(k, APP_NAME, 0, winreg.REG_SZ, f'"{exe}" --minimized')
        else:
            try:
                winreg.DeleteValue(k, APP_NAME)
            except FileNotFoundError:
                pass


# ------------------------------------------------------------------ the window
def run_gui(start_minimized: bool):
    import tkinter as tk
    from tkinter import messagebox

    cfg = load_config()
    shield: Shield | None = None

    root = tk.Tk()
    root.title(APP_NAME)
    root.geometry("430x360")
    root.resizable(False, False)

    status_var = tk.StringVar(value="Protection is OFF")
    stats_var = tk.StringVar(value="")
    detail_var = tk.StringVar(value="")

    tk.Label(root, text=APP_NAME, font=("Segoe UI", 15, "bold")).pack(pady=(16, 2))
    tk.Label(root, text="Blocks dangerous and unwanted domains for the whole PC.",
             font=("Segoe UI", 9)).pack()

    tk.Label(root, textvariable=status_var, font=("Segoe UI", 12, "bold")).pack(pady=(16, 0))
    tk.Label(root, textvariable=stats_var, font=("Segoe UI", 9)).pack()
    tk.Label(root, textvariable=detail_var, font=("Segoe UI", 8), fg="#666",
             wraplength=400).pack()

    btns = tk.Frame(root)
    btns.pack(pady=14)
    toggle_btn = tk.Button(btns, text="Turn ON", width=14, font=("Segoe UI", 10, "bold"))
    toggle_btn.grid(row=0, column=0, padx=5)
    test_btn = tk.Button(btns, text="Test connection", width=14)
    test_btn.grid(row=0, column=1, padx=5)

    autostart_var = tk.BooleanVar(value=bool(cfg.get("autostart")))
    tk.Checkbutton(root, text="Start with Windows", variable=autostart_var).pack()

    removed_var = tk.BooleanVar(value=False)

    def refresh():
        if removed_var.get():
            status_var.set("Device removed on the website")
            stats_var.set("")
            detail_var.set("Add the device again on the DNS shield page and paste the new address.")
        elif shield and shield.enabled:
            f = shield.forwarder
            if f.paused:
                status_var.set("PAUSED on the website")
                detail_var.set("Unpause it on the DNS shield page to resume protection.")
            elif f.degraded:
                status_var.set("PROTECTED – server unreachable (direct DNS)")
                detail_var.set(f.last_error)
            else:
                status_var.set("PROTECTED")
                detail_var.set("")
            stats_var.set(f"{f.n_queries} queries · {f.n_blocked} blocked")
        else:
            status_var.set("Protection is OFF")
            stats_var.set("")
            detail_var.set("")
        root.after(1000, refresh)

    def do_enable():
        nonlocal shield
        url = cfg.get("doh_url", "")
        if not valid_doh_url(url):
            messagebox.showwarning(APP_NAME, "Your AntiPhish address is missing.\n"
                                             "Open the DNS shield page on the website, add a device "
                                             "and paste its address here on first start.")
            ask_url()
            url = cfg.get("doh_url", "")
            if not valid_doh_url(url):
                return
        try:
            shield = shield or Shield(url)
            shield.enable()
            cfg["enabled"] = True
            save_config(cfg)
        except Exception as e:
            messagebox.showerror(APP_NAME, f"Could not switch the DNS settings:\n{e}\n\n"
                                           "Make sure to run me as Administrator.")
            shield = None

    def do_disable():
        nonlocal shield
        if shield:
            shield.disable()
        cfg["enabled"] = False
        save_config(cfg)

    def on_toggle():
        if shield and shield.enabled:
            do_disable()
            toggle_btn.config(text="Turn ON")
        else:
            do_enable()
            if shield and shield.enabled:
                toggle_btn.config(text="Turn OFF")

    def on_test():
        nonlocal shield
        url = cfg.get("doh_url", "")
        if not valid_doh_url(url):
            messagebox.showwarning(APP_NAME, "Set your AntiPhish address first.")
            return
        shield = shield or Shield(url)
        messagebox.showinfo(APP_NAME, shield.self_test())

    def ask_url():
        win = tk.Toplevel(root)
        win.title("Your AntiPhish address")
        win.geometry("420x150")
        tk.Label(win, text="Paste the DoH address of your device\n"
                           "(DNS shield page on the website → Add device):",
                 justify="left").pack(pady=(14, 4))
        entry = tk.Entry(win, width=52)
        entry.pack()
        entry.insert(0, cfg.get("doh_url", ""))

        def save():
            url = entry.get().strip()
            if not valid_doh_url(url):
                messagebox.showwarning(APP_NAME, "That does not look like an AntiPhish "
                                                 "DoH address (https://.../dns-query/apdns_...).",
                                       parent=win)
                return
            cfg["doh_url"] = url
            save_config(cfg)
            win.destroy()

        tk.Button(win, text="Save", command=save).pack(pady=8)
        win.transient(root)
        win.grab_set()

    def on_close():
        if shield and shield.enabled:
            if not messagebox.askyesno(APP_NAME, "Closing me switches the protection off and "
                                                 "restores your normal DNS.\nClose anyway?"):
                return
            do_disable()
        try:
            set_autostart(autostart_var.get())
        except Exception:
            pass
        root.destroy()

    toggle_btn.config(command=on_toggle)
    test_btn.config(command=on_test)
    root.protocol("WM_DELETE_WINDOW", on_close)

    if not cfg.get("doh_url"):
        root.after(200, ask_url)
    if cfg.get("enabled") and valid_doh_url(cfg.get("doh_url", "")):
        root.after(300, lambda: (do_enable(), toggle_btn.config(text="Turn OFF")
                                 if shield and shield.enabled else None))
    if start_minimized:
        root.iconify()

    def on_device_removed():
        removed_var.set(True)
        if shield and shield.enabled:
            do_disable()
            toggle_btn.config(text="Turn ON")
        messagebox.showinfo(APP_NAME, "This device was removed on the website's DNS shield page.\n"
                                      "Protection was switched off and your DNS restored.")

    def reporter():
        """Every 25 s: tell the website our on/off, learn its pause state."""
        while True:
            time.sleep(25)
            url = cfg.get("doh_url", "")
            if not valid_doh_url(url) or removed_var.get():
                continue
            try:
                state = report_state(url, bool(shield and shield.enabled))
                if shield:
                    shield.forwarder.paused = not state.get("active", True)
            except DeviceGone:
                root.after(0, on_device_removed)
                return
            except Exception:
                pass                            # offline - fail-open handles it

    threading.Thread(target=reporter, daemon=True).start()
    refresh()
    root.mainloop()


def main():
    if sys.platform != "win32":
        print("This agent is for Windows. (On other systems use any DoH client "
              "with your address.)")
        sys.exit(1)
    if not is_admin():
        ctypes.windll.shell32.ShellExecuteW(None, "runas", sys.executable,
                                            " ".join(f'"{a}"' for a in sys.argv), None, 1)
        sys.exit(0)                     # re-launched elevated; this copy exits
    run_gui("--minimized" in sys.argv)


if __name__ == "__main__":
    main()
