"""Browser walk-through of "Connect email" against a real IMAP server (GreenMail).
usage: python3 e2e_browser.py BASE_URL OUTDIR ADMIN_EMAIL ADMIN_PW IMAP_HOST [smtp_port]
Needs playwright + chromium. Mail is delivered by deliver.py, run with the interpreter in
$APP_PYTHON (one that can import the project; default: this one). Exits 1 on the first failed check."""
import os, subprocess, sys, time
from playwright.sync_api import sync_playwright

base, out, email, pw, imap_host = sys.argv[1:6]
smtp_port = sys.argv[6] if len(sys.argv) > 6 else "3025"
# GreenMail creates a mailbox on first delivery; its password is the address itself
BOX = f"box{int(time.time())}@test.local"
BOXPW = BOX
checks = []


def check(name, ok, extra=""):
    checks.append((name, bool(ok)))
    print(("PASS " if ok else "FAIL ") + name + (f"  [{extra}]" if extra else ""), flush=True)
    if not ok:
        raise SystemExit(1)


def deliver(n, off):
    subprocess.run([os.getenv("APP_PYTHON", sys.executable), os.path.join(os.path.dirname(os.path.abspath(__file__)), "deliver.py"),
                    BOX, str(n), str(off), smtp_port],
                   check=True, capture_output=True)


def wait_msgs(page, at_least, seconds=90):
    end = time.time() + seconds
    n = 0
    while time.time() < end:
        n = page.locator("a.msg").count()
        if n >= at_least:
            return n
        page.wait_for_timeout(1000)
    return n


with sync_playwright() as p:
    b = p.chromium.launch()
    ctx = b.new_context(viewport={"width": 1280, "height": 900}, ignore_https_errors=True)
    page = ctx.new_page()
    problems = []
    page.on("console", lambda m: problems.append(m.text) if m.type == "error" else None)
    page.on("pageerror", lambda e: problems.append(str(e)))

    deliver(6, 20)                                   # six messages are in the mailbox before it is connected
    page.goto(base + "/login")
    page.fill("input[name=email]", email); page.fill("input[name=password]", pw); page.click("button.primary")
    page.wait_for_url(base + "/")
    check("first visit shows the connect-your-mail screen", page.locator("text=Connect your email").count() == 1)
    page.screenshot(path=f"{out}/1_onboarding.png")

    page.click("a.tile:has-text('Drugi mail')")
    page.wait_for_url("**/mailboxes/connect/imap")
    # wrong password first
    page.fill("input[name=email]", BOX); page.fill("input[name=secret]", "not-the-password"); page.fill("input[name=host]", imap_host)
    page.click("button.wide"); page.wait_for_load_state("domcontentloaded")
    check("wrong password: explained, nothing connected", page.locator(".flash.error:has-text('refused the sign-in')").count() == 1
          and page.input_value("input[name=secret]") == "" and page.input_value("input[name=email]") == BOX)
    page.screenshot(path=f"{out}/2_wrong_password.png")
    # a host that is not a mail server name
    page.fill("input[name=secret]", BOXPW); page.fill("input[name=host]", "localhost")
    page.click("button.wide"); page.wait_for_load_state("domcontentloaded")
    check("'localhost' as mail server is refused", page.locator(".flash.error:has-text('not allowed')").count() == 1)
    # now the real thing
    page.fill("input[name=secret]", BOXPW); page.fill("input[name=host]", imap_host)
    page.click("button.wide"); page.wait_for_url(base + "/")
    check("connected: confirmation and mailbox card", page.locator(".flash.ok:has-text('is connected')").count() == 1
          and page.locator(f".box:has-text('{BOX}')").count() == 1)
    page.screenshot(path=f"{out}/3_connected.png")
    n = wait_msgs(page, 6)
    check("first check: the 6 existing messages appear without touching the page", n == 6, f"{n} rows")
    check("mailbox card says active", page.locator(".box .dot.ok").count() == 1 and page.locator("text=Aktivno").count() >= 1)
    page.screenshot(path=f"{out}/4_first_results.png", full_page=True)

    deliver(3, 40)                                   # new mail arrives
    page.click(".box button:has-text('Provjeri sada')")
    n = wait_msgs(page, 9)
    check("new mail: 3 more rows after 'Provjeri sada'", n == 9, f"{n} rows")
    danger = page.locator("a.msg.crit, a.msg.high").count()
    check("some of them are rated dangerous", danger >= 1, f"{danger} dangerous")
    page.goto(base + "/?f=danger"); page.locator("a.msg").first.click(); page.wait_for_load_state("domcontentloaded")
    check("result page opens from the list", page.locator(".verdict").count() == 1 and page.locator("dt:has-text('Primljeno')").count() == 1)
    page.screenshot(path=f"{out}/5_result.png", full_page=True)

    deliver(1, 50)                                   # and one more, found by the periodic check alone
    page.goto(base + "/")
    n = wait_msgs(page, 10, 90)
    check("periodic check finds new mail on its own", n == 10, f"{n} rows")

    page.goto(base + "/mailboxes")
    page.click("summary:has-text('Odvoji')"); page.check("input[name=delete_scans]")
    page.screenshot(path=f"{out}/6_disconnect.png")
    page.click("button.danger"); page.wait_for_load_state("domcontentloaded")
    check("disconnect: confirmation, mailbox gone", page.locator(".flash.ok:has-text('je odvojeno')").count() == 1
          and page.locator(f".box-row:has-text('{BOX}')").count() == 0)
    page.goto(base + "/")
    check("results deleted with it: back to the connect-your-mail screen",
          page.locator("a.msg").count() == 0 and page.locator("text=Connect your email").count() == 1)
    # the two refused form posts above are answered with HTTP 400 on purpose; the browser lists those too
    real = [x for x in problems if "status of 400" not in x]
    check("no browser console errors (CSP, scripts)", not real, "; ".join(real[:3]))
    b.close()
print(f"\n{len(checks)} checks passed")
