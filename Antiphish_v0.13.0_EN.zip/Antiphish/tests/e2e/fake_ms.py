"""A stand-in for Microsoft sign-in + Microsoft Graph, speaking real HTTP, for walking
through "Connect Outlook" with a real browser. It follows Microsoft's published protocol
(v2.0 authorize / token endpoints, Graph /me, list inbox messages, MIME $value) - it is
NOT Microsoft, so it proves our side of the conversation only.

    uvicorn fake_ms:app --host 0.0.0.0 --port 9100

Test hooks:  POST /_test/add?n=..&minute=..&phish=0|1   POST /_test/revoke   GET /_test/log
"""
import base64
import hashlib
import secrets
import time
from urllib.parse import urlencode

from fastapi import FastAPI, Form, Request
from fastapi.responses import HTMLResponse, JSONResponse, PlainTextResponse, RedirectResponse

app = FastAPI()
CLIENT_ID, CLIENT_SECRET = "11111111-2222-3333-4444-555555555555", "fake-client-secret-value"
ADDRESS = "amra.test@outlook.com"
S = {"codes": {}, "refresh": set(), "access": {}, "inbox": [], "log": [], "revoked": False}


def _mail(n: int, phish: bool) -> bytes:
    if phish:
        return (f"From: Microsoft account team <no-reply@msft-account-protection.com>\r\nTo: {ADDRESS}\r\n"
                f"Subject: Unusual sign-in activity #{n}\r\n"
                "Authentication-Results: mx; spf=pass; dkim=pass; dmarc=pass\r\n"
                "MIME-Version: 1.0\r\nContent-Type: text/html\r\n\r\n"
                "<p>We detected something unusual. Verify your password now or your account will be suspended:</p>"
                '<p><a href="http://login-microsoftonline.account-verify.top/login">https://account.microsoft.com/security</a></p>\r\n').encode()
    return (f"From: Lejla Begic <lejla.begic@firma-primjer.ba>\r\nTo: {ADDRESS}\r\nSubject: Sastanak #{n}\r\n"
            "MIME-Version: 1.0\r\nContent-Type: text/plain; charset=utf-8\r\n\r\n"
            "Zdravo, mozemo li pomjeriti sastanak na srijedu u 10h? Pozdrav, Lejla\r\n").encode()


def _add(n: int, minute: int, phish: bool):
    S["inbox"].append({"id": f"AAMkAGI2-{n:04d}=", "receivedDateTime": f"2026-11-23T10:{minute:02d}:00Z",
                       "raw": _mail(n, phish)})


for i in range(1, 6):
    _add(i, i, phish=(i in (2, 5)))


@app.get("/{tenant}/oauth2/v2.0/authorize")
def authorize(request: Request, tenant: str, client_id: str = "", response_type: str = "", redirect_uri: str = "",
              scope: str = "", state: str = "", code_challenge: str = "", code_challenge_method: str = "",
              response_mode: str = "query", prompt: str = ""):
    S["log"].append({"authorize": dict(request.query_params)})
    problems = []
    if client_id != CLIENT_ID:
        problems.append("AADSTS700016: application not found")
    if response_type != "code" or code_challenge_method != "S256" or len(code_challenge) != 43:
        problems.append("invalid_request")
    if not {"offline_access", "Mail.Read"} <= set(scope.split()):
        problems.append("scope")
    if not redirect_uri.endswith("/mailboxes/microsoft/callback"):
        problems.append("AADSTS50011: redirect URI mismatch")
    if problems:
        return HTMLResponse("<h1>Sign-in error</h1><p>" + "; ".join(problems) + "</p>", status_code=400)
    code = secrets.token_urlsafe(24)
    S["codes"][code] = {"challenge": code_challenge, "redirect_uri": redirect_uri, "at": time.time()}
    back = redirect_uri + "?" + urlencode({"code": code, "state": state})
    # the "user" signs in and consents by clicking the one link on this page
    return HTMLResponse(f'<h1>Fake Microsoft sign-in</h1><p>AntiPhish wants to: Read your mail</p>'
                        f'<p><a id="accept" href="{back}">Accept</a> '
                        f'<a id="deny" href="{redirect_uri}?{urlencode({"error": "access_denied", "error_description": "user cancelled", "state": state})}">Cancel</a></p>')


def _error(status, error, desc):
    return JSONResponse({"error": error, "error_description": desc, "error_codes": [0]}, status_code=status)


@app.post("/{tenant}/oauth2/v2.0/token")
def token(tenant: str, grant_type: str = Form(""), client_id: str = Form(""), client_secret: str = Form(""),
          code: str = Form(""), redirect_uri: str = Form(""), code_verifier: str = Form(""),
          refresh_token: str = Form(""), scope: str = Form("")):
    S["log"].append({"token": grant_type})
    if client_id != CLIENT_ID or client_secret != CLIENT_SECRET:
        return _error(401, "invalid_client", "AADSTS7000215: Invalid client secret provided.")
    if grant_type == "authorization_code":
        c = S["codes"].pop(code, None)
        calc = base64.urlsafe_b64encode(hashlib.sha256(code_verifier.encode()).digest()).decode().rstrip("=")
        if not c or calc != c["challenge"] or redirect_uri != c["redirect_uri"] or time.time() - c["at"] > 60:
            return _error(400, "invalid_grant", "AADSTS70000: The provided authorization code is invalid or expired.")
    elif grant_type == "refresh_token":
        if S["revoked"] or refresh_token not in S["refresh"]:
            return _error(400, "invalid_grant", "AADSTS70008: The refresh token has expired or was revoked.")
    else:
        return _error(400, "unsupported_grant_type", "AADSTS70003")
    at, rt = "at-" + secrets.token_urlsafe(16), "rt-" + secrets.token_urlsafe(24)
    S["access"][at] = time.time() + 3600
    S["refresh"].add(rt)
    return {"token_type": "Bearer", "expires_in": 3599, "scope": "Mail.Read User.Read", "access_token": at,
            "refresh_token": rt}


def _auth(request: Request):
    tok = request.headers.get("authorization", "")[7:]
    return (not S["revoked"]) and S["access"].get(tok, 0) > time.time()


def _deny():
    return JSONResponse({"error": {"code": "InvalidAuthenticationToken", "message": "Access token has expired or is not yet valid."}},
                        status_code=401)


@app.get("/v1.0/me")
def me(request: Request):
    S["log"].append({"graph": "/me"})
    if not _auth(request):
        return _deny()
    return {"mail": ADDRESS, "userPrincipalName": ADDRESS}


@app.get("/v1.0/me/mailFolders/inbox/messages")
def messages(request: Request):
    q = request.query_params
    S["log"].append({"graph": "list", "query": dict(q), "prefer": request.headers.get("prefer")})
    if not _auth(request):
        return _deny()
    items = sorted(S["inbox"], key=lambda m: m["receivedDateTime"])
    flt = q.get("$filter", "")
    if flt:
        if not flt.startswith("receivedDateTime ge "):
            return JSONResponse({"error": {"code": "BadRequest", "message": "unsupported filter"}}, status_code=400)
        items = [m for m in items if m["receivedDateTime"] >= flt.split(" ge ")[1]]
    if q.get("$orderby", "").endswith("desc"):
        items = items[::-1]
    items = items[:int(q.get("$top", "10"))]
    return {"@odata.context": "x", "value": [{"id": m["id"], "receivedDateTime": m["receivedDateTime"]} for m in items]}


@app.get("/v1.0/me/messages/{message_id}/$value")
def mime(request: Request, message_id: str):
    S["log"].append({"graph": "mime", "id": message_id})
    if not _auth(request):
        return _deny()
    hit = [m for m in S["inbox"] if m["id"] == message_id]
    if not hit:
        return JSONResponse({"error": {"code": "ErrorItemNotFound"}}, status_code=404)
    return PlainTextResponse(hit[0]["raw"], media_type="text/plain")


@app.post("/_test/add")
def test_add(n: int, minute: int, phish: int = 0):
    _add(n, minute, bool(phish))
    return {"inbox": len(S["inbox"])}


@app.post("/_test/revoke")
def test_revoke():
    S["revoked"] = True
    return {"revoked": True}


@app.get("/_test/log")
def test_log():
    return S["log"]
