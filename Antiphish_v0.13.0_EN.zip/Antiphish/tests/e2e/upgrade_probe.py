"""before / watch / after an upgrade of a running site.  usage: upgrade_probe.py before|watch|after"""
import pickle, re, sys, time, requests, urllib3
urllib3.disable_warnings()
BASE, JAR = "https://antiphish.localhost", "/tmp/upgrade_cookies.pkl"
PHISH = (b"From: PayPal Security <security@paypa1-secure.tk>\r\nTo: you@example.com\r\nSubject: Urgent: verify your account (before upgrade)\r\n"
         b"Authentication-Results: mx; spf=fail; dkim=fail; dmarc=fail\r\nMIME-Version: 1.0\r\nContent-Type: text/plain\r\n\r\n"
         b"Your account will be suspended. Verify your password now: http://paypa1-secure.tk/login\r\n")
def sess():
    s = requests.Session(); s.trust_env = False; s.verify = False; return s
def csrf(s, path="/login"):
    return re.search(r'name="csrf" value="([^"]+)"', s.get(BASE + path, timeout=20).text).group(1)
mode = sys.argv[1]
if mode == "before":
    s = sess()
    r = s.post(BASE + "/login", data={"email": "upg-user@example.com", "password": "upgrade-user-pass-1", "csrf": csrf(s)}, allow_redirects=False, timeout=20)
    assert r.status_code == 303, r.status_code
    r = s.post(BASE + "/scan", data={"csrf": csrf(s, "/"), "mode": "quick"}, files={"file": ("m.eml", PHISH, "message/rfc822")}, allow_redirects=False, timeout=60)
    assert r.headers["location"].startswith("/r/"), r.headers
    page = s.get(BASE + r.headers["location"], timeout=20).text
    score = re.search(r'class="num">(\d+)<', page).group(1)
    s.post(BASE + r.headers["location"] + "/feedback", data={"csrf": csrf(s, "/"), "label": "1", "comment": "prije nadogradnje"}, timeout=20)
    pickle.dump({"cookies": s.cookies, "result": r.headers["location"], "score": score}, open(JAR, "wb"))
    print("before: logged in, scanned, score", score, "result", r.headers["location"], "| history has it:", "before upgrade" in s.get(BASE + "/history", timeout=20).text)
elif mode == "watch":
    s = sess(); t0 = time.time(); bad = []; n = 0; last = None; ver = set()
    while time.time() - t0 < float(sys.argv[2]):
        try:
            r = s.get(BASE + "/login", timeout=5); ok = r.status_code == 200
            ver.add("new" if "app.js" in r.text else "old")
        except Exception as e:
            ok = False
        n += 1
        if not ok: bad.append(round(time.time() - t0, 1))
        time.sleep(1)
    gap = (max(bad) - min(bad) + 1) if bad else 0
    print(f"watch: {n} requests in {time.time()-t0:.0f}s, failed {len(bad)} (between {min(bad) if bad else '-'}s and {max(bad) if bad else '-'}s => ~{gap:.0f}s), pages seen: {sorted(ver)}")
else:
    st = pickle.load(open(JAR, "rb")); s = sess(); s.cookies = st["cookies"]
    r = s.get(BASE + "/", allow_redirects=False, timeout=20)
    print("after: still logged in:", r.status_code == 200, "| new overview:", "Dashboard" in r.text, "| old result listed:", "before upgrade" in r.text,
          "| feedback tag:", "reported: phishing" in r.text)
    page = s.get(BASE + st["result"], timeout=20).text
    m = re.search(r'class="ring-num"><b>(\d+)<', page)
    print("after: old result page opens:", bool(m), "| same score:", m and m.group(1) == st["score"], "| credits shown:", re.search(r"<b>(\d+)</b> credits", page).group(1))
    r = s.post(BASE + "/scan", data={"csrf": csrf(s, "/"), "raw": PHISH.decode().replace("before", "after")}, allow_redirects=False, timeout=60)
    print("after: a new manual scan works:", r.headers.get("location", "").startswith("/r/"))
