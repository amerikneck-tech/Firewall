"""More situations with a real IMAP server (GreenMail), through HTTPS: restart in the middle of the first
check, only the newest N, nothing marked as read, an oversized message, the mail server not answering."""
import imaplib, os, re, smtplib, subprocess, sys, time, requests
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "..")))
from antiphish.scenarios import all_scenarios
B = os.getenv("BASE_URL", "https://antiphish.localhost"); CA = os.getenv("CADDY_CA", "/tmp/caddy-root.crt")
# how to reach "docker compose" of the stack under test, e.g. "cd /opt/antiphish && docker compose "
DC = os.getenv("COMPOSE", "docker compose ")
BOX = f"more{int(time.time())}@test.local"
n_checks = 0
def check(name, ok, extra=""):
    global n_checks; n_checks += 1
    print(("PASS " if ok else "FAIL ") + name + (f"  [{extra}]" if extra else ""), flush=True)
    if not ok: raise SystemExit(1)
def sh(cmd): return subprocess.run(cmd, shell=True, capture_output=True, text=True).stdout
def csrf(s, path="/"): return re.search(r'name="csrf"\s+value="([^"]+)"', s.get(B + path, timeout=20).text).group(1)
def deliver(raws):
    with smtplib.SMTP("127.0.0.1", 3025, timeout=60) as s:
        for raw in raws: s.sendmail("bounce@sender.example", [BOX], raw)
def box_line():
    out = sh(DC + "exec -T -u app web python -m webapp.manage mailboxes")
    return next((l for l in out.splitlines() if BOX in l), "")
def n_scans():
    m = re.search(r"messages=(\d+)", box_line()); return int(m.group(1)) if m else -1
def wait_scans(n, seconds=120):
    end = time.time() + seconds
    while time.time() < end:
        if n_scans() >= n: return True
        time.sleep(2)
    return False
def flags():
    m = imaplib.IMAP4("127.0.0.1", 3143); m.login(BOX, BOX); typ, d = m.select("INBOX", readonly=True); n = int(d[0])
    typ, fl = m.fetch("1:*", "(FLAGS)"); m.logout()
    return n, sum(1 for f in fl if b"\\Seen" in f), sum(1 for f in fl if b"\\Deleted" in f)

scs = all_scenarios()
deliver([scs[i % len(scs)].raw for i in range(30)])
s = requests.Session(); s.trust_env = False; s.verify = CA
r = s.post(B + "/login", data={"email": "admin@example.com", "password": "Admin-Lozinka-2026!", "csrf": csrf(s, "/login")}, timeout=20)
r = s.post(B + "/mailboxes/connect/imap", data={"csrf": csrf(s), "email": BOX, "secret": BOX, "host": "mail.test.local"}, timeout=60, allow_redirects=False)
check("mailbox with 30 messages connected", r.status_code == 303, r.status_code)
time.sleep(1.5)
sh(DC + "restart web")                                   # the server is restarted while the first check runs
t0 = time.time()
ok = wait_scans(20, 150)
check("first check completes after the restart", ok, f"{n_scans()} checked, {time.time() - t0:.0f}s after restart")
time.sleep(25)
out = sh(DC + "exec -T -u app web python -c \"import sqlite3; c=sqlite3.connect('/app/data/antiphish.db'); r=c.execute('select count(*), count(distinct msg_key), min(cast(substr(msg_key, instr(msg_key, \\\":\\\")+1) as int)), max(cast(substr(msg_key, instr(msg_key, \\\":\\\")+1) as int)) from scans where mailbox_id is not null and mailbox_id=(select max(id) from mailboxes)').fetchone(); print(*r)\"").split()
check("exactly the newest 20 of 30, none twice", out == ["20", "20", "11", "30"], " ".join(out))
n, seen, deleted = flags()
check("nothing in the mailbox was changed: 30 messages, none marked read or deleted", (n, seen, deleted) == (30, 0, 0), f"{n} messages, {seen} read, {deleted} deleted")

big = b"From: Veliki <veliki@example.com>\r\nTo: x@test.local\r\nSubject: 16 MB\r\nMIME-Version: 1.0\r\nContent-Type: text/plain\r\n\r\n" + (b"A" * 76 + b"\r\n") * (16 * 1024 * 1024 // 78)
deliver([big, scs[3].raw])
s.post(B + f"/mailboxes/{re.search(r'/mailboxes/(\d+)/scan', s.get(B + '/', timeout=20).text).group(1)}/scan", data={"csrf": csrf(s)}, timeout=20)
ok = wait_scans(21, 90); time.sleep(6)
check("16 MB message is skipped, the one after it is checked", ok and n_scans() == 21, f"{n_scans()} checked")
log = sh(DC + "logs --tail 200 web")
check("...and the log says why", "larger than 15 MB - not checked" in log)

sh("docker pause gm")                                    # the mail server stops answering
time.sleep(58)
line = box_line()
home = s.get(B + "/", timeout=20).text
check("mail server silent for a minute: no alarm on the page yet", "Aktivno" in home and "Privremeni problem" not in home, line[60:140])
sh("docker unpause gm"); time.sleep(2)
deliver([scs[5].raw])
ok = wait_scans(22, 240)
check("mail server back: checking continues by itself", ok, f"{n_scans()} checked; {box_line()[60:120]}")
n, seen, deleted = flags()
check("still nothing marked as read", seen == 0 and deleted == 0 and n == 33, f"{n} messages, {seen} read")
print(f"\n{n_checks} checks passed")
