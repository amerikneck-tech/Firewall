"""Deliver scenario mails into a GreenMail user's INBOX (as an MX would).
usage: deliver.py rcpt count [offset] [smtp_port]"""
import os, smtplib, sys, random
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "..")))
from antiphish.scenarios import all_scenarios
rcpt, n = sys.argv[1], int(sys.argv[2]); off = int(sys.argv[3]) if len(sys.argv) > 3 else 0
port = int(sys.argv[4]) if len(sys.argv) > 4 else 3025
scs = all_scenarios(); random.seed(11); random.shuffle(scs)
with smtplib.SMTP("127.0.0.1", port, timeout=20) as s:
    for sc in scs[off:off + n]:
        s.sendmail("bounce@sender.example", [rcpt], sc.raw); print("delivered:", sc.kind, sc.name)
