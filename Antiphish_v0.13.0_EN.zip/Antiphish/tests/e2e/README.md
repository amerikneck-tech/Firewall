# End-to-end checks (not run by `pytest`)

These scripts drive a **running** AntiPhish through HTTPS the way a user does. They were
used to check v0.11 on the image built from the release zip; they are kept so the next
change can be checked the same way. Nothing here is copied into the Docker image.

The rig (all on one machine, Docker):

| Part | What | Notes |
|---|---|---|
| the stack | `docker compose up -d --build`, `DOMAIN=antiphish.localhost` | Caddy issues a certificate from its own CA: `docker compose cp caddy:/data/caddy/pki/authorities/local/root.crt /tmp/caddy-root.crt`; add `127.0.0.1 antiphish.localhost` to `/etc/hosts` |
| a real IMAP/SMTP server | `greenmail/standalone:2.1.3` on the compose network with the alias `mail.test.local`, IMAPS on 993 with a certificate from a test CA; plain SMTP 3025 and IMAP 3143 published to the host | the web container trusts the test CA through `SSL_CERT_FILE=/app/data/test-ca.crt` and needs `MAILBOX_ALLOW_PRIVATE_HOSTS=1` (the server has a private address). GreenMail creates a mailbox on first delivery; its password is the address |
| a stand-in for Microsoft | `fake_ms.py` (uvicorn, port 9100) on the compose network as `fakems.test.local`, published to the host | `.env`: `MS_CLIENT_ID=11111111-2222-3333-4444-555555555555`, `MS_CLIENT_SECRET=fake-client-secret-value`, `MS_LOGIN_BASE=http://fakems.test.local:9100`, `MS_GRAPH_BASE=http://fakems.test.local:9100/v1.0`. It follows Microsoft's documented protocol; it is not Microsoft |

| Script | Checks |
|---|---|
| `e2e_https.py` | 51 checks with `requests`: login, CSRF, manual scans, attachments, credits, feedback, admin, access control, the new pages, refused mail-server names. Needs a fresh database with `admin@example.com` / `drug@example.com` (passwords in the file) |
| `e2e_browser.py` | Chromium (playwright): connect a mailbox, wrong password, first check appears by itself, new mail, periodic check, result page, disconnect, no CSP / script errors |
| `e2e_ms_browser.py` | Chromium: Microsoft sign-in redirect and return, refused consent, results, new mail, revoked access, disconnect |
| `e2e_imap_more.py` | restart during the first check, only the newest N, nothing marked as read, a 16 MB message, a mail server that stops answering |
| `keepalive_ab.py` | pages must not hang after a mail with an attachment was scanned (the v0.10.1 bug: 7 of 12 page loads hung; v0.11: none) |
| `upgrade_probe.py` | `before` / `watch` / `after` an upgrade of a running site: session, old results and credits survive |
| `deliver.py` | puts scenario mails into a GreenMail mailbox (as an MX would) |
