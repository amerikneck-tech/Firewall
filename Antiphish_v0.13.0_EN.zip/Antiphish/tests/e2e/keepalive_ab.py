"""Does a page hang after a mail with an attachment was scanned? (through Caddy, HTTPS)
The attachment scan starts a worker process; before v0.11 that worker kept copies of the
web server's open connections, so connections the server closed later stayed "open" for Caddy."""
import io, os, re, sys, threading, time, zipfile, email.message, requests
B = os.getenv("BASE_URL", "https://antiphish.localhost"); CA = os.getenv("CADDY_CA", "/tmp/caddy-root.crt")
def S():
    s = requests.Session(); s.trust_env = False; s.verify = CA; return s
def csrf(t): return re.search(r'name="csrf"\s+value="([^"]+)"', t).group(1)
u = S(); r = u.get(B + "/login", timeout=10)
u.post(B + "/login", data={"email": "admin@example.com", "password": "Admin-Lozinka-2026!", "csrf": csrf(r.text)}, timeout=20)
buf = io.BytesIO(); z = zipfile.ZipFile(buf, "w"); z.writestr("faktura.pdf.exe", b"MZ" + b"\x00" * 200); z.close()
m = email.message.EmailMessage(); m["From"] = "Racuni <racuni@firma-dobavljac.com>"; m["To"] = "a@example.com"; m["Subject"] = "Faktura"
m.set_content("U prilogu je faktura."); m.add_attachment(buf.getvalue(), maintype="application", subtype="zip", filename="faktura.zip")
# several connections Caddy -> web are open and busy while the worker process is started
stop = False
def chatter():
    s = S()
    while not stop:
        try: s.get(B + "/login", timeout=10)
        except Exception: pass
th = [threading.Thread(target=chatter) for _ in range(6)]; [t.start() for t in th]
time.sleep(1.0)
pg = u.get(B + "/check", timeout=20)
r = u.post(B + "/scan", data={"csrf": csrf(pg.text), "mode": "quick"}, files={"file": ("a.eml", m.as_bytes(), "message/rfc822")}, timeout=60)
print("scan with attachment:", r.status_code, "score", (re.search(r'ring-num"><b>(\d+)<', r.text) or re.search(r'class="num">(\d+)<', r.text)).group(1))
time.sleep(1.0); stop = True; [t.join() for t in th]
time.sleep(20)                    # well past the 5 s after which the web server closes an idle connection
slow = []
for i in range(12):
    t = time.time()
    try:
        code = S().get(B + "/login", timeout=8).status_code
    except Exception as e:
        code = type(e).__name__
    dt = time.time() - t
    if dt > 1 or code != 200: slow.append((i, code, round(dt, 1)))
    time.sleep(0.3)
print(f"12 page loads afterwards: {12 - len(slow)} normal, {len(slow)} hung (no answer within 8 s)", slow[:8])
