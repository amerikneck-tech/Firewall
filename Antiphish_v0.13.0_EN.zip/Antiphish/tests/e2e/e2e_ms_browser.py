"""Browser walk-through of "Connect Outlook" against the stand-in Microsoft server (fake_ms.py).
usage: python3 e2e_ms_browser.py BASE_URL OUTDIR ADMIN_EMAIL ADMIN_PW FAKE_MS_URL"""
import json, sys, time, urllib.request
from playwright.sync_api import sync_playwright

base, out, email, pw, fake = sys.argv[1:6]
BOX = "amra.test@outlook.com"
n_checks = 0


def check(name, ok, extra=""):
    global n_checks
    n_checks += 1
    print(("PASS " if ok else "FAIL ") + name + (f"  [{extra}]" if extra else ""), flush=True)
    if not ok:
        raise SystemExit(1)


def fake_call(path, method="POST"):
    req = urllib.request.Request(fake + path, method=method, data=b"" if method == "POST" else None)
    with urllib.request.build_opener(urllib.request.ProxyHandler({})).open(req, timeout=10) as r:
        return json.loads(r.read())


def wait_for(page, fn, seconds=60):
    end = time.time() + seconds
    while time.time() < end:
        if fn():
            return True
        page.wait_for_timeout(1000)
    return fn()


with sync_playwright() as p:
    b = p.chromium.launch()
    ctx = b.new_context(viewport={"width": 1280, "height": 900}, ignore_https_errors=True)
    page = ctx.new_page()
    problems = []
    page.on("console", lambda m: problems.append(m.text) if m.type == "error" else None)
    page.goto(base + "/login")
    page.fill("input[name=email]", email); page.fill("input[name=password]", pw); page.click("button.primary")
    page.wait_for_url(base + "/")

    page.goto(base + "/mailboxes/connect/microsoft")
    check("Outlook page offers Microsoft sign-in and has no password field",
          page.locator("a:has-text('Nastavi na Microsoft prijavu')").count() == 1 and page.locator("input[type=password]").count() == 0)
    page.screenshot(path=f"{out}/ms1_connect.png")
    # the user changes their mind on Microsoft's page
    page.click("a:has-text('Nastavi na Microsoft prijavu')"); page.wait_for_url(fake + "/**")
    check("browser is sent to the sign-in server, with PKCE and without the client secret",
          "code_challenge_method=S256" in page.url and "client_secret" not in page.url and "fake-client-secret" not in page.url)
    page.click("#deny"); page.wait_for_url(base + "/mailboxes")
    check("consent refused: said so, nothing connected", page.locator(".flash.error:has-text('not approved')").count() == 1
          and page.locator(f"text={BOX}").count() == 0)
    # and now for real
    page.goto(base + "/mailboxes/connect/microsoft")
    page.click("a:has-text('Nastavi na Microsoft prijavu')"); page.wait_for_url(fake + "/**")
    page.screenshot(path=f"{out}/ms2_fake_signin.png")
    page.click("#accept"); page.wait_for_url(base + "/")
    check("back from sign-in: the session survived the cross-site redirect and the mailbox is connected",
          page.locator(".flash.ok:has-text('is connected')").count() == 1 and page.locator(f".box:has-text('{BOX}')").count() == 1)
    ok = wait_for(page, lambda: page.locator("a.msg").count() >= 5)
    n = page.locator("a.msg").count()
    check("first check: the 5 messages of the inbox appear", ok and n == 5, f"{n} rows")
    danger = page.locator("a.msg.crit, a.msg.high").count()
    check("the two look-alike sign-in warnings are rated dangerous, the three notes are not", danger == 2, f"{danger} dangerous")
    page.screenshot(path=f"{out}/ms3_results.png", full_page=True)

    fake_call("/_test/add?n=6&minute=30&phish=1")
    page.click(".box button:has-text('Provjeri sada')")
    ok = wait_for(page, lambda: page.locator("a.msg").count() >= 6)
    check("new mail is found, nothing is listed twice", ok and page.locator("a.msg").count() == 6, f"{page.locator('a.msg').count()} rows")

    log = fake_call("/_test/log", "GET")
    graph = [e for e in log if "graph" in e]
    tokens = [e["token"] for e in log if "token" in e]
    check("token requests: one code redemption, no refresh needed yet", tokens == ["authorization_code"], str(tokens))
    lists = [e for e in graph if e["graph"] == "list"]
    check("every list request asks for immutable ids", lists and all(e["prefer"] == 'IdType="ImmutableId"' for e in lists))
    mimes = [e["id"] for e in graph if e["graph"] == "mime"]
    check("each message was downloaded exactly once", len(mimes) == 6 and len(set(mimes)) == 6, f"{len(mimes)} downloads")

    fake_call("/_test/revoke")                    # the user removes the app's access at Microsoft
    page.click(".box button:has-text('Provjeri sada')")
    def reloaded():        # the page also reloads itself when the check ends - do not trip over that
        try:
            page.goto(base + "/", wait_until="domcontentloaded")
        except Exception:
            page.wait_for_load_state("domcontentloaded")
        return page.locator("text=Reconnect needed").count() >= 1
    ok = wait_for(page, reloaded, 40)
    check("access revoked at Microsoft: the card asks to connect again", ok)
    check("...and offers the way back", page.locator("a:has-text('Reconnect')").count() == 1)
    page.screenshot(path=f"{out}/ms4_reauth.png")
    page.goto(base + "/mailboxes")
    page.click("summary:has-text('Odvoji')"); page.check("input[name=delete_scans]"); page.click("button.danger")
    page.wait_for_load_state("domcontentloaded")
    check("disconnect works for a Microsoft mailbox too", page.locator(".flash.ok:has-text('je odvojeno')").count() == 1)
    check("no browser console errors", not problems, "; ".join(problems[:3]))
    b.close()
print(f"\n{n_checks} checks passed")
