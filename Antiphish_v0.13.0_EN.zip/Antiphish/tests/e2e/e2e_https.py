"""End-to-end check of the deployed stack THROUGH Caddy/HTTPS (test rig: Caddy internal CA).
Needs a FRESH database with the two accounts below (it changes passwords and disables a user).
BASE_URL / CADDY_CA can be set in the environment."""
import os, re, sys, time, io, zipfile, requests
B = os.getenv("BASE_URL", "https://antiphish.localhost"); CA = os.getenv("CADDY_CA", "/tmp/caddy-root.crt")
HERE = os.path.dirname(os.path.abspath(__file__))
ADMIN = ("admin@example.com", "Admin-Lozinka-2026!"); USER = ("drug@example.com", "Drug-Lozinka-2026!")
ok_all = True
def check(name, cond, extra=""):
    global ok_all; ok_all &= bool(cond)
    print(("PASS " if cond else "FAIL ") + name + (f"  [{extra}]" if extra else ""))
def S():
    s = requests.Session(); s.trust_env = False; s.verify = CA; return s
def csrf(html):
    m = re.search(r'name="csrf"\s+value="([^"]+)"', html); return m.group(1) if m else ""
def login(s, cred, **kw):
    r = s.get(B + "/login")
    return s.post(B + "/login", data={"email": cred[0], "password": cred[1], "csrf": csrf(r.text)}, **kw)
def scan(s, name=None, raw=None, text=None, mode="quick"):
    page = s.get(B + "/")
    data = {"csrf": csrf(page.text), "mode": mode}
    files = None
    if raw is not None: files = {"file": (name, raw, "message/rfc822")}
    else: data["raw"] = text; files = {"file": ("", b"", "application/octet-stream")}
    t = time.time(); r = s.post(B + "/scan", data=data, files=files); dt = time.time() - t
    m = re.search(r'class="ring-num"><b>(\d{1,3})<', r.text)
    return r, (int(m.group(1)) if m else None), dt

PHISH = open(os.path.join(HERE, "phish_auth_pass.eml"), "rb").read()
LEGIT = open(os.path.join(HERE, "legit_internal.eml"), "rb").read()

# --- unauthenticated
s = S()
r = s.get(B + "/", allow_redirects=False); check("unauth / redirects to /login", r.status_code == 303 and r.headers["location"] == "/login")
r = s.get(B + "/admin", allow_redirects=False); check("unauth /admin redirects", r.status_code == 303)
r = s.get(B + "/history", allow_redirects=False); check("unauth /history redirects", r.status_code == 303)
r = s.post(B + "/login", data={"email": USER[0], "password": USER[1], "csrf": "wrong"}); check("login without valid CSRF -> 400", r.status_code == 400, r.status_code)
r = s.post(B + "/scan", data={"csrf": "x"}, allow_redirects=False); check("unauth POST /scan redirects", r.status_code == 303)

# --- user flow
u = S(); r = login(u, USER); check("user login", r.status_code == 200 and r.url == B + "/", r.url)
ck = [c for c in u.cookies if c.name == "ap_session"][0]
check("session cookie is Secure + HttpOnly", ck.secure and ck.has_nonstandard_attr("HttpOnly") or ck.secure and "httponly" in str(ck._rest).lower(), str(ck._rest))
r, sc, dt = scan(u, "phish.eml", PHISH); check("phishing that passes SPF/DKIM/DMARC -> >=85", sc is not None and sc >= 85, f"score={sc} {dt:.2f}s")
phish_url = r.url
check("result page shows score arithmetic", "How the score is calculated" in r.text)
check("links on result page are defanged", "hxxp" in r.text and "https://login-microsoftonline.pages.dev" not in r.text)
r, sc, dt = scan(u, "legit.eml", LEGIT); check("internal legit mail -> <30", sc is not None and sc < 30, f"score={sc} {dt:.2f}s")
legit_url = r.url
r, sc, dt = scan(u, text="Hitno! Vaš račun je blokiran. Potvrdite lozinku ovdje: http://192.168.1.5/login odmah ili gubite pristup."); check("pasted text scan works, warns about missing headers", sc is not None and ("header" in r.text.lower()), f"score={sc}")
# attachments: zip with exe disguised
buf = io.BytesIO(); z = zipfile.ZipFile(buf, "w"); z.writestr("faktura.pdf.exe", b"MZ" + b"\x00" * 200); z.close()
import email.message
m = email.message.EmailMessage(); m["From"] = "Racunovodstvo <racuni@firma-dobavljac.com>"; m["To"] = "drug@example.com"; m["Subject"] = "Faktura 2026-114"; m["Date"] = "Mon, 23 Nov 2026 08:00:00 +0000"; m["Message-ID"] = "<z1@firma-dobavljac.com>"
m.set_content("U prilogu je faktura."); m.add_attachment(buf.getvalue(), maintype="application", subtype="zip", filename="faktura.zip")
r, sc, dt = scan(u, "att.eml", m.as_bytes()); check("zip with .pdf.exe -> >=90", sc is not None and sc >= 90, f"score={sc} {dt:.2f}s")
r = u.get(B + "/history"); check("history lists scans", r.status_code == 200 and r.text.count("/r/") >= 4, r.text.count("/r/"))
# feedback
pg = u.get(legit_url); r = u.post(legit_url + "/feedback", data={"csrf": csrf(pg.text), "label": "0", "comment": "test"}); check("feedback saved", "feedback was saved" in r.text or "Thank you" in r.text)
pg = u.get(phish_url); r = u.post(phish_url + "/feedback", data={"csrf": csrf(pg.text), "label": "1"}); check("feedback (phishing) saved", "Hvala" in r.text)
# .msg rejected, empty rejected, big file rejected
page = u.get(B + "/"); r = u.post(B + "/scan", data={"csrf": csrf(page.text)}, files={"file": ("mail.msg", b"\xd0\xcf\x11\xe0xxxx", "application/octet-stream")}); check(".msg upload -> friendly error", ".msg is not supported" in r.text)
page = u.get(B + "/"); r = u.post(B + "/scan", data={"csrf": csrf(page.text)}, files={"file": ("big.eml", b"From: a@b.c\nSubject: x\n\n" + b"A" * (16 * 1024 * 1024), "message/rfc822")}); check("16 MB upload -> 'larger than 15 MB'", "larger than 15 MB" in r.text, r.status_code)
try:
    page = u.get(B + "/"); r = u.post(B + "/scan", data={"csrf": csrf(page.text)}, files={"file": ("huge.eml", b"A" * (21 * 1024 * 1024), "message/rfc822")}); check("21 MB upload stopped by Caddy (413)", r.status_code == 413, r.status_code)
except requests.exceptions.RequestException as e:
    check("21 MB upload stopped by Caddy (connection closed)", True, type(e).__name__)
# access control
r = u.get(B + "/admin"); check("normal user cannot open /admin (403)", r.status_code == 403, r.status_code)
r = u.post(B + "/admin/users", data={"csrf": csrf(u.get(B + "/").text), "email": "x@y.z", "password": "0123456789ab"}); check("normal user cannot create users (403)", r.status_code == 403, r.status_code)

# --- pages new in v0.11 (the mailbox flow itself is walked through with a browser: mbox/e2e_browser.py)
r = u.get(B + "/"); check("overview lists the manual scans with reasons", r.text.count('class="msg ') >= 4 and "msg-reason" in r.text, r.text.count('class="msg '))
check("overview offers to connect a mailbox", 'href="/mailboxes/connect/gmail"' in r.text and "Connect your email" in r.text)
r = u.get(B + "/?f=danger"); check("filter 'Opasno' shows only dangerous ones", 0 < r.text.count('class="msg ') < 4, r.text.count('class="msg '))
r = u.get(B + "/check"); check("manual check has its own page", r.status_code == 200 and 'action="/scan"' in r.text)
r = u.get(B + "/mailboxes"); check("mailboxes page", r.status_code == 200 and "Connect a mailbox" in r.text)
r = u.get(B + "/mailboxes/connect/gmail"); check("Gmail connect page explains the app password", "apppasswords" in r.text and 'type="password"' in r.text)
r = u.get(B + "/mailboxes/connect/microsoft"); check("Outlook page asks for no password (offers Microsoft sign-in, or says it is not set up)", 'type="password"' not in r.text and ("not enabled yet" in r.text or "Continue to Microsoft sign-in" in r.text))
r = u.get(B + "/api/status"); check("status endpoint answers JSON", r.headers["content-type"].startswith("application/json") and "latest" in r.json())
r = u.post(B + "/mailboxes/connect/imap", data={"csrf": csrf(u.get(B + "/").text), "email": "a@b.ba", "secret": "x", "host": "169.254.169.254"}); check("internal address as mail server is refused", r.status_code == 400 and "not allowed" in r.text, r.status_code)
r = u.post(B + "/mailboxes/connect/imap", data={"csrf": csrf(u.get(B + "/").text), "email": "a@b.ba", "secret": "x", "host": "web"}); check("another container's name as mail server is refused", r.status_code == 400, r.status_code)
r = u.get(B + "/static/app.js"); check("script is served from the site itself", r.status_code == 200 and "javascript" in r.headers["content-type"])
r = u.get(B + "/"); check("CSP still allows only this site", "script-src 'self'" in r.headers.get("content-security-policy", "") and "default-src 'self'" in r.headers.get("content-security-policy", ""))

# --- admin flow
a = S(); r = login(a, ADMIN); check("admin login", r.url == B + "/")
r = a.get(B + "/admin"); check("admin page", r.status_code == 200 and "drug@example.com" in r.text)
check("admin page shows the mailbox checker is alive", "Mailbox checking" in r.text and ">running<" in r.text)
check("admin page shows Qwen status", "Qwen AI" in r.text)
r = a.post(B + "/admin/users", data={"csrf": csrf(r.text), "email": "treci@example.com", "password": "Treci-Lozinka-2026", "credits": "5"}); check("admin creates user", "has been created" in r.text)
uid = re.search(r'/admin/users/(\d+)/credits"[^>]*>(?:(?!</form>).)*?', r.text, re.S)
ids = re.findall(r'/admin/users/(\d+)/credits', r.text); new_id = max(map(int, ids))
r = a.post(B + f"/admin/users/{new_id}/credits", data={"csrf": csrf(a.get(B + '/admin').text), "credits": "1"}); check("admin sets credits", "Credits updated" in r.text)
r = a.post(B + "/admin/feedback/export", data={"csrf": csrf(a.get(B + '/admin').text)}); check("admin exports feedback (2 rows)", "2 novih primjera" in r.text, re.findall(r'(\d+ novih primjera)', r.text))
r = a.get(phish_url); check("admin can open a user's result", r.status_code == 200)

# --- third user: credits, isolation, disable
t = S(); r = login(t, ("treci@example.com", "Treci-Lozinka-2026")); check("third user login", r.url == B + "/")
r = t.get(phish_url); check("user cannot open someone else's result (404)", r.status_code == 404, r.status_code)
r, sc, dt = scan(t, "legit.eml", LEGIT); check("scan with 1 credit works", sc is not None)
r, sc, dt = scan(t, "legit.eml", LEGIT); check("0 credits -> message", "Not enough credits" in r.text)
r = a.post(B + f"/admin/users/{new_id}/toggle", data={"csrf": csrf(a.get(B + '/admin').text)}); r = t.get(B + "/", allow_redirects=False); check("disabled user is logged out", r.status_code == 303)
r = login(t, ("treci@example.com", "Treci-Lozinka-2026")); check("disabled user cannot log in", r.status_code == 401, r.status_code)

# --- password change logs out other sessions
u2 = S(); login(u2, USER)
pg = u.get(B + "/account"); r = u.post(B + "/account/password", data={"csrf": csrf(pg.text), "current": USER[1], "new": "Nova-Lozinka-2026!!"}); check("password change", "Lozinka je promijenjena" in r.text)
r = u2.get(B + "/", allow_redirects=False); check("other session logged out after password change", r.status_code == 303)
r = u.get(B + "/", allow_redirects=False); check("current session stays", r.status_code == 200)
pg = u.get(B + "/"); r = u.post(B + "/logout", data={"csrf": csrf(pg.text)}); r = u.get(B + "/", allow_redirects=False); check("logout", r.status_code == 303)
print("\nALL PASS" if ok_all else "\nSOME CHECKS FAILED"); sys.exit(0 if ok_all else 1)
