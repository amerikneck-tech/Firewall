"""v0.13: DNS shield - DoH endpoint (RFC 8484), device tokens, rules, query log.

No real network here: the upstream resolver is always mocked. What IS tested end to
end is our side - wire parsing, blocking, token auth, rate limiting, the log and
the dashboard pages.
"""
import base64
import os
import re
import struct
import time

import pytest

fastapi = pytest.importorskip("fastapi")
from fastapi.testclient import TestClient  # noqa: E402

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
KEY = "test-secret-key-0123456789-abcdefghijklmnopqrstuvwxyz"


def make_query(domain: str, qtype: int = 1, qid: int = 0x1234) -> bytes:
    labels = b"".join(bytes([len(p)]) + p.encode() for p in domain.split(".")) + b"\x00"
    return struct.pack("!HHHHHH", qid, 0x0100, 1, 0, 0, 0) + labels + struct.pack("!HH", qtype, 1)


def rcode(resp: bytes) -> int:
    return struct.unpack("!H", resp[2:4])[0] & 0x000F


def fake_answer(query: bytes) -> bytes:
    """What the (mocked) upstream resolver returns: the query with the QR bit set."""
    return query[:2] + b"\x81\x80" + query[4:]


@pytest.fixture()
def env(tmp_path, monkeypatch):
    from webapp import config, db, security
    monkeypatch.setattr(config, "DB_PATH", str(tmp_path / "t.db"))
    monkeypatch.setattr(config, "DATA_DIR", str(tmp_path))
    monkeypatch.setattr(config, "WEB_USE_URL_INTEL", False)
    monkeypatch.setattr(config, "WEB_ALLOW_LLM", False)
    monkeypatch.setattr(config, "SECRET_KEY", KEY)
    monkeypatch.setattr(config, "SECRET_KEY_IS_RANDOM", False)
    monkeypatch.setattr(config, "MAILBOX_ENABLED", False)
    monkeypatch.setattr(config, "BILLING_ENABLED", False)
    monkeypatch.setattr(config, "DNSFW_ENABLED", True)
    monkeypatch.setattr(config, "DNSFW_DEVICES_PER_USER", 2)
    monkeypatch.setattr(config, "DNSFW_QUERIES_PER_MIN", 600)
    monkeypatch.setattr(db, "_initialized_for", None)
    ids = {"alice": db.create_user("alice@example.com", security.hash_password("alice-password-1"), 10),
           "bob": db.create_user("bob@example.com", security.hash_password("bob-password-12"), 10)}
    from webapp import dnsfw
    dnsfw._rl.clear()
    dnsfw._seen.clear()
    from webapp.main import app
    return app, ids


def _csrf(client, path="/login"):
    return re.search(r'name="csrf" value="([^"]+)"', client.get(path).text).group(1)


def _client(app, who="alice"):
    pw = {"alice": "alice-password-1", "bob": "bob-password-12"}[who]
    c = TestClient(app)
    r = c.post("/login", data={"email": f"{who}@example.com", "password": pw, "csrf": _csrf(c)},
               follow_redirects=False)
    assert r.status_code == 303
    return c


def _add_device(app, who="alice", name="Laptop"):
    """Create a device through the page; returns (device_id, token)."""
    from webapp import db
    c = _client(app, who)
    r = c.post("/shield/devices", data={"name": name, "csrf": _csrf(c, "/shield")},
               follow_redirects=False)
    assert r.status_code == 303
    m = re.search(r"/dns-query/(apdns_[A-Za-z0-9_-]+)", c.get("/shield").text)
    assert m, "the DoH address with the token should be shown once after creation"
    token = m.group(1)
    from webapp import dnsfw
    device = db.get_device_by_token(dnsfw.token_hash(token))
    assert device and device["name"] == name
    return device["id"], token


# ------------------------------------------------------------------ wire format
def test_parse_query_roundtrip():
    from webapp import dnsfw
    q = dnsfw.parse_query(make_query("Example.COM"))
    assert q["qname"] == "example.com" and q["qtype"] == 1 and q["id"] == 0x1234


def test_parse_rejects_garbage_and_responses():
    from webapp import dnsfw
    with pytest.raises(dnsfw.QueryError):
        dnsfw.parse_query(b"\x00\x01")
    with pytest.raises(dnsfw.QueryError):
        dnsfw.parse_query(make_query("a.com")[:2] + b"\x81\x80" + make_query("a.com")[4:])


def test_nxdomain_keeps_id_and_question():
    from webapp import dnsfw
    raw = make_query("evil.com", qid=0xBEEF)
    q = dnsfw.parse_query(raw)
    ans = dnsfw.nxdomain_response(raw, q)
    assert struct.unpack("!H", ans[:2])[0] == 0xBEEF          # same id
    assert rcode(ans) == 3                                     # NXDOMAIN
    assert ans[12:] == raw[12:q["question_end"]]               # question echoed


# ------------------------------------------------------------------ rules
def test_rule_matching_and_allow_precedence():
    from webapp import dnsfw
    assert dnsfw.normalize_pattern("*.Evil.COM.") == ("*.evil.com", "suffix")
    assert dnsfw.normalize_pattern("evil.com") == ("evil.com", "exact")
    assert dnsfw.normalize_pattern("not a domain!") == ("", "")
    rules = [{"pattern": "*.evil.com", "scope": "suffix", "action": "block"},
             {"pattern": "safe.evil.com", "scope": "exact", "action": "allow"}]
    assert dnsfw.decide("evil.com", rules) == ("blocked", "*.evil.com")
    assert dnsfw.decide("sub.evil.com", rules) == ("blocked", "*.evil.com")
    assert dnsfw.decide("safe.evil.com", rules) == ("allowed", "safe.evil.com")
    assert dnsfw.decide("notevil.com", rules) == ("allowed", "")
    assert dnsfw.decide("evil.com.hop.com", rules) == ("allowed", "")


# ------------------------------------------------------------------ the DoH endpoint
def test_doh_blocked_rule_answers_nxdomain_without_upstream(env, monkeypatch):
    from webapp import db, dnsfw
    app, ids = env
    db.add_dns_rule(ids["alice"], "*.evil.com", "suffix", "block")
    _did, token = _add_device(app)
    monkeypatch.setattr(dnsfw, "forward",
                        lambda q: (_ for _ in ()).throw(AssertionError("blocked must not hit upstream")))
    c = TestClient(app)
    r = c.post(f"/dns-query/{token}", content=make_query("sub.evil.com"),
               headers={"content-type": "application/dns-message"})
    assert r.status_code == 200
    assert r.headers["content-type"].startswith("application/dns-message")
    assert rcode(r.content) == 3
    assert struct.unpack("!H", r.content[:2])[0] == 0x1234


def test_doh_allowed_query_is_forwarded_and_logged(env, monkeypatch):
    from webapp import db, dnsfw
    app, ids = env
    did, token = _add_device(app)
    monkeypatch.setattr(dnsfw, "forward", fake_answer)
    c = TestClient(app)
    r = c.post(f"/dns-query/{token}", content=make_query("example.com"),
               headers={"content-type": "application/dns-message"})
    assert r.status_code == 200 and rcode(r.content) == 0
    events = db.list_dns_events(did)
    assert len(events) == 1 and events[0]["domain"] == "example.com"
    assert events[0]["action"] == "allowed"


def test_doh_get_form_works(env, monkeypatch):
    from webapp import dnsfw
    app, ids = env
    _did, token = _add_device(app)
    monkeypatch.setattr(dnsfw, "forward", fake_answer)
    b64 = base64.urlsafe_b64encode(make_query("example.org")).rstrip(b"=").decode()
    c = TestClient(app)
    r = c.get(f"/dns-query/{token}?dns={b64}")
    assert r.status_code == 200 and rcode(r.content) == 0


def test_doh_builtin_test_domain_is_always_blocked(env, monkeypatch):
    from webapp import dnsfw
    app, ids = env
    _did, token = _add_device(app)
    monkeypatch.setattr(dnsfw, "forward",
                        lambda q: (_ for _ in ()).throw(AssertionError("must not forward")))
    c = TestClient(app)
    r = c.post(f"/dns-query/{token}", content=make_query(dnsfw.TEST_BLOCKED_DOMAIN),
               headers={"content-type": "application/dns-message"})
    assert r.status_code == 200 and rcode(r.content) == 3


def test_doh_rejects_strangers(env, monkeypatch):
    from webapp import db, dnsfw
    app, ids = env
    did, token = _add_device(app)
    monkeypatch.setattr(dnsfw, "forward", fake_answer)
    c = TestClient(app)
    # unknown token -> 404 (not an open resolver)
    assert c.post("/dns-query/apdns_wrong", content=make_query("a.com"),
                  headers={"content-type": "application/dns-message"}).status_code == 404
    # paused device -> 404
    db.set_device_active(did, ids["alice"], False)
    assert c.post(f"/dns-query/{token}", content=make_query("a.com"),
                  headers={"content-type": "application/dns-message"}).status_code == 404
    # wrong content type / garbage body
    db.set_device_active(did, ids["alice"], True)
    assert c.post(f"/dns-query/{token}", content=make_query("a.com"),
                  headers={"content-type": "text/plain"}).status_code == 415
    assert c.post(f"/dns-query/{token}", content=b"\x99\x98",
                  headers={"content-type": "application/dns-message"}).status_code == 400
    # never logged anything for the strangers
    assert db.list_dns_events(did) == []


def test_doh_rate_limit(env, monkeypatch):
    from webapp import config, dnsfw
    app, ids = env
    monkeypatch.setattr(config, "DNSFW_QUERIES_PER_MIN", 3)
    monkeypatch.setattr(dnsfw, "forward", fake_answer)
    _did, token = _add_device(app)
    c = TestClient(app)
    codes = [c.post(f"/dns-query/{token}", content=make_query("a.com"),
                    headers={"content-type": "application/dns-message"}).status_code
             for _ in range(5)]
    assert codes[:3] == [200, 200, 200] and codes[3:] == [429, 429]


def test_doh_upstream_failure_answers_servfail(env, monkeypatch):
    from webapp import db, dnsfw
    app, ids = env
    did, token = _add_device(app)
    monkeypatch.setattr(dnsfw, "forward",
                        lambda q: (_ for _ in ()).throw(OSError("no route")))
    c = TestClient(app)
    r = c.post(f"/dns-query/{token}", content=make_query("example.net"),
               headers={"content-type": "application/dns-message"})
    assert r.status_code == 200 and rcode(r.content) == 2
    assert db.list_dns_events(did)[0]["action"] == "error"


# ------------------------------------------------------------------ the pages
def test_shield_pages_and_device_lifecycle(env, monkeypatch):
    from webapp import db, dnsfw
    app, ids = env
    monkeypatch.setattr(dnsfw, "forward", fake_answer)
    c = _client(app)
    # empty overview
    assert "Add your first device" in c.get("/shield").text
    # create
    did, token = _add_device(app)
    page = c.get("/shield").text
    assert "Laptop" in page and "never connected" in page
    # the token is NOT shown again on later visits
    assert token not in page
    # generate a query, see it in the log on the device page
    c.post(f"/dns-query/{token}", content=make_query("example.com"),
           headers={"content-type": "application/dns-message"})
    detail = c.get(f"/shield/devices/{did}").text
    assert "example.com" in detail and "allowed" in detail
    # blocked filter
    assert "No queries with this result" in c.get(f"/shield/devices/{did}?f=blocked").text
    # toggle pause -> endpoint stops answering
    r = c.post(f"/shield/devices/{did}/toggle",
               data={"csrf": _csrf(c, f"/shield/devices/{did}")}, follow_redirects=False)
    assert r.status_code == 303
    assert c.post(f"/dns-query/{token}", content=make_query("a.com"),
                  headers={"content-type": "application/dns-message"}).status_code == 404
    # delete -> token dead for good, log gone
    c.post(f"/shield/devices/{did}/toggle",
           data={"csrf": _csrf(c, f"/shield/devices/{did}")})
    c.post(f"/shield/devices/{did}/delete",
           data={"csrf": _csrf(c, f"/shield/devices/{did}")})
    assert c.post(f"/dns-query/{token}", content=make_query("a.com"),
                  headers={"content-type": "application/dns-message"}).status_code == 404
    assert db.list_dns_events(did) == []


def test_shield_rules_via_pages(env):
    from webapp import db
    app, ids = env
    c = _client(app)
    c.post("/shield/rules", data={"pattern": "*.Bad.COM.", "action": "block",
                                  "csrf": _csrf(c, "/shield")})
    rules = db.list_dns_rules(ids["alice"])
    assert [(r["pattern"], r["scope"], r["action"]) for r in rules] == [("*.bad.com", "suffix", "block")]
    page = c.get("/shield").text
    assert "*.bad.com" in page
    # duplicate is refused
    c.post("/shield/rules", data={"pattern": "*.bad.com", "action": "allow",
                                  "csrf": _csrf(c, "/shield")})
    assert len(db.list_dns_rules(ids["alice"])) == 1
    # invalid pattern
    c.post("/shield/rules", data={"pattern": "not a domain!", "action": "block",
                                  "csrf": _csrf(c, "/shield")})
    assert len(db.list_dns_rules(ids["alice"])) == 1
    # delete
    c.post(f"/shield/rules/{rules[0]['id']}/delete", data={"csrf": _csrf(c, "/shield")})
    assert db.list_dns_rules(ids["alice"]) == []


def test_shield_limits_and_privacy(env):
    from webapp import config, db
    app, ids = env
    _add_device(app, "alice", "One")
    _add_device(app, "alice", "Two")
    c = _client(app)
    # third device refused (DNSFW_DEVICES_PER_USER = 2 in the fixture)
    r = c.post("/shield/devices", data={"name": "Three", "csrf": _csrf(c, "/shield")},
               follow_redirects=True)
    assert "the maximum" in r.text
    assert db.count_devices(ids["alice"]) == 2
    # bob cannot open alice's device page
    bob = _client(app, "bob")
    did = db.list_devices(ids["alice"])[0]["id"]
    assert bob.get(f"/shield/devices/{did}").status_code == 404
    # bob's rules do not affect alice's devices
    from webapp import dnsfw
    db.add_dns_rule(ids["bob"], "*.evil.com", "suffix", "block")
    assert dnsfw.decide("evil.com", db.list_dns_rules(ids["alice"])) == ("allowed", "")


def test_shield_disabled_hides_everything(env, monkeypatch):
    from webapp import config, dnsfw
    app, ids = env
    did, token = _add_device(app)
    monkeypatch.setattr(config, "DNSFW_ENABLED", False)
    c = _client(app)
    assert c.get("/shield").status_code == 404
    assert "/shield" not in c.get("/", follow_redirects=True).text   # no nav link
    assert TestClient(app).post(f"/dns-query/{token}", content=make_query("a.com"),
                                headers={"content-type": "application/dns-message"}).status_code == 404
