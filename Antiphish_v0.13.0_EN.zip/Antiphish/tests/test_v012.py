"""v0.12: buying credits - the built-in simulator checkout and the Stripe webhook.

No real Stripe here: the simulator runs the same crediting path, and the webhook
tests sign the payload themselves with a test secret - which proves OUR side
(verification, idempotency, crediting), not Stripe's.
"""
import hashlib
import hmac
import json
import os
import re
import time

import pytest

fastapi = pytest.importorskip("fastapi")
from fastapi.testclient import TestClient  # noqa: E402

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
KEY = "test-secret-key-0123456789-abcdefghijklmnopqrstuvwxyz"
WHSEC = "whsec_testsecret0123456789"


@pytest.fixture()
def env(tmp_path, monkeypatch):
    from webapp import config, db, security
    monkeypatch.setattr(config, "DB_PATH", str(tmp_path / "t.db"))
    monkeypatch.setattr(config, "DATA_DIR", str(tmp_path))
    monkeypatch.setattr(config, "WEB_USE_URL_INTEL", False)
    monkeypatch.setattr(config, "WEB_ALLOW_LLM", False)
    monkeypatch.setattr(config, "SECRET_KEY", KEY)
    monkeypatch.setattr(config, "SECRET_KEY_IS_RANDOM", False)
    monkeypatch.setattr(config, "MAILBOX_ENABLED", False)
    monkeypatch.setattr(config, "BILLING_ENABLED", True)
    monkeypatch.setattr(config, "BILLING_PROVIDER", "simulator")
    monkeypatch.setattr(config, "BILLING_PACKAGES", "")
    monkeypatch.setattr(config, "STRIPE_SECRET_KEY", "")
    monkeypatch.setattr(config, "STRIPE_WEBHOOK_SECRET", WHSEC)
    monkeypatch.setattr(config, "BASE_URL", "https://antiphish.example.com")
    monkeypatch.setattr(db, "_initialized_for", None)
    ids = {"alice": db.create_user("alice@example.com", security.hash_password("alice-password-1"), 10),
           "bob": db.create_user("bob@example.com", security.hash_password("bob-password-12"), 10)}
    from webapp.main import app
    return app, ids


def _csrf(client, path="/login"):
    return re.search(r'name="csrf" value="([^"]+)"', client.get(path).text).group(1)


def _client(app, who="alice"):
    pw = {"alice": "alice-password-1", "bob": "bob-password-12"}[who]
    c = TestClient(app)
    r = c.post("/login", data={"email": f"{who}@example.com", "password": pw, "csrf": _csrf(c)},
               follow_redirects=False)
    assert r.status_code == 303
    return c


def _credits(uid):
    from webapp import db
    return db.get_user(uid)["credits"]


def _buy_url(client, package="standard"):
    """POST the Buy button and return the simulator checkout URL."""
    r = client.post(f"/billing/buy/{package}", data={"csrf": _csrf(client, "/billing")},
                    follow_redirects=False)
    assert r.status_code == 303
    return r.headers["location"]


# ------------------------------------------------------------------ simulator
def test_billing_page_lists_packages_and_test_mode(env):
    app, ids = env
    c = _client(app)
    r = c.get("/billing")
    assert r.status_code == 200
    for word in ("Starter", "Standard", "Pro", "Test mode"):
        assert word in r.text
    assert "100" in r.text and "500" in r.text and "2000" in r.text


def test_simulator_full_flow_adds_credits(env):
    app, ids = env
    c = _client(app)
    url = _buy_url(c, "standard")                     # 500 credits
    assert url.startswith("/billing/sim/")
    page = c.get(url)
    assert page.status_code == 200 and "SIMULATOR" in page.text
    r = c.post(url + "/pay", data={"csrf": _csrf(c, "/billing")}, follow_redirects=False)
    assert r.status_code == 303 and r.headers["location"] == "/billing/success"
    assert _credits(ids["alice"]) == 10 + 500
    ok = c.get("/billing/success")
    assert "510" in ok.text
    hist = c.get("/billing")
    assert "+500" in hist.text and "standard" in hist.text


def test_simulator_pay_is_idempotent(env):
    app, ids = env
    c = _client(app)
    url = _buy_url(c, "starter")                      # 100 credits
    csrf = _csrf(c, "/billing")
    assert c.post(url + "/pay", data={"csrf": csrf}, follow_redirects=False).status_code == 303
    r = c.post(url + "/pay", data={"csrf": csrf}, follow_redirects=True)   # same session again
    assert "already processed" in r.text
    assert _credits(ids["alice"]) == 10 + 100         # added once, not twice


def test_simulator_session_is_bound_to_its_user(env):
    app, ids = env
    alice = _client(app, "alice")
    url = _buy_url(alice, "pro")
    bob = _client(app, "bob")
    assert bob.get(url).status_code == 404                                   # not bob's session
    r = bob.post(url + "/pay", data={"csrf": _csrf(bob, "/billing")})
    assert r.status_code == 404
    assert _credits(ids["alice"]) == 10 and _credits(ids["bob"]) == 10       # nobody got anything


def test_simulator_session_signature_cannot_be_forged(env):
    app, ids = env
    c = _client(app)
    url = _buy_url(c, "starter")
    body, sig = url.rsplit(".", 1)
    forged = body + "." + ("0" * len(sig))
    assert c.post(forged + "/pay", data={"csrf": _csrf(c, "/billing")}).status_code == 404
    assert _credits(ids["alice"]) == 10


def test_unknown_package_and_csrf(env):
    app, ids = env
    c = _client(app)
    r = c.post("/billing/buy/nonexistent", data={"csrf": _csrf(c, "/billing")})
    assert r.status_code == 404
    r = c.post("/billing/buy/starter", data={"csrf": "wrong"})
    assert r.status_code == 400


def test_billing_requires_login(env):
    app, _ = env
    r = TestClient(app).get("/billing", follow_redirects=False)
    assert r.status_code in (303, 307) and "/login" in r.headers["location"]


def test_billing_disabled_is_404(env, monkeypatch):
    from webapp import config
    monkeypatch.setattr(config, "BILLING_ENABLED", False)
    app, _ = env
    c = _client(app)
    assert c.get("/billing").status_code == 404
    assert c.post("/billing/webhook", content=b"{}").status_code == 404


# ------------------------------------------------------------------ Stripe webhook
def _event(uid, package="standard", event_id="evt_test_1", payment_status="paid"):
    return json.dumps({
        "id": event_id, "type": "checkout.session.completed",
        "data": {"object": {"payment_status": payment_status,
                            "client_reference_id": str(uid),
                            "metadata": {"user_id": str(uid), "package_id": package}}},
    }).encode()


def _sig(payload: bytes, secret: str = WHSEC, ts: int | None = None) -> str:
    ts = ts or int(time.time())
    return f"t={ts},v1=" + hmac.new(secret.encode(), str(ts).encode() + b"." + payload,
                                    hashlib.sha256).hexdigest()


def _post_webhook(client, payload: bytes, sig: str):
    return client.post("/billing/webhook", content=payload,
                       headers={"stripe-signature": sig, "content-type": "application/json"})


def test_stripe_webhook_adds_credits_once(env, monkeypatch):
    from webapp import config
    monkeypatch.setattr(config, "BILLING_PROVIDER", "stripe")
    app, ids = env
    c = TestClient(app)
    payload = _event(ids["alice"], "standard")
    r = _post_webhook(c, payload, _sig(payload))
    assert r.status_code == 200 and r.json() == {"received": True}
    assert _credits(ids["alice"]) == 10 + 500
    # Stripe retries the same event: credits must not double
    r = _post_webhook(c, payload, _sig(payload))
    assert r.status_code == 200
    assert _credits(ids["alice"]) == 10 + 500


def test_stripe_webhook_rejects_bad_signature(env, monkeypatch):
    from webapp import config
    monkeypatch.setattr(config, "BILLING_PROVIDER", "stripe")
    app, ids = env
    c = TestClient(app)
    payload = _event(ids["alice"])
    assert _post_webhook(c, payload, "t=1,v1=forged").status_code == 400
    assert _post_webhook(c, payload, _sig(payload, "whsec_wrong")).status_code == 400
    old = int(time.time()) - 3600                       # older than the 5 min tolerance
    assert _post_webhook(c, payload, _sig(payload, ts=old)).status_code == 400
    assert _credits(ids["alice"]) == 10


def test_stripe_webhook_ignores_unpaid_and_other_events(env, monkeypatch):
    from webapp import config
    monkeypatch.setattr(config, "BILLING_PROVIDER", "stripe")
    app, ids = env
    c = TestClient(app)
    unpaid = _event(ids["alice"], payment_status="unpaid", event_id="evt_unpaid")
    assert _post_webhook(c, unpaid, _sig(unpaid)).status_code == 200
    other = json.dumps({"id": "evt_other", "type": "payment_intent.created", "data": {"object": {}}}).encode()
    assert _post_webhook(c, other, _sig(other)).status_code == 200
    assert _credits(ids["alice"]) == 10


def test_stripe_buy_without_keys_falls_back_with_message(env, monkeypatch):
    from webapp import config
    monkeypatch.setattr(config, "BILLING_PROVIDER", "stripe")
    monkeypatch.setattr(config, "STRIPE_SECRET_KEY", "")
    app, ids = env
    c = _client(app)
    r = c.post("/billing/buy/starter", data={"csrf": _csrf(c, "/billing")}, follow_redirects=True)
    assert "Stripe is not configured" in r.text
    assert _credits(ids["alice"]) == 10


# ------------------------------------------------------------------ packages from .env
def test_custom_packages_from_env(env, monkeypatch):
    from webapp import billing, config
    monkeypatch.setattr(config, "BILLING_PACKAGES",
                        '[{"id":"mini","name":"Mini","credits":42,"price_cents":199,"currency":"USD"}]')
    app, ids = env
    c = _client(app)
    r = c.get("/billing")
    assert "Mini" in r.text and "Starter" not in r.text
    url = _buy_url(c, "mini")
    c.post(url + "/pay", data={"csrf": _csrf(c, "/billing")})
    assert _credits(ids["alice"]) == 10 + 42
    # invalid JSON falls back to the built-in packages
    monkeypatch.setattr(config, "BILLING_PACKAGES", "{not json")
    assert billing.get_package("standard") is not None


def test_stripe_checkout_sends_tax_code_and_metadata(env, monkeypatch):
    """Accounts with Stripe Tax / managed payments refuse checkout without a tax code."""
    from webapp import billing, config
    monkeypatch.setattr(config, "BILLING_PROVIDER", "stripe")
    monkeypatch.setattr(config, "STRIPE_SECRET_KEY", "sk_test_x")
    monkeypatch.setattr(config, "STRIPE_TAX_CODE", "txcd_10000000")
    sent = {}

    class FakeResp:
        status_code = 200
        def json(self):
            return {"url": "https://checkout.stripe.com/test"}

    monkeypatch.setattr(billing.requests, "post",
                        lambda url, **kw: sent.update(url=url, data=kw["data"]) or FakeResp())
    app, ids = env
    url = billing.stripe_checkout_url({"id": ids["alice"], "email": "alice@example.com"},
                                      billing.get_package("standard"))
    assert url == "https://checkout.stripe.com/test"
    assert sent["url"] == "https://api.stripe.com/v1/checkout/sessions"
    assert sent["data"]["line_items[0][price_data][product_data][tax_code]"] == "txcd_10000000"
    assert sent["data"]["metadata[user_id]"] == str(ids["alice"])
    assert sent["data"]["metadata[package_id]"] == "standard"


def test_csp_form_action_allows_stripe_checkout(env):
    """Chrome applies CSP form-action to a form's whole redirect chain, so the
    303 from POST /billing/buy/<id> to checkout.stripe.com is blocked unless the
    header allows it."""
    app, ids = env
    c = _client(app)
    r = c.get("/billing")
    csp = r.headers["content-security-policy"]
    m = re.search(r"form-action ([^;]+)", csp)
    assert m, "form-action missing from CSP"
    assert "https://checkout.stripe.com" in m.group(1)
