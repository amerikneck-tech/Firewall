"""v0.11: connected mailboxes (IMAP with an app password, Outlook through Microsoft
sign-in), the mailbox worker, and the pages around them.

The mail servers here are stand-ins that record what was asked of them: FakeIMAP
follows the calls imaplib makes, FakeMicrosoft follows Microsoft's published
protocol. They prove what OUR side sends and does - not that a real provider
agrees (see HANDOFF.md for what was checked against real servers).
"""
import base64
import glob
import hashlib
import imaplib
import json
import os
import re
import socket
import sqlite3
import time
from urllib.parse import parse_qs, urlparse

import pytest

fastapi = pytest.importorskip("fastapi")
from fastapi.testclient import TestClient  # noqa: E402

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
KEY = "test-secret-key-0123456789-abcdefghijklmnopqrstuvwxyz"


def _mail(n: int, subject: str = "", phish: bool = False) -> bytes:
    if phish:
        return (f"From: PayPal Security <security@paypa1-secure.tk>\r\nTo: you@example.com\r\n"
                f"Subject: Urgent: verify your account #{n}\r\n"
                "Authentication-Results: mx; spf=fail; dkim=fail; dmarc=fail\r\n"
                "MIME-Version: 1.0\r\nContent-Type: text/plain\r\n\r\n"
                "Your account will be suspended. Verify your password now: http://paypa1-secure.tk/login\r\n").encode()
    return (f"From: Marko <marko@firma-primjer.ba>\r\nTo: you@example.com\r\n"
            f"Subject: {subject or 'Sastanak'} #{n}\r\nMIME-Version: 1.0\r\nContent-Type: text/plain\r\n\r\n"
            "Zdravo, mozemo li pomjeriti sastanak na srijedu u 10h? Pozdrav, Marko\r\n").encode()


# ------------------------------------------------------------------ stand-in IMAP server
class FakeIMAP:
    """Answers the way an IMAP server does to the calls imaplib makes; keeps a log."""
    password = "abcdabcdabcdabcd"
    uidvalidity = "7"
    messages: dict = {}            # uid -> raw bytes
    sizes: dict = {}               # uid -> size to report (default: real size)
    login_error = None             # text of a NO answer to LOGIN, or an exception instance
    connect_error = None
    log: list = []
    instances = 0

    @classmethod
    def reset(cls, n: int = 0):
        cls.password, cls.uidvalidity = "abcdabcdabcdabcd", "7"
        cls.messages = {uid: _mail(uid) for uid in range(1, n + 1)}
        cls.sizes, cls.login_error, cls.connect_error, cls.log, cls.instances = {}, None, None, [], 0

    def __init__(self, host, port, ip, ssl_context, timeout):
        if FakeIMAP.connect_error:
            raise FakeIMAP.connect_error
        FakeIMAP.instances += 1
        FakeIMAP.log.append(("connect", host, port, ip, ssl_context.verify_mode.name, ssl_context.check_hostname))

    def login(self, user, password):
        FakeIMAP.log.append(("login", user, password))
        err = FakeIMAP.login_error
        if isinstance(err, Exception):
            raise err
        if err:
            raise imaplib.IMAP4.error(err)
        if password != FakeIMAP.password:
            raise imaplib.IMAP4.error(b"[AUTHENTICATIONFAILED] Invalid credentials (Failure)")
        return "OK", [b"done"]

    def select(self, mailbox="INBOX", readonly=False):
        FakeIMAP.log.append(("select", mailbox, readonly))
        return "OK", [str(len(FakeIMAP.messages)).encode()]

    def response(self, code):
        return code, [FakeIMAP.uidvalidity.encode()]

    def fetch(self, seqset, parts):
        FakeIMAP.log.append(("fetch", seqset, parts))
        uids = sorted(FakeIMAP.messages)
        start = int(seqset.split(":")[0])
        return "OK", [f"{i} (UID {u})".encode() for i, u in enumerate(uids, 1) if i >= start]

    def uid(self, command, *args):
        FakeIMAP.log.append(("uid", command, *args))
        uids = sorted(FakeIMAP.messages)
        if command == "SEARCH":
            low = int(re.search(r"UID (\d+):\*", args[1]).group(1))
            hit = [u for u in uids if u >= low] or uids[-1:]      # "N:*" always includes the newest
            return "OK", [" ".join(map(str, hit)).encode()]
        if command == "FETCH" and "BODY.PEEK[]" in args[1]:
            u = int(args[0])
            if u not in FakeIMAP.messages:
                return "OK", [None]
            raw = FakeIMAP.messages[u]
            part = re.search(r"<0\.(\d+)>", args[1])               # partial fetch: at most N bytes
            if part:
                raw = raw[:int(part.group(1))]
            return "OK", [(f"1 (UID {u} BODY[]<0> {{{len(raw)}}}".encode(), raw), b")"]
        if command == "FETCH":
            out = []
            for u in (int(x) for x in args[0].split(",")):
                if u in FakeIMAP.messages:
                    size = FakeIMAP.sizes.get(u, len(FakeIMAP.messages[u]))
                    out.append(f'1 (UID {u} RFC822.SIZE {size} INTERNALDATE "23-Nov-2026 10:{u % 60:02d}:00 +0000")'.encode())
            return "OK", out
        raise AssertionError(f"the mailbox must never be changed, got UID {command}")

    def logout(self):
        FakeIMAP.log.append(("logout",))

    def __getattr__(self, name):            # store / copy / expunge / create / append ...
        raise AssertionError(f"unexpected IMAP call: {name}")


def _commands():
    return [e[1] if e[0] == "uid" else e[0] for e in FakeIMAP.log]


@pytest.fixture()
def env(tmp_path, monkeypatch):
    from webapp import config, db, mailbox_worker, mailboxes, netguard, scanning, security
    monkeypatch.setattr(config, "DB_PATH", str(tmp_path / "t.db"))
    monkeypatch.setattr(config, "DATA_DIR", str(tmp_path))
    monkeypatch.setattr(config, "WEB_USE_URL_INTEL", False)
    monkeypatch.setattr(config, "WEB_ALLOW_LLM", False)
    monkeypatch.setattr(config, "SECRET_KEY", KEY)
    monkeypatch.setattr(config, "SECRET_KEY_IS_RANDOM", False)
    monkeypatch.setattr(config, "MAILBOX_KEY", "")
    monkeypatch.setattr(config, "MAILBOX_ENABLED", True)
    monkeypatch.setattr(config, "COST_MAILBOX", 0)
    monkeypatch.setattr(config, "MAILBOX_INITIAL_SCAN", 3)
    monkeypatch.setattr(config, "MAILBOX_BATCH", 25)
    monkeypatch.setattr(config, "MAILBOX_SCANS_PER_HOUR", 120)
    monkeypatch.setattr(config, "MAILBOXES_PER_USER", 3)
    monkeypatch.setattr(config, "MAILBOX_USE_LLM", False)
    monkeypatch.setattr(config, "MAILBOX_ALLOW_PRIVATE_HOSTS", False)
    monkeypatch.setattr(config, "MS_CLIENT_ID", "")
    monkeypatch.setattr(config, "MS_CLIENT_SECRET", "")
    monkeypatch.setattr(config, "BASE_URL", "https://antiphish.example.com")
    monkeypatch.setattr(db, "_initialized_for", None)
    monkeypatch.setitem(scanning._llm_state, "at", None)
    monkeypatch.setattr(mailboxes, "_PinnedIMAP4SSL", FakeIMAP)
    # every name resolves to a public address unless a test says otherwise
    monkeypatch.setattr(netguard.socket, "getaddrinfo",
                        lambda host, port, **kw: [(socket.AF_INET, socket.SOCK_STREAM, 6, "", ("142.250.102.108", port))])
    mailbox_worker._tokens.clear()
    mailbox_worker._stop.clear()
    FakeIMAP.reset()
    ids = {"alice": db.create_user("alice@example.com", security.hash_password("alice-password-1"), 10),
           "bob": db.create_user("bob@example.com", security.hash_password("bob-password-12"), 10),
           "admin": db.create_user("admin@example.com", security.hash_password("admin-password-1"), 999, True)}
    db.set_meta(mailbox_worker.BEAT_KEY, f"{time.time():.0f}")     # as if the checker were running
    from webapp.main import app
    return app, ids


def _csrf(client, path="/login"):
    return re.search(r'name="csrf" value="([^"]+)"', client.get(path).text).group(1)


def _client(app, who="alice"):
    pw = {"alice": "alice-password-1", "bob": "bob-password-12", "admin": "admin-password-1"}[who]
    c = TestClient(app)
    r = c.post("/login", data={"email": f"{who}@example.com", "password": pw, "csrf": _csrf(c)},
               follow_redirects=False)
    assert r.status_code == 303
    return c


def _box(user_id, addr="alice@gmail.com", provider="gmail", password=None, host="imap.gmail.com"):
    """A connected mailbox as the connect page leaves it."""
    from webapp import crypto, db, mailboxes
    enc = crypto.encrypt(password or FakeIMAP.password, mailboxes.secret_aad(user_id, addr))
    return db.create_mailbox(user_id, addr, provider, "imap", enc, host=host)


def _visit(mailbox_id):
    from webapp import mailbox_worker
    return mailbox_worker.process_mailbox(mailbox_id)


def _n_scans(user_id):
    from webapp import db
    return db.count_scans(user_id)


# ================================================================== stored secrets
def test_secret_roundtrip_and_what_is_stored_is_not_the_password(env):
    from webapp import crypto
    token = crypto.encrypt("abcd efgh ijkl mnop", "mailbox:1:a@b.c")
    assert token.startswith("v1:") and "abcd" not in token and "mnop" not in token
    assert crypto.decrypt(token, "mailbox:1:a@b.c") == "abcd efgh ijkl mnop"
    assert crypto.encrypt("same", "x") != crypto.encrypt("same", "x")      # fresh nonce every time


def test_secret_is_bound_to_its_mailbox_and_detects_tampering(env):
    from webapp import crypto
    token = crypto.encrypt("the-password", "mailbox:1:alice@gmail.com")
    with pytest.raises(crypto.SecretError):                  # copied into another user's row
        crypto.decrypt(token, "mailbox:2:alice@gmail.com")
    raw = bytearray(base64.urlsafe_b64decode(token[3:]))
    raw[-1] ^= 1
    with pytest.raises(crypto.SecretError):
        crypto.decrypt("v1:" + base64.urlsafe_b64encode(bytes(raw)).decode(), "mailbox:1:alice@gmail.com")
    for junk in ("", "plain-text", "v1:!!!", "v1:" + "A" * 8):
        with pytest.raises(crypto.SecretError):
            crypto.decrypt(junk, "mailbox:1:alice@gmail.com")


def test_secret_needs_the_same_server_key(env, monkeypatch):
    from webapp import config, crypto
    token = crypto.encrypt("the-password", "aad")
    monkeypatch.setattr(config, "SECRET_KEY", KEY + "-changed")
    with pytest.raises(crypto.SecretError):
        crypto.decrypt(token, "aad")
    monkeypatch.setattr(config, "MAILBOX_KEY", "a-dedicated-key")     # MAILBOX_KEY wins over SECRET_KEY
    t2 = crypto.encrypt("pw", "aad")
    monkeypatch.setattr(config, "SECRET_KEY", "something else entirely")
    assert crypto.decrypt(t2, "aad") == "pw"


def test_without_a_stable_key_mailboxes_cannot_be_connected(env, monkeypatch):
    from webapp import config, crypto, db
    app, ids = env
    monkeypatch.setattr(config, "SECRET_KEY_IS_RANDOM", True)
    assert not crypto.available()
    c = _client(app)
    page = c.get("/mailboxes/connect/gmail").text
    assert "SECRET_KEY" in page
    r = c.post("/mailboxes/connect/gmail", data={"csrf": _csrf(c, "/"), "email": "alice@gmail.com",
                                                 "secret": FakeIMAP.password})
    assert r.status_code == 503 and db.count_mailboxes(ids["alice"]) == 0 and FakeIMAP.instances == 0
    monkeypatch.setattr(config, "MAILBOX_KEY", "set")
    assert crypto.available()


# ================================================================== mail server names
@pytest.mark.parametrize("host", ["127.0.0.1", "10.0.0.5", "[::1]", "localhost", "ollama", "web", "caddy",
                                  "imap", "169.254.169.254", "imap.gmail.com:143", "imap.gmail.com/x",
                                  "user@imap.gmail.com", "a b.com", "", "-bad.example.com", "x." + "a" * 30])
def test_host_names_that_are_not_public_mail_servers_are_refused_before_any_lookup(env, monkeypatch, host):
    from webapp import netguard
    monkeypatch.setattr(netguard.socket, "getaddrinfo",
                        lambda *a, **k: pytest.fail("must be refused without a DNS lookup"))
    with pytest.raises(netguard.HostNotAllowed):
        netguard.resolve_checked(host)


@pytest.mark.parametrize("ip", ["127.0.0.1", "10.1.2.3", "172.17.0.2", "192.168.1.10", "169.254.169.254",
                                "100.64.0.1", "0.0.0.0", "::1", "fe80::1", "fd00::5", "::ffff:10.0.0.1",
                                "224.0.0.1", "64:ff9b::a9fe:a9fe", "2002:a9fe:a9fe::1", "64:ff9b:1::a00:1"])
def test_a_name_that_resolves_to_an_internal_address_is_refused(env, monkeypatch, ip):
    from webapp import netguard
    fam = socket.AF_INET6 if ":" in ip else socket.AF_INET
    monkeypatch.setattr(netguard.socket, "getaddrinfo",
                        lambda host, port, **kw: [(fam, socket.SOCK_STREAM, 6, "", (ip, port))])
    with pytest.raises(netguard.HostNotAllowed):
        netguard.resolve_checked("mail.attacker-example.com")


def test_one_internal_address_among_public_ones_is_enough_to_refuse(env, monkeypatch):
    from webapp import netguard
    monkeypatch.setattr(netguard.socket, "getaddrinfo", lambda host, port, **kw: [
        (socket.AF_INET, socket.SOCK_STREAM, 6, "", ("142.250.102.108", port)),
        (socket.AF_INET, socket.SOCK_STREAM, 6, "", ("169.254.169.254", port))])
    with pytest.raises(netguard.HostNotAllowed):
        netguard.resolve_checked("imap.rebind-example.com")


def test_public_server_is_accepted_and_private_only_when_the_operator_allows_it(env, monkeypatch):
    from webapp import config, netguard
    assert netguard.resolve_checked("IMAP.Gmail.com.") == ["142.250.102.108"]
    monkeypatch.setattr(netguard.socket, "getaddrinfo",
                        lambda host, port, **kw: [(socket.AF_INET, socket.SOCK_STREAM, 6, "", ("10.0.0.5", port))])
    monkeypatch.setattr(config, "MAILBOX_ALLOW_PRIVATE_HOSTS", True)
    assert netguard.resolve_checked("mail.intern.example.com") == ["10.0.0.5"]


def test_connection_goes_to_the_checked_address_with_certificate_and_name_verified(env):
    from webapp import mailboxes
    assert mailboxes.test_login("imap.gmail.com", "a@gmail.com", FakeIMAP.password) == 0
    kind, host, port, ip, verify, check_host = FakeIMAP.log[0]
    assert (host, port, ip) == ("imap.gmail.com", 993, "142.250.102.108")
    assert verify == "CERT_REQUIRED" and check_host is True


def test_pinned_connection_dials_the_ip_but_verifies_the_name(monkeypatch):
    """The real class (not the stand-in): socket to the checked IP, TLS for the host name."""
    from webapp import mailboxes
    seen = {}

    class Ctx:
        def wrap_socket(self, sock, server_hostname=None):
            seen["sni"] = server_hostname
            raise OSError("stop here")

    monkeypatch.setattr(mailboxes.socket, "create_connection",
                        lambda addr, timeout=None: seen.setdefault("addr", addr) and object())
    with pytest.raises(OSError):
        mailboxes._PinnedIMAP4SSL("imap.example.com", 993, "203.0.113.9", Ctx(), 5)
    assert seen == {"addr": ("203.0.113.9", 993), "sni": "imap.example.com"}


def test_only_port_993_is_ever_used(env):
    from webapp import mailboxes
    with pytest.raises(mailboxes.MailboxError) as e:
        mailboxes.open_imap("imap.gmail.com", "a@gmail.com", "x", port=6379)
    assert e.value.kind == "host" and FakeIMAP.instances == 0


# ================================================================== reading a mailbox
def test_first_visit_checks_the_newest_messages_only_and_reads_without_changing(env):
    from webapp import db
    app, ids = env
    FakeIMAP.reset(10)
    FakeIMAP.messages[9] = _mail(9, phish=True)
    mb = _box(ids["alice"])
    assert _visit(mb) == "ok:3"
    rows = db.list_scans(ids["alice"])
    assert sorted(r["subject"][-2:].strip("#") for r in rows) == ["10", "8", "9"]     # newest 3 of 10
    box = db.get_mailbox(mb)
    assert (box["status"], box["last_uid"], box["uidvalidity"]) == ("ok", 10, "7")
    assert {r["mailbox_id"] for r in rows} == {mb} and all(r["msg_date"] for r in rows)
    assert {r["level"] for r in rows} >= {"LOW"} and any(r["level"] in ("HIGH", "CRITICAL") for r in rows)
    # read-only: opened with EXAMINE, bodies fetched with PEEK, nothing else asked of the server
    assert ("select", "INBOX", True) in FakeIMAP.log
    assert set(_commands()) == {"connect", "login", "select", "fetch", "SEARCH", "FETCH", "logout"}
    assert all("PEEK" in e[3] or "RFC822.SIZE" in e[3] for e in FakeIMAP.log if e[:2] == ("uid", "FETCH"))


def test_later_visits_check_only_new_mail_and_never_the_same_message_twice(env):
    app, ids = env
    FakeIMAP.reset(5)
    mb = _box(ids["alice"])
    assert _visit(mb) == "ok:3"
    assert _visit(mb) == "ok:0" and _n_scans(ids["alice"]) == 3      # "N:*" returning the newest again is ignored
    FakeIMAP.messages[6] = _mail(6)
    FakeIMAP.messages[7] = _mail(7, phish=True)
    assert _visit(mb) == "ok:2" and _n_scans(ids["alice"]) == 5
    assert _visit(mb) == "ok:0" and _n_scans(ids["alice"]) == 5


def test_initial_scan_zero_means_only_mail_that_arrives_later(env, monkeypatch):
    from webapp import config, db
    app, ids = env
    monkeypatch.setattr(config, "MAILBOX_INITIAL_SCAN", 0)
    FakeIMAP.reset(4)
    mb = _box(ids["alice"])
    assert _visit(mb) == "ok:0" and db.get_mailbox(mb)["last_uid"] == 4
    FakeIMAP.messages[5] = _mail(5)
    assert _visit(mb) == "ok:1"


def test_empty_mailbox(env):
    from webapp import db
    app, ids = env
    mb = _box(ids["alice"])
    assert _visit(mb) == "ok:0" and db.get_mailbox(mb)["status"] == "ok"
    FakeIMAP.messages[1] = _mail(1)
    assert _visit(mb) == "ok:1"


def test_renumbered_folder_is_not_checked_all_over_again(env):
    from webapp import db
    app, ids = env
    FakeIMAP.reset(5)
    mb = _box(ids["alice"])
    _visit(mb)
    FakeIMAP.uidvalidity = "8"                       # the server renumbered the folder
    FakeIMAP.messages = {u + 100: m for u, m in FakeIMAP.messages.items()}
    assert _visit(mb) == "ok:0" and _n_scans(ids["alice"]) == 3
    assert db.get_mailbox(mb)["last_uid"] == 105 and db.get_mailbox(mb)["uidvalidity"] == "8"
    FakeIMAP.messages[106] = _mail(106)
    assert _visit(mb) == "ok:1"


def test_automatic_checks_are_free_by_default_and_charged_when_configured(env, monkeypatch):
    from webapp import config, db
    app, ids = env
    FakeIMAP.reset(3)
    mb = _box(ids["alice"])
    _visit(mb)
    assert db.get_user(ids["alice"])["credits"] == 10
    monkeypatch.setattr(config, "COST_MAILBOX", 2)
    FakeIMAP.messages[4] = _mail(4)
    _visit(mb)
    assert db.get_user(ids["alice"])["credits"] == 8


def test_out_of_credits_pauses_and_the_mail_waits_instead_of_being_skipped(env, monkeypatch):
    from webapp import config, db
    app, ids = env
    monkeypatch.setattr(config, "COST_MAILBOX", 1)
    monkeypatch.setattr(config, "MAILBOX_INITIAL_SCAN", 5)
    db.set_credits(ids["alice"], 2)
    FakeIMAP.reset(5)
    mb = _box(ids["alice"])
    assert _visit(mb) == "no_credits"
    box = db.get_mailbox(mb)
    assert _n_scans(ids["alice"]) == 2 and box["status"] == "no_credits" and box["last_uid"] == 2
    assert box["next_check"] > time.time() + 300 and "credits" in box["status_detail"]
    connects = FakeIMAP.instances
    assert _visit(mb) == "no_credits" and FakeIMAP.instances == connects      # no pointless login
    db.set_credits(ids["alice"], 10)
    assert _visit(mb) == "ok:3" and _n_scans(ids["alice"]) == 5
    assert db.get_mailbox(mb)["status"] == "ok" and db.get_user(ids["alice"])["credits"] == 7


def test_hourly_limit_postpones_the_rest(env, monkeypatch):
    from webapp import config, db
    app, ids = env
    monkeypatch.setattr(config, "MAILBOX_SCANS_PER_HOUR", 4)
    monkeypatch.setattr(config, "MAILBOX_INITIAL_SCAN", 6)
    FakeIMAP.reset(6)
    mb = _box(ids["alice"])
    assert _visit(mb) == "ok:4"
    assert db.get_mailbox(mb)["last_uid"] == 4 and db.get_mailbox(mb)["next_check"] < time.time() + 10
    assert _visit(mb) == "rate_limited" and _n_scans(ids["alice"]) == 4
    assert db.get_mailbox(mb)["status"] == "ok" and "limit" in db.get_mailbox(mb)["status_detail"]
    db.clear(f"mbscan:{ids['alice']}")               # an hour later
    assert _visit(mb) == "ok:2"


def test_a_large_backlog_is_worked_off_in_batches(env, monkeypatch):
    from webapp import config, db
    app, ids = env
    monkeypatch.setattr(config, "MAILBOX_BATCH", 2)
    monkeypatch.setattr(config, "MAILBOX_INITIAL_SCAN", 5)
    FakeIMAP.reset(5)
    mb = _box(ids["alice"])
    assert _visit(mb) == "ok:2" and db.get_mailbox(mb)["next_check"] < time.time() + 10     # more waiting: soon
    assert _visit(mb) == "ok:2"
    assert _visit(mb) == "ok:1" and db.get_mailbox(mb)["next_check"] > time.time() + 60


def test_oversized_message_is_skipped_without_being_downloaded(env, monkeypatch):
    from webapp import config, db
    app, ids = env
    monkeypatch.setattr(config, "MAX_UPLOAD_MB", 1)
    FakeIMAP.reset(3)
    FakeIMAP.sizes[2] = 5 * 1024 * 1024
    mb = _box(ids["alice"])
    assert _visit(mb) == "ok:2" and db.get_mailbox(mb)["last_uid"] == 3
    assert not [e for e in FakeIMAP.log if e[:3] == ("uid", "FETCH", "2") and "BODY" in e[3]]


def test_a_server_that_understates_the_size_still_cannot_push_a_huge_message(env, monkeypatch):
    from webapp import config, db
    app, ids = env
    monkeypatch.setattr(config, "MAX_UPLOAD_MB", 1)
    FakeIMAP.reset(3)
    FakeIMAP.messages[2] = b"From: a@b.c\r\nSubject: big #2\r\n\r\n" + b"x" * (3 * 1024 * 1024)
    FakeIMAP.sizes[2] = 400                                    # the server says: tiny
    mb = _box(ids["alice"])
    assert _visit(mb) == "ok:2" and db.get_mailbox(mb)["last_uid"] == 3
    asked = [e[3] for e in FakeIMAP.log if e[:3] == ("uid", "FETCH", "2") and "BODY" in e[3]]
    assert asked == ["(BODY.PEEK[]<0.1048577>)"]              # never more than the limit + 1 byte
    assert sorted(r["subject"][-1] for r in db.list_scans(ids["alice"])) == ["1", "3"]


def test_a_message_that_cannot_be_analysed_does_not_block_the_ones_after_it(env, monkeypatch):
    from webapp import db, scanning
    app, ids = env
    FakeIMAP.reset(3)
    real = scanning.analyze_email

    def picky(parsed, **kw):
        if parsed.get("subject", "").endswith("#2"):
            raise RuntimeError("boom")
        return real(parsed, **kw)

    monkeypatch.setattr(scanning, "analyze_email", picky)
    mb = _box(ids["alice"])
    assert _visit(mb) == "ok:2" and db.get_mailbox(mb)["last_uid"] == 3


def test_refused_password_is_retried_sparingly_then_waits_for_the_owner(env):
    from webapp import db, mailbox_worker
    app, ids = env
    FakeIMAP.reset(3)
    mb = _box(ids["alice"])
    _visit(mb)
    FakeIMAP.password = "changed-at-google"
    waits = []
    for attempt in range(mailbox_worker.AUTH_RETRIES - 1):
        assert _visit(mb) == "error:auth"
        box = db.get_mailbox(mb)
        assert box["status"] == "error" and box["fail_count"] == attempt + 1
        waits.append(box["next_check"] - time.time())
    assert waits[0] >= 280 and waits[1] >= 1700                 # minutes, not seconds
    assert _visit(mb) == "reauth"
    box = db.get_mailbox(mb)
    assert box["status"] == "reauth" and "Reconnect the mailbox" in box["status_detail"]
    db.update_mailbox(mb, next_check=0, scan_requested=1)
    assert mb not in db.due_mailboxes()                          # no more logins until reconnected
    assert not db.request_mailbox_scan(mb, ids["alice"])
    assert sum(1 for e in FakeIMAP.log if e[0] == "login") == 1 + mailbox_worker.AUTH_RETRIES


def test_server_glitch_at_login_is_not_mistaken_for_a_wrong_password(env):
    from webapp import db
    app, ids = env
    FakeIMAP.reset(2)
    mb = _box(ids["alice"])
    _visit(mb)
    FakeIMAP.login_error = b"[UNAVAILABLE] Temporary System Error"
    for _ in range(6):
        assert _visit(mb) == "error:network"
    assert db.get_mailbox(mb)["status"] != "reauth"
    FakeIMAP.login_error = None
    assert _visit(mb) == "ok:0" and db.get_mailbox(mb)["fail_count"] == 0


def test_short_network_trouble_is_not_shown_as_a_problem_until_it_lasts(env):
    from webapp import db
    app, ids = env
    FakeIMAP.reset(1)
    mb = _box(ids["alice"])
    _visit(mb)
    FakeIMAP.connect_error = OSError("timed out")
    assert _visit(mb) == "error:network" and db.get_mailbox(mb)["status"] == "ok"
    assert _visit(mb) == "error:network" and db.get_mailbox(mb)["status"] == "ok"
    assert _visit(mb) == "error:network"
    box = db.get_mailbox(mb)
    assert box["status"] == "error" and "Cannot connect" in box["status_detail"]
    assert 60 <= box["next_check"] - time.time() <= 900
    FakeIMAP.connect_error = None
    assert _visit(mb) == "ok:0" and db.get_mailbox(mb)["status"] == "ok"


def test_changed_server_key_asks_the_owner_to_reconnect_instead_of_failing_forever(env, monkeypatch):
    from webapp import config, db
    app, ids = env
    mb = _box(ids["alice"])
    monkeypatch.setattr(config, "SECRET_KEY", KEY + "-rotated")
    assert _visit(mb) == "reauth:key"
    assert db.get_mailbox(mb)["status"] == "reauth" and FakeIMAP.instances == 0


def test_disabled_user_and_removed_mailbox_are_left_alone(env):
    from webapp import db
    app, ids = env
    FakeIMAP.reset(2)
    mb = _box(ids["alice"])
    db.set_disabled(ids["alice"], True)
    assert _visit(mb) == "skip:user" and FakeIMAP.instances == 0
    assert mb not in db.due_mailboxes()
    assert _visit(9999) == "gone"


def test_worker_round_takes_due_mailboxes_once_and_respects_a_lease(env):
    from webapp import db, mailbox_worker
    app, ids = env
    FakeIMAP.reset(2)
    a, b = _box(ids["alice"]), _box(ids["bob"], "bob@gmail.com")
    assert set(db.due_mailboxes()) == {a, b}
    assert db.lease_mailbox(b, "another-process") and not db.lease_mailbox(b, mailbox_worker.OWNER)
    assert mailbox_worker.tick() == 1                       # b is held by somebody else
    assert _n_scans(ids["alice"]) == 2 and _n_scans(ids["bob"]) == 0
    assert db.get_mailbox(a)["lease_until"] == 0             # released after the visit
    db.release_mailbox(b, "another-process")
    assert mailbox_worker.tick() == 1 and _n_scans(ids["bob"]) == 2
    assert mailbox_worker.tick() == 0                       # nothing due until the next poll time
    assert db.request_mailbox_scan(a, ids["alice"]) and db.due_mailboxes() == [a]


def test_lease_is_renewed_while_a_long_batch_is_worked_on(env, monkeypatch):
    from webapp import db, mailbox_worker, scanning
    app, ids = env
    FakeIMAP.reset(3)
    mb = _box(ids["alice"])
    seen = []
    real = scanning.run_scan

    def slow(*a, **kw):
        # pretend the lease is about to run out when each message starts
        db.update_mailbox(mb, lease_until=time.time() + 1)
        out = real(*a, **kw)
        return out

    monkeypatch.setattr(scanning, "run_scan", slow)
    real_renew = db.renew_lease
    monkeypatch.setattr(db, "renew_lease", lambda *a, **kw: (real_renew(*a, **kw), seen.append(db.get_mailbox(mb)["lease_until"])))
    assert db.lease_mailbox(mb, mailbox_worker.OWNER, mailbox_worker.LEASE_SECONDS)
    assert mailbox_worker.process_mailbox(mb) == "ok:3"
    assert len(seen) == 3 and all(t > time.time() + 60 for t in seen)
    db.renew_lease(mb, "somebody-else", 9999)                     # only the holder can extend it
    assert db.get_mailbox(mb)["lease_until"] < time.time() + 9000


def test_shutdown_in_the_middle_of_a_batch_stops_cleanly_and_the_rest_follows_later(env, monkeypatch):
    from webapp import db, mailbox_worker, scanning
    app, ids = env
    monkeypatch.setattr(config_mod(), "MAILBOX_INITIAL_SCAN", 5)
    FakeIMAP.reset(5)
    mb = _box(ids["alice"])
    real = scanning.run_scan

    def scan_then_shutdown(*a, **kw):
        out = real(*a, **kw)
        mailbox_worker._stop.set()                 # the server is told to stop while message 1 is being checked
        return out

    monkeypatch.setattr(scanning, "run_scan", scan_then_shutdown)
    assert mailbox_worker.tick() == 1
    box = db.get_mailbox(mb)
    assert _n_scans(ids["alice"]) == 1 and box["last_uid"] == 1 and box["lease_until"] == 0
    assert box["next_check"] < time.time() + 10                     # "more waiting": first thing after the restart
    monkeypatch.setattr(scanning, "run_scan", real)
    mailbox_worker._stop.clear()                   # ... the server is back
    time.sleep(2.1)
    assert mailbox_worker.tick() == 1 and _n_scans(ids["alice"]) == 5
    assert sorted(r["subject"][-1] for r in db.list_scans(ids["alice"])) == ["1", "2", "3", "4", "5"]


def config_mod():
    from webapp import config
    return config


def test_a_crash_in_one_mailbox_does_not_stop_the_round(env, monkeypatch):
    from webapp import db, mailbox_worker
    app, ids = env
    FakeIMAP.reset(1)
    a, b = _box(ids["alice"]), _box(ids["bob"], "bob@gmail.com")
    real = mailbox_worker._run_imap
    monkeypatch.setattr(mailbox_worker, "_run_imap",
                        lambda mb, pw, budget: (_ for _ in ()).throw(RuntimeError("bug")) if mb["id"] == a else real(mb, pw, budget))
    assert mailbox_worker.tick() == 2
    assert db.get_mailbox(a)["status"] == "error" and db.get_mailbox(a)["lease_until"] == 0
    assert db.get_mailbox(b)["status"] == "ok" and _n_scans(ids["bob"]) == 1


def test_worker_loop_reports_in_and_stops_when_asked(env, monkeypatch):
    import threading
    from webapp import mailbox_worker
    app, ids = env
    monkeypatch.setattr(mailbox_worker, "TICK_SECONDS", 0.05)
    FakeIMAP.reset(1)
    _box(ids["alice"])
    stop = threading.Event()
    t = threading.Thread(target=mailbox_worker.run_forever, args=(stop,), daemon=True)
    t.start()
    deadline = time.time() + 20
    while _n_scans(ids["alice"]) < 1 and time.time() < deadline:
        time.sleep(0.05)
    stop.set()
    t.join(5)
    assert not t.is_alive() and _n_scans(ids["alice"]) == 1
    assert mailbox_worker.heartbeat_age() is not None and mailbox_worker.heartbeat_age() < 30


def test_old_mailbox_results_are_removed_but_not_those_with_feedback(env):
    from webapp import db
    app, ids = env
    FakeIMAP.reset(3)
    mb = _box(ids["alice"])
    _visit(mb)
    rows = db.list_scans(ids["alice"])
    db.save_feedback(rows[0]["id"], ids["alice"], 1, "text")
    with db.tx() as con:
        con.execute("UPDATE scans SET created_at = created_at - 100 * 86400")
    c = _client(app)                                             # a manual check of the same age stays
    c.post("/scan", data={"csrf": _csrf(c, "/"), "raw": "Meeting moved to Tuesday"})
    with db.tx() as con:
        con.execute("UPDATE scans SET created_at = created_at - 100 * 86400 WHERE mailbox_id IS NULL")
    assert db.purge_old_mailbox_scans(0) == 0                    # 0 = keep
    assert db.purge_old_mailbox_scans(90) == 2
    left = db.list_scans(ids["alice"])
    assert len(left) == 2 and {r["id"] for r in left} >= {rows[0]["id"]}


def test_mailbox_ai_check_without_an_answer_is_noted_and_costs_the_same(env, monkeypatch):
    from webapp import config, db, scanning
    app, ids = env
    monkeypatch.setattr(config, "MAILBOX_USE_LLM", True)
    monkeypatch.setattr(config, "COST_MAILBOX", 1)
    monkeypatch.setattr(scanning, "llm_ready", lambda: True)
    FakeIMAP.reset(1)
    mb = _box(ids["alice"])
    seen = {}
    real = scanning.analyze_email

    def spy(parsed, **kw):
        seen.update(kw)
        return real(parsed, **dict(kw, use_llm=False))

    monkeypatch.setattr(scanning, "analyze_email", spy)
    assert _visit(mb) == "ok:1" and seen["use_llm"] is True
    row = db.get_scan(db.list_scans(ids["alice"])[0]["id"])
    assert row["mode"] == "quick" and row["cost"] == 1 and db.get_user(ids["alice"])["credits"] == 9
    note = json.loads(row["result_json"])["note"]
    assert "gave no answer" in note and "charged" not in note


# ================================================================== connecting through the pages
def _connect(c, provider="gmail", **form):
    data = {"csrf": _csrf(c, "/"), "email": "alice@gmail.com", "secret": FakeIMAP.password}
    data.update(form)
    return c.post(f"/mailboxes/connect/{provider}", data=data, follow_redirects=False)


def test_connect_page_needs_login_and_csrf(env):
    app, ids = env
    anon = TestClient(app)
    assert anon.get("/mailboxes", follow_redirects=False).headers["location"] == "/login"
    assert anon.get("/mailboxes/connect/gmail", follow_redirects=False).status_code == 303
    assert anon.get("/api/status", follow_redirects=False).status_code == 303
    c = _client(app)
    r = c.post("/mailboxes/connect/gmail", data={"csrf": "wrong", "email": "a@gmail.com", "secret": "x"})
    assert r.status_code == 400 and FakeIMAP.instances == 0
    assert c.get("/mailboxes/connect/nope").status_code == 404
    assert c.post("/mailboxes/connect/microsoft", data={"csrf": _csrf(c, "/")}).status_code == 404


def test_connecting_gmail_stores_only_an_encrypted_secret_and_starts_the_first_check(env):
    from webapp import config, crypto, db, mailboxes
    app, ids = env
    FakeIMAP.reset(4)
    c = _client(app)
    r = _connect(c, secret="abcd abcd abcd abcd ")           # the way Google shows it
    assert r.status_code == 303 and r.headers["location"] == "/"
    assert ("login", "alice@gmail.com", "abcdabcdabcdabcd") in FakeIMAP.log
    box = db.list_mailboxes(ids["alice"])[0]
    assert (box["email"], box["provider"], box["kind"], box["host"], box["port"]) == \
           ("alice@gmail.com", "gmail", "imap", "imap.gmail.com", 993)
    assert box["status"] == "new" and box["scan_requested"] == 1 and box["id"] in db.due_mailboxes()
    assert crypto.decrypt(box["secret"], mailboxes.secret_aad(ids["alice"], "alice@gmail.com")) == "abcdabcdabcdabcd"
    with open(config.DB_PATH, "rb") as f:
        blob = f.read()
    for wal in glob.glob(config.DB_PATH + "-wal"):
        blob += open(wal, "rb").read()
    assert b"abcdabcdabcdabcd" not in blob and b"abcd abcd" not in blob     # nowhere in the database files
    home = c.get("/").text
    assert "alice@gmail.com" in home and "First check in progress" in home and "abcdabcd" not in home
    assert _visit(box["id"]) == "ok:3"
    home = c.get("/").text
    assert "Active" in home and home.count('class="msg ') == 3


def test_wrong_password_is_explained_and_nothing_is_stored(env):
    from webapp import db
    app, ids = env
    c = _client(app)
    r = _connect(c, secret="my-normal-google-password")
    assert r.status_code == 400 and "app password" in r.text
    assert "my-normal-google-password" not in r.text and 'value="alice@gmail.com"' in r.text
    assert db.count_mailboxes(ids["alice"]) == 0


def test_connect_attempts_are_limited(env):
    from webapp import main
    app, ids = env
    c = _client(app)
    for _ in range(main.CONNECT_ATTEMPTS):
        assert _connect(c, secret="wrong-guess").status_code == 400
    logins = sum(1 for e in FakeIMAP.log if e[0] == "login")
    r = _connect(c)                                           # even the right password has to wait now
    assert r.status_code == 429 and sum(1 for e in FakeIMAP.log if e[0] == "login") == logins


@pytest.mark.parametrize("host", ["localhost", "127.0.0.1", "ollama", "169.254.169.254", "web:8000",
                                  "metadata.google.internal"])
def test_own_imap_server_must_be_a_public_host(env, monkeypatch, host):
    from webapp import db, netguard
    app, ids = env
    monkeypatch.setattr(netguard.socket, "getaddrinfo",
                        lambda h, port, **kw: [(socket.AF_INET, socket.SOCK_STREAM, 6, "", ("169.254.169.254", port))])
    c = _client(app)
    r = _connect(c, "imap", email="alice@firma.ba", host=host)
    assert r.status_code == 400 and FakeIMAP.instances == 0 and db.count_mailboxes(ids["alice"]) == 0
    assert "is invalid" in r.text or "not allowed" in r.text


def test_own_imap_server_with_separate_user_name(env):
    from webapp import db
    app, ids = env
    FakeIMAP.password = "pass word"
    c = _client(app)
    assert _connect(c, "imap", email="alice@firma.ba", host="").status_code == 400       # host is required
    r = _connect(c, "imap", email="alice@firma.ba", host="Mail.Firma.ba", login="alice", secret=" pass word ")
    assert r.status_code == 303
    assert ("login", "alice", "pass word") in FakeIMAP.log     # inner spaces of a normal password are kept
    box = db.list_mailboxes(ids["alice"])[0]
    assert (box["host"], box["login"], box["provider"]) == ("mail.firma.ba", "alice", "imap")
    FakeIMAP.log.clear()
    assert _visit(box["id"]) == "ok:0"
    assert FakeIMAP.log[0][1] == "mail.firma.ba" and FakeIMAP.log[1] == ("login", "alice", "pass word")


def test_icloud_tries_the_short_user_name_when_the_full_address_is_refused(env, monkeypatch):
    from webapp import db
    app, ids = env
    real_login = FakeIMAP.login

    def apple_login(self, user, password):           # this server knows the account as "ana", not "ana@icloud.com"
        if "@" in user:
            FakeIMAP.log.append(("login", user, password))
            raise imaplib.IMAP4.error(b"[AUTHENTICATIONFAILED] Authentication failed")
        return real_login(self, user, password)

    monkeypatch.setattr(FakeIMAP, "login", apple_login)
    c = _client(app)
    assert _connect(c, "icloud", email="ana@icloud.com", secret="abcd-abcd-abcd-abcd").status_code == 400   # wrong password: still refused
    FakeIMAP.password = "abcd-abcd-abcd-abcd"
    assert _connect(c, "icloud", email="ana@icloud.com", secret="abcd-abcd-abcd-abcd").status_code == 303
    box = db.list_mailboxes(ids["alice"])[0]
    assert (box["email"], box["login"], box["host"]) == ("ana@icloud.com", "ana", "imap.mail.me.com")
    assert _visit(box["id"]) == "ok:0"                # the worker logs in with the name that worked
    assert _connect(_client(app, "bob"), "gmail", email="b@gmail.com", secret="wrong").status_code == 400
    assert [e[1] for e in FakeIMAP.log if e[0] == "login"][-1] == "b@gmail.com"      # no second guess for other providers


def test_fixed_provider_ignores_a_host_smuggled_into_the_form(env):
    from webapp import db
    app, ids = env
    c = _client(app)
    assert _connect(c, host="evil.example.net").status_code == 303
    assert db.list_mailboxes(ids["alice"])[0]["host"] == "imap.gmail.com"
    assert FakeIMAP.log[0][1] == "imap.gmail.com"


def test_bad_input_is_refused_before_any_connection(env):
    app, ids = env
    c = _client(app)
    for form in ({"email": "not-an-address"}, {"email": "a@b"}, {"secret": ""}, {"secret": "x" * 300},
                 {"email": "a b@gmail.com"}, {"email": "<x>@gmail.com"}):
        assert _connect(c, **form).status_code == 400
    assert FakeIMAP.instances == 0


def test_mailboxes_per_user_limit_and_reconnecting_does_not_count(env, monkeypatch):
    from webapp import config, db
    app, ids = env
    monkeypatch.setattr(config, "MAILBOXES_PER_USER", 2)
    c = _client(app)
    assert _connect(c, email="one@gmail.com").status_code == 303
    assert _connect(c, email="two@gmail.com").status_code == 303
    r = _connect(c, email="three@gmail.com")
    assert r.status_code == 400 and "maximum per account" in r.text and db.count_mailboxes(ids["alice"]) == 2
    assert _connect(c, email="ONE@gmail.com").status_code == 303            # same mailbox again
    assert db.count_mailboxes(ids["alice"]) == 2
    assert "maximum number of mailboxes" in c.get("/mailboxes").text


def test_reconnecting_replaces_the_password_and_keeps_the_place(env):
    from webapp import crypto, db, mailboxes
    app, ids = env
    FakeIMAP.reset(4)
    c = _client(app)
    _connect(c)
    mb = db.list_mailboxes(ids["alice"])[0]["id"]
    _visit(mb)
    db.update_mailbox(mb, status="reauth", status_detail="x", fail_count=3)
    assert "Reconnect" in c.get("/").text
    FakeIMAP.password = "newpasswordnewpw"
    assert _connect(c, secret="newp assw ordn ewpw").status_code == 303
    box = db.get_mailbox(mb)
    assert (box["status"], box["fail_count"], box["last_uid"], box["status_detail"]) == ("new", 0, 4, "")
    assert crypto.decrypt(box["secret"], mailboxes.secret_aad(ids["alice"], "alice@gmail.com")) == "newpasswordnewpw"
    FakeIMAP.messages[5] = _mail(5)
    assert _visit(mb) == "ok:1" and _n_scans(ids["alice"]) == 4               # nothing checked twice


def test_two_users_may_connect_the_same_mailbox_and_see_only_their_own(env):
    from webapp import db
    app, ids = env
    FakeIMAP.reset(2)
    a, b = _client(app, "alice"), _client(app, "bob")
    assert _connect(a, email="shared@gmail.com").status_code == 303
    assert _connect(b, email="shared@gmail.com").status_code == 303
    box_a, box_b = db.list_mailboxes(ids["alice"])[0], db.list_mailboxes(ids["bob"])[0]
    assert box_a["secret"] != box_b["secret"]
    _visit(box_a["id"])
    assert _n_scans(ids["alice"]) == 2 and _n_scans(ids["bob"]) == 0
    assert b.get("/").text.count('class="msg ') == 0
    scan_id = db.list_scans(ids["alice"])[0]["id"]
    assert b.get(f"/r/{scan_id}").status_code == 404 and a.get(f"/r/{scan_id}").status_code == 200


def test_another_user_cannot_touch_my_mailbox(env):
    from webapp import db
    app, ids = env
    a, b = _client(app, "alice"), _client(app, "bob")
    _connect(a)
    mb = db.list_mailboxes(ids["alice"])[0]["id"]
    db.update_mailbox(mb, scan_requested=0)
    assert b.post(f"/mailboxes/{mb}/disconnect", data={"csrf": _csrf(b, "/")}).status_code == 404
    b.post(f"/mailboxes/{mb}/scan", data={"csrf": _csrf(b, "/")})
    assert db.get_mailbox(mb) is not None and db.get_mailbox(mb)["scan_requested"] == 0
    assert a.post(f"/mailboxes/{mb}/scan", data={"csrf": "bad"}).status_code == 400
    assert a.post(f"/mailboxes/{mb}/disconnect", data={"csrf": "bad"}).status_code == 400
    # the storage layer checks the owner itself, whatever the page above it does
    assert db.delete_mailbox(mb, ids["bob"], delete_scans=True) is False and db.get_mailbox(mb) is not None
    assert db.get_mailbox(mb, ids["bob"]) is None and not db.request_mailbox_scan(mb, ids["bob"])
    assert "alice@gmail.com" not in b.get("/mailboxes").text
    assert json.loads(b.get("/api/status").text)["boxes"] == []


def test_check_now_button(env):
    from webapp import db
    app, ids = env
    c = _client(app)
    _connect(c)
    mb = db.list_mailboxes(ids["alice"])[0]["id"]
    _visit(mb)
    assert mb not in db.due_mailboxes()
    r = c.post(f"/mailboxes/{mb}/scan", data={"csrf": _csrf(c, "/")}, follow_redirects=True)
    assert "Mailbox check started" in r.text and mb in db.due_mailboxes()
    for _ in range(8):
        r = c.post(f"/mailboxes/{mb}/scan", data={"csrf": _csrf(c, "/")}, follow_redirects=True)
    assert "wait a moment" in r.text


def test_pages_say_so_when_the_checker_is_not_running(env):
    from webapp import db, mailbox_worker
    app, ids = env
    FakeIMAP.reset(1)
    c = _client(app)
    _connect(c)
    mb = db.list_mailboxes(ids["alice"])[0]["id"]
    _visit(mb)
    assert "Active" in c.get("/").text and "not running" not in c.get("/").text
    db.set_meta(mailbox_worker.BEAT_KEY, f"{time.time() - 630:.0f}")       # silent for ten minutes
    home = c.get("/").text
    assert "Checking is not running" in home and "Active" not in home
    assert json.loads(c.get("/api/status").text)["busy"] is False          # the page stops asking every 4 s
    adm = _client(app, "admin").get("/admin").text
    assert "stalled for 10 min" in adm


def test_reconnect_link_brings_the_address_along_and_check_now_returns_to_the_same_page(env):
    from webapp import db
    app, ids = env
    c = _client(app)
    _connect(c)
    mb = db.list_mailboxes(ids["alice"])[0]["id"]
    r = c.post(f"/mailboxes/{mb}/scan", data={"csrf": _csrf(c, "/"), "back": "mailboxes"}, follow_redirects=False)
    assert r.headers["location"] == "/mailboxes"
    r = c.post(f"/mailboxes/{mb}/scan", data={"csrf": _csrf(c, "/"), "back": "https://evil.example"},
               follow_redirects=False)
    assert r.headers["location"] == "/"
    db.update_mailbox(mb, status="reauth")
    assert 'href="/mailboxes/connect/gmail?email=alice%40gmail.com"' in c.get("/mailboxes").text
    assert 'value="alice@gmail.com"' in c.get("/mailboxes/connect/gmail?email=alice%40gmail.com").text
    assert 'value=""' in c.get('/mailboxes/connect/gmail?email="><script>').text


def test_disconnect_deletes_the_secret_and_keeps_or_deletes_results_as_asked(env):
    from webapp import config, db
    app, ids = env
    FakeIMAP.reset(3)
    c = _client(app)
    _connect(c)
    mb = db.list_mailboxes(ids["alice"])[0]["id"]
    _visit(mb)
    r = c.post(f"/mailboxes/{mb}/disconnect", data={"csrf": _csrf(c, "/")}, follow_redirects=True)
    assert "has been disconnected" in r.text and db.get_mailbox(mb) is None
    assert _n_scans(ids["alice"]) == 3                             # results kept ...
    assert all(r["mailbox_id"] is None for r in db.list_scans(ids["alice"]))
    with sqlite3.connect(config.DB_PATH) as con:
        assert con.execute("SELECT COUNT(*) FROM mailboxes").fetchone()[0] == 0      # ... the secret is gone
    # again, this time with "delete the results too" - except the one with feedback
    _connect(c)
    mb2 = db.list_mailboxes(ids["alice"])[0]["id"]
    _visit(mb2)
    keep = [r for r in db.list_scans(ids["alice"]) if r["mailbox_id"] == mb2][0]["id"]
    c.post(f"/r/{keep}/feedback", data={"csrf": _csrf(c, "/"), "label": "0"})
    c.post(f"/mailboxes/{mb2}/disconnect", data={"csrf": _csrf(c, "/"), "delete_scans": "1"})
    assert db.get_mailbox(mb2) is None and _n_scans(ids["alice"]) == 3 + 1
    assert db.get_scan(keep) is not None and db.get_scan(keep)["mailbox_id"] is None


def test_mailbox_feature_can_be_switched_off(env, monkeypatch):
    from webapp import config
    app, ids = env
    monkeypatch.setattr(config, "MAILBOX_ENABLED", False)
    c = _client(app)
    assert c.get("/mailboxes").status_code == 404
    assert c.get("/mailboxes/connect/gmail").status_code == 404
    home = c.get("/").text
    assert 'href="/mailboxes"' not in home and 'href="/check"' in home


# ================================================================== overview page
def test_overview_onboarding_then_list_with_filters_and_pages(env, monkeypatch):
    from webapp import config, db, main
    app, ids = env
    monkeypatch.setattr(main, "PAGE_SIZE", 4)
    monkeypatch.setattr(config, "MAILBOX_INITIAL_SCAN", 9)
    c = _client(app)
    first = c.get("/").text
    assert "Connect your email" in first and 'href="/mailboxes/connect/gmail"' in first
    assert 'href="/mailboxes/connect/microsoft"' in first and 'class="msgs"' not in first
    FakeIMAP.reset(9)
    for uid in (2, 5, 9):
        FakeIMAP.messages[uid] = _mail(uid, phish=True)
    _connect(c)
    mb = db.list_mailboxes(ids["alice"])[0]["id"]
    _visit(mb)
    home = c.get("/").text
    assert "Connect your email" not in home and "Page 1 of 3" in home and home.count('class="msg ') == 4
    assert home.index("#9") < home.index("#8") < home.index("#7")            # newest first
    danger = c.get("/?f=danger").text
    assert danger.count('class="msg ') == 3 and "paypa1-secure.tk" in danger and "Marko" not in danger
    low = c.get("/?f=low&p=2").text
    assert low.count('class="msg ') == 2 and "Page 2 of 2" in low
    assert c.get("/?f=nonsense&p=999&m=4242").status_code == 200             # junk parameters are harmless
    assert c.get("/?m=%d" % mb).text.count('class="msg ') == 4
    st = json.loads(c.get("/api/status").text)
    assert st["latest"] > 0 and st["busy"] is False and st["boxes"] == [{"id": mb, "status": "ok"}]
    assert c.get("/history", follow_redirects=False).headers["location"] == "/"


def test_overview_shows_the_main_reason_and_escapes_what_the_sender_wrote(env):
    from webapp import db
    app, ids = env
    FakeIMAP.reset(0)
    FakeIMAP.messages[1] = (b'From: "<script>alert(1)</script>" <x@paypa1-secure.tk>\r\nTo: you@example.com\r\n'
                            b"Subject: <img src=x onerror=alert(2)> verify your account\r\n"
                            b"Authentication-Results: mx; spf=fail; dkim=fail; dmarc=fail\r\n"
                            b"MIME-Version: 1.0\r\nContent-Type: text/plain\r\n\r\n"
                            b"Verify your password now: http://paypa1-secure.tk/login\r\n")
    c = _client(app)
    _connect(c)
    _visit(db.list_mailboxes(ids["alice"])[0]["id"])
    home = c.get("/").text
    assert "<script>alert(1)" not in home and "<img src=x" not in home
    assert "&lt;script&gt;" in home and "msg-reason" in home
    page = c.get("/r/" + db.list_scans(ids["alice"])[0]["id"]).text
    assert "<img src=x" not in page and "Received" in page and ">mailbox<" in page


def test_manual_check_still_works_from_its_own_page(env):
    from webapp import db
    app, ids = env
    c = _client(app)
    page = c.get("/check").text
    assert 'action="/scan"' in page and 'type="file"' in page
    r = c.post("/scan", data={"csrf": _csrf(c, "/"), "raw": _mail(1, phish=True).decode()}, follow_redirects=False)
    assert r.headers["location"].startswith("/r/")
    r = c.post("/scan", data={"csrf": _csrf(c, "/")}, follow_redirects=False)
    assert r.headers["location"] == "/check"
    home = c.get("/").text                       # no mailbox yet: onboarding AND the manual result
    assert "Connect your email" in home and home.count('class="msg ') == 1 and ">text<" in home
    assert db.get_user(ids["alice"])["credits"] == 9


def test_admin_sees_mailboxes_without_secrets(env):
    from webapp import db
    app, ids = env
    a = _client(app, "alice")
    _connect(a)
    box = db.list_mailboxes(ids["alice"])[0]
    adm = _client(app, "admin")
    page = adm.get("/admin").text
    assert "alice@gmail.com" in page and "Connected mailboxes" in page
    assert box["secret"] not in page and box["secret"][3:20] not in page and FakeIMAP.password not in page
    assert "secret" not in db.all_mailboxes()[0].keys()
    assert a.get("/admin").status_code == 403


def test_pages_carry_no_inline_script_or_style_so_the_strict_csp_holds(env):
    app, ids = env
    for path in sorted(glob.glob(os.path.join(ROOT, "webapp", "templates", "*.html"))):
        html = open(path, encoding="utf-8").read()
        assert not re.search(r"\sstyle\s*=", html), path
        assert not re.search(r"\son[a-z]+\s*=", html), path
        assert not re.search(r"<script(?![^>]*\ssrc=)", html), path
        assert not re.search(r"<style", html), path
        assert not re.search(r"""(src|href)=["']https?://""", html.replace("{{ p.link }}", "")), path
    css = open(os.path.join(ROOT, "webapp", "static", "style.css"), encoding="utf-8").read()
    assert "url(" not in css and "@import" not in css
    c = _client(app)
    r = c.get("/")
    assert "script-src 'self'" in r.headers["content-security-policy"]
    assert c.get("/static/app.js").status_code == 200 and c.get("/static/style.css").status_code == 200


def test_external_provider_link_opens_without_passing_our_address(env):
    app, ids = env
    page = _client(app).get("/mailboxes/connect/gmail").text
    assert 'href="https://myaccount.google.com/apppasswords" target="_blank" rel="noopener noreferrer"' in page
    assert 'autocomplete="new-password"' in page


# ================================================================== database upgrade
def test_database_of_the_previous_version_is_upgraded_in_place(tmp_path, monkeypatch):
    from webapp import config, db
    path = str(tmp_path / "old.db")
    con = sqlite3.connect(path)
    con.executescript("""
        CREATE TABLE users (id INTEGER PRIMARY KEY AUTOINCREMENT, email TEXT NOT NULL UNIQUE COLLATE NOCASE,
            password_hash TEXT NOT NULL, is_admin INTEGER NOT NULL DEFAULT 0, credits INTEGER NOT NULL DEFAULT 0,
            created_at REAL NOT NULL, disabled INTEGER NOT NULL DEFAULT 0);
        CREATE TABLE scans (id TEXT PRIMARY KEY, user_id INTEGER NOT NULL REFERENCES users(id), created_at REAL NOT NULL,
            source TEXT NOT NULL, mode TEXT NOT NULL, subject TEXT, sender TEXT, score REAL NOT NULL, level TEXT NOT NULL,
            result_json TEXT NOT NULL, text TEXT, cost INTEGER NOT NULL DEFAULT 0);
        CREATE INDEX ix_scans_user ON scans(user_id, created_at DESC);
        CREATE TABLE feedback (id INTEGER PRIMARY KEY AUTOINCREMENT, scan_id TEXT NOT NULL UNIQUE REFERENCES scans(id),
            user_id INTEGER NOT NULL REFERENCES users(id), label INTEGER NOT NULL, text TEXT NOT NULL, comment TEXT,
            created_at REAL NOT NULL, exported INTEGER NOT NULL DEFAULT 0);
        CREATE TABLE events (key TEXT NOT NULL, ts REAL NOT NULL);
        INSERT INTO users(email, password_hash, credits, created_at) VALUES ('old@example.com', 'x', 7, 1);
        INSERT INTO scans VALUES ('abc', 1, 1700000000, 'upload', 'quick', 'Old subject', 'a@b.c', 12.0, 'LOW',
            '{"score": 12.0, "level": "LOW", "signals": []}', NULL, 1);
    """)
    con.commit()
    con.close()
    monkeypatch.setattr(config, "DB_PATH", path)
    monkeypatch.setattr(db, "_initialized_for", None)
    db.init()
    monkeypatch.setattr(db, "_initialized_for", None)
    db.init()                                                    # running it again changes nothing
    rows = db.list_scans(1, with_result=True)
    assert len(rows) == 1 and rows[0]["subject"] == "Old subject" and rows[0]["mailbox_id"] is None
    assert rows[0]["shown_at"] == 1700000000 and db.get_user(1)["credits"] == 7
    assert db.level_counts(1) == {"LOW": 1, "SUSPICIOUS": 0, "HIGH": 0, "CRITICAL": 0}
    assert db.list_mailboxes(1) == [] and db.due_mailboxes() == []


# ================================================================== Microsoft (Outlook)
class FakeMicrosoft:
    """Token endpoint + Graph as Microsoft documents them; records every request."""

    def __init__(self):
        self.calls, self.codes, self.refresh_tokens = [], {}, {"rt-1"}
        self.access = {"at-1"}
        self.n_tokens = 1
        self.address = "amra@outlook.com"
        self.inbox = []                 # [{"id", "receivedDateTime", "raw"}], any order
        self.token_error = None         # (status, {"error": ...})
        self.graph_status = None        # (status, headers) for the next Graph call
        self.rotate = True

    def add(self, n, minute, phish=False, raw=None):
        self.inbox.append({"id": f"AAMk-{n}", "receivedDateTime": f"2026-11-23T10:{minute:02d}:00Z",
                           "raw": raw or _mail(n, phish=phish)})

    def issue_code(self, challenge):
        code = f"code-{len(self.codes) + 1}"
        self.codes[code] = challenge
        return code

    # -- requests.post
    def post(self, url, data=None, timeout=None):
        self.calls.append(("POST", url, dict(data)))
        assert url == "https://login.microsoftonline.com/common/oauth2/v2.0/token"
        assert timeout
        if self.token_error:
            return _Resp(self.token_error[0], self.token_error[1])
        if data["client_id"] != "client-123" or data["client_secret"] != "s3cret":
            return _Resp(401, {"error": "invalid_client", "error_description": "AADSTS7000215: bad secret"})
        if data["grant_type"] == "authorization_code":
            challenge = self.codes.pop(data["code"], None)
            calc = base64.urlsafe_b64encode(hashlib.sha256(data["code_verifier"].encode()).digest()).decode().rstrip("=")
            if challenge is None or calc != challenge or \
                    data["redirect_uri"] != "https://antiphish.example.com/mailboxes/microsoft/callback":
                return _Resp(400, {"error": "invalid_grant", "error_description": "AADSTS70000: bad code"})
        elif data["grant_type"] == "refresh_token":
            if data["refresh_token"] not in self.refresh_tokens:
                return _Resp(400, {"error": "invalid_grant", "error_description": "AADSTS70008: expired"})
        else:
            return _Resp(400, {"error": "unsupported_grant_type"})
        self.n_tokens += 1
        at, rt = f"at-{self.n_tokens}", (f"rt-{self.n_tokens}" if self.rotate else data.get("refresh_token", "rt-1"))
        self.access.add(at)
        self.refresh_tokens.add(rt)
        return _Resp(200, {"token_type": "Bearer", "expires_in": 3599, "access_token": at, "refresh_token": rt,
                           "scope": "Mail.Read User.Read"})

    # -- requests.get
    def get(self, url, params=None, stream=False, timeout=None, headers=None):
        self.calls.append(("GET", url, dict(params or {}), dict(headers or {})))
        assert url.startswith("https://graph.microsoft.com/v1.0/") and timeout
        if self.graph_status:
            status, hdrs = self.graph_status
            self.graph_status = None
            return _Resp(status, {"error": {"code": "x"}}, hdrs)
        if headers.get("Authorization", "")[7:] not in self.access:
            return _Resp(401, {"error": {"code": "InvalidAuthenticationToken"}})
        path = url[len("https://graph.microsoft.com/v1.0"):]
        if path == "/me":
            return _Resp(200, {"mail": None, "userPrincipalName": self.address.upper()})
        if path == "/me/mailFolders/inbox/messages":
            items = sorted(self.inbox, key=lambda m: m["receivedDateTime"])
            flt = params.get("$filter")
            if flt:
                cut = re.fullmatch(r"receivedDateTime ge (\S+)", flt).group(1)
                items = [m for m in items if m["receivedDateTime"] >= cut]
                assert params["$orderby"] == "receivedDateTime asc"
            else:
                assert params["$orderby"] == "receivedDateTime desc"
                items = items[::-1]
            items = items[:int(params["$top"])]
            return _Resp(200, {"value": [{"id": m["id"], "receivedDateTime": m["receivedDateTime"]} for m in items]})
        m = re.fullmatch(r"/me/messages/([^/]+)/\$value", path)
        if m:
            hit = [x for x in self.inbox if x["id"] == m.group(1)]
            return _Resp(200, raw=hit[0]["raw"]) if hit else _Resp(404, {"error": {"code": "ErrorItemNotFound"}})
        return _Resp(400, {"error": {"code": "BadRequest"}})


class _Resp:
    def __init__(self, status, body=None, headers=None, raw=None):
        self.status_code, self._body, self.headers, self._raw = status, body, headers or {}, raw
        self.text = json.dumps(body) if body is not None else ""

    def json(self):
        if self._body is None:
            raise ValueError("no json")
        return self._body

    def iter_content(self, size):
        for i in range(0, len(self._raw), size):
            yield self._raw[i:i + size]

    def close(self):
        pass


@pytest.fixture()
def ms(env, monkeypatch):
    from webapp import config, msgraph
    fake = FakeMicrosoft()
    monkeypatch.setattr(config, "MS_CLIENT_ID", "client-123")
    monkeypatch.setattr(config, "MS_CLIENT_SECRET", "s3cret")
    monkeypatch.setattr(config, "MS_TENANT", "common")
    monkeypatch.setattr(config, "MS_LOGIN_BASE", "https://login.microsoftonline.com")
    monkeypatch.setattr(config, "MS_GRAPH_BASE", "https://graph.microsoft.com/v1.0")
    monkeypatch.setattr(msgraph.requests, "post", fake.post)
    monkeypatch.setattr(msgraph.requests, "get", fake.get)
    return fake


def _ms_signin(c, fake):
    """Start the sign-in and play Microsoft's part: -> (state, code)."""
    r = c.get("/mailboxes/microsoft/start", follow_redirects=False)
    assert r.status_code == 303
    url = urlparse(r.headers["location"])
    q = {k: v[0] for k, v in parse_qs(url.query).items()}
    return url, q, fake.issue_code(q["code_challenge"])


def _ms_box(user_id, addr="amra@outlook.com", refresh="rt-1"):
    from webapp import crypto, db, mailboxes
    return db.create_mailbox(user_id, addr, "microsoft", "graph",
                             crypto.encrypt(refresh, mailboxes.secret_aad(user_id, addr)))


def test_outlook_without_app_registration_explains_instead_of_asking_for_a_password(env):
    app, ids = env
    c = _client(app)
    page = c.get("/mailboxes/connect/microsoft").text
    assert "not enabled yet" in page and 'type="password"' not in page and "MS_CLIENT_ID" not in page
    assert c.get("/mailboxes/microsoft/start", follow_redirects=False).headers["location"] == "/mailboxes/connect/microsoft"
    adm = _client(app, "admin").get("/mailboxes/connect/microsoft").text
    assert "MS_CLIENT_ID" in adm and "https://antiphish.example.com/mailboxes/microsoft/callback" in adm


def test_microsoft_sign_in_request_follows_the_documented_flow(ms, env):
    app, ids = env
    c = _client(app)
    assert "Continue to Microsoft sign-in" in c.get("/mailboxes/connect/microsoft").text
    url, q, _code = _ms_signin(c, ms)
    assert (url.scheme, url.netloc, url.path) == ("https", "login.microsoftonline.com", "/common/oauth2/v2.0/authorize")
    assert q["client_id"] == "client-123" and q["response_type"] == "code" and q["response_mode"] == "query"
    assert q["redirect_uri"] == "https://antiphish.example.com/mailboxes/microsoft/callback"
    assert set(q["scope"].split()) == {"offline_access", "User.Read", "Mail.Read"}        # read-only mail
    assert q["code_challenge_method"] == "S256" and len(q["code_challenge"]) == 43 and len(q["state"]) >= 24
    assert "client_secret" not in q and "s3cret" not in url.query


def test_microsoft_callback_connects_the_mailbox_and_keeps_the_refresh_token_encrypted(ms, env):
    from webapp import crypto, db, mailboxes
    app, ids = env
    c = _client(app)
    url, q, code = _ms_signin(c, ms)
    r = c.get(f"/mailboxes/microsoft/callback?code={code}&state={q['state']}", follow_redirects=False)
    assert r.status_code == 303 and r.headers["location"] == "/"
    post = [x for x in ms.calls if x[0] == "POST"][0][2]
    assert post["grant_type"] == "authorization_code" and post["client_secret"] == "s3cret"
    assert len(post["code_verifier"]) >= 43
    box = db.list_mailboxes(ids["alice"])[0]
    assert (box["email"], box["provider"], box["kind"], box["status"]) == ("amra@outlook.com", "microsoft", "graph", "new")
    assert box["secret"].startswith("v1:") and "rt-2" not in box["secret"]
    assert crypto.decrypt(box["secret"], mailboxes.secret_aad(ids["alice"], "amra@outlook.com")) == "rt-2"
    assert "amra@outlook.com" in c.get("/").text
    # the same answer cannot be replayed
    r = c.get(f"/mailboxes/microsoft/callback?code={code}&state={q['state']}", follow_redirects=True)
    assert "was not completed" in r.text and db.count_mailboxes(ids["alice"]) == 1


def test_microsoft_callback_is_refused_without_the_matching_state(ms, env):
    from webapp import db
    app, ids = env
    victim, attacker = _client(app, "alice"), _client(app, "bob")
    url, q, code = _ms_signin(attacker, ms)
    # the attacker's code + state, opened in the victim's browser: must not attach anything
    r = victim.get(f"/mailboxes/microsoft/callback?code={code}&state={q['state']}", follow_redirects=True)
    assert "was not completed" in r.text and db.count_mailboxes(ids["alice"]) == 0
    _ms_signin(victim, ms)
    r = victim.get(f"/mailboxes/microsoft/callback?code={code}&state=guess", follow_redirects=True)
    assert "was not completed" in r.text and db.count_mailboxes(ids["alice"]) == 0
    assert not [x for x in ms.calls if x[0] == "POST"]             # the code was never sent anywhere
    anon = TestClient(app)
    assert anon.get(f"/mailboxes/microsoft/callback?code={code}&state={q['state']}",
                    follow_redirects=False).headers["location"] == "/login"


def test_microsoft_callback_reports_denied_consent_and_expired_sign_in(ms, env, monkeypatch):
    from webapp import db
    app, ids = env
    c = _client(app)
    url, q, code = _ms_signin(c, ms)
    r = c.get(f"/mailboxes/microsoft/callback?error=access_denied&error_description=<b>x</b>&state={q['state']}",
              follow_redirects=True)
    assert "not approved" in r.text and "<b>x</b>" not in r.text
    url, q, code = _ms_signin(c, ms)
    real = time.time
    monkeypatch.setattr(time, "time", lambda: real() + 1000)
    r = c.get(f"/mailboxes/microsoft/callback?code={code}&state={q['state']}", follow_redirects=True)
    monkeypatch.setattr(time, "time", real)
    assert "was not completed" in r.text and db.count_mailboxes(ids["alice"]) == 0


def test_microsoft_wrong_client_secret_is_reported_as_a_setup_problem(ms, env, monkeypatch, caplog):
    from webapp import config, db
    app, ids = env
    monkeypatch.setattr(config, "MS_CLIENT_SECRET", "expired-secret")
    c = _client(app)
    url, q, code = _ms_signin(c, ms)
    with caplog.at_level("WARNING"):
        r = c.get(f"/mailboxes/microsoft/callback?code={code}&state={q['state']}", follow_redirects=True)
    assert "MS_CLIENT_SECRET" in r.text and db.count_mailboxes(ids["alice"]) == 0
    assert "AADSTS7000215" in caplog.text and "expired-secret" not in caplog.text


def test_outlook_first_visit_then_only_new_mail(ms, env):
    from webapp import db
    app, ids = env
    for n in range(1, 7):
        ms.add(n, n, phish=(n == 5))
    mb = _ms_box(ids["alice"])
    assert _visit(mb) == "ok:3"
    rows = db.list_scans(ids["alice"])
    assert sorted(r["subject"][-1] for r in rows) == ["4", "5", "6"]
    assert rows[0]["msg_date"] == 1795428360.0 and rows[0]["source"] == "mailbox"      # 2026-11-23T10:06:00Z
    assert db.get_mailbox(mb)["cursor"] == "2026-11-23T10:06:00Z"
    downloads = len([x for x in ms.calls if x[1].endswith("/$value")])
    assert downloads == 3
    assert _visit(mb) == "ok:0" and _n_scans(ids["alice"]) == 3
    assert len([x for x in ms.calls if x[1].endswith("/$value")]) == downloads     # nothing fetched twice
    ms.add(7, 6)                      # same second as the last one already checked
    ms.add(8, 9, phish=True)
    assert _visit(mb) == "ok:2" and _n_scans(ids["alice"]) == 5
    assert _visit(mb) == "ok:0"
    gets = [x for x in ms.calls if x[0] == "GET"]
    assert all(x[3].get("Prefer") == 'IdType="ImmutableId"' for x in gets)
    assert all(x[1].startswith("https://graph.microsoft.com/v1.0/me/") for x in gets)   # read calls only
    assert not [x for x in ms.calls if x[0] == "POST" and "graph" in x[1]]


def test_outlook_rotated_refresh_token_is_stored_and_access_token_is_reused(ms, env):
    from webapp import crypto, db, mailboxes
    app, ids = env
    ms.add(1, 1)
    mb = _ms_box(ids["alice"])
    _visit(mb)
    aad = mailboxes.secret_aad(ids["alice"], "amra@outlook.com")
    assert crypto.decrypt(db.get_mailbox(mb)["secret"], aad) == "rt-2"
    _visit(mb)
    _visit(mb)
    assert len([x for x in ms.calls if x[0] == "POST"]) == 1               # one token request for three visits


def test_outlook_expired_access_token_is_renewed_once(ms, env):
    from webapp import db, mailbox_worker
    app, ids = env
    ms.add(1, 1)
    mb = _ms_box(ids["alice"])
    _visit(mb)
    ms.access.clear()                                        # Microsoft no longer accepts the old access token
    ms.add(2, 2)
    assert _visit(mb) == "ok:1"
    assert len([x for x in ms.calls if x[0] == "POST"]) == 2
    assert mailbox_worker._tokens[mb]["access_token"] in ms.access and db.get_mailbox(mb)["status"] == "ok"


def test_outlook_revoked_access_waits_for_the_owner(ms, env):
    from webapp import db
    app, ids = env
    mb = _ms_box(ids["alice"], refresh="rt-revoked")
    assert _visit(mb) == "reauth"
    box = db.get_mailbox(mb)
    assert box["status"] == "reauth" and "Reconnect the mailbox" in box["status_detail"]
    assert mb not in db.due_mailboxes()
    c = _client(app)
    assert 'href="/mailboxes/connect/microsoft?email=amra%40outlook.com"' in c.get("/").text


def test_outlook_throttling_waits_as_long_as_microsoft_asks(ms, env):
    from webapp import db
    app, ids = env
    ms.add(1, 1)
    mb = _ms_box(ids["alice"])
    _visit(mb)
    ms.graph_status = (429, {"Retry-After": "240"})
    assert _visit(mb) == "throttled"
    box = db.get_mailbox(mb)
    assert box["status"] == "ok" and 230 <= box["next_check"] - time.time() <= 245


def test_outlook_oversized_or_vanished_message_is_skipped(ms, env, monkeypatch):
    from webapp import config, db
    app, ids = env
    monkeypatch.setattr(config, "MAX_UPLOAD_MB", 1)
    ms.add(1, 1)
    ms.add(2, 2, raw=b"From: a@b.c\r\nSubject: big\r\n\r\n" + b"x" * (2 * 1024 * 1024))
    ms.add(3, 3)
    mb = _ms_box(ids["alice"])
    assert _visit(mb) == "ok:2" and db.get_mailbox(mb)["cursor"] == "2026-11-23T10:03:00Z"
    assert sorted(r["subject"][-1] for r in db.list_scans(ids["alice"])) == ["1", "3"]


def test_graph_requests_never_leave_the_graph_server(ms, env):
    from webapp import msgraph
    with pytest.raises(msgraph.MailboxError):
        msgraph._get("https://evil.example.net/v1.0/me", "at-1")
    with pytest.raises(msgraph.MailboxError):
        msgraph._get("https://graph.microsoft.com.evil.example.net/v1.0/me", "at-1")
    assert not ms.calls


def test_disconnecting_outlook_forgets_tokens(ms, env):
    from webapp import db, mailbox_worker
    app, ids = env
    c = _client(app)
    url, q, code = _ms_signin(c, ms)
    c.get(f"/mailboxes/microsoft/callback?code={code}&state={q['state']}")
    mb = db.list_mailboxes(ids["alice"])[0]["id"]
    assert mb in mailbox_worker._tokens
    r = c.post(f"/mailboxes/{mb}/disconnect", data={"csrf": _csrf(c, "/")}, follow_redirects=True)
    assert "has been disconnected" in r.text and mb not in mailbox_worker._tokens and db.get_mailbox(mb) is None


# ================================================================== sandbox worker and the server's sockets
def test_sandbox_worker_does_not_keep_the_servers_connections_open():
    """Found with a real browser: the page stopped answering some seconds after a mail
    with an attachment had been scanned. The forked attachment worker held a copy of
    the browser's connection, so the server's close() never reached the browser."""
    from antiphish import attachment_scan as a
    a.shutdown_sandbox()
    srv = socket.socket()
    srv.bind(("127.0.0.1", 0))
    srv.listen(1)
    cli = socket.create_connection(srv.getsockname())
    conn, _ = srv.accept()
    try:
        assert a._get_pool().submit(int, "1").result(timeout=60) == 1    # worker starts while connected
        conn.close()                                   # the server ends the connection ...
        cli.settimeout(5)
        assert cli.recv(1) == b""                      # ... and the other side is told (no endless wait)
    finally:
        cli.close()
        srv.close()
        a.shutdown_sandbox()


def _socket_fds():
    import stat
    out = []
    for name in os.listdir("/proc/self/fd"):
        try:
            if int(name) > 2 and stat.S_ISSOCK(os.fstat(int(name)).st_mode):
                out.append(int(name))
        except OSError:
            pass
    return out


@pytest.mark.skipif(not os.path.isdir("/proc/self/fd"), reason="Linux only (workers are forked there)")
def test_sandbox_worker_holds_no_inherited_socket_and_still_scans():
    from antiphish import attachment_scan as a
    a.shutdown_sandbox()
    srv = socket.socket()
    srv.bind(("127.0.0.1", 0))
    srv.listen(1)
    try:
        assert _socket_fds()                           # the parent has one ...
        assert a._get_pool().submit(_socket_fds).result(timeout=60) == []      # ... the worker none
        signals, findings = a.analyze_attachment_isolated("faktura.pdf.exe", b"MZ" + b"\x00" * 200, use_model=False)
        assert any(s["signal"].startswith("attachment_") for s in signals)   # and it works as before
    finally:
        srv.close()
        a.shutdown_sandbox()


# ================================================================== packaging
def test_release_files_know_about_the_new_feature():
    env_example = open(os.path.join(ROOT, ".env.example"), encoding="utf-8").read()
    for key in ("COST_MAILBOX", "MAILBOX_POLL_SECONDS", "MS_CLIENT_ID", "MS_CLIENT_SECRET", "MAILBOX_KEY"):
        assert key in env_example, key
    req = open(os.path.join(ROOT, "requirements-server.txt"), encoding="utf-8").read()
    pins = open(os.path.join(ROOT, "constraints-server.txt"), encoding="utf-8").read()
    assert re.search(r"^cryptography", req, re.M) and re.search(r"^cryptography==", pins, re.M)
    guide = open(os.path.join(ROOT, "deploy", "DEPLOY.md"), encoding="utf-8").read()
    assert "/mailboxes/microsoft/callback" in guide and "apppasswords" in guide

