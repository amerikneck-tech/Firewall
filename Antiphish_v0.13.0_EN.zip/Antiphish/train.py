"""Train the production model.

    python scripts/build_corpus.py   # once: download public corpora -> data/corpus.csv
    python train.py                  # train on corpus + starter + data/feedback.csv
    python evaluate.py               # how good is it? (held-out protocol, see evaluation.py)

The model file gets two sidecars: <model>.sha256 (integrity, checked on load)
and <model>.meta.json (what it was trained on - the "model card").
"""
import json
import os
import sys
import time

from antiphish.config import MODEL_PATH
from antiphish.model import CORPUS_PATH, dataset_summary, save_model, train

if __name__ == "__main__":
    if not os.path.exists(CORPUS_PATH):
        print("WARNING: data/corpus.csv not found - training on the small starter set only.\n"
              "         Run: python scripts/build_corpus.py")
    summary = dataset_summary()
    print(f"Training on {summary['total']} texts ({summary['phishing']} phishing / {summary['legit']} legit)")
    for src, c in summary["by_source"].items():
        print(f"   {src:16s} phishing {c['phishing']:6d}   legit {c['legit']:6d}")
    t0 = time.time()
    pipe = train()
    os.makedirs(os.path.dirname(os.path.abspath(MODEL_PATH)), exist_ok=True)
    meta = {"training_data": summary, "train_seconds": round(time.time() - t0, 1)}
    manifest = os.path.join(os.path.dirname(os.path.abspath(CORPUS_PATH)), "corpus_manifest.json")
    if os.path.exists(manifest):
        try:
            with open(manifest, encoding="utf-8") as f:
                m = json.load(f)
            meta["corpus"] = {k: m.get(k) for k in ("built_at", "emails", "phishing", "legit",
                                                    "by_source", "missing_files")}
        except (OSError, ValueError):
            pass
    save_model(pipe, MODEL_PATH, meta=meta)
    print(f"Model trained in {meta['train_seconds']}s and saved to {MODEL_PATH} (+ .sha256, .meta.json)")
    if "--no-eval" not in sys.argv and not summary["corpus_present"]:
        print("NOTE: this is the starter model. It is much weaker than the corpus model.")
