#!/usr/bin/env bash
# AntiPhish - server check. Changes nothing, only reads and prints what is OK and what isn't.
#
#   bash deploy/provjera.sh before     # BEFORE "docker compose up": server, .env, DNS, ports, internet
#   bash deploy/provjera.sh after      # AFTER: containers, HTTPS, certificate, headers, model, mailboxes
#
# Run it from the project folder (e.g. /opt/antiphish). Exit code 0 = no errors.
# (The old mode names "prije" and "poslije" still work.)
set -u
cd "$(dirname "$0")/.." || exit 2

MODE="${1:-}"
OK=0; WARN=0; FAIL=0
DOMAIN_OK=0      # becomes 1 when check_env confirms DOMAIN in .env is filled in correctly
ok()   { OK=$((OK + 1));     printf '  [ OK ]  %s\n' "$*"; }
warn() { WARN=$((WARN + 1)); printf '  [ ?? ]  %s\n' "$*"; }
bad()  { FAIL=$((FAIL + 1)); printf '  [ERROR] %s\n' "$*"; }
note() { printf '          %s\n' "$*"; }
have() { command -v "$1" >/dev/null 2>&1; }

# value from .env (without quotes); empty if it doesn't exist
envval() {
  [ -f .env ] || return 0
  grep -E "^$1=" .env | tail -n 1 | cut -d= -f2- | sed -e 's/[[:space:]]*$//' -e "s/^'\(.*\)'$/\1/" -e 's/^"\(.*\)"$/\1/'
}

resolve4() {   # A records of the domain (one per line)
  if have dig; then dig +short A "$1" 2>/dev/null | grep -E '^[0-9.]+$'
  else getent ahostsv4 "$1" 2>/dev/null | awk '{print $1}' | sort -u; fi
}
resolve6() {
  if have dig; then dig +short AAAA "$1" 2>/dev/null | grep ':'
  else getent ahostsv6 "$1" 2>/dev/null | awk '{print $1}' | grep -v '^::ffff:' | sort -u; fi
}
public_ip() {
  local ip
  for url in https://api.ipify.org https://ifconfig.me/ip https://icanhazip.com; do
    ip=$(curl -4 -fsS -m 6 "$url" 2>/dev/null | tr -d '[:space:]')
    if printf '%s' "$ip" | grep -Eq '^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+$'; then printf '%s' "$ip"; return 0; fi
  done
  return 1
}
port_busy() {    # 0 = something is listening on TCP port $1
  if have ss; then ss -H -ltn 2>/dev/null | awk '{print $4}' | grep -Eq "[:.]$1\$"; return $?; fi
  (exec 3<>"/dev/tcp/127.0.0.1/$1") 2>/dev/null
}
port_owner() {   # who is listening on port $1 (may stay empty)
  if have ss; then ss -H -ltnp 2>/dev/null | awk -v p="[:.]$1\$" '$4 ~ p {print $NF}' | head -n 1; fi
}

check_mtu() {
  # Docker networks default to MTU 1500. Some cloud servers have a smaller one (Google Cloud: 1460). Then large
  # packets from the container depend on the network returning ICMP "fragmentation needed"; if it doesn't, downloads
  # in the build or Caddy's certificate request can hang. Two commands fix that.
  have ip || return 0
  UPIF=$(ip -4 route show default 2>/dev/null | awk '{for (i = 1; i <= NF; i++) if ($i == "dev") {print $(i + 1); exit}}')
  [ -n "$UPIF" ] || return 0
  UPMTU=$(ip -o link show dev "$UPIF" 2>/dev/null | sed -n 's/.* mtu \([0-9][0-9]*\).*/\1/p' | head -n 1)
  [ -n "$UPMTU" ] || return 0
  DMTU=$(docker network inspect bridge -f '{{index .Options "com.docker.network.driver.mtu"}}' 2>/dev/null | grep -E '^[0-9]+$' || true)
  DMTU=${DMTU:-1500}
  if [ "$UPMTU" -ge 1500 ] || [ "$DMTU" -le "$UPMTU" ]; then
    ok "server network MTU $UPMTU, Docker $DMTU"
    return 0
  fi
  warn "the server network has MTU $UPMTU, but Docker uses $DMTU (typical for Google Cloud). It often works anyway,"
  note "but downloads in the build or certificate issuance can hang. Align them before the build:"
  if [ -f /etc/docker/daemon.json ]; then
    note "add to the existing /etc/docker/daemon.json:  \"mtu\": $UPMTU, \"default-network-opts\": {\"bridge\": {\"com.docker.network.driver.mtu\": \"$UPMTU\"}}"
  else
    note "echo '{\"mtu\": $UPMTU, \"default-network-opts\": {\"bridge\": {\"com.docker.network.driver.mtu\": \"$UPMTU\"}}}' > /etc/docker/daemon.json"
  fi
  note "systemctl restart docker      (if AntiPhish is already running, afterwards:  docker compose down && docker compose up -d)"
}

check_env() {
  echo "== .env"
  if [ ! -f .env ]; then
    bad ".env does not exist. Run:  cp .env.example .env  then fill it in (DEPLOY.md, step 4)."
    return
  fi
  DOMAIN=$(envval DOMAIN); BASE_URL=$(envval BASE_URL); SECRET=$(envval SECRET_KEY)
  if [ -z "$DOMAIN" ] || [ "$DOMAIN" = "antiphish.example.com" ]; then
    bad "DOMAIN is not set (it still shows the example). Enter your subdomain, e.g. antiphish.yourdomain.com"
  elif printf '%s' "$DOMAIN" | grep -Eq '://|/|[[:space:]]'; then
    bad "DOMAIN must be just the name (no https:// and no slash): $DOMAIN"
  else
    DOMAIN_OK=1
    ok "DOMAIN=$DOMAIN"
  fi
  if [ "$DOMAIN_OK" = 1 ]; then
    if [ "$BASE_URL" = "https://$DOMAIN" ]; then
      ok "BASE_URL=$BASE_URL"
    else
      bad "BASE_URL must be exactly https://$DOMAIN (now: '${BASE_URL:-empty}')"
      note "If it doesn't start with https://, sign-in won't work properly (session cookie)."
    fi
  elif ! printf '%s' "$BASE_URL" | grep -q '^https://'; then
    bad "BASE_URL must start with https:// (now: '${BASE_URL:-empty}')"
  fi
  if [ "${#SECRET}" -ge 32 ]; then
    ok "SECRET_KEY is set (${#SECRET} characters)"
  else
    bad "SECRET_KEY is empty or too short. Generate:  python3 -c \"import secrets; print(secrets.token_urlsafe(48))\"   (or: openssl rand -hex 32)"
  fi
  PERM=$(stat -c '%a' .env 2>/dev/null || echo "")
  if [ "$PERM" = "600" ]; then ok ".env is readable only by the owner (600)"
  else warn ".env has permissions ${PERM:-?} - recommended:  chmod 600 .env"; fi
  IU=$(envval INTAKE_USER); IP_RAW=$(grep -E '^INTAKE_PASSWORD=' .env | tail -n 1 | cut -d= -f2-)
  if [ -n "$IU" ]; then
    if [ -z "$IP_RAW" ]; then
      bad "INTAKE_USER is set, but INTAKE_PASSWORD is empty."
    elif printf '%s' "$IP_RAW" | grep -q "^'.*'\$"; then
      ok "INTAKE_PASSWORD is in single quotes"
    elif printf '%s' "$IP_RAW" | grep -Eq '[$#[:space:]"]'; then
      bad "INTAKE_PASSWORD contains \$, #, a space or a quote, and is not in 'single quotes' - Docker would cut it off."
      note "Write:  INTAKE_PASSWORD='your-password'"
    else
      ok "INTAKE_PASSWORD is set"
    fi
  fi
  if [ "$(envval WEB_ALLOW_LLM)" = "1" ]; then
    warn "WEB_ALLOW_LLM=1 - keep 0 for the first test; enable AI only once the basics work (DEPLOY.md, step 8)."
  fi
}

check_dns() {
  echo "== DNS"
  DOMAIN=$(envval DOMAIN)
  if [ "$DOMAIN_OK" != 1 ]; then
    warn "skipped (fix DOMAIN in .env first)"; return
  fi
  MYIP=$(public_ip || true)
  LOCAL4=$(hostname -I 2>/dev/null | tr ' ' '\n' | grep -E '^[0-9.]+$' || true)   # addresses on the network interfaces
  A=$(resolve4 "$DOMAIN" | tr '\n' ' ' | sed 's/ $//')
  if [ -z "$A" ]; then
    bad "$DOMAIN has no A record (or it hasn't propagated yet). Add an A record in hPanel → Domains → DNS."
    note "Don't start Caddy before this passes - the certificate cannot be issued without DNS."
  elif printf '%s\n' $A | grep -qxF -e "${MYIP:-none}" || { [ -n "$LOCAL4" ] && printf '%s\n' $A | grep -qxF -f <(printf '%s\n' $LOCAL4); }; then
    ok "$DOMAIN → $A (that is this server)"
  elif [ -z "$MYIP" ]; then
    warn "$DOMAIN → $A (I couldn't determine this server's public IP - compare with hPanel → VPS → Overview)"
  else
    bad "$DOMAIN points to $A, but this server is $MYIP. Fix the A record and wait for it to propagate."
  fi
  AAAA=$(resolve6 "$DOMAIN" | tr '\n' ' ' | sed 's/ $//')
  if [ -n "$AAAA" ]; then
    MY6=$(ip -6 addr show scope global 2>/dev/null | awk '/inet6/ {sub(/\/.*/, "", $2); print $2}')
    if [ -n "$MY6" ] && printf '%s\n' $AAAA | grep -qxF "$(printf '%s\n' $MY6 | head -n 1)"; then
      ok "AAAA (IPv6) record points to this server"
    else
      warn "$DOMAIN also has an AAAA (IPv6) record: $AAAA"
      note "If that is NOT this server's address, delete that record - otherwise certificate issuance may fail."
    fi
  fi
}

check_before() {
  echo "== Server"
  if ! have docker; then
    # clean Ubuntu: one command installs both Docker and Compose (verified on Ubuntu 24.04 and 26.04)
    bad "Docker is not installed. Install it (it comes together with Docker Compose):"
    note "apt-get update && apt-get install -y curl && curl -fsSL https://get.docker.com | sh"
    note "then run this check again."
  else
    ok "$(docker --version 2>/dev/null)"
    if docker compose version >/dev/null 2>&1; then ok "$(docker compose version 2>/dev/null | head -n 1)"
    else
      bad "'docker compose' doesn't work (Compose v2 is needed):  apt-get install -y docker-compose-plugin"
      note "(if that package doesn't exist:  apt-get install -y docker-compose-v2)"
    fi
    if docker info >/dev/null 2>&1; then ok "Docker service is running"; check_mtu
    else bad "Docker service is not running or you lack permissions:  systemctl start docker  (and run as root)"; fi
  fi
  have curl || { bad "curl is not installed (this check needs it too):  apt-get update && apt-get install -y curl"; }
  # Training the model in the build needs ~1.25 GB (measured: passes with 1.3 GB, fails with 1 GB without swap;
  # with 0.7 GB RAM + 2 GB swap it passes, but ~5x slower). PROVJERA_MEMINFO exists only for tests.
  MEMINFO="${PROVJERA_MEMINFO:-/proc/meminfo}"
  MEM=$(awk '/^MemTotal/ {printf "%d", $2/1024}' "$MEMINFO" 2>/dev/null || echo 0)
  SWAP=$(awk '/^SwapTotal/ {printf "%d", $2/1024}' "$MEMINFO" 2>/dev/null || echo 0)
  MEM=${MEM:-0}; SWAP=${SWAP:-0}
  swap_howto() {
    note "2 GB of swap (once, survives reboots):"
    note "fallocate -l 2G /swapfile && chmod 600 /swapfile && mkswap /swapfile && swapon /swapfile && echo '/swapfile none swap sw 0 0' >> /etc/fstab"
  }
  if [ "$MEM" -ge 3500 ]; then ok "RAM: ${MEM} MB"
  elif [ $((MEM + SWAP)) -ge 2800 ]; then
    warn "RAM: ${MEM} MB + swap ${SWAP} MB - enough for the build and operation (slower than 4 GB); without Qwen AI."
  elif [ "$MEM" -ge 1700 ]; then
    warn "RAM: ${MEM} MB, swap ${SWAP} MB - the build barely passes (training needs ~1.25 GB). Add swap before the build:"
    swap_howto
  else
    bad "RAM: ${MEM} MB, swap ${SWAP} MB - too little for the build (training needs ~1.25 GB)."
    swap_howto
    note "With 1 GB RAM and that swap the build passes, but slowly; better to get a machine with 2-4 GB."
  fi
  DISK=$(df -Pm . | awk 'NR==2 {print $4}')
  if [ "${DISK:-0}" -ge 6000 ]; then ok "Free disk: $((DISK / 1024)) GB"
  elif [ "${DISK:-0}" -ge 3000 ]; then warn "Free disk: ${DISK} MB (image ~1 GB + ~450 MB temporary during the build) - enough, but tight"
  else bad "Free disk: ${DISK:-?} MB - too little (at least 3 GB needed)"; fi
  echo "== Ports 80 and 443"
  RUNNING=$(docker compose ps -q caddy 2>/dev/null | head -n 1)
  for p in 80 443; do
    if ! port_busy "$p"; then ok "port $p is free"
    elif [ -n "$RUNNING" ]; then ok "port $p is held by AntiPhish (Caddy is already running)"
    else
      who=$(port_owner "$p")
      bad "port $p is taken${who:+ ($who)}"
      note "Something else is already listening (nginx/Apache/Traefik/panel). Either stop it, or use the variant without Caddy (DEPLOY.md, step 5)."
    fi
  done
  check_env
  check_dns
  echo "== Internet access (training data sources for the build)"
  if ! have curl; then warn "skipped (no curl)"; return; fi
  for url in https://monkey.org/~jose/phishing/ https://spamassassin.apache.org/old/publiccorpus/ https://lists.apache.org/ https://www.cs.cmu.edu/~enron/ https://pypi.org/simple/pip/; do
    code=$(curl -sS -o /dev/null -m 15 -w '%{http_code}' -A "Mozilla/5.0 antiphish-provjera" "$url" 2>/dev/null || echo 000)
    host=$(printf '%s' "$url" | awk -F/ '{print $3}')
    case "$code" in
      2*|3*) ok "$host reachable" ;;
      000)   warn "$host is not reachable from this server (the build doesn't stop, but the model is weaker without that source)" ;;
      *)     warn "$host responds $code (check the build log to see whether the source was downloaded)" ;;
    esac
  done
}

check_after() {
  check_env
  DOMAIN=$(envval DOMAIN)
  echo "== Containers"
  if ! docker compose ps >/dev/null 2>&1; then bad "'docker compose ps' doesn't work in this folder"; return; fi
  WEB_UP=0
  for svc in web caddy; do
    cid=$(docker compose ps -q "$svc" 2>/dev/null | head -n 1)
    if [ -z "$cid" ]; then
      if [ "$svc" = caddy ]; then warn "caddy is not running (fine only if you use your own nginx)"; else bad "web container is not running:  docker compose up -d --build"; fi
      continue
    fi
    state=$(docker inspect -f '{{.State.Status}}{{if .State.Health}} {{.State.Health.Status}}{{end}}' "$cid" 2>/dev/null)
    case "$state" in
      "running healthy"|"running") ok "$svc: $state"; [ "$svc" = web ] && WEB_UP=1 ;;
      "running starting")          warn "$svc: still starting - wait a minute and repeat"; [ "$svc" = web ] && WEB_UP=1 ;;
      *)                           bad "$svc: $state  →  docker compose logs --tail 50 $svc" ;;
    esac
  done
  if [ "$WEB_UP" != 1 ]; then
    note "The other checks need a running web container - fix that first."
    return
  fi
  check_mtu
  icid=$(docker compose ps -q intake 2>/dev/null | head -n 1)
  if [ -n "$icid" ]; then
    if docker compose logs --tail 40 intake 2>/dev/null | grep -Eq 'login as .* was refused|could not be verified'; then
      bad "intake: sign-in to the scan@ mailbox fails  →  docker compose logs --tail 20 intake"
    else ok "intake is running ($(docker inspect -f '{{.State.Status}}' "$icid"))"; fi
  fi
  BIND=$(docker compose port web 8000 2>/dev/null | head -n 1)
  case "$BIND" in
    127.0.0.1:*) ok "the application (port 8000) is not exposed to the internet - only $BIND" ;;
    "")          warn "cannot read which address port 8000 is bound to" ;;
    *)           bad "port 8000 is open to the internet ($BIND) - docker-compose.yml must say 127.0.0.1:8000:8000" ;;
  esac

  echo "== Model"
  CARD=$(docker compose exec -T web python -c "
import json
m = json.load(open('/app/data/models/model.joblib.meta.json'))
t = m.get('training_data') or {}
print(t.get('total', 0), 1 if t.get('corpus_present') else 0, len((m.get('corpus') or {}).get('missing_files') or []), m.get('feedback_rows', 0))
" 2>/dev/null | tail -n 1)
  if [ -z "$CARD" ]; then
    bad "model not found in /app/data/models  →  docker compose logs web"
  else
    set -- $CARD
    if [ "$2" = 1 ] && [ "$1" -ge 15000 ]; then
      FB=""; [ "${4:-0}" -gt 0 ] 2>/dev/null && FB=", including feedback: $4 rows"
      ok "model trained on the full corpus ($1 texts$FB)"
      if [ "$3" -gt 0 ]; then
        warn "$3 source files were missing when the corpus was built - the model is somewhat weaker"
        note "Repeat later:  docker compose build --no-cache web && docker compose up -d"
        note "then fold the new corpus into the model:  docker compose exec -u app web python -m antiphish.learn"
      fi
    else
      bad "the model is only the STARTER one ($1 texts) - much weaker. The corpus download in the build failed."
      note "Repeat:  docker compose build --no-cache web && docker compose up -d"
      note "(when the build succeeds, the container replaces the starter model with the real one at startup)"
    fi
  fi
  SC=$(docker compose exec -T web python -c "
from antiphish.scenarios import run_scenarios
s = run_scenarios()['summary']
print(sum(v['LOW'] for k, v in s.items() if k.endswith('legit')), sum(v['n'] for k, v in s.items() if k.endswith('legit')),
      sum(v['HIGH'] + v['CRITICAL'] for k, v in s.items() if k.endswith('phish')), sum(v['n'] for k, v in s.items() if k.endswith('phish')))
" 2>/dev/null | tail -n 1)
  if [ -n "$SC" ]; then
    set -- $SC
    if [ "$1" -ge $(( $2 - 2 )) ] && [ "$3" -ge $(( $4 - 2 )) ]; then
      ok "built-in test: legitimate emails $1/$2 low, phishing $3/$4 high"
    else
      bad "built-in test: legitimate $1/$2 low, phishing $3/$4 high - worse than expected (around 49/50 and 51/51)"
      note "Most common reason: the model is only the starter one (see the line above) or an old model is left in data/models."
    fi
  else warn "the built-in test could not be run"; fi
  ADMINS=$(docker compose exec -T -u app web python -m webapp.manage list 2>/dev/null | grep -c 'admin=1' || true)
  if [ "${ADMINS:-0}" -ge 1 ]; then ok "an admin account exists"
  else warn "no admin account yet:  docker compose exec -u app web python -m webapp.manage create-admin YOU@email.com"; fi

  echo "== Connected mailboxes"
  MB=$(docker compose exec -T -u app web python -m webapp.manage mailboxes 2>/dev/null)
  case "$MB" in
    *"mailbox checking: running"*)   ok "connected mailbox checking is running" ;;
    *"DISABLED"*)                    ok "mailbox connection is disabled (MAILBOX_ENABLED=0)" ;;
    *"WAITING FOR SECRET_KEY"*)      bad "mailbox connection doesn't work until SECRET_KEY is set in .env" ;;
    *"hasn't run yet"*)              warn "mailbox checking hasn't reported in yet - wait a minute and repeat" ;;
    *"STALLED"*)                     bad "mailbox checking is stalled  →  docker compose logs --tail 50 web | grep -i mailbox ;  docker compose restart web" ;;
    *)                               warn "mailbox checking state not read (version older than 0.11?)" ;;
  esac
  case "$MB" in
    *"checking: running"*|*"hasn't run yet"*)
      if docker compose exec -T web python -c "import socket; socket.create_connection(('imap.gmail.com', 993), 8).close()" >/dev/null 2>&1; then
        ok "outbound port 993 (IMAP) is open - the server can reach mail providers"
      else
        warn "imap.gmail.com:993 is not reachable from the server - users won't be able to connect mailboxes"
        note "Check outbound firewall rules (ufw status; at the provider: egress / outbound)."
      fi
      case "$MB" in
        *"(Outlook): configured"*) ok "Microsoft sign-in (Outlook) is configured" ;;
        *) note "Outlook / Microsoft 365: not configured (MS_CLIENT_ID, MS_CLIENT_SECRET) - see deploy/DEPLOY.md" ;;
      esac
      NRE=$(printf '%s\n' "$MB" | grep -c ' reauth ' || true)
      [ "${NRE:-0}" -gt 0 ] && note "$NRE mailbox(es) waiting for the owner to reconnect (password revoked / expired)."
      ;;
  esac

  check_dns
  echo "== Page on the internet"
  if [ "$DOMAIN_OK" != 1 ]; then bad "skipped - fix DOMAIN in .env first"; return; fi
  URL="https://$DOMAIN"
  BODY=$(curl -sS -m 15 "$URL/healthz" 2>/tmp/antiphish_provjera_err)
  RC=$?
  if [ $RC -eq 0 ] && printf '%s' "$BODY" | grep -q '"ok": *true'; then
    ok "$URL/healthz responds, the HTTPS certificate is valid"
    if have openssl; then
      CERT=$(echo | openssl s_client -connect "$DOMAIN:443" -servername "$DOMAIN" 2>/dev/null | openssl x509 -noout -issuer -enddate 2>/dev/null | tr '\n' ' ')
      [ -n "$CERT" ] && note "$CERT"
    fi
  elif [ $RC -eq 60 ] || [ $RC -eq 35 ] || [ $RC -eq 51 ]; then
    bad "the HTTPS certificate for $DOMAIN is not valid (not issued yet?)"
    note "Check DNS above, that ports 80 and 443 are open to the internet (Google Cloud: VM → Edit → Firewalls), and:"
    note "docker compose logs --tail 30 caddy   (look for 'challenge failed' / 'certificate obtained')"
    note "Caddy retries on its own; once DNS is correct, the certificate arrives without a restart."
  elif [ $RC -eq 6 ]; then
    bad "$DOMAIN cannot be resolved (DNS)"
  elif [ $RC -eq 7 ] || [ $RC -eq 28 ]; then
    bad "$URL is not reachable (connection refused / timed out): firewall? Ports 80 and 443 must be open."
    note "Hostinger VPS: ufw and hPanel → VPS → Security → Firewall.   Google Cloud: VM → Edit → Firewalls → Allow HTTP/HTTPS traffic."
  else
    bad "$URL/healthz doesn't respond as it should (curl code $RC): $(head -c 200 /tmp/antiphish_provjera_err 2>/dev/null)"
    note "502 means the web container is still starting or has crashed:  docker compose logs --tail 50 web"
  fi
  rm -f /tmp/antiphish_provjera_err
  [ $RC -eq 0 ] || return

  REDIR=$(curl -sS -m 10 -o /dev/null -w '%{http_code} %{redirect_url}' "http://$DOMAIN/" 2>/dev/null)
  case "$REDIR" in
    30*" https://$DOMAIN/"*) ok "http:// redirects to https://" ;;
    *) warn "http://$DOMAIN/ → '$REDIR' (expected a redirect to https)";;
  esac
  HDRS=$(curl -sS -m 10 -D - -o /dev/null "$URL/login" 2>/dev/null | tr -d '\r')
  STATUS=$(printf '%s\n' "$HDRS" | head -n 1)
  if printf '%s' "$STATUS" | grep -q ' 200'; then ok "the sign-in page opens"; else bad "sign-in page: $STATUS"; fi
  for h in strict-transport-security content-security-policy x-frame-options x-content-type-options; do
    if printf '%s\n' "$HDRS" | grep -qi "^$h:"; then ok "security header $h"; else bad "missing header $h (BASE_URL must start with https://)"; fi
  done
  COOKIE=$(printf '%s\n' "$HDRS" | grep -i '^set-cookie: ap_session=' | head -n 1)
  if printf '%s' "$COOKIE" | grep -qi 'secure' && printf '%s' "$COOKIE" | grep -qi 'httponly'; then ok "session cookie is Secure + HttpOnly"
  else bad "session cookie is not marked Secure/HttpOnly - BASE_URL in .env must start with https://"; fi
  DOCS=$(curl -sS -m 10 -o /dev/null -w '%{http_code}' "$URL/docs" 2>/dev/null)
  if [ "$DOCS" = "404" ]; then ok "API documentation is not publicly exposed"; else warn "/docs returns $DOCS (expected 404)"; fi
}

case "$MODE" in
  prije|before)   check_before ;;
  poslije|after)  check_after ;;
  *) echo "Usage:  bash deploy/provjera.sh before | after"; exit 2 ;;
esac

echo
echo "Result: $OK OK, $WARN warnings, $FAIL errors."
if [ "$FAIL" -gt 0 ]; then
  echo "Fix the items marked with [ERROR] and run again."
  exit 1
fi
if [ "$MODE" = "prije" ] || [ "$MODE" = "before" ]; then echo "You can continue:  docker compose up -d --build"; else echo "The server looks healthy. Next: create accounts and go through the testing plan (DEPLOY.md, steps 6 and 10)."; fi
exit 0
