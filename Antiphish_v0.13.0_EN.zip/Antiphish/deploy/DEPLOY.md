# AntiPhish – deployment on a Hostinger VPS (testing with friends)

This guide brings the web application up at `https://antiphish.YOURDOMAIN.com`, with
HTTPS, accounts, credits, feedback, and (optionally) a forwarding address
`scan@YOURDOMAIN.com`.

**Version: v0.13.0.** New: **DNS shield** – a DNS firewall for the user's devices
(DNS-over-HTTPS endpoint + device tokens + block/allow rules + a live query log);
see [DNS shield](#dns-shield). v0.12 added buying credits (built-in test checkout, real
Stripe is a key swap) – see [Selling credits](#selling-credits-stripe); v0.11 added
connected mailboxes – see [Connecting mailboxes](#connecting-mailboxes-connect-email).
If you already have an older version on the server, go to [Upgrade](#upgrading-to-v013) – you don't
need to repeat steps 0–4.

## Shortest path (all commands in one place)

The details of each step are below. Replace `VPS_IP` and `antiphish.YOURDOMAIN.com` with your own.

```text
hPanel:      VPS with Ubuntu 24.04 – template "Ubuntu 24.04 with Docker" or plain Ubuntu   (step 0)
hPanel:      DNS → A record  antiphish → VPS_IP                                          (step 1)
```
```powershell
# on your own computer (PowerShell), from the folder with the zip
scp Antiphish_v0.13.0.zip root@VPS_IP:/opt/
ssh root@VPS_IP
```
```bash
# on the server
apt-get update && apt-get install -y unzip curl
docker --version || curl -fsSL https://get.docker.com | sh   # installs Docker only if missing (plain Ubuntu)
cd /opt && unzip Antiphish_v0.13.0.zip && mv Antiphish antiphish && cd antiphish
cp .env.example .env && nano .env          # DOMAIN, BASE_URL, SECRET_KEY  (step 4)
chmod 600 .env
bash deploy/provjera.sh before             # continue only when there is no [ERROR] line
docker compose up -d --build               # 6–10 minutes
bash deploy/provjera.sh after              # containers, model, HTTPS and certificate
docker compose exec -u app web python -m webapp.manage create-admin YOU@email.com
```

`deploy/provjera.sh` changes nothing on the server – it only checks, and for every problem it says what
to do. If anything gets stuck, run it first.

Is your server not a Hostinger VPS but, say, **Google Cloud**, with only the site and domain on Hostinger?
Then follow the section right below.

---

## Variant: server on Google Cloud, site and domain stay on Hostinger

For the case where you have hosting with a website on Hostinger (which you don't want to touch) and an
empty VM on Google Cloud. **AntiPhish goes on the Google VM.** On Hostinger you add one DNS record and
nothing more: nothing is uploaded there and the site's files are not touched.

Why not on Hostinger: ordinary Web/Cloud hosting cannot run this program (step 0), and even on a VPS
the site already holds ports 80 and 443.

### G1. Google Cloud console → Compute Engine → VM instances → click the VM's name

| Check | Required |
|---|---|
| **Machine type** | `e2-medium` (4 GB RAM) – no worries. `e2-small` (2 GB) – works, add swap (G3). `e2-micro` (1 GB) – only with swap, and slow. Changing the type: **Stop** → **Edit** → *Machine type* → **Save** → **Start** ([Google guide](https://docs.cloud.google.com/compute/docs/instances/changing-machine-type-of-stopped-instance)); a larger machine costs more |
| **Boot disk** | Debian or Ubuntu; 10 GB is enough (without the Qwen AI) |
| **External IP** | must exist – write it down |

Measured: model training in the build passes with 1.3 GB RAM and fails with 1 GB and no swap. With
0.7 GB RAM + 2 GB swap and a quarter of a CPU core (simulating `e2-micro`) it passes, but takes
3.5 minutes instead of 40 seconds.

Then, on the same page:

1. **Edit** → **Firewalls** section → enable **Allow HTTP traffic** and **Allow HTTPS traffic** → **Save**.
   Without that, the site is unreachable from outside and the certificate cannot be issued
   ([Google guide](https://docs.cloud.google.com/compute/docs/tutorials/basic-webserver-apache)).
2. **A permanent address.** Menu → *VPC network* → *IP addresses* → in the row of your VM's address
   click **Reserve** (or *Promote to static IP address*), enter a name, confirm
   ([Google guide](https://docs.cloud.google.com/vpc/docs/reserve-static-external-ip-address)).
   Otherwise the VM gets a different address after being stopped and started, and the DNS record no
   longer points to it. If you ever delete the VM, release that address too – a reserved address that
   isn't attached is billed.

### G2. Hostinger hPanel – one DNS record only

*Domains* → your domain → **Manage** → **DNS / Nameservers** → *DNS records* tab →
*Manage DNS records* ([Hostinger guide](https://www.hostinger.com/support/8907694-how-to-create-a-subdomain-without-a-hosting-plan-at-hostinger/)):

| Type | Name | Points to | TTL |
|---|---|---|---|
| A | `antiphish` | External IP of the Google VM | leave the suggested value |

→ **Add record**.

- **Do not change or delete anything existing** (`@`, `www`, MX, TXT ...): your site and mail depend on those records.
- Don't create a subdomain in the *Websites* / hosting section – that ties it to the Hostinger hosting. Only this record is needed.
- If that page says the domain uses someone else's nameservers (e.g. Cloudflare), add the record there.
- Record propagation can take a while; `provjera.sh before` (below) says whether it has arrived.

### G3. On the Google VM

In the VM list click **SSH** – a terminal opens in the browser. In that window click
**Upload file** and choose `Antiphish_v0.13.0.zip`
([Google guide](https://docs.cloud.google.com/compute/docs/instances/transfer-files)).
That is the only file you upload. Then, line by line:

```bash
sudo -i                                    # on Google Cloud you sign in as a normal user; this makes you root
free -m; head -2 /etc/os-release           # how much RAM there is and which system (Debian or Ubuntu required)
mv /home/*/Antiphish_v0.13.0.zip /opt/     # the upload landed in your home folder
apt-get update && apt-get install -y unzip curl nano
docker --version || curl -fsSL https://get.docker.com | sh

# The Google Cloud network has MTU 1460, Docker assumes 1500 - align them (once):
[ -f /etc/docker/daemon.json ] || echo '{"mtu": 1460, "default-network-opts": {"bridge": {"com.docker.network.driver.mtu": "1460"}}}' > /etc/docker/daemon.json
systemctl restart docker

# ONLY if RAM is below 4 GB (e2-small, e2-micro) - 2 GB of swap:
fallocate -l 2G /swapfile && chmod 600 /swapfile && mkswap /swapfile && swapon /swapfile && echo '/swapfile none swap sw 0 0' >> /etc/fstab

cd /opt && unzip Antiphish_v0.13.0.zip && mv Antiphish antiphish && cd antiphish
cp .env.example .env && nano .env          # DOMAIN, BASE_URL, SECRET_KEY  (step 4)
chmod 600 .env
bash deploy/provjera.sh before             # continue only when there is no [ERROR] line
nohup docker compose up -d --build > build.log 2>&1 &
tail -f build.log                          # Ctrl+C stops only the following; it's done when it says "Container antiphish-caddy-1 Started"
bash deploy/provjera.sh after
docker compose exec -u app web python -m webapp.manage create-admin YOU@email.com
```

Differences from a Hostinger VPS (steps 2–5 below):
- no `ssh root@...` with a password – use the **SSH** button in the console;
- skip `ufw`: the firewall is the one from G1;
- the build runs via `nohup` so closing the SSH window doesn't interrupt it (on a small machine it takes longer);
- everything else – `.env`, accounts, `scan@`, maintenance, troubleshooting – is the same as below.

About MTU, honestly: in the environment where this was tested the network has MTU 1400 and Docker 1500, and
everything worked even without aligning. Google, however, states that with the default MTU 1460 Docker needs
extra configuration ([Containers on Compute Engine](https://cloud.google.com/compute/docs/containers)),
and when it fails, it fails silently (a download in the build or a certificate request just hangs). The
command above was tried: the default network, the compose network and the build steps get the configured MTU,
and the app works. `provjera.sh` also notices the mismatch and prints this command.

It was also verified that the commands above install Docker on clean Debian 12 and 13 (the usual Google
Cloud images) and Ubuntu 24.04 and 26.04. None of this was run on a real Google VM.

---

## 0. Check that you have a VPS (most important)

Python applications on Hostinger run **only on a VPS**. Ordinary *Web Hosting* /
*Cloud Hosting* (where your website is) has no root access and **cannot** run
this program.

hPanel → left menu: if you see **VPS** with your server – great. If not:

| Plan | RAM | Enough for |
|---|---|---|
| KVM 1 | 4 GB | web + forwarding, **without** the local Qwen AI |
| KVM 2 | 8 GB | + Qwen `qwen2.5:3b` locally (slow on CPU) |
| KVM 4+ | 16 GB | + Qwen `qwen2.5:7b` locally |

Measured (limited to 1 CPU core, like KVM 1): model training in the build needs about
**1.2–1.3 GB RAM** and ~40 s; the app in operation uses ~250 MB; retraining from feedback
(`antiphish.learn`) up to ~1.5 GB. A server with less than 2 GB RAM is not enough. Ollama with the
`qwen2.5:3b` model loaded takes about 2.7 GB, with `qwen2.5:7b` about 5.2 GB.

The website stays where it is – AntiPhish goes on a **subdomain**.

When setting up the VPS choose the OS template **Ubuntu 24.04 with Docker** – or **plain Ubuntu**
(24.04 or 26.04). The result is the same; on plain Ubuntu just one command in step 2 installs
Docker first. Verified on clean Ubuntu 24.04 and 26.04: that command installs Docker and Docker Compose
(the same versions everything here was tested with).

If you already have a VPS with plain Ubuntu, **do not change the template** because of this: changing the
template erases everything on the server
([Hostinger: OS templates](https://www.hostinger.com/support/1583571-what-are-the-available-operating-systems-for-vps-at-hostinger/)).

---

## 1. DNS: subdomain → VPS

hPanel → **Domains** → your domain → **DNS / Nameservers** → *Add record*:

| Type | Name | Points to | TTL |
|---|---|---|---|
| A | `antiphish` | VPS IP address (hPanel → VPS → Overview) | 3600 |

Check (can take up to an hour): `ping antiphish.YOURDOMAIN.com` must show
the VPS's IP.

If the domain's DNS is not at Hostinger (e.g. Cloudflare), add the A record where the domain's
*nameservers* are. On Cloudflare, disable the proxy for this subdomain (grey cloud, "DNS only"): this
guide assumes visitors come directly to the VPS (otherwise the app sees Cloudflare's address instead
of the visitor's, so the wrong-password limit doesn't work per visitor).

If an **AAAA** (IPv6) record exists for that subdomain and doesn't point to this VPS, delete it –
the certificate-issuance check looks at both A and AAAA records, and a wrong AAAA breaks issuance.
`deploy/provjera.sh before` checks both.

---

## 2. Connect to the VPS and install Docker (if it isn't already)

From Windows (PowerShell):
```powershell
ssh root@VPS_IP
```
On the server:
```bash
apt-get update && apt-get install -y curl unzip
docker --version || curl -fsSL https://get.docker.com | sh    # on plain Ubuntu installs Docker + Compose
docker compose version            # must print a version (Compose v2 or newer)
# firewall: SSH, HTTP, HTTPS only   (if there is no ufw command: apt-get install -y ufw)
ufw allow 22/tcp && ufw allow 80/tcp && ufw allow 443/tcp && ufw --force enable
```
The *Ubuntu 24.04 with Docker* template already has Docker and Compose
([Hostinger guide](https://www.hostinger.com/support/8306612-how-to-use-the-docker-vps-template-at-hostinger/)),
so the second command there just prints the version. On plain Ubuntu it downloads Docker's official
installation script (takes a minute or two). `apt-get update` is deliberate: on a fresh server without
it `apt-get install` may report `Unable to locate package`.

**Hostinger firewall (hPanel → VPS → Security → Firewall)** is separate from `ufw`. While it's disabled
it doesn't get in the way. If you enable it: by default it **rejects all traffic** without a rule, so
BEFORE activating it add *accept* rules for TCP 22, 80 and 443 – otherwise you lose SSH too
([Hostinger: managed VPS firewall](https://www.hostinger.com/support/8172641-how-to-use-a-managed-vps-firewall-at-hostinger/)).

**Ports 80 and 443 must be free.** If you set up the VPS with some panel or already started something
with Traefik/nginx via the hPanel *Docker Manager*, those ports are taken and Caddy won't start.
Check: `ss -ltnp | grep -E ':(80|443) '` (empty = free). `provjera.sh before` reports this itself.

---

## 3. Copy the program to the server

**Option A – zip from your computer (recommended)** (PowerShell, from the folder with the zip):
```powershell
scp Antiphish_v0.13.0.zip root@VPS_IP:/opt/
```
On the server:
```bash
apt-get update && apt-get install -y unzip
cd /opt && unzip Antiphish_v0.13.0.zip && mv Antiphish antiphish && cd antiphish
```
(If `/opt/antiphish` already exists from an earlier attempt, move it away first: `mv /opt/antiphish /opt/antiphish-old`.)

**Option B – GitHub:** `git clone https://github.com/YOUR_ACCOUNT/Antiphish /opt/antiphish`

⚠️ **Don't use option B until you update the repo.** GitHub currently has the old version (v0.6 in
the root, v0.9 in the `Antiphish/` subfolder) – `git clone` would give you the **old** program. When you
want the repo to track the new version: unpack the zip, put the contents of the `Antiphish/` folder into
the repo root (delete the old stuff), commit and push. The repo is also **public** – switch it to *Private*
(Settings → Danger zone) before putting production things in, and **never** commit `.env`.

---

## 4. Configure `.env`

```bash
cd /opt/antiphish
cp .env.example .env
python3 -c "import secrets; print(secrets.token_urlsafe(48))"   # copy the result  (or: openssl rand -hex 32)
nano .env
```
Mandatory:
```
DOMAIN=antiphish.YOURDOMAIN.com
BASE_URL=https://antiphish.YOURDOMAIN.com
SECRET_KEY=<paste the generated string>
```
`DOMAIN` is just the name (without `https://`), and `BASE_URL` is the same name **with** `https://` in front.
If `BASE_URL` doesn't start with `https://`, signing in on the site won't work properly.
For the first test keep the AI off: `WEB_ALLOW_LLM=0` (that's also what `.env.example` says; see step 8).
Save: `Ctrl+O`, Enter, `Ctrl+X`. Protect the file: `chmod 600 .env`

**Values with special characters** (a mailbox password etc.): if they contain `$`, `#` or a
space, put them in **single quotes** – `INTAKE_PASSWORD='My$Password#1'`. Without quotes
Docker truncates the value at `$` or ` #` (verified: `abc$def` becomes `abc`) and signing in fails.

Then check everything at once:
```bash
bash deploy/provjera.sh before
```
It checks Docker, RAM and disk, free ports 80/443, `.env`, whether DNS points to this
server and whether the data sources are reachable. Continue only when there is no `[ERROR]` line.

---

## 5. Start it

```bash
docker compose up -d --build
```
The first build takes 6–10 minutes: it installs the libraries (exactly the versions this release
was tested with – `constraints-server.txt`), downloads the public corpora (~450 MB, of which
~30 MB stays in the image; ~4 minutes, depends on the connection) and trains the ML model **inside**
the image (~40 s on one core).

You don't have to read the log to know whether the model came out right: `bash deploy/provjera.sh after` checks that
it was trained on the full corpus, that no source was missing, and runs the built-in test (101 scenarios).
If you still want the full build log (Docker otherwise condenses it while running):
```bash
BUILDKIT_PROGRESS=plain docker compose build web 2>&1 | tee build.log
```
Three places matter in it:

1. the line `wrote /app/data/corpus.csv: ~17000 emails (~8600 phishing / ~8300 legit)`;
2. that there is **no** line `NOTE: N source file(s) missing and skipped` – if there is, some source
   wasn't reachable (the build doesn't stop, but the model is weaker) → repeat the build later;
3. the `SCENARIO SUITE` table right after training – expected: `dev_legit ... LOW 30`,
   `dev_phish ... HIGH 5, CRITICAL 25` (small deviations are possible).

If you see `WARNING: corpus build failed - starter model only`, the model is just the starter
one (much weaker) – repeat the build.

Slow connection or little disk? Smaller build (without the Enron and Apache sources, weaker on business mail):
```bash
CORPUS_FLAGS="--no-enron --no-lists" docker compose up -d --build
```

Check:
```bash
bash deploy/provjera.sh after   # containers, model, HTTPS from outside, certificate, headers
docker compose ps                 # web: healthy, caddy: running
docker compose logs -f web        # Ctrl+C to exit
```
Open `https://antiphish.YOURDOMAIN.com` – Caddy gets the HTTPS certificate by itself
(~30 s the first time). If the certificate doesn't work: DNS hasn't propagated yet or ports 80/443 are closed.

**If the certificate doesn't arrive, don't keep restarting Caddy.** Caddy does issuance in the background and
retries on its own, less and less often ([Caddy: Automatic HTTPS](https://caddyserver.com/docs/automatic-https)),
and Let's Encrypt allows only 5 failed checks per name per hour
([Let's Encrypt: Rate Limits](https://letsencrypt.org/docs/rate-limits/)). Fix the cause (A record,
AAAA record, ports 80/443, hPanel firewall), then watch `docker compose logs -f caddy` until
`certificate obtained successfully` appears.

> **Already have nginx/Apache on that VPS on ports 80/443?** Then start without Caddy:
> `docker compose up -d --build web` and use `deploy/nginx-antiphish.conf` + `certbot`.
> If you copied the nginx configuration from v0.9, **replace it with the new one**: the old one forwarded
> the client's `X-Forwarded-For`, which let the wrong-password limit be bypassed.

---

## 6. Create accounts

```bash
docker compose exec -u app web python -m webapp.manage create-admin YOU@email.com
docker compose exec -u app web python -m webapp.manage create-user FRIEND@email.com --credits 100
docker compose exec -u app web python -m webapp.manage list
```
(You type the password hidden – it's not shown while you type – min 10 characters. Always use `-u app`.)
Accounts, credits and deactivation can also be done in the web **Admin** panel.
Forgotten password: `docker compose exec -u app web python -m webapp.manage reset-password FRIEND@email.com`

---

## 7. (Optional) Forwarding address `scan@YOURDOMAIN.com`

1. hPanel → **Emails** → your domain → *Create email account* → `scan@...` (strong password).
2. In `.env` (put the password in single quotes – see step 4):
   ```
   INTAKE_USER=scan@YOURDOMAIN.com
   INTAKE_PASSWORD='<that mailbox's password>'
   ```
   If two-factor verification (2FA) is enabled on the mailbox, an *app password* is needed instead of
   the password (hPanel → Emails → Mailboxes → ⋮ → App passwords).
3. `docker compose --profile intake up -d` → `docker compose logs -f intake`
   - Correct: `Intake mailbox scan@... via imap.hostinger.com - polling every 20s` and nothing else.
   - `IMAP login as ... was refused`: wrong password, a password without quotes, or an app
     password is needed. After fixing `.env`: `docker compose --profile intake up -d` (the program
     otherwise retries on its own, but less and less often – up to 15 min – so the mail server doesn't
     block the account).
   - `certificate ... could not be verified`: wrong server name. Use `imap.hostinger.com` /
     `smtp.hostinger.com`, not `mail.YOURDOMAIN.com`. (Older mailboxes on the Titan platform:
     `INTAKE_IMAP_HOST=imap.titan.email`, `INTAKE_SMTP_HOST=smtp.titan.email`.)
4. Test: from an address registered as a user, forward a suspicious mail
   **as an attachment** to `scan@...`. The report arrives in ~20–40 s.
   - Gmail: open the mail → ⋮ → *Forward as attachment* (or select the mail in the list → ⋮ → *Forward as attachment*).
   - Plain forwarding works too, but without the original's headers (weaker analysis – the report says so).
   - Mails from unregistered addresses are silently ignored.

---

## 8. (Optional) Qwen AI

First get everything else working (steps 0–6). The AI check is an extra: the user chooses it on the page
and it costs more credits (`COST_AI`).

**a) Locally on the VPS** (needs RAM – see the table in step 0):
```bash
docker compose --profile llm up -d
docker compose exec ollama ollama pull qwen2.5:3b     # or qwen2.5:7b on 16 GB
```
`.env`: `WEB_ALLOW_LLM=1`, `QWEN_PROVIDER=ollama`, `QWEN_BASE_URL=http://ollama:11434`,
`QWEN_MODEL=qwen2.5:3b`, then `docker compose up -d`.

Measured live with `qwen2.5:3b` (Ollama, 4 CPU cores, 101 scenarios from `antiphish/scenarios*.py`):

| | v0.10.0 (old prompt) | v0.10.1 (new prompt + guard) |
|---|---|---|
| phishing scenarios the model itself called phishing | 2/51 | **45/51** |
| legitimate scenarios the model called phishing | 0/50 | 0/50 |
| phishing rated HIGH/CRITICAL: without AI → with AI | 51 → 49 of 51 | 51 → 51 of 51 |
| legitimate rated LOW: without AI → with AI | 49 → 50 of 50 | 49 → 50 of 50 |
| time per mail (median / slowest) | 9.3 s / 25.0 s | 9.3 s / 22.3 s |

What that means: a small model is a weak judge, so the program trusts it in a limited way – a "phishing"
opinion without technical confirmation adds at most 8–15 points, and a "legitimate" opinion can lower only a
SUSPICIOUS rating, never HIGH/CRITICAL. The AI check doesn't change the outcome much on these scenarios (the
scanner catches them on its own); the benefit is in the explanation and in borderline cases. We wrote the
scenarios ourselves, so these numbers are not a measure of accuracy on your mail. The same measurement for
the model you use: `docker compose exec -u app web python scripts/eval_llm.py` (~15 min).

Resources: the Ollama image takes ~8.5 GB of disk, the `qwen2.5:3b` model another 1.9 GB; while the model is
loaded, the Ollama container uses ~2.7 GB RAM.
With Ollama limited to 2 cores (like KVM 2) the same mails take 16–37 s (median ~29 s, 8 mails).

`qwen2.5:7b` (same test, one run, 4 cores) didn't prove better: it called 46 of 51 phishing scenarios
phishing and 1 of 50 legitimate ones (an internal IT password reminder – its rating moved from
LOW to SUSPICIOUS); median 24 s per mail, 2 answers didn't arrive within 90 s (a build was also running
on the same machine at that moment). Ollama with that model uses ~5.2 GB RAM. Not measured on 2 cores; if it
slows down like the 3b (about 2.5×), some answers would exceed `LLM_TIMEOUT`.

**b) Alibaba Cloud Model Studio / DashScope (cloud, faster, pay per use):**
`QWEN_PROVIDER=dashscope`, `DASHSCOPE_API_KEY=...`, `QWEN_MODEL=qwen-plus`.
⚠️ Mail contents go to Alibaba Cloud – testers must know that.

An API key is valid **only in the region where it was created**
([Alibaba Cloud: regions](https://www.alibabacloud.com/help/en/model-studio/regions)). A key from the
international console (alibabacloud.com, Singapore region) also needs this line in `.env`:
```
DASHSCOPE_BASE_URL=https://dashscope-intl.aliyuncs.com/compatible-mode/v1
```
Without it the program calls the address for mainland China and the key is rejected (HTTP 401) – in
`docker compose logs web` it then says `the API key was rejected` together with these same instructions.
This variant **has not been tried live** (no key in the verification environment); it was only verified
that the program calls the configured address and reports the error clearly.

The admin panel shows whether Qwen is available; the "AI check" is active on the page only then.
If the model doesn't answer in time (`LLM_TIMEOUT`, 90 s), the result says so and a quick check is charged.

---

## Connecting mailboxes ("Connect email")

From v0.11 the user doesn't have to download .eml files. On the **Mailboxes** page they pick their provider,
connect the mailbox once, and the server then **itself** checks incoming mail: the newest 20 messages at once,
then every new one (every 2 minutes). Results are on the **Dashboard** page. The manual check (.eml / text)
still exists as a separate page.

**Nothing extra needs to run on the server** – checking runs in the `web` container as soon as v0.11 comes up.
The condition is that `SECRET_KEY` is set in `.env` (it is, if you followed step 4). The admin panel shows
whether checking is running; so does `docker compose exec -u app web python -m webapp.manage mailboxes`.

The server opens **outbound** connections for this: port 993 (IMAP over TLS) to mail providers and 443 to
Microsoft. Google Cloud and Hostinger VPS allow outbound traffic by default.

### What the user does

| Provider | How to connect | Note |
|---|---|---|
| **Gmail** | address + **app password** (16 letters). Requirement: 2-Step Verification enabled; the password is created at `myaccount.google.com/apppasswords` | the regular Google password doesn't work. When the user changes their Google password, Google revokes app passwords too → the mailbox asks to be reconnected. Google Workspace: the domain administrator can forbid app passwords |
| **Yahoo, iCloud** | address + app password (created in the account settings; the steps are written on the page) | |
| **Hostinger Email** | address + mailbox password | |
| **Other (IMAP)** | address, password, IMAP server name | port 993 only, the server certificate is verified; only public servers are allowed |
| **Outlook / Hotmail / Live / Microsoft 365** | the "Continue to Microsoft sign-in" button – the password is entered only at Microsoft | works only after you do the registration below; until then the page says so |

The steps for the user are written on the connect page itself. **Google sign-in ("Sign in with
Google") is deliberately not built in:** to read Gmail, Google requires a public app to pass verification
and a yearly paid security assessment; without that, access expires every 7 days and covers at most 100
manually listed users. An app password has none of those limits.

### Outlook / Microsoft 365: app registration (once)

For its mailboxes Microsoft accepts only sign-in through Microsoft (OAuth). For that, AntiPhish must be
registered as an app with Microsoft – you do this, for free:

1. Open `https://entra.microsoft.com` → **App registrations** → **New registration**.
   (You need a Microsoft Entra directory. If you don't have one, Microsoft creates it when you open a free
   Azure account – it asks for a card for identity verification.)
2. **Name:** `AntiPhish`. **Supported account types:** *Accounts in any organizational directory and
   personal Microsoft accounts*. **Redirect URI:** platform **Web**, value exactly
   `https://antiphish.YOURDOMAIN.com/mailboxes/microsoft/callback` (also shown in the Admin panel). → **Register**.
3. On the app page copy **Application (client) ID** → that is `MS_CLIENT_ID`.
4. **Certificates & secrets** → **New client secret** → copy the **Value** column (not *Secret ID*) → that is
   `MS_CLIENT_SECRET`. Note the expiry date: when the secret expires, create a new one and replace it in `.env`
   (connected mailboxes keep working, users don't have to do anything).
5. **API permissions** → **Add a permission** → **Microsoft Graph** → **Delegated permissions** → add
   `Mail.Read` and `offline_access` (`User.Read` is already there). Nothing else – AntiPhish only reads mail.
6. Put both values in `.env` and bring the container up again:
   ```bash
   cd /opt/antiphish && nano .env          # MS_CLIENT_ID=...  MS_CLIENT_SECRET=...
   docker compose up -d
   ```
7. The admin panel now shows "Microsoft sign-in (Outlook): configured". Try it: Mailboxes → Outlook → sign in.

Who can connect a mailbox:
* **personal accounts** (outlook.com, hotmail.com, live.com) – yes; Microsoft's consent screen says the
  app's publisher is not verified (*unverified*), which is expected for your own app;
* **work / school Microsoft 365 accounts of other organizations** – Microsoft doesn't let ordinary users
  approve mail reading for an unverified publisher's app; that organization's administrator must approve it
  (or you pass Microsoft's *publisher verification*).

> **Not verified against real Microsoft.** This part was written from Microsoft's documentation and
> verified against a stand-in server behaving per that documentation (sign-in, tokens, reading messages,
> access renewal, revocation). The first connection of a real Outlook account is therefore also the first
> real test – if it fails, the reason is in `docker compose logs web | grep -i microsoft` (the line contains
> Microsoft's error code `AADSTS…`).

### Settings (`.env`, all optional)

| Setting | Default | Meaning |
|---|---|---|
| `COST_MAILBOX` | `0` | credits per automatically checked message. `0` = free (the limits below still apply). With `1`, checking pauses for a user with 50 credits after 50 messages, until you top up their credits |
| `MAILBOX_POLL_SECONDS` | `120` | how often each mailbox is checked |
| `MAILBOX_INITIAL_SCAN` | `20` | how many of the newest messages are checked when connecting (`0` = only new ones) |
| `MAILBOX_SCANS_PER_HOUR` | `120` | most checks per user per hour; the excess waits, it isn't skipped |
| `MAILBOXES_PER_USER` | `3` | most mailboxes per account |
| `MAILBOX_RETAIN_DAYS` | `90` | automatic-check results are deleted after this many days (`0` = keep) |
| `MAILBOX_USE_LLM` | `0` | `1` = automatic checks also go to Qwen (slow; with a cloud API mail contents go to a third party) |
| `MAILBOX_ENABLED` | `1` | `0` = turn off the whole feature |
| `MAILBOX_KEY` | empty | separate key for encrypting stored access; empty = derived from `SECRET_KEY` |

### What to know before inviting users

* **The server stores access to other people's mailboxes.** App passwords and Microsoft tokens are
  encrypted in the database (AES-256-GCM), and the key is in `.env`, not in the database – a copy of the
  database alone doesn't reveal them. But whoever runs the server (or breaks into it) can decrypt them.
  So: SSH by key only, regular updates, don't share or e-mail `.env` and `data/`.
* **An app password isn't limited to reading** – technically it grants access to the whole mailbox.
  AntiPhish uses it only to read incoming mail (the folder is opened read-only, messages
  are not marked as read). The Microsoft permission *is* limited to reading (`Mail.Read`).
* **Do not change `SECRET_KEY`.** If you change it, stored access can no longer be read and every
  user must reconnect their mailbox (the page says so itself). Keep a backup of `.env` together with `data/`.
* **Privacy:** the *Privacy* page describes all this to the user. You as the administrator can open a
  check result (subject, sender, links), but not the mail itself.
* **Volume:** one mailbox check takes about a second; the server walks them in turn. For tens of mailboxes
  that's enough; for hundreds it needs measuring.
* **Not verified on real accounts:** Gmail, Yahoo, iCloud and Hostinger. Verified on a real
  IMAP server (GreenMail) with TLS, through a browser and HTTPS – see `HANDOFF.md`.

---

## DNS shield

New in v0.13: a **DNS firewall** for the user's devices, built into the same app.

**How it works.** Each device gets a personal DNS-over-HTTPS (DoH, RFC 8484) address
`https://antiphish.YOURDOMAIN.com/dns-query/<token>`, created on the *DNS shield* page. An agent on
the device (or any DoH client) sends DNS queries there. Domains on the user's block list get an
NXDOMAIN answer immediately; everything else is forwarded to the upstream resolver
(`DNSFW_UPSTREAM`, default 1.1.1.1). Every query lands in the device's live log (visible on the
device's page, kept `DNSFW_LOG_RETENTION_DAYS`, default 14 days).

**Security notes (read once):**

* **It is never an open resolver.** Unknown or switched-off tokens get a plain 404, and the port
  it listens on is the ordinary HTTPS 443 you already have – do NOT additionally open UDP/TCP 53
  to the internet.
* The token is the device's only credential; the server stores just its SHA-256 hash and shows the
  full address **once**, when the device is created.
* Per-device rate limit: `DNSFW_QUERIES_PER_MIN` (default 600). Abuse of one token cannot drown
  the server for the others.
* If the server is unreachable, a well-behaved agent must fall back to the system's normal DNS
  ("fail-open") – otherwise the user's internet looks dead during your deploys. The agent in
  `agent/` does this by itself.

**Settings (.env):**

| Setting | Default | Meaning |
|---|---|---|
| `DNSFW_ENABLED` | `1` | master switch (`0` hides the page and closes the endpoint) |
| `DNSFW_UPSTREAM` | `1.1.1.1` | resolver for allowed queries (e.g. `9.9.9.9`) |
| `DNSFW_UPSTREAM_PORT` | `53` | upstream port |
| `DNSFW_TIMEOUT` | `5` | upstream wait, seconds |
| `DNSFW_DEVICES_PER_USER` | `5` | device limit per account |
| `DNSFW_QUERIES_PER_MIN` | `600` | per-device rate limit |
| `DNSFW_LOG_RETENTION_DAYS` | `14` | how long the query log is kept |

**Trying it out without an agent:** any DoH client works, e.g. from a PC:
`curl -H "content-type: application/dns-message" --data-binary @query.bin
https://antiphish.YOURDOMAIN.com/dns-query/<token>`. The domain `dns-shield-test.invalid` is always
blocked – a blocked answer to it proves the whole path works.

---

## Selling credits (Stripe)

The **Buy credits** page works out of the box with the built-in simulator (`BILLING_PROVIDER=simulator`)
– a fake checkout for trying the whole flow, no real money. For real payments you need a Stripe account
(note: Stripe does not open accounts for businesses in every country – check yours first; alternatives
like Paddle or Polar follow the same webhook principle but are not built in here).

1. Stripe dashboard → switch to **Test mode** → *Developers → API keys* → copy the **Secret key**
   (`sk_test_...`) into `.env`:
   ```
   BILLING_PROVIDER=stripe
   STRIPE_SECRET_KEY=sk_test_...
   ```
2. *Developers → Webhooks → Add endpoint*: URL `https://antiphish.YOURDOMAIN.com/billing/webhook`,
   event to listen to: **`checkout.session.completed`** (nothing else). Copy the endpoint's
   **Signing secret** (`whsec_...`):
   ```
   STRIPE_WEBHOOK_SECRET=whsec_...
   ```
3. `docker compose up -d`, then try it: Buy credits → pay with the test card `4242 4242 4242 4242`
   (any future date, any CVC) → the credits appear on the account within seconds. If they don't:
   `docker compose logs web | grep -i stripe` (a `400` there means the signing secret is wrong).
4. Going live: switch Stripe out of test mode, replace both keys with the live ones
   (`sk_live_...` + a new webhook signing secret for the live endpoint). The code doesn't change.

Your own packages (optional, one line of JSON in `.env`; single quotes because of the `$`/`#` rule):
```
BILLING_PACKAGES='[{"id":"starter","name":"Starter","credits":100,"price_cents":500,"currency":"EUR"},{"id":"standard","name":"Standard","credits":500,"price_cents":2000,"currency":"EUR","featured":true}]'
```

Notes:
* The webhook is safe to expose: it verifies Stripe's signature before reading anything, every
  payment adds credits **exactly once** (retries are ignored), and everything else is acknowledged
  and ignored.
* Keep `BILLING_PROVIDER=simulator` until the webhook works in test mode – the simulator and Stripe
  share the same crediting code, so "the simulator works" + "the test-mode webhook arrives" means
  the live flow works.
* If Stripe isn't available in your country: `BILLING_PROVIDER=simulator` also serves as the
  "manual" mode – users click Buy, see the test checkout, and you add the credits yourself in the
  Admin panel after they pay you some other way.

---

## 9. Everyday maintenance

| What | Command |
|---|---|
| Whether everything works | `bash deploy/provjera.sh after` |
| Logs | `docker compose logs -f web` (or `intake`, `caddy`) |
| Restart | `docker compose restart web` |
| Program update | copy the new code into `/opt/antiphish` (keep `.env` and `data/`), then `docker compose up -d --build` (see "Upgrading to v0.13") |
| Database backup | `docker compose exec -u app web python -c "import sqlite3; s=sqlite3.connect('/app/data/antiphish.db'); d=sqlite3.connect('/app/data/backup.db'); s.backup(d)"` → file `data/backup.db` (download it with `scp`) |
| Learning from feedback | Admin → *Export to feedback.csv*, then `docker compose exec -u app web python -m antiphish.learn` (~1–2 min, up to 1.5 GB RAM). The new model is installed **only if it passes the check** (it must not be worse than the current one on mails it hasn't seen) and loads itself in ~30 s – no restart needed |
| Checking the feedback | `docker compose exec -u app web python -m antiphish.learn --stats` (contradictory or one-sided labels) |
| Rolling back to the previous model | `docker compose exec -u app web python -m antiphish.learn --rollback` |
| Test on your own mail | copy an export into `data/` (e.g. `data/my_mail.mbox`), then `docker compose exec -u app web python scripts/scan_folder.py /app/data/my_mail.mbox --expect legit` (add `--add-feedback` to send wrong ratings into feedback) |
| Credits | Admin panel or `... python -m webapp.manage credits FRIEND@email.com 200` |
| Connected mailboxes | Admin panel, or `docker compose exec -u app web python -m webapp.manage mailboxes` (each mailbox's state and whether checking is running) |
| Measuring the model | `docker compose exec -u app web python evaluate.py` (text model + probes + scenarios, ~1 min) |
| How much the AI model is worth | `docker compose exec -u app web python scripts/eval_llm.py` (101 calls to the model: what it says and what it changes; step 8) |
| What the model was trained on | `docker compose exec -u app web cat /app/data/models/model.joblib.meta.json` |

Everything that needs preserving is in **`/opt/antiphish/data/`** (database, model, feedback) and **`.env`**.

After a server restart the containers come up on their own (`restart: unless-stopped`) – verified by stopping
and starting the Docker service. Accounts, history and the model survive `docker compose down` / `up`.

---

## Upgrading to v0.13

Applies to v0.12.x → v0.13.0, and v0.11.x or v0.10.x → v0.13.0 in one step (for v0.9 also read the part below).
The commands are for `root` (on a Google Cloud VM first `sudo -i`).

1. **Backup** (mandatory):
   ```bash
   cp -r /opt/antiphish/data /opt/antiphish-data-backup-$(date +%F)
   cp /opt/antiphish/.env /opt/antiphish-env-backup-$(date +%F)
   ```
2. Copy `Antiphish_v0.13.0.zip` to the server (Hostinger: `scp ... root@IP:/opt/`; Google Cloud:
   *SSH* in the browser → *Upload file*, then `mv /home/*/Antiphish_v0.13.0.zip /opt/`).
3. New code over the old, **`.env` and `data/` stay untouched**:
   ```bash
   apt-get update && apt-get install -y unzip rsync
   cd /opt && unzip -o Antiphish_v0.13.0.zip -d /opt/_new
   rsync -a --exclude data --exclude .env /opt/_new/Antiphish/ /opt/antiphish/ && rm -rf /opt/_new
   cd /opt/antiphish && nohup docker compose up -d --build > build.log 2>&1 &
   tail -f /opt/antiphish/build.log        # Ctrl+C stops only the display, not the build
   ```
   The build takes as long as the first time (the model is trained again in the image). The site runs on the
   old version until the build finishes; the interruption when the container is replaced is a few seconds.
4. Check: `bash deploy/provjera.sh after`, then open the site.

What happens during the upgrade:
* **The database extends itself** (v0.11: three new columns and two new tables; v0.12: the
  `billing_events` table; v0.13: the `devices`, `dns_rules` and `dns_events` tables); accounts, credits and previous results remain and are visible on the new
  *Dashboard* page. Going back to the old version with the same database is possible – the old version
  ignores the new columns and tables.
* **Buying credits is on by default, in test mode** (`BILLING_PROVIDER=simulator`): the "Buy credits"
  page works immediately, no real payments. To hide the page: `BILLING_ENABLED=0`. For real payments
  see [Selling credits](#selling-credits-stripe).
* **DNS shield is on by default** (new *DNS shield* page in the menu). To hide it: `DNSFW_ENABLED=0`.
  Nothing else changes; it starts working when the first device is added on that page.
* **The model in `data/models/` stays** the one you have (rules and model didn't change in v0.11).
* **You don't have to touch `.env`.** The new settings have default values (table in the
  [Connecting mailboxes](#connecting-mailboxes-connect-email) section); for Outlook add `MS_CLIENT_ID` and
  `MS_CLIENT_SECRET`.
* Users stay signed in. The look of all pages is new; the `/history` address leads to the *Dashboard*,
  the manual check is at `/check`.

### From v0.9

Do the steps above, with this:

* On first start the container itself notices that the model in `data/models/` is from the old version
  (it can't be used with the new code), moves it to `model.pre-upgrade.joblib` and installs a new one.
  In `docker compose logs web` look for: `entrypoint: model on the data volume was from another version`.
* If you have `data/feedback.csv` from v0.9, include it in the new model:
  `docker compose exec -u app web python -m antiphish.learn`

**What testers will notice:** ratings differ from v0.9 (a different calculation; the result page
now says how the score was calculated), more phishing gets CRITICAL, and newsletters and notices from
known services get "Suspicious" less often. Old ratings in the history stay as they were.

If you also use the desktop monitor (`python -m antiphish.monitor`): it moves mails rated ≥ 90 to the
`AntiPhish-Quarantine` folder. Since the new calculation reaches ≥ 90 more often, a second condition was
added – at least 40 points of firm technical evidence (`QUARANTINE_MIN_FIRM`: dangerous attachment, fake
domain, failed authentication ...); the wording of the text and the AI model's opinion cannot move a mail.
Still, during the first days check that folder regularly (or set `QUARANTINE=0` in `.env`).

---

## 10. Testing plan (you + a friend)

1. **Sign in/out**, password change (other sessions get signed out).
2. **Legitimate mails** (Gmail → ⋮ → *Download message* → upload .eml): newsletters, invoices,
   notices. Expected: LOW. Every wrong one → the *This is legitimate email* button.
3. **Phishing from the spam folder** – same, expected HIGH/CRITICAL; mark misses as *This is phishing*.
4. **Attachments:** a zip with `login.html` (a form with a password) and `invoice.pdf.exe` (plain text renamed) → CRITICAL.
5. **Text only** (paste without headers) → a warning that the analysis is limited.
6. **Forwarding** to `scan@` (as an attachment and plain).
7. **Limits:** 0 credits → a message; 8 wrong passwords → a 15 min lock-out.
8. After a few days: export feedback → `antiphish.learn` → compare the results.
9. **New in v0.10 – worth trying in particular:**
   - phishing that passes SPF/DKIM/DMARC (most of today's) – expected HIGH/CRITICAL, no longer LOW;
   - an HTML mail where the link text shows one address but the link leads to another;
   - a "boss" from a Gmail address asking for gift cards or an urgent payment (no links) – expected HIGH;
   - a mail with a QR code **in the message body** (an image), not only in an attachment;
   - messages in Bosnian/Serbian (including Cyrillic) and Swedish;
   - real mails from Google, a bank, a courier service, newsletters – expected LOW. Every one that isn't
     LOW is the most valuable feedback you can give.

10. **New in v0.11 – a connected mailbox:**
    - connect your Gmail (app password) → within a minute at most, the newest 20 messages are on the *Dashboard*;
    - send yourself a mail from another account → it appears on its own in 2–3 minutes (or right away with *Check now*);
    - check in Gmail that the messages are **not** marked as read and that nothing was moved;
    - revoke the app password at Google → after a while the mailbox card says
      *Reconnect needed* (deliberately not right away: it first tries twice more, with pauses);
    - *Disconnect* the mailbox, with and without deleting the results;
    - (if you did the registration) connect an Outlook account – that is also the first test on real Microsoft.

Write down: what was slow, what was unclear on the page, every wrong rating.

---

## Troubleshooting

First run `bash deploy/provjera.sh after` – it recognises most things in this table itself.

| Symptom | Cause / fix |
|---|---|
| `docker: command not found` / `provjera.sh`: "Docker is not installed" | plain Ubuntu without Docker: `apt-get update && apt-get install -y curl && curl -fsSL https://get.docker.com \| sh` (step 2) |
| `apt-get install`: `Unable to locate package ...` | fresh server without the package list: first `apt-get update` |
| The build "hangs" on downloads (`pip`, `downloading ...`) or Caddy can't reach Let's Encrypt, while DNS and firewall are fine | the server's network has a smaller MTU than Docker (Google Cloud: 1460). `bash deploy/provjera.sh before` shows this and prints the two commands to align them |
| The build dies with `Killed` / code 137 during training | too little RAM (needs ~1.25 GB): add swap – `provjera.sh before` prints the command – or take a bigger machine |
| You closed the SSH window mid-build | start the build like this: `nohup docker compose up -d --build > build.log 2>&1 &` then `tail -f build.log` |
| `Permission denied` in the log | old version of the entrypoint – rebuild: `docker compose up -d --build` |
| `docker compose up`: `port is already allocated` / `address already in use` | something else holds port 80 or 443 (nginx, Apache, Traefik from Docker Manager, a panel). `ss -ltnp \| grep -E ':(80\|443) '` shows what. Turn that off, or use the variant without Caddy (step 5) |
| `set DOMAIN in .env` at startup | `.env` doesn't exist in `/opt/antiphish` or has no `DOMAIN=...` line |
| Site doesn't open, Caddy log: `challenge failed` | the DNS A record doesn't point to the VPS yet, a wrong AAAA record exists, or ports 80/443 are closed (ufw **or** hPanel firewall). Don't restart in a loop – see step 5 |
| Browser: "connection is not secure" / certificate not valid | the certificate hasn't been issued yet – same as the row above; `docker compose logs --tail 30 caddy` |
| "Invalid security token (CSRF)" at **every** sign-in | you're opening the site over `http://` (e.g. a tunnel on port 8000, or nginx without a certificate) while `BASE_URL` is `https://` – the session cookie is sent only over HTTPS. Open `https://...` |
| "Invalid security token (CSRF)" once | the page was open for a long time or cookies are disabled – refresh the page (F5) and try again |
| `502 Bad Gateway` | the web container is still starting / crashed: `docker compose logs web` |
| "The server is busy right now" | raise `SCAN_CONCURRENCY` (if there's RAM) |
| You get signed out after a restart | `SECRET_KEY` isn't set in `.env` |
| Intake doesn't answer | `docker compose logs --tail 30 intake` – the message says what's wrong (password, quotes in `.env`, server name). The sender must be a registered user, otherwise the mail is silently ignored |
| Intake log: `report ... could NOT be sent` | the check was done (visible in the history on the site) but the reply wasn't sent by mail: `INTAKE_SMTP_HOST` / `INTAKE_SMTP_PORT` (465, or 587) / password |
| AI check grey/unavailable | `WEB_ALLOW_LLM=0`, Ollama isn't running or the model isn't `pull`-ed; see the Admin panel. After a change wait ~30 s (the state is checked periodically) |
| The result says "The AI check gave no answer" | the model is too slow or unavailable; a quick check was charged. The reason is in `docker compose logs web` (line `Qwen ... gave no answer`). Slow: a smaller model or a larger `LLM_TIMEOUT` |
| Log: `HTTP 401 - the API key was rejected` (DashScope) | the key is from a different region than the service address – set `DASHSCOPE_BASE_URL` (step 8b) |
| `GATE FAILED - the live model was NOT replaced` | the new model is worse than the current one – usually because of wrong labels in `data/feedback.csv`. Run `python -m antiphish.learn --stats`, fix the rows, repeat. The current model stays in use |
| Mailbox card: *Reconnect needed* | the provider no longer accepts the stored password: it was revoked, or the user changed the account password (Google then revokes app passwords too). The user clicks *Reconnect* and enters a new one |
| Gmail refuses the password when connecting | the regular password was entered instead of an app password; 2-Step Verification isn't enabled; the Workspace administrator forbade app passwords; the account is in the *Advanced Protection* program (then it can't) |
| Mailbox card: *Checking is not running*, Admin: "STALLED N min" | checking in the `web` container isn't reporting in: `docker compose logs --tail 50 web \| grep -i mailbox`, then `docker compose restart web` |
| Card: "The stored access can no longer be read" | `SECRET_KEY` (or `MAILBOX_KEY`) was changed. Restore the old key from the `.env` backup, or have users reconnect their mailboxes |
| Connecting: "Could not connect to 'imap…'" | the IMAP server name isn't correct, or **outbound** port 993 is closed on the server (`ufw status`, outbound rules of the provider's firewall) |
| Connecting: "The server's certificate … is not valid" | a name was entered that isn't on the certificate (e.g. `mail.domain.com` instead of the name the provider states) |
| Microsoft: error page `AADSTS50011` (redirect URI) | the *Redirect URI* in the app registration must be exactly `BASE_URL` + `/mailboxes/microsoft/callback`, platform *Web* |
| Microsoft: "rejected the app's credentials", log shows `AADSTS7000215` / `invalid_client` | *Secret ID* was entered as `MS_CLIENT_SECRET` instead of *Value*, or the secret has expired – create a new one |
| Microsoft: *Need admin approval* | a work / school account of another organization: its administrator must approve it (see the Outlook section) |
| Buying credits: "Stripe refused the payment session" | the exact reason is in `docker compose logs web \| grep -i stripe`. `tax code is missing`: the account has Stripe Tax / managed payments – `STRIPE_TAX_CODE` in `.env` must be set (default since v0.12.0: `txcd_10000000`). `401`: wrong/revoked key, or a key from another environment (sandbox vs live test mode) |
| `provjera.sh`: "model is only the STARTER one" | the corpus download in the build failed. `docker compose build --no-cache web && docker compose up -d`; once the build succeeds, the container replaces the starter model itself at startup (log: `was only the small starter model`) |
| `provjera.sh`: "N source files were missing" (in the build log `NOTE: ... source file(s) missing`) | some public source wasn't reachable; the model was trained without it. Later: `docker compose build --no-cache web && docker compose up -d`, then `docker compose exec -u app web python -m antiphish.learn` |
| `Model not loaded (...feature version...)` in the log | a model from another version; the container replaces it itself at startup. If it still appears: `docker compose exec -u app web python train.py` |
