#!/bin/sh
# Runs as root only long enough to fix volume permissions, then drops to user "app".
set -e
mkdir -p /app/data/models
# docker creates bind-mounted ./data as root -> give it to the app user
chown -R app:app /app/data

LIVE=/app/data/models/model.joblib
BAKED=/app/models-baked/model.joblib

install_baked() {
  cp "$BAKED" "$BAKED.sha256" /app/data/models/
  [ -f "$BAKED.meta.json" ] && cp "$BAKED.meta.json" /app/data/models/
  chown app:app /app/data/models/*
}

feature_version() {   # prints the feature version a model file was trained with ("" if unknown)
  python - "$1" <<'PY' 2>/dev/null || true
import json, sys
try:
    print(json.load(open(sys.argv[1] + ".meta.json")).get("feature_version", ""))
except Exception:
    print("")
PY
}

trained_on_corpus() {  # prints 1 when the model was trained with the public corpus, 0 for the small starter set
  python - "$1" <<'PY' 2>/dev/null || true
import json, sys
try:
    td = json.load(open(sys.argv[1] + ".meta.json")).get("training_data") or {}
    print({True: 1, False: 0}.get(td.get("corpus_present"), ""))     # unknown -> "" (leave the model alone)
except Exception:
    print("")
PY
}

if [ ! -f "$LIVE" ]; then
  install_baked
  echo "entrypoint: installed baked model into /app/data/models"
elif [ "$(trained_on_corpus "$LIVE")" = "0" ] && [ "$(trained_on_corpus "$BAKED")" = "1" ]; then
  # an earlier build could not download the corpus and left the weak starter model on the
  # data volume; this image has the real one. Without this, a successful rebuild changed nothing.
  for ext in "" .sha256 .meta.json; do
    [ -f "$LIVE$ext" ] && mv "$LIVE$ext" "/app/data/models/model.starter-only.joblib$ext"
  done
  install_baked
  echo "entrypoint: the model on the data volume was only the small starter model - installed the corpus-trained model of this image"
elif [ "$(feature_version "$LIVE")" != "$(feature_version "$BAKED")" ]; then
  # model from an older AntiPhish version on the data volume: it cannot be used by this
  # code (different text features). Keep it aside and install the model built with the image.
  for ext in "" .sha256 .meta.json; do
    [ -f "$LIVE$ext" ] && mv "$LIVE$ext" "/app/data/models/model.pre-upgrade.joblib$ext"
  done
  install_baked
  echo "entrypoint: model on the data volume was from another version - installed the new baked model"
  if [ -s /app/data/feedback.csv ]; then
    echo "entrypoint: NOTE you have feedback in data/feedback.csv - include it with:"
    echo "            docker compose exec -u app web python -m antiphish.learn"
  fi
fi
exec setpriv --reuid=app --regid=app --init-groups "$@"
