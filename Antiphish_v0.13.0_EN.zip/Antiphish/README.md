# 🛡️ AntiPhish

AI-assisted phishing email detection: heuristics + a text ML model + (optional) Qwen LLM,
with an explainable 0–100 risk score. **Current version: v0.13.0** – new **DNS shield**: a DNS
firewall for the user's devices (DNS-over-HTTPS endpoint, per-device tokens, block/allow rules,
live query log; section [v0.13](#v013--dns-shield) at the bottom). v0.12 brought buying credits
(built-in test checkout, real Stripe is a key swap; [v0.12](#v012--buying-credits)), v0.11
connected mailboxes (Gmail, Outlook,
any IMAP) and the new look (section [v0.11](#v011--connect-your-mailbox)). Measured detection
numbers: [v0.10](#v010--measured-end-to-end-rebuilt-where-it-failed) and
[v0.10.1](#v0101--checked-for-deployment); project status and next steps: [HANDOFF.md](HANDOFF.md);
server setup: [deploy/DEPLOY.md](deploy/DEPLOY.md).

| File | Role |
|---|---|
| `antiphish/email_parser.py`, `html_extract.py` | .eml → structured mail: visible/hidden text, **link targets**, forms, images, Authentication-Results with alignment |
| `antiphish/checks.py`, `domains.py`, `brands.py` | Links, sender, authentication, recipient context; registry of brands and their real domains |
| `antiphish/features.py` | Text patterns (EN / BS-HR-SR Latin and Cyrillic / SV): BEC, device-code, ClickFix, callback, QR ... |
| `antiphish/attachment_scan.py` | Deep attachment scanning in an isolated process (archives, Office, PDF, HTML/SVG, QR, OneNote, .rdp ...) |
| `antiphish/model.py`, `synth_legit.py`, `synth_phish.py` | Text ML classifier (word+character TF-IDF, calibrated linear SVM) and training data |
| `antiphish/scorer.py` | Three-tier evidence scoring → risk 0–100 |
| `antiphish/detector.py` | Main API: `analyze_email(email_dict)` / `analyze_eml(path)` |
| `antiphish/evaluation.py`, `eval_sets.py`, `scenarios*.py` | Honest measurement: separate test sets, probes, modern-mail scenarios |
| `antiphish/learn.py` | Retraining from feedback with a safety gate and rollback |
| `antiphish/llm_judge.py`, `monitor.py` | Qwen judge (optional), IMAP inbox monitoring |
| `webapp/`, `deploy/`, `Dockerfile` | Web application (FastAPI) and VPS deployment – see `deploy/DEPLOY.md` |
| `webapp/mailboxes.py`, `msgraph.py`, `mailbox_worker.py`, `crypto.py`, `netguard.py` | Connected mailboxes: reading over IMAP (read-only) and Microsoft Graph, background checking, encryption of stored access, mail server name verification |
| `scripts/build_corpus.py`, `scripts/scan_folder.py` | Downloading public corpora; measuring and learning on YOUR emails |

## Getting started

```bash
pip install -r requirements.txt
python scripts/build_corpus.py   # once: downloads public corpora (~450 MB) -> data/corpus.csv
python train.py                  # trains the model (~1 min) -> models/model.joblib (+ .sha256, .meta.json)
python evaluate.py               # how good is it? (separate test sets, probes, scenarios)
python parse_eml.py sample_phishing.eml     # analysis of one .eml file, with the score arithmetic
python demo.py                   # demo analysis
streamlit run app.py             # simple local UI
python -m pytest tests/          # 347 tests
```
Without the `build_corpus` step the model is trained only on the small starter set and is **much weaker**.

## API

```python
from antiphish.detector import analyze_email, analyze_eml

result = analyze_eml("suspicious.eml")          # recommended: a full email with headers
result = analyze_email({
    "subject": "Urgent: verify your account",
    "body": "...email text...",
    "sender": "PayPal <security@fake-paypal.tk>",
    "to": ["me@company.com"],                    # optional: enables recipient-context checks
    "spf": "fail", "dkim": "fail", "dmarc": "fail",
})
# result["score"] -> 0..100
# result["level"] -> LOW / SUSPICIOUS / HIGH / CRITICAL
# result["signals"] -> list of signals: signal, weight, detail, tier (firm | context | soft)
# result["score_breakdown"] -> the arithmetic: firm + (context + soft) x ml_factor + ml - mitigation = points
# result["ml_phishing_probability"] -> ML text assessment
```

## Risk levels

- **< 30 LOW** — normal caution
- **30-60 SUSPICIOUS** — verify the sender before clicking
- **60-85 HIGH** — probably phishing; do not click
- **> 85 CRITICAL** — almost certainly phishing; block and report

## Limitations (honestly)

- Public legitimate-mail corpora are old (2000–2002) or of a narrow genre (mailing lists). Behaviour on
  **your own current** mail should therefore be measured: `python scripts/scan_folder.py export.mbox --expect legit`
  and feed wrong verdicts back through feedback. That is the most important next step.
- The text model is strongest on English. BS/HR/SR and Swedish are covered by generated examples and
  hand-written probes, not a real corpus.
- Abuse of real platforms (a real PayPal invoice with a fake note, a real Microsoft account) and
  image-only emails remain the hardest cases.
- The Qwen LLM part was not changed or retested against a live model in v0.10 (tests simulate it).
- The tool is an aid, not a guarantee. The version history below describes how it got here.

---

# Version history

> The sections below are kept as written at the time. Their numbers apply to the version and the
> measurement method of that time (see v0.10 for why some were over-optimistic).

## v0.1 — MVP (initial notes)

- ML trained on ~90 synthetic examples — good for a demo, **not for production**
- No sandbox attachment analysis (next phase)
- False-positive rate not calibrated on real traffic
- Heuristics designed to be explainable (explainability > maximum accuracy)

Roadmap from the MVP phase and where it stands today:

1. **Real dataset** instead of synthetic data — done in v0.8 (Nazario + SpamAssassin), expanded in v0.10
2. **VirusTotal/Urlscan integration** — done (v0.2; endpoint fix in v0.9)
3. **Microsoft Graph API** (reading from M365, banners) — not done
4. **Behavioral baseline** per company (for BEC) — not done; v0.10 adds BEC text patterns and recipient-context checks
5. **Multilingual model** (XLM-R / mBERT) — not done; v0.10 covers BS/HR/SR and Swedish through text normalization and generated examples

## v0.2 — "Real" upgrade

- **280-sample starter corpus** including evasion variants (spaced words,
  leetspeak, homoglyphs, QR/vishing lures, BEC scripts) + calibrated model
  (trustworthy probabilities)
- **Real .eml parsing** (`parse_eml.py` / `analyze_eml()`) — headers,
  auth results, HTML->text, attachments
- **New signals**: display-name spoofing, freemail-for-role, risky attachments
- **Threat intel ready**: VirusTotal + urlscan.io clients in
  `antiphish/urlintel.py` — set `VT_API_KEY` / `URLSCAN_API_KEY` env vars
- **Evaluation**: `python evaluate.py` (current CV F1 ~0.81 on synthetic corpus)

### End-to-end test result
Phishing .eml (fake PayPal + IP-host URL + auth fails): **99.5 CRITICAL**
Legit .eml: **2.2 LOW**

### Metrics caveat
F1 ~0.81 is measured ONLY on the synthetic starter corpus. Real-world
performance requires a real labeled corpus — see roadmap item 1.


## v0.3 — Qwen AI judge + live inbox monitor

### Qwen LLM-as-judge (`antiphish/llm_judge.py`)
- Local & free via **Ollama**: install from ollama.com, then `ollama pull qwen2.5:7b`
- Or cloud via **DashScope**: set `DASHSCOPE_API_KEY` + `QWEN_PROVIDER=dashscope`
- Returns strict JSON verdict -> `llm_phishing_judged` (+25/35) or `llm_clean_judged` (-12)
- Usage: `analyze_email(email, use_llm=True)` — degrades gracefully if Qwen down

### Live monitor (`python -m antiphish.monitor`)
Connects to any IMAP mailbox and analyzes every new email automatically,
raising a Windows desktop notification when level >= SUSPICIOUS.
All alerts also go to `antiphish_alerts.log`.

Setup (Gmail): 2FA -> App password, then:
```
set IMAP_HOST=imap.gmail.com
set IMAP_USER=you@gmail.com
set IMAP_PASSWORD=your_app_password
python -m antiphish.monitor
```
Stop with Ctrl+C. Works with Outlook (imap-mail.outlook.com), Yahoo, etc.

### New tests: 14 total, all passing.


## v0.4 — FP fixes + feedback loop

- `auth_all_pass` legitimacy signal (-15): SPF+DKIM+DMARC pass marks sender as likely legit
- ALL CAPS detection ignores product codes (YZY, QNTM, B2B), needs 5+ hits
- Reply-To extraction fixed (parses real address from 'Name <addr>' headers)
- Reduced weights for many-subdomains / very long URLs (newsletter tracking links)
- **Feedback loop**: put misclassified emails into `data/feedback.csv` as
  `"subject + body text",0` (legit) or `,1` (phishing), then `python -m antiphish.learn`.
  Each retrain includes your real traffic -> fewer false positives over time.
- Monitor: set `MONITOR_USE_LLM=1` to add Qwen judgment to every scanned email
  (fixes borderline cases like 'Confirm your email' transactional mail).
- Startup log now shows VirusTotal ON/OFF and LLM ON/OFF status.

Measured on your real inbox traffic: newsletters dropped from HIGH (80) to LOW (5-16),
real phishing stays CRITICAL (99.3).


## v0.5 — Setup wizard + provider auto-detection

`python -m antiphish.monitor` now starts an interactive wizard if no
credentials are configured:
1. Enter your email -> provider auto-detected (Gmail, Outlook, Yahoo,
   iCloud, AOL, GMX, Zoho, Proton, Seznam + IMAP host guessing for unknown domains)
2. Provider-specific app-password instructions shown
3. Password entered via hidden input (getpass)
4. Connection tested BEFORE saving; 3 attempts on failure
5. Optional: save to `.env` (auto-loaded on every start) - never commit .env!

Environment variables / .env still override the wizard (IMAP_HOST, IMAP_USER,
IMAP_PASSWORD). `.env` loader is built into config.py - no extra dependency.

## v0.5.1 - critical fix
run() polling loop restored (dropped accidentally in the wizard refactor) +
30s socket timeout on all IMAP connections. Regression test added.

## v0.6 — Attachment scanning + score-based alerts

### Attachment scanning (`antiphish/attachment_scan.py`)
Every attachment is now analyzed, not just its filename:
1. SHA256 hash -> VirusTotal file reputation (hash lookup only, no upload)
2. PDFs: text extracted (pypdf, with raw-byte fallback) -> phishing
   heuristics + ML probability on the content
3. URLs found inside the file -> same URL checks as body links
4. Size cap 10MB

### Score-based notifications
Monitor alerts only when score >= NOTIFY_MIN_SCORE (default **70** =
HIGH and above). Newsletters at 40-60 no longer pop notifications.
Override: set NOTIFY_MIN_SCORE=60 (or any value) in .env / config.

Startup line now shows the threshold: "Alert score >= 70".
Tests: 26 total, all passing (incl. end-to-end .eml with phishing PDF).


## v0.7 — Deep attachment scanning (archives, Office, HTML/SVG, QR)

`antiphish/attachment_scan.py` was rewritten into a recursive, in-memory scanner.
**Files are never executed or written to disk.**

| What | Detection |
|---|---|
| ZIP / 7z / RAR / GZ / TAR | Opened in memory, up to 3 nested levels; each file inside is scanned again |
| Password-protected archives | Password is taken from the email body ("password: 1234", "lozinka je...", "lösenord:") or common ones; if it can't be opened → `archive_encrypted` (+30) |
| Zip bombs | Limits: 100 files, 20MB per file, 50MB total, compression ratio 100:1 |
| Executables | .exe/.js/.vbs/.lnk/.hta/.iso... inside archives, double extensions (`invoice.pdf.exe`), RTLO trick, real type from magic bytes (an .exe disguised as .pdf) |
| Office | VBA macros (docm/xlsm and legacy .doc via oletools), remote template injection, DDE, ActiveX, embedded objects, + text and URL analysis |
| PDF | JavaScript/Launch/EmbeddedFile, text, link annotations, **QR codes on the first 3 pages** |
| HTML / SVG | Password login forms, HTML smuggling (atob/Blob/eval), redirects, base64 payloads, JS in SVG |
| Calendar (.ics) | Links in invites (calendar phishing) |
| Images | QR code → URL → URL checks (quishing) |
| Attached .eml | Body + its own attachments recursively |

Qwen gets an **ATTACHMENT REPORT** (what the scanner found) and a prompt
hardened against prompt injection (email content is marked as untrusted).

```bash
python parse_eml.py suspicious.eml --llm      # CLI with attachment analysis
streamlit run app.py                          # UI now accepts attachment uploads
```

Optional libraries (`requirements.txt`) enable 7z/RAR/QR/macros; without
them the scanner still works and only reports that it could not inspect the file.

Tests: 45 total (19 new in `tests/test_attachments.py`), all passing.


## v0.8 — Real-data model + launch blockers fixed

### ML model trained on real phishing (Nazario 2015-2025) + modern legit mail
```bash
python scripts/build_corpus.py   # downloads ~110MB public corpora -> data/corpus.csv (7,203 emails)
python train.py                  # corpus + generated modern legit + your data/feedback.csv
python evaluate.py               # honest metrics (see below)
```
- Text normalization (URLs/emails/numbers/years -> tokens) so the model learns
  language patterns, not "2002 email = legit".
- Word + character n-grams (resists `P a y P a l`, `verífy`, `acc0unt`).
- `antiphish/synth_legit.py`: 1,500 generated MODERN legit mails (receipts,
  sign-in alerts, newsletters, notifications) - public legit corpora are ~20 years old.
- Your `data/feedback.csv` is weighted x5: your own mail matters most.
- `models/model.joblib.sha256`: model is hash-verified before loading
  (pickle files can execute code); a tampered model is refused and retrained.

| Metric (held-out) | old synthetic model | v0.8 |
|---|---|---|
| Modern legit flagged as phishing (probe set) | 57% (corpus-only model) | **3%** |
| Modern phishing caught (probe set) | – | **93%** |
| 2024-2025 phishing caught (never seen in training) | – | **91%** at 99.9% precision |

Caveat: the probe sets are small (30 legit / 15 phishing). Real-world numbers
need a labeled sample of real traffic - collect it via `data/feedback.csv`.

### Monitor fixes
- **No longer marks mail as read** (`BODY.PEEK[]`).
- **UID tracking** (`data/monitor_state.json`): mail you already opened on your
  phone is still scanned; nothing is scanned twice. First start scans the newest
  `INITIAL_SCAN` (default 20) messages.
- **Quarantine**: score >= `QUARANTINE_MIN_SCORE` (default 90 = hard evidence)
  is moved to the `AntiPhish-Quarantine` folder (Gmail: label). Disable with `QUARANTINE=0`.
- **Password in Windows Credential Manager** (`keyring`), not in `.env`.
- Log rotation (5 MB x 3). `.gitignore` added (protects `.env`).

### Hardening
- **Sandboxed attachment scanning**: separate worker process, hard timeout
  (`ATTACHMENT_TIMEOUT`, default 30 s) and 1 GB memory cap (Linux/macOS).
  A hanging/crashing file kills only the worker and is flagged as suspicious.
- **Prompt-injection guard**: a Qwen "clean" verdict can no longer lower the
  score when strong technical evidence exists.
- New text patterns for 2025-2026 lures (AiTM sign-in, device-code, MFA
  re-enrollment, QR, "corporate credentials").

Tests: 58, all passing. Data licensing: see NOTICE.md.

## v0.8.3 — Qwen calibration
- Qwen now receives TECHNICAL CONTEXT (DMARC alignment, List-Unsubscribe, link
  domains vs sender domain, scanner red flags) and must name concrete `red_flags`.
- An LLM "phishing" verdict counts fully (+35) only when TECHNICAL evidence
  corroborates it. Alone it's a tie-breaker: +8 for authenticated senders, +15 otherwise.
  Text heuristics don't count as corroboration (same words the LLM reads).
- LLM verdict no longer cancels the legit-newsletter bonus.
- `url_at_symbol` only for the real trick (`https://brand.com@evil.tk`), not for
  e-mail addresses inside tracking-link paths.


## v0.9 — Web app for live testing (Hostinger VPS)

```
webapp/            FastAPI web app: login, .eml upload / paste, results, history,
                   feedback, credits, admin panel (Bosnian UI)
webapp/mail_intake.py   forward-to-scan mailbox (scan@yourdomain.com) -> e-mail report
Dockerfile, docker-compose.yml, deploy/   VPS deployment (Caddy auto-HTTPS)
deploy/DEPLOY.md   step-by-step guide (Bosnian)
```
Run locally: `pip install -r requirements-server.txt`, then
`python -m webapp.manage create-admin you@x.com` and `uvicorn webapp.main:app --reload`.

Security: scrypt passwords, CSRF on every form, login rate limit (no user
enumeration), per-user result isolation, strict CSP (no inline JS/CSS),
defanged links everywhere (incl. bare domains in e-mail reports), e-mail text
auto-deleted after `RETAIN_TEXT_HOURS`, container runs as non-root.

Also fixed in v0.9: VirusTotal URL lookup used a wrong endpoint (never worked);
model/sandbox thread safety for the web server; configurable DATA_DIR / model path.

Tests: 79 (15 web/intake). Docker image built and verified end-to-end
(corpus download + training inside the image, scans, feedback -> retrain).


## v0.10 — Measured end to end, rebuilt where it failed

v0.9 reported "91% of 2024-2025 phishing caught at 99.9% precision". That number was the text
model at p >= 0.5, not the score a user sees. v0.10 starts from a new measurement: the **whole
detector** (parse -> rules -> model -> score) on raw mail it was never trained on, with both
versions run on exactly the same messages.

| Held-out raw mail (never trained on) | n | v0.9 | **v0.10** |
|---|---|---|---|
| Phishing, Nazario 2024-2025 — rated HIGH or CRITICAL | 884 | 52.8% | **90.2%** |
| ...of which rated LOW (missed) | | 27.0% | **3.3%** |
| Honeypot mail, phishing_pot 2022-2026 (another collector) — HIGH or CRITICAL | 1,500 | 33.0% | **78.5%** |
| ...rated LOW | | 20.4% | **7.5%** |
| Legitimate, SpamAssassin held-out — flagged SUSPICIOUS or higher | 317 | 17.7% | **1.3%** |
| Legitimate, Enron mailboxes never seen in training — flagged | 601 | 9.0% | **1.5%** |
| Legitimate, Apache lists 2024-2026 never seen in training — flagged | 339 | 27.1% | **0.6%** |
| Legitimate mail rated HIGH or CRITICAL (all three sets) | 1,257 | 2 mails | **0** |
| Scenario suite, dev: legit rated LOW / phishing rated HIGH+ | 30 / 30 | 27 / 12 | **30 / 30** |
| Scenario suite, holdout: legit rated LOW / phishing rated HIGH+ | 20 / 21 | 16 / 9 | **19 / 21** |

Reproduce: `python scripts/build_corpus.py --with-phishing-pot && python evaluate.py --e2e --max 1500`.
Each version was trained with its own recipe on its own training split (phishing up to 2023).

How to read it:
* phishing_pot is honeypot mail: besides phishing it contains casino/health/dating spam and a
  few ordinary messages. AntiPhish targets phishing and scams, not spam in general, so that row
  under-states recall on real phishing. It is licensed CC BY-NC and is used for evaluation only.
* The legitimate public corpora are from 2000-2002 or are developer mailing lists. They say
  little about today's consumer inbox. The scenario suite (`antiphish/scenarios*.py`, 101
  complete messages with realistic headers) was written for that, by this project — the holdout
  half was written after the rules were frozen and run once, but it is still our own writing.
  **Measure on your own mail** (below) before trusting any of this.
* With the production model the holdout phishing result is 21/21; with the stricter evaluation
  model (trained without 2024-2025 phishing) it is 20/21.

### What was wrong in v0.9 (each one measured, then fixed)

| Finding | Evidence | Fix |
|---|---|---|
| Passing SPF+DKIM+DMARC subtracted 15 points, and the score formula turned a negative sum into a huge negative: authenticated phishing with ML = 0.99 scored 7 (LOW) | 27% of 2024-2025 phishing rated LOW; 98% of those carried `auth_all_pass`; half of that corpus passes all three checks | New scorer (`scorer.py`): evidence points in three tiers; mitigation can never reduce firm evidence; a pass is worth -3 |
| HTML was regex-stripped, every `<a href>` was thrown away | links found in 30% of phishing mail; 794 of 884 contain `<a href>` | `html_extract.py`: real parser — link targets with anchor text, forms, hidden text, inline images, Outlook-only links |
| Brands matched as substrings | `s3.amazonaws.com`, `login.microsoftonline.com`, `store.steampowered.com` flagged as spoofing; `paypal.evil-host.tk`, `paypa1.com` not flagged; "Sebastian" flagged as the bank SEB | `brands.py`: 117 brand entries (global + Sweden + BA/RS/HR) with their real domains, look-alike spelling, platform tenants |
| Any Cyrillic letter in the sender = "spoofing" | `Петар Петровић <petar@firma.rs>` got +15 | only mixed alphabets inside one word/address count |
| The model had learned the corpus owner's address | 48% of phishing training texts contained "jose"/"monkey.org"; adding those two words to a harmless sentence moved p from 0.006 to 0.70 | `scrub_recipient()` at training and scan time: the recipient's own name/domain become placeholders |
| Unbounded regexes over the whole body | `normalize_text` on 80,000 characters without "@": 14 s (quadratic) — one large mail could occupy a scan slot for minutes | bounded patterns + input caps; regression test |
| Reply-To on another domain = +18, also on mailing lists | 18% of held-out legitimate mail rated SUSPICIOUS | list/helpdesk aware; only "replies go to a free mailbox" stays firm |
| One unreachable download discarded the whole corpus | `build_corpus.py` raised on the first error; the image was then built with the small starter model, with only a WARNING in the build log | every source optional, retried, reported; manifest; class-balance guard |
| Retrained models were installed without any check (feedback weighted x5) | v0.9 had no check at all. Experiment with the v0.10 trainer: 400 wrongly labelled feedback rows raised missed probe phishing from 3 to 17 | `learn.py` gate: a retrained model must match the live one on unseen mail, else it is not installed; `--rollback` |
| nginx sample config appended `X-Forwarded-For` | checked with uvicorn: a client sending its own header value is seen by the app as that IP, which defeats the per-IP login limit | header is overwritten; additional per-account limit |

### Detection added (what current reporting says attackers do)

The additions were chosen from two things: what the held-out mail shows, and 2026 threat reporting.

* **Own measurement.** 60% of the 2024-2025 Nazario phishing passes DMARC and half of it passes
  SPF, DKIM and DMARC together, so "it passed DMARC" is not a verdict. (An even higher industry
  figure circulates; we only saw it second-hand — a PhishEye summary attributing it to KnowBe4 —
  and did not check the primary report, so it is not relied on here.)
* [Microsoft, Q1 2026](https://www.microsoft.com/en-us/security/blog/2026/04/30/email-threat-landscape-q1-2026-trends-and-insights/):
  QR-code phishing as the fastest-growing technique, CAPTCHA-gated phishing pages, ClickFix
  delivered through fake CAPTCHA.
* [Microsoft, Q3 2026](https://www.microsoft.com/en-us/security/blog/2026/11/05/email-threat-landscape-q3-2026-trends-and-insights/):
  SVG attachments at the centre of CAPTCHA-gated attacks, a device-code campaign delivered with QR
  codes, payroll / purchase-order lures carrying disguised archives.
* [Barracuda, 2026 Email Threats Report](https://www.barracuda.com/reports/2026-email-threats-report):
  phishing-kit techniques — URL obfuscation, MFA bypass, CAPTCHA, QR codes, malicious (HTML)
  attachments, abuse of trusted platforms, Blob URIs, ClickFix.
* [LevelBlue SpiderLabs](https://www.levelblue.com/blogs/spiderlabs-blog/the-device-code-phishing-tsunami-what-were-seeing-in-the-wild):
  device-code phishing kits, password-protected PDFs, legitimate platforms used as redirectors,
  `workers.dev` hosting.
* [APWG, Q2 2026](https://docs.apwg.org/reports/apwg_trends_report_q2_2026.pdf): what BEC
  messages ask for — gift cards 54%, wire transfer 17%, payroll diversion 10%.

What that became in the code:

* **Links**: redirectors and link rewriters are unwrapped (Safe Links, Proofpoint, `google.com/url`,
  ad-click, AMP, translate proxy); IPFS gateways; free hosting / app platforms (`pages.dev`, `r2.dev`,
  `workers.dev`, `vercel.app`, `web.app` ...); wildcard and dynamic DNS; "the text shows one site,
  the link opens another"; look-alike and embedded domains; homograph IDNs (real IDNs are left alone).
* **Sender**: display-name impersonation with word boundaries and disguised letters; look-alike sender
  domains; role claims from free mailboxes; *recipient context* — your own address in the subject,
  your organisation's name in a stranger's display name, "IT Helpdesk" from an outside domain.
* **Text** (EN, BS/HR/SR in Latin and Cyrillic, SV, some DE): gift-card requests, bank-detail
  change, payroll diversion, BEC pretext, device-code, ClickFix, callback ("call to cancel"),
  QR lures, mailbox/password-expiry notices, parcel fees, refunds, wallet seed phrases, extortion;
  mixed-alphabet words and invisible characters.
* **Attachments**: QR codes in images *embedded in the body*; calendar parts; `.rdp`, `.library-ms`,
  `.xll`, `.msc`, OneNote with embedded scripts; HTML that posts to Telegram/Discord webhooks;
  ClickFix and fake-CAPTCHA pages; SVG with embedded HTML; password-protected PDFs; links inside
  attached e-mails.
* **Fake-invoice pictures**: an "order/invoice" notice that is only an image.

### Scoring (`scorer.py`)

`score = 100 * (1 - exp(-0.035 * points))`, where
`points = firm + max(0, (context + min(soft, 32)) * factor + ML - mitigation)`.

* **firm** — technical indicators; counted in full, nothing argues them away.
* **context** — suspicious only in company (free hosting, shortener, Reply-To elsewhere); weighted
  by how phishing-like the text model finds the mail (`factor` 0.3 ... 1.0).
* **soft** — generic wording; as context, and capped.
* **ML** — up to 28 points: alone it reaches the bottom of HIGH, never CRITICAL.
* **mitigation** — authenticated newsletter, verified brand sender; reduces wording only.

Every result carries `score_breakdown`, and the web page shows the arithmetic.

### Model and data

```bash
python scripts/build_corpus.py       # ~17,000 mails: 8,600 phishing / 8,300 legitimate
python train.py                      # + 5,300 starter/generated texts; ~35 s on 4 cores
python evaluate.py [--e2e]           # held-out protocol, probe sets, scenario suite
```

* Phishing: Nazario 2015-2025 **plus** the 2004-2015 mailboxes (same era as the public legitimate mail).
* Legitimate: SpamAssassin, a sample of **Enron** business mail (invoices, payments, IT notices),
  **Apache lists 2024-2026**. Licences and caveats: NOTICE.md.
* Generated: modern legitimate mail and lures in EN / BS-HR-SR / SV (`synth_legit.py`, `synth_phish.py`).
* Classifier: calibrated linear SVM on word + character TF-IDF, chosen on the held-out protocol
  (recall at 1% false positives 96.5% vs 94.6% for the previous logistic regression).
* Text model alone, held out: ROC-AUC 0.996; 2024-2025 phishing 93.0% at p >= 0.5 with 0.29% of
  legitimate mail above 0.5.

Two ablations worth knowing:
* Adding the legacy phishing **without** Enron made the model flag 24% of held-out business mail
  (0.7% with both). `train.py` therefore trims the phishing side if a legitimate source is missing.
* Without the generated modern legitimate mail the same model flags 73% of the original
  modern-legit probe set (48-100% of the newer ones). Good behaviour on today's mail currently
  rests on generated examples — the reason the next step is your own mail:

```bash
python scripts/scan_folder.py export.mbox --expect legit                  # how many false alarms?
python scripts/scan_folder.py export.mbox --expect legit --add-feedback   # wrong verdicts -> feedback.csv
python -m antiphish.learn                                                 # retrain; installed only if the gate passes
```

### Operations

* Model files carry `.meta.json`; a model built with other text features or another scikit-learn
  version is refused and rebuilt instead of mis-scoring silently. After an upgrade the container
  installs the new baked model and keeps the old one as `model.pre-upgrade.joblib`.
* A retrained model is picked up within ~30 s; no restart.
* The inbox monitor still quarantines at score >= 90, and now additionally requires 40 points of
  firm technical evidence (`QUARANTINE_MIN_FIRM`): wording plus the text model can raise the
  alarm but never move mail on their own. (v0.10.0 still counted firm *text* patterns such as a
  gift-card request towards those 40 points; since v0.10.1 only non-text evidence counts.)
* Stored scan text (used for feedback) is recipient-neutral.

Not re-verified in v0.10: the Qwen LLM judge against a live model (code unchanged), the IMAP monitor
against a real mailbox (one change: the quarantine condition above), the Streamlit UI (`app.py`,
unchanged), a deployment on the VPS. (Most of this list was worked through in v0.10.1, below.)

Tests: 191 (112 new). Docker image: see HANDOFF.md for what was verified.

## v0.10.1 — Checked for deployment

No change to the detection rules or the text model (a model file from v0.10.0 still loads). This
release is the result of running everything the way it will run on the server — `docker compose`
with Caddy and HTTPS, the forward-to-scan worker and the inbox monitor against a real IMAP/SMTP
server, the Qwen judge against a live model — and fixing what that turned up.

### What was run (2026-11-23)

| What | How | Result |
|---|---|---|
| `docker compose up -d --build` from the release zip | real compose file, Caddy with its internal CA for a `.localhost` name | image built, web healthy, HTTP -> HTTPS redirect, HSTS/CSP headers, Secure + HttpOnly cookie |
| Web application through HTTPS | 38 scripted checks: login, CSRF, upload / paste, attachments, credits, feedback, admin, access control, password change, limits | all pass |
| Proxy headers | 10 wrong logins, each with a different forged `X-Forwarded-For` | Caddy ignores the forged header, the lock-out holds; behind real nginx with the sample config the app also saw the true peer address |
| Markup in subject, sender, links, comment | `<script>`, `onerror=`, `javascript:` | escaped on result, history and admin pages |
| Restart behaviour | `down` / `up`, Docker daemon restart | accounts, history and model persist; containers come back on their own |
| Small server | corpus + training with 1 CPU and a memory limit | training peaks at ~1.2 GB and takes ~40 s; fails at 1 GB; `antiphish.learn` in the running container peaks at ~1.45 GB |
| Forward-to-scan worker (`--profile intake`) | GreenMail (IMAP + SMTP over TLS, own test CA): attached, `.eml`, inline forward, stranger, auto-reply, spoofed, disabled user | reports arrive, strangers get nothing |
| Inbox monitor | same server | mail with technical evidence moved to `AntiPhish-Quarantine` (IMAP MOVE); a gift-card request from a free mailbox raises a CRITICAL alert and stays; legitimate mail untouched and unread |
| Qwen judge (`--profile llm`) | Ollama + `qwen2.5:3b`, all 101 scenarios, three prompt versions | see below |
| Streamlit UI, `demo.py` | `streamlit.testing` AppTest, server start | work with the v0.10 result format |
| Upgrade | release zip over a running v0.10.0 directory with `rsync` | data and `.env` kept, new image runs |
| A small VM on another cloud (the guide's Google Cloud variant) | the guide's commands in clean Debian 12 and 13 images; training with 0.5 CPU / 1.5 GB, and with 0.25 CPU / 0.7 GB + 2 GB swap; Docker MTU setting with a real daemon (the test host itself has an uplink MTU of 1400) | Docker installs; training takes 95 s resp. 216 s instead of 40 s, and fails with 1 GB and no swap; default, compose and build networks take the configured MTU and the stack runs with it. Not run on a real Google Cloud VM |
| Plain Ubuntu, no Docker template | the guide's commands typed into clean Ubuntu 24.04 and 26.04 images | `get.docker.com` installs Docker 29.10.0 and Compose 5.8.0 - the versions everything above ran on; `docker compose config` accepts the release. Not exercised there: the Docker service starting under systemd |

Still not run: a real VPS with public DNS and a Let's Encrypt certificate, Hostinger's mail
servers, the DashScope API (no key), the monitor against Gmail/Outlook. `qwen2.5:7b` was run once
(numbers below).

One observation is unexplained (HANDOFF.md, section 4): three times in about three hours a single
request from the test host to Caddy's published port got no answer, each time within minutes of
the web container being (re)created. It could not be reproduced on purpose, and two probes that
then called the site every two seconds - one from the host, one inside the Docker network - saw
no further stall in about a thousand calls each.

### What that turned up

| Finding | Evidence | Fix |
|---|---|---|
| IMAP connections did not verify the server certificate | `imaplib.IMAP4_SSL` uses an unverified context unless given one; the worker and the monitor logged in to a server with an untrusted certificate, and under a wrong host name | `providers.mail_ssl_context()`: certificate and host name are checked for IMAP and SMTP; explicit opt-out `MAIL_TLS_VERIFY=0`; the error says what to change |
| A wrong mailbox password was retried on every poll (20 s), with a traceback each time | by reading the loop: a refused login fell into the catch-all handler; mail providers lock accounts or block addresses for repeated failures | clear message (quotes in `.env`, app password), retry interval grows to 15 min |
| Passwords with `$` or `#` in `.env` were cut off by Compose | `abc$def` arrived in the container as `abc` | documented (`'single quotes'`), checked by `deploy/provjera.sh` |
| The intake container was shown as `unhealthy` | it inherited the web health check (port 8000) | health check disabled for that service |
| With `qwen2.5:3b` the "AI scan" made detection worse | the model called 49 of 51 phishing scenarios legitimate; that opinion took 12 points off, two scenarios fell from HIGH to SUSPICIOUS | new prompt and scanner context (below); a "legitimate" opinion can no longer lower a HIGH/CRITICAL rating |
| Display name and subject went into the LLM prompt unfiltered | a display name containing the block delimiter closed the "untrusted" section early | delimiters removed from all sender-controlled text; finding details are reduced to plain characters |
| An AI scan the model never answered was charged as an AI scan, with no trace on the page | time-outs are normal on a CPU-only server | charged and labelled as a quick scan, with a note; the reason is logged |
| A neutralised or undecided AI opinion was invisible | weight-0 signals were not rendered | shown under "AI model opinion" on the page and in the mail report |
| DashScope endpoint was fixed to the mainland-China region | API keys are bound to a region; an international key is rejected with HTTP 401 | `DASHSCOPE_BASE_URL`; a 401 is logged with that hint (default unchanged) |
| Quarantine counted firm *text* patterns as "technical evidence" | a gift-card request from a free mailbox (wording, plus 20 points for the sender) was moved out of the inbox | only non-text, non-LLM firm evidence counts towards `QUARANTINE_MIN_FIRM`; 26% instead of 29% of the held-out Nazario phishing would be moved, still 0 of 1257 legitimate |
| A successful rebuild after a failed corpus download changed nothing | the container start only installed the image's model when none existed or the feature version differed, so the weak starter model stayed on the data volume | a starter-only model is replaced by a corpus-trained one on start (kept aside as `model.starter-only.joblib`); a trained or unknown model is never touched — three cases run in the container |
| Model file written through `docker exec` was world-writable | `docker exec` ran with umask 0 in the test environment; the file is a pickle | fixed permissions (0644) on model, hash and metadata |
| A later build could install different library versions than the tested one | only scikit-learn was pinned | `constraints-server.txt` (all 60 packages of the tested image) |
| Two old tests left a fake LLM installed for the rest of the test run | plain assignment instead of `monkeypatch` | fixed; it had hidden nothing, but would have |
| Streamlit showed `:darkred[CRITICAL]` literally | not a Streamlit colour | `red` |

### Qwen as a second opinion — measured

Live `qwen2.5:3b` through Ollama (4 CPU cores), the 101 scenarios, scanner without and with the judge:

| | v0.10.0 (old prompt, no guard) | v0.10.1 (new prompt and context, guard) |
|---|---|---|
| Phishing scenarios the model itself called phishing (dev · holdout) | 2/30 · 0/21 | **27/30 · 18/21** |
| Legitimate scenarios the model called phishing | 0/50 | 0/50 |
| Phishing rated HIGH/CRITICAL: scanner alone -> with the judge | 51/51 -> 49/51 | 51/51 -> 51/51 |
| ... of those CRITICAL | 41 -> 39 | 41 -> 45 |
| Phishing scenarios whose score the judge lowered | 9 | 0 |
| Legitimate rated LOW: scanner alone -> with the judge | 49/50 -> 50/50 | 49/50 -> 50/50 |
| Seconds per mail (median / slowest) | 9.3 / 25.0 | 9.3 / 22.3 |

How to read it: the scenarios are our own writing; the prompt was chosen on the "dev" half (a third
version that recognised one more phishing mail but accused three legitimate ones was rejected), the
"holdout" half was not looked at while choosing. A 3-billion-parameter model is a weak judge; the
scoring treats it accordingly — an uncorroborated "phishing" opinion adds at most 8-15 points, a
"legitimate" opinion can clear a SUSPICIOUS mail but never lower HIGH or CRITICAL.

One run with `qwen2.5:7b` and the same prompt: 46/51 phishing scenarios called phishing, 1/50
legitimate ones (an internal IT password reminder, which went from LOW to SUSPICIOUS), median 24 s
per mail, two answers later than the 90 s limit (a build was running on the same machine). On
this suite it is not better than the small model, and two to three times slower. Ollama used
2.7 GB of RAM with the 3b model loaded and 5.2 GB with the 7b model; with two CPU cores instead
of four, the 3b model took 16-37 s per mail.

### New for the server

* `deploy/provjera.sh prije | poslije` — read-only checks before and after `docker compose up`:
  Docker, memory, ports, `.env`, DNS, containers, model, certificate, headers. Each failed check
  says what to do.
* `scripts/eval_llm.py` — the measurement above for whatever Qwen model is configured
  (`docker compose exec -u app web python scripts/eval_llm.py`); raw answers of the runs quoted
  here are in `docs/llm_eval_2026-11-23/`.
* `deploy/DEPLOY.md` — one-screen command list, port / firewall / DNS (AAAA) pitfalls, what the
  worker's log lines mean; a complete variant for "server on Google Cloud, site and domain stay
  at Hostinger" (firewall check boxes, static address, the one DNS record, swap, Docker MTU).
* `provjera.sh` also judges memory by what was measured (and prints the swap command), notices a
  network MTU below Docker's (and prints the fix), and gives one instruction when Docker is missing.
* `.env.example` — AI off by default (as the guide says), time zone, quoting rule.
* `.gitattributes` and a `sed` in the Dockerfile keep shell scripts on Unix line endings.

Tests: 236 (45 new in `tests/test_v0101.py`). For the code fixes, each test was checked to fail
when its fix is taken out again; the container start script and the deployment files were
checked in the running container.

## v0.11 — Connect your mailbox

Until now a user had to save a message as `.eml` and upload it. From v0.11 the user connects a
mailbox once and the server checks every new message on its own; the results appear on the new
overview page. The detection rules and the text model are unchanged (a v0.10 model file loads as is).

### What is new

* **"Connect email"** – Gmail, Yahoo, iCloud, Hostinger and any other IMAP server with an (app) password;
  Outlook.com / Hotmail / Microsoft 365 with Microsoft sign-in (OAuth 2.0 authorization code flow with
  PKCE) and Microsoft Graph, permission `Mail.Read`. The Microsoft part needs an app registration by the
  operator (`MS_CLIENT_ID`, `MS_CLIENT_SECRET`, see `deploy/DEPLOY.md`); without it the page says so and
  asks for no password.
* **Mailbox worker** (`webapp/mailbox_worker.py`, a thread of the web process; no new container): the
  newest 20 messages when a mailbox is connected, then every new one, each mailbox every 2 minutes.
  A message is checked once (IMAP UID / Graph id stored with the result). No credits, or the hourly
  limit reached: the mail waits, it is not skipped. A refused password is tried three times with pauses
  of 5 and 30 minutes, then the mailbox waits for its owner; a refused Microsoft token is never retried.
* **Read-only by construction**: the folder is opened with `EXAMINE`, bodies are fetched with
  `BODY.PEEK[]` and a byte limit the server cannot exceed, nothing is stored, moved, flagged or deleted.
* **Stored secrets** (`webapp/crypto.py`): AES-256-GCM, key derived from `SECRET_KEY` (or `MAILBOX_KEY`),
  each value bound to its user and mailbox. A copy of the database alone does not reveal them; whoever
  controls the running server can decrypt them - the privacy page says so.
* **A mail-server name typed by a user** (`webapp/netguard.py`): only port 993, a real host name, every
  address it resolves to must be public (also NAT64 / 6to4 wrappers are refused), the connection goes to
  the address that was checked and the certificate is verified against the name.
* **New pages** (no external fonts, scripts or styles; the strict CSP is unchanged): overview with
  mailbox state, counts and the message list with the main reason for each rating, filters and paging;
  mailbox pages with step-by-step help; the manual check moved to `/check`; result, account, admin and
  privacy pages redrawn; usable on a phone. The overview refreshes itself when new results arrive
  (`static/app.js`, the only script; everything works without it).
* **Why no "Sign in with Google"**: reading Gmail through Google's API needs a restricted scope
  (verification plus a yearly paid security assessment for a public app; in testing mode at most 100
  listed users and access that expires after 7 days). An app password over IMAP has none of these limits.

### A bug found on the way - and it concerns v0.10.1 in production

Driving the pages with a real browser showed a page that stopped answering some seconds after a mail
with an attachment had been checked. Cause: the attachment scanner runs in a worker process made with
`fork()`, and that worker kept a copy of every connection the web server had open at that moment. When
the server later closed such a connection, the other side (the browser, or Caddy in front) never learned
of it and sent its next request into a connection nobody read. Fixed in
`attachment_scan._close_inherited_sockets()`.

Measured through Caddy/HTTPS on the same image, with only `attachment_scan.py` swapped
(`tests/e2e/keepalive_ab.py`: one mail with an attachment is scanned, then 12 page loads 20 s later):

| | page loads that got no answer within 8 s | sockets held by the worker |
|---|---|---|
| `attachment_scan.py` of v0.10.1 | **7 of 12** | 10 |
| v0.11 | 0 of 12 | 0 |

This is very likely also what the "three unexplained stalls" noted in HANDOFF for v0.10.1 were.

### What was run (2026-11-23)

All of it on the image built from the release zip, behind Caddy with HTTPS, unless noted.

| What | How | Result |
|---|---|---|
| Unit tests | 111 new (347 in total): stand-in IMAP and Microsoft servers that record every request; 39 deliberate faults put into the code one at a time | all pass; every fault was caught |
| Real IMAP server | GreenMail, TLS with a test CA, certificate and host name verified | connect, first check, new mail, periodic check, disconnect |
| The pages in a real browser | Chromium (playwright), 13 checks: wrong password, refused server name, results appear without touching the page, "Check now", result page, disconnect, no CSP or script errors | all pass |
| Microsoft sign-in | Chromium against a stand-in server speaking Microsoft's documented protocol over real HTTP, 14 checks: redirect with PKCE, return with the session intact, refused consent, results, new mail, each message downloaded once, revoked access, disconnect | all pass. **Not run against Microsoft itself** |
| Harder situations | server restarted while a mailbox was being connected; 30 messages (only the newest 20 checked, none twice); a 16 MB message; mail server silent for a minute | all as intended; after everything the mailbox still had every message unread |
| Upgrade | the guide's commands over a running v0.10.1 with its data | database extended in place, the user stayed signed in, old results and credits intact, model file untouched; the site answered with the old version during the build and returned 502 for about 2.5 s when the container was replaced |
| Everything from v0.10.1 | the scripted HTTPS checks, extended to 51 | all pass |
| `deploy/provjera.sh poslije` | new section for the mailbox checker and outbound port 993 | reports correctly (in the test environment outbound 993 is closed - and it says so) |

**Not checked:** a real Gmail, Yahoo, iCloud or Hostinger mailbox (the test environment has no outbound
IMAP), Microsoft's real sign-in and Graph, real-world volumes (hundreds of mailboxes).

### Decisions taken (change them in `.env`)

* Automatically checked messages cost **0 credits** (`COST_MAILBOX`); limits: 120 checks per user and
  hour, 3 mailboxes per user.
* Results of automatic checks are deleted after **90 days** (`MAILBOX_RETAIN_DAYS`), except those the user
  gave feedback on.
* Automatic checks do **not** go to the Qwen model (`MAILBOX_USE_LLM=0`).
* Nothing is moved or deleted in the user's mailbox, and no warning e-mail is sent: the result is on the
  overview page only. Both are possible next steps (see HANDOFF).

## v0.12 — Buying credits

Users can top up their credits themselves, on the new **Buy credits** page (`/billing`). The
detection, mailboxes and the model are unchanged; the database gets one new table
(`billing_events`) which extends itself on startup, like v0.11 did.

### How it works

* **Packages** – three by default (100 / 500 / 2000 credits, prices in EUR); your own set goes into
  `BILLING_PACKAGES` in `.env` as one line of JSON.
* **Two providers** (`BILLING_PROVIDER`):
  * `simulator` (default) – a built-in test checkout: no account, no keys, no real money. The
    "payment" runs through exactly the same crediting code as a real one, so the whole flow
    (packages → checkout → payment → credits on the account) can be tried out immediately.
  * `stripe` – real Stripe Checkout. The app creates the session with one HTTPS call (no Stripe
    library), the user pays on Stripe's page, and Stripe's webhook (`POST /billing/webhook`,
    event `checkout.session.completed`) adds the credits. Test mode: `sk_test_...` keys and card
    `4242 4242 4242 4242`; going live is a key swap, the code doesn't change. Setup:
    `deploy/DEPLOY.md`, section "Selling credits".
* **Once means once** – every payment is recorded by its event id and the credits are added in the
    same transaction; a retried webhook or a double-clicked Pay button cannot credit twice
    (`billing_events` primary key, `INSERT OR IGNORE` + credit update in one `BEGIN IMMEDIATE`).
* **The webhook checks Stripe's signature** (`STRIPE_WEBHOOK_SECRET`, HMAC-SHA256 over
    `timestamp.payload`, 5-minute timestamp tolerance) before anything is read from the payload;
    events that aren't a paid checkout for a known user and package are acknowledged and ignored.
* The simulator's checkout session is a signed, stateless token bound to the user it was created
    for – another user gets a 404, a forged signature gets a 404.

### What was run (2026-11-24)

15 new tests: the full simulator flow (buy → pay → credits added,
visible on the success and billing pages), idempotency (same payment twice → credits once),
session bound to its user, forged session signature refused, unknown package and CSRF checks,
login required, `BILLING_ENABLED=0` → 404 everywhere, Stripe webhook with a self-signed payload
(credits once, replay refused), bad/wrong/old signatures refused (400), unpaid and unrelated
events ignored, Stripe without keys → a clear message instead of a crash, custom packages from
`.env` (and fallback to the built-ins on invalid JSON). **Not run:** against Stripe itself – the
checkout request and the webhook verification follow Stripe's published API, the first real
`sk_test_` purchase is the first real test.

## v0.13 — DNS shield

A **DNS firewall** for the user's devices, built into the same app: the new **DNS shield** page
(`/shield`) creates devices, and each device gets a personal DNS-over-HTTPS (DoH, RFC 8484)
address `BASE_URL/dns-query/<token>`. An agent on the device (or any DoH client) sends raw DNS
queries there; domains on the user's block list are answered with NXDOMAIN on the spot, everything
else is forwarded byte-for-byte to the upstream resolver (`DNSFW_UPSTREAM`, default 1.1.1.1, UDP
with a TCP retry on truncated answers). Every query is written to the device's live log.

### How it works

* **Token = the only credential.** The token is shown once (at device creation); the server stores
  just its SHA-256 hash. Unknown or paused devices get a plain 404 – the server never behaves like
  an open resolver, and it all runs on the HTTPS port you already have (never open UDP/TCP 53).
* **Rules per user:** `example.com` (exact) or `*.example.com` (the domain + every subdomain),
  each block or allow; an *allow* always beats a *block* (personal whitelist). The domain
  `dns-shield-test.invalid` is always blocked – a built-in end-to-end test.
* **Only the question is parsed.** The resolver's answer is passed through untouched; blocking
  needs just the queried domain, so there is no deep packet inspection and no fake certificates.
* **Safety rails:** per-device rate limit (`DNSFW_QUERIES_PER_MIN`, default 600/min), `last_seen`
  written at most once a minute, query log pruned after `DNSFW_LOG_RETENTION_DAYS` (default 14),
  upstream outage → SERVFAIL (the agent then fails open to plain DNS and keeps re-trying the
  shield every 30 s, so protection returns by itself).
* **The Windows agent** lives in `agent/` – a small zero-dependency program that points the PC's
  DNS at this server (with fail-open and automatic recovery), so the whole PC is protected, not
  just the browser. `agent/build-agent.bat` packs it into a single standalone .exe.
* **The database extends itself** on startup: `devices`, `dns_rules`, `dns_events` tables –
  nothing to migrate by hand (v0.10–v0.12 upgrades land here in one step too).

### What was run (2026-11-24)

15 new tests (373 in total, all passing): wire parsing (incl. rejecting responses and truncated
messages), NXDOMAIN synthesis (same id, echoed question), rule normalization and matching
(suffix vs exact, allow-beats-block), the full DoH flow over POST and GET (blocked → NXDOMAIN
without touching upstream, allowed → forwarded and logged), the built-in test domain, strangers
(wrong token / paused device / wrong content type / garbage → 404/415/400, nothing logged),
per-device rate limit (429), upstream outage → SERVFAIL + error log entry, the dashboard pages
(add/list/pause/delete a device, the token shown exactly once, the query log with filters),
rules via the pages (add, duplicate refused, invalid refused, delete), the per-user device limit,
one user cannot open another's device, one user's rules don't affect another's devices, and
`DNSFW_ENABLED=0` hiding the page, the menu link and the endpoint. Separately smoke-tested: the
agent's blocking counter, fail-open and self-recovery logic. **Not run:** the agent on a real
Windows PC and against a real upstream resolver – the first install is the first real test.
