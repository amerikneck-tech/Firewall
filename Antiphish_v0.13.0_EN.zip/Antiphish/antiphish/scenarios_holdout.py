"""HOLDOUT scenarios - written after the detection rules were frozen.

Other brands, other situations and other wording than the dev set in
scenarios.py. They were run ONCE; the result is recorded in HANDOFF.md.
Do not tune rules against these - add new dev scenarios instead, and write
fresh holdout cases when this set has been "used up".
"""
from __future__ import annotations

from .scenarios import RCPT_SE, Scenario, _UNSUB_FOOT, _auth, _html, _pdf, _qr_png, _zip, eml


def holdout_scenarios() -> list[Scenario]:
    S: list[Scenario] = []
    legit = lambda n, raw, note="": S.append(Scenario(n, "legit", raw, "holdout", note))   # noqa: E731
    phish = lambda n, raw, note="": S.append(Scenario(n, "phish", raw, "holdout", note))   # noqa: E731

    # ------------------------------------------------------------------ legitimate
    legit("ms_account_single_use_code", eml(
        "Microsoft account team <account-security-noreply@accountprotection.microsoft.com>", "Your single-use code",
        html=_html("<p>Hi amra.hodzic@outlook.com,</p><p>We received your request for a single-use code to use with "
                   "your Microsoft account.</p><p>Your single-use code is: 5521903</p><p>If you didn't request this "
                   "code, you can safely ignore this email. Someone else might have typed your email address by "
                   "mistake.</p><p>Thanks,<br>The Microsoft account team</p>"),
        to="amra.hodzic@outlook.com", auth=_auth("accountprotection.microsoft.com", signer="accountprotection.microsoft.com")))

    legit("revolut_card_payment", eml(
        "Revolut <no-reply@revolut.com>", "You spent €23.40 at Konzum",
        html=_html("<p>Hi Amra,</p><p>You paid €23.40 at Konzum Sarajevo with your card ending 4471.</p><p>Balance "
                   "after payment: €311.02</p><p>See the details in the Revolut app. If you don't recognise this "
                   "payment, freeze your card in the app under Cards.</p>"),
        auth=_auth("revolut.com")))

    legit("airbnb_trip_reminder", eml(
        "Airbnb <automated@airbnb.com>", "Reminder: your trip to Split starts in 3 days",
        html=_html("<h2>Pack your bags, Amra</h2><p>Your stay at 'Apartman uz more' starts on Friday. Check-in is "
                   "after 15:00, self check-in with lockbox.</p><p>Your host Ivana will send the door code on the "
                   "day of arrival.</p><a href='https://www.airbnb.com/trips/v1/HMXQ2A9P4K'>View your itinerary</a>"),
        auth=_auth("airbnb.com")))

    legit("uber_receipt", eml(
        "Uber Receipts <noreply@uber.com>", "Your Friday evening trip with Uber",
        html=_html("<p>Thanks for riding, Erik</p><p>Total 184,00 kr</p><p>Trip fare 164,00 kr<br>Booking fee 20,00 kr"
                   "</p><p>Payments: Visa ••••2291</p><a href='https://riders.uber.com/trips/8f3c2a10'>Visit the trip "
                   "page</a> for more information, including invoices (where available).</p>"),
        to=RCPT_SE, auth=_auth("uber.com")))

    legit("wolt_order_bs", eml(
        "Wolt <info@wolt.com>", "Tvoja narudžba je potvrđena: Ćevabdžinica Željo",
        html=_html("<p>Hej Amra!</p><p>Narudžba je primljena i restoran je počeo s pripremom. Procijenjeno vrijeme "
                   "dostave: 25-35 minuta.</p><p>1x Desetka u somunu 9,00 KM<br>1x Jogurt 2,00 KM<br>Dostava 1,90 KM"
                   "<br>Ukupno 12,90 KM</p><p>Prati narudžbu u aplikaciji.</p>"),
        auth=_auth("wolt.com")))

    legit("power_utility_ebill_bs", eml(
        "Elektroprivreda BiH <eracun@epbih.ba>", "E-račun za novembar 2026",
        text="Poštovani kupče,\n\nu prilogu Vam dostavljamo račun za električnu energiju za novembar 2026. godine.\n"
             "Iznos računa: 61,35 KM. Rok plaćanja: 20.12.2026.\nRačun možete platiti na uobičajen način.\n\n"
             "JP Elektroprivreda BiH d.d. Sarajevo",
        auth=_auth("epbih.ba", policy="quarantine"),
        attachments=[("Racun_112026.pdf", "application/pdf", _pdf("JP Elektroprivreda BiH racun 11/2026 iznos 61,35 KM"))]))

    legit("swedbank_message_sv", eml(
        "Swedbank <noreply@swedbank.se>", "Du har ett nytt meddelande från banken", to=RCPT_SE,
        html=_html("<p>Hej,</p><p>Du har fått ett nytt meddelande i internetbanken och appen.</p><p>Av säkerhetsskäl "
                   "skickar vi aldrig länkar till inloggning i mejl. Logga in som vanligt via appen eller "
                   "swedbank.se för att läsa meddelandet.</p><p>Vänliga hälsningar<br>Swedbank</p>"),
        auth=_auth("swedbank.se")))

    legit("klarna_invoice_reminder_sv", eml(
        "Klarna <noreply@klarna.se>", "Din faktura förfaller om 3 dagar", to=RCPT_SE,
        html=_html("<p>Hej Erik,</p><p>Din faktura på 549,00 kr för ditt köp hos Elgiganten förfaller den 28 "
                   "november.</p><p>Betala enkelt i Klarna-appen. Har du redan betalat kan du bortse från detta "
                   "meddelande.</p><a href='https://app.klarna.com/payments'>Öppna Klarna-appen</a>"),
        auth=_auth("klarna.se")))

    legit("internal_hr_payslips_bs", eml(
        "Kadrovska služba <kadrovska@firma-primjer.ba>", "Platne liste za oktobar su na portalu",
        text="Kolegice i kolege,\n\nplatne liste za oktobar dostupne su na internom HR portalu, kao i svakog mjeseca.\n"
             "Podsjećamo da se zahtjevi za godišnji odmor za decembar predaju do 01.12.\n\nKadrovska služba",
        auth=_auth("firma-primjer.ba")))

    sub = "https://substack.com/redirect/2/eyJlIjoiaHR0cHM6Ly9leGFtcGxlLm9yZy9w{i}"
    legit("substack_newsletter", eml(
        "Benedict's Newsletter <benedict@substack.com>", "No. 571: AI agents, chips and the price of everything",
        html=_html("<h1>This week</h1><p>Three things worth reading this week, and a longer note on why enterprise "
                   "software adoption takes longer than anyone expects.</p>" + "".join(
                       f"<p><a href='{sub.format(i=i)}'>Read: story number {i}</a></p>" for i in range(5))
                   + "<p>Thanks for reading. This post is public so feel free to share it.</p>",
                   _UNSUB_FOOT.format(u=sub.format(i=90), p=sub.format(i=91))),
        auth=_auth("substack.com"), list_unsub="<https://substack.com/unsubscribe?token=abc>",
        headers={"List-ID": "<benedict.substack.com>"}))

    legit("google_calendar_invitation", eml(
        "Lejla Begić <calendar-notification@google.com>", "Invitation: Ručak s klijentom @ Thu 26 Nov 2026 12:30",
        html=_html("<p>You have been invited to the following event.</p><h3>Ručak s klijentom</h3><p>When: Thu 26 Nov "
                   "2026 12:30 – 13:30 (CET)<br>Where: Restoran Park Prinčeva</p><p>Going? <a href='https://calendar."
                   "google.com/calendar/event?action=RESPOND&eid=NDRh&rst=1'>Yes</a> - <a href='https://calendar."
                   "google.com/calendar/event?action=RESPOND&eid=NDRh&rst=3'>Maybe</a> - <a href='https://calendar."
                   "google.com/calendar/event?action=RESPOND&eid=NDRh&rst=2'>No</a></p><p>Invitation from Google "
                   "Calendar. You are receiving this email because you are an attendee of the event.</p>"),
        auth=_auth("google.com"), reply_to="Lejla Begić <lejla.begic@gmail.com>",
        attachments=[("invite.ics", "text/calendar",
                      b"BEGIN:VCALENDAR\r\nMETHOD:REQUEST\r\nBEGIN:VEVENT\r\nSUMMARY:Rucak s klijentom\r\n"
                      b"DTSTART:20261126T113000Z\r\nLOCATION:Restoran Park Princeva\r\nEND:VEVENT\r\nEND:VCALENDAR\r\n")]))

    legit("stripe_saas_receipt", eml(
        "Figma <receipts+acct_1A2b3C@stripe.com>", "Your receipt from Figma #2291-4410",
        html=_html("<p>Receipt from Figma</p><p>Amount paid $15.00<br>Date paid Nov 22, 2026<br>Payment method Visa – "
                   "4242</p><p>Professional plan (1 editor), Nov 22 – Dec 22, 2026</p><p>If you have any questions, "
                   "contact us at <a href='mailto:support@figma.com'>support@figma.com</a>.</p><a href='https://pay."
                   "stripe.com/receipts/invoices/CAcaFwoVYWNjdF8x'>Download invoice</a>"),
        auth=_auth("stripe.com"), reply_to="Figma <support@figma.com>"))

    legit("small_vendor_quote_xlsx", eml(
        "Senad Delić <senad@stolarija-delic.ba>", "Ponuda za kuhinju po mjeri",
        text="Poštovana gđo Hodžić,\n\nkako smo dogovorili prilikom izmjere, u prilogu je ponuda sa specifikacijom "
             "materijala. Cijena uključuje montažu. Avans 30% po potpisu ugovora, ostatak po završetku.\n\n"
             "Lijep pozdrav,\nSenad Delić\nStolarija Delić, Visoko\n061 555 014",
        auth=_auth("stolarija-delic.ba", mode="none"),
        attachments=[("Ponuda_kuhinja.xlsx", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                      _zip({"[Content_Types].xml": "<Types/>", "xl/sharedStrings.xml": "<sst><si><t>Ponuda kuhinja "
                            "iveral 18mm radna ploca 3200 KM</t></si></sst>"}))]))

    legit("dropbox_real_share", eml(
        "Marko Marković (via Dropbox) <no-reply@dropbox.com>", "Marko Marković shared \"Fotografije objekta\" with you",
        html=_html("<p>Hi Amra,</p><p>Marko Marković (marko.markovic@partner-doo.rs) invited you to view the folder "
                   "\"Fotografije objekta\" on Dropbox.</p><a href='https://www.dropbox.com/scl/fo/8x1k2m/h?rlkey="
                   "abc123&dl=0'>View folder</a><p>Enjoy!<br>The Dropbox team</p>"),
        auth=_auth("dropbox.com"), reply_to="marko.markovic@partner-doo.rs"))

    legit("steam_purchase_receipt", eml(
        "Steam Store <noreply@steampowered.com>", "Thank you for your Steam purchase!",
        html=_html("<p>Hello amra_h,</p><p>Thanks for your recent purchase on Steam. The items below have been added "
                   "to your library.</p><p>Hades II — 28,99€</p><p>Account name: amra_h<br>Invoice: 4401882299</p>"
                   "<a href='https://store.steampowered.com/account/history/'>View your purchase history</a>"
                   "<p>This email message will serve as your receipt.</p>"),
        auth=_auth("steampowered.com")))

    legit("customer_first_inquiry_gmail", eml(
        "Dženana Kovač <dzenana.kovac91@gmail.com>", "Upit za cijenu servisa klime",
        text="Poštovani,\n\nzanima me cijena redovnog servisa klima uređaja (dvije unutrašnje jedinice) i kada "
             "imate slobodan termin sljedeće sedmice. Adresa je u Ilidži.\n\nHvala unaprijed,\nDženana Kovač\n"
             "062 555 019", auth=_auth("gmail.com", policy="none")))

    legit("school_form_link", eml(
        "OŠ Skender Kulenović <sekretarijat@osskenderkulenovic.edu.ba>", "Anketa za roditelje - izborni predmeti",
        text="Poštovani roditelji,\n\nmolimo vas da do petka popunite kratku anketu o izbornim predmetima za narednu "
             "školsku godinu: https://forms.gle/4mPq8Zt2xYw1AbCd9\nAnketa je anonimna i traje dvije minute.\n\n"
             "Sekretarijat škole", auth=_auth("osskenderkulenovic.edu.ba", mode="none")))

    legit("dev_newsletter_github_pages", eml(
        "Python Weekly <newsletter@pythonweekly.com>", "Python Weekly - Issue 733",
        html=_html("<h2>Articles, Tutorials and Talks</h2><p><a href='https://realpython.github.io/python-guide/"
                   "writing/structure/'>Structuring your project</a> - a refreshed guide.</p><p><a href='https://"
                   "pandas-dev.github.io/pandas-governance/'>How pandas is governed</a></p><p><a href='https://my-"
                   "little-demo.vercel.app/'>Interactive demo of the new REPL</a></p><p>Interesting projects, tools "
                   "and libraries below.</p>",
                   _UNSUB_FOOT.format(u="https://pythonweekly.us2.list-manage.com/unsubscribe?u=e2e", p="https://www.pythonweekly.com/privacy")),
        auth=_auth("pythonweekly.com"), list_unsub="<https://pythonweekly.us2.list-manage.com/unsubscribe?u=e2e>"))

    legit("bank_card_shipped_sv", eml(
        "Handelsbanken <noreply@handelsbanken.se>", "Ditt nya kort är på väg", to=RCPT_SE,
        html=_html("<p>Hej Erik,</p><p>Ditt nya bankkort har skickats och kommer med posten inom fem vardagar. Koden "
                   "är densamma som till ditt gamla kort.</p><p>Aktivera kortet genom att göra ett köp med chip och "
                   "kod. Det gamla kortet slutar gälla när det nya används.</p><p>Vi ber dig aldrig lämna ut koder "
                   "eller logga in via länkar i mejl.</p>"),
        auth=_auth("handelsbanken.se")))

    legit("m365_real_password_expiry", eml(
        "Microsoft 365 <msonlineservicesteam@microsoftonline.com>", "Your password will expire in 5 days",
        html=_html("<p>Hello Amra Hodzic,</p><p>The password for your organizational account amra.hodzic@firma-"
                   "primjer.ba will expire in 5 days.</p><p>To change your password, sign in to your account at "
                   "<a href='https://portal.office.com/'>https://portal.office.com</a>, select Settings, then "
                   "Password. You can also press Ctrl+Alt+Delete on a work computer.</p><p>Sincerely,<br>Microsoft "
                   "365 Team</p>"),
        auth=_auth("microsoftonline.com")),
        "hardest legit case: a genuine password-expiry notice")

    # ------------------------------------------------------------------ phishing
    phish("ms_unusual_signin_workers_dev", eml(
        "Microsoft account team <no-reply@msft-account-protection.com>", "Microsoft account unusual sign-in activity",
        html=_html("<p>We detected something unusual about a recent sign-in to the Microsoft account am**@firma-"
                   "primjer.ba.</p><p>Sign-in details<br>Country/region: Russia<br>IP address: 103.225.77.255</p>"
                   "<p>Please go to your recent activity page to let us know whether or not this was you.</p>"
                   "<a href='https://ms-activity-review.accounts-check.workers.dev/'>https://account.live.com/Activity</a>"),
        auth=_auth("msft-account-protection.com", policy="none")))

    phish("revolut_restricted_dmarc_pass", eml(
        "Revolut <support@revolut-verify-center.com>", "Your account has been restricted",
        html=_html("<p>Hi,</p><p>We were unable to verify some of your information, so we have temporarily restricted "
                   "your Revolut account. Verify your identity within 24 hours to restore full access.</p>"
                   "<a href='https://revolut-verify-center.com/kyc'>Verify identity</a>"),
        auth=_auth("revolut-verify-center.com")))

    phish("booking_guest_message_embedded_domain", eml(
        "Booking.com <noreply@guest-messages-portal.com>", "New message from your guest about reservation 4411223901",
        html=_html("<p>Dear partner,</p><p>You have received a new message from a guest regarding an upcoming stay. "
                   "The guest reports a problem with the payment. Please review it urgently to avoid cancellation "
                   "and a penalty fee.</p><a href='https://booking.com-reservation.id-7781443.com/extranet/login'>"
                   "Reply to guest</a>"),
        auth=_auth("guest-messages-portal.com", mode="nodmarc")))

    phish("bec_acquisition_wire_lookalike_domain", eml(
        "Emir Kovačević <emir.kovacevic@firma-prirnjer.ba>", "Povjerljivo - akvizicija",
        text="Amra,\n\nu toku je povjerljiva akvizicija i treba mi tvoja pomoć danas. Advokat će ti poslati podatke "
             "za uplatu, potrebno je izvršiti transfer od 38.400 EUR prije 15h. Ne mogu da pričam, na sastanku sam "
             "sa investitorima, pa komuniciramo samo mejlom. Nikome ne govori dok ne objavimo.\n\nEmir",
        auth=_auth("firma-prirnjer.ba", policy="none")),
        "sender domain is a one-letter look-alike of the recipient's own domain")

    qr = _qr_png("https://benefits-enroll-2027.pages.dev/login")
    if qr:
        phish("hr_benefits_qr_pdf_like_image_attachment", eml(
            "HR Benefits <benefits@hr-enrollment-notice.com>", "Open enrollment closes Friday - action required",
            text="Dear employee,\n\nOpen enrollment for 2027 benefits closes this Friday. Scan the QR code in the "
                 "attached notice with your phone to review and confirm your selections.\n\nHuman Resources",
            auth=_auth("hr-enrollment-notice.com", mode="nodmarc"),
            attachments=[("Benefits_2027_Notice.png", "image/png", qr)]))

    phish("sv_bankid_renew_webapp", eml(
        "BankID <info@bankid-kundservice.net>", "Ditt BankID går ut - förnya idag", to=RCPT_SE,
        html=_html("<p>Hej,</p><p>Ditt BankID upphör att gälla inom 24 timmar. För att fortsätta använda Swish och "
                   "internetbanken behöver du förnya det idag. Logga in och bekräfta dina uppgifter.</p>"
                   "<a href='https://bankid-fornya.web.app/start'>Förnya BankID</a>"),
        auth=_auth("bankid-kundservice.net", mode="nodmarc")))

    phish("bs_euprava_traffic_fine", eml(
        "eUprava MUP <obavjestenje@euprava-kazne.top>", "Neplaćena saobraćajna kazna - posljednja opomena",
        html=_html("<p>Poštovani,</p><p>Evidentirana je neplaćena saobraćajna kazna na Vaše ime u iznosu od 30,00 EUR. "
                   "Ukoliko kaznu ne platite u roku od 48 sati, iznos se uvećava i pokreće se prinudna naplata.</p>"
                   "<a href='https://euprava-kazne.top/placanje'>Plati kaznu karticom</a>"),
        auth=_auth("euprava-kazne.top", policy="none")))

    phish("bs_telecom_disconnection_shortener", eml(
        "Telekom <racuni@korisnicki-servis-info.com>", "Vaša usluga će biti isključena",
        html=_html("<p>Poštovani korisniče,</p><p>Plaćanje Vašeg posljednjeg računa nije uspjelo. Ažurirajte podatke "
                   "o plaćanju u roku od 12 sati kako biste izbjegli isključenje usluge.</p>"
                   "<a href='https://cutt.ly/tel-uplata-77'>Ažuriraj podatke</a>"),
        auth=_auth("korisnicki-servis-info.com", mode="nodmarc")))

    phish("docusign_spoof_via_esp_dmarc_fail", eml(
        "DocuSign <dse@docusign.net>", "Please DocuSign: Updated_Salary_Structure_2027.pdf",
        html=_html("<p>Your document has been completed and is ready for review.</p><a href='https://u44127718.ct."
                   "sendgrid.net/ls/click?upn=u001.Zq9k3mPx7LwT2vB8'>VIEW COMPLETED DOCUMENT</a><p>Do Not Share This "
                   "Email. This email contains a secure link to DocuSign.</p>"),
        auth=_auth("docusign.net", mode="unaligned", signer="sendgrid.net")))

    phish("onedrive_share_embedded_domain", eml(
        "Ivana Jurić <ivana.juric@transport-logistika.hr>", "Ivana Jurić shared a file with you",
        html=_html("<p>Here's the document that Ivana Jurić shared with you.</p><p>Ponuda_2027.xlsx</p><a href="
                   "'https://onedrive.live.com.auth-share.xyz/redir?resid=44A1'>Open</a><p>This link only works for "
                   "the direct recipients of this message.</p>"),
        auth=_auth("transport-logistika.hr", policy="quarantine")),
        "authenticated mail from a real (compromised) partner")

    gif = b"GIF89a" + b"\x00" * 60000
    phish("image_only_order_callback_freemail", eml(
        "Paula Jenkins <pjenkins.orders8841@gmail.com>", "Order Confirmation 60526 - Thank you for your purchase",
        html="<html><body><p>7731 Lake St, Phoenix</p><img src='cid:inv@img'></body></html>",
        auth=_auth("gmail.com", policy="none"), inline=[("inv.gif", "image/gif", gif)]))

    phish("ledger_recovery_phrase", eml(
        "Ledger <security@ledger-device-update.com>", "Critical firmware update for your Ledger Nano",
        html=_html("<p>Dear Ledger user,</p><p>A vulnerability affects your device firmware. To protect your assets "
                   "you must validate your wallet by entering your 24-word recovery phrase in the secure update "
                   "tool before 30 November.</p><a href='https://ledger-device-update.com/validate'>Start update</a>"),
        auth=_auth("ledger-device-update.com", policy="none")))

    phish("recruiter_fake_login", eml(
        "Talent Acquisition <careers@global-talent-partners.site>", "Interview invitation - Senior Accountant position",
        html=_html("<p>Hello,</p><p>We reviewed your profile and would like to invite you to an interview. Please "
                   "schedule your slot through our portal. Log in with your Google or Microsoft account to confirm "
                   "your identity and pick a time.</p><a href='https://interview-scheduler.global-talent-partners."
                   "site/login'>Schedule interview</a>"),
        auth=_auth("global-talent-partners.site", mode="nodmarc")))

    phish("invoice_pdf_html_double_extension", eml(
        "Accounts <accounts@invoicing-service-eu.com>", "Invoice INV-2231 overdue",
        text="Hello,\n\nplease see the attached invoice INV-2231 which is now overdue. Open the document to view "
             "the amount due.\n\nRegards,\nAccounts",
        auth=_auth("invoicing-service-eu.com", mode="nodmarc"),
        attachments=[("Invoice_INV-2231.pdf.html", "text/html",
                      b"<html><body><script>var u=atob('aHR0cHM6Ly9leGFtcGxlLmludmFsaWQ=');var b=new Blob([u]);"
                      b"window.location=u;</script><form><input type='password' name='pw'></form></body></html>")]))

    phish("zip_password_in_body_lnk", eml(
        "Dragan Petrović <dragan.petrovic@inzenjering-plus.rs>", "Dokumentacija za tender",
        text="Poštovani,\n\nu prilogu je dokumentacija za tender. Arhiva je zaštićena, lozinka: tender2026\n\n"
             "Pozdrav,\nDragan",
        auth=_auth("inzenjering-plus.rs", mode="nodmarc"),
        attachments=[("Dokumentacija.zip", "application/zip", _zip({"Tender_dokumentacija.pdf.lnk": b"L\x00\x00\x00"
                      b"\x01\x14\x02\x00" + b"\x00" * 80, "readme.txt": b"otvorite precicu"}))]))

    phish("zoom_fake_invite_live_tld", eml(
        "Zoom <meetings@zoom-us.meeting-join.live>", "You have been invited to a Zoom meeting: Q4 payroll review",
        html=_html("<p>HR is inviting you to a scheduled Zoom meeting.</p><p>Topic: Q4 payroll review (mandatory)</p>"
                   "<a href='https://zoom-us.meeting-join.live/j/84512345678'>Join Meeting</a><p>Sign in with your "
                   "work account to join.</p>"),
        auth=_auth("zoom-us.meeting-join.live", policy="none")))

    phish("wetransfer_ipfs", eml(
        "WeTransfer <noreply@wetransfer-files-delivery.com>", "You have received 4 files via WeTransfer",
        html=_html("<p>4 items, 18.2 MB in total · Expires in 2 days</p><a href='https://bafybeihkoviema7g3gxyt6la7"
                   "example.ipfs.dweb.link/index.html?e=amra'>Get your files</a><p>To make sure our emails arrive, "
                   "please add noreply@wetransfer.com to your contacts.</p>"),
        auth=_auth("wetransfer-files-delivery.com", mode="nodmarc")))

    phish("sv_postnord_customs_embedded", eml(
        "PostNord <no-reply@leverans-meddelande.com>", "Ditt paket väntar på tullklarering", to=RCPT_SE,
        html=_html("<p>Hej,</p><p>Ditt paket från utlandet väntar på tullklarering. Betala tullavgiften på 24,50 kr "
                   "inom 48 timmar för att undvika att paketet returneras.</p><a href='https://postnord-se.delivery-"
                   "avgift.com/betala'>Betala nu</a>"),
        auth=_auth("leverans-meddelande.com", mode="nodmarc")))

    phish("voicemail_htm_obfuscated_js", eml(
        "Voice Mail <vm-noreply@unified-messaging-alerts.com>", "Missed call - voice message attached (00:52)",
        text="You have a new voice message. Open the attachment to play it.",
        auth=_auth("unified-messaging-alerts.com", mode="nodmarc"),
        attachments=[("Play_VM_00052.htm", "text/html",
                      b"<html><body><script>var a=atob('ZG9jdW1lbnQud3JpdGU=');var s=String.fromCharCode(60,102,111,"
                      b"114,109,62);eval(a);location.replace('https://example.invalid/vm');</script></body></html>")]))

    phish("salary_letter_urldefense_pages_dev", eml(
        "HR Portal <hr-noreply@staff-documents-center.com>", "Your 2027 salary adjustment letter",
        html=_html("<p>Dear colleague,</p><p>Your salary adjustment letter for 2027 is ready. Sign in with your "
                   "corporate credentials to view and acknowledge it before Friday.</p><a href='https://urldefense.com/"
                   "v3/__https://salary-letters-2027.pages.dev/view__;!!AbCd!xyz$'>View letter</a>"),
        auth=_auth("staff-documents-center.com", policy="none")))

    phish("it_helpdesk_own_org_display", eml(
        "firma-primjer.ba IT Support <helpdesk@secure-mail-services.net>", "Mailbox upgrade required",
        html=_html("<p>Dear user,</p><p>We are upgrading all firma-primjer.ba mailboxes to the new server tonight. "
                   "To avoid losing messages, validate your mailbox now.</p><a href='https://mailbox-upgrade."
                   "secure-mail-services.net/validate'>Validate mailbox</a>"),
        auth=_auth("secure-mail-services.net", policy="none")))
    return S
