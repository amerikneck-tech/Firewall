"""Text-content heuristics (EN + Bosnian/Croatian/Serbian + Swedish + some German).

v0.10: every pattern is a compiled regex with word boundaries ("won" no
longer matches "wonderful"), diacritics are folded so "placanje" == "plaćanje",
and the lure families that dominate current reporting get their own signals:
BEC (gift cards, bank-detail change, payroll diversion), device-code phishing,
ClickFix, callback/TOAD, QR lures, mailbox/password-expiry notices, delivery
fee and refund lures, wallet seed phrases, extortion.

analyze_text(text, phones=None, html=None) -> list of signal dicts.
"""
from __future__ import annotations

import re

from .domains import fold_for_matching, mixed_script_words


MAX_TEXT_CHARS = 20000


def _rx(*alts: str) -> re.Pattern:
    return re.compile(r"(?<![\w])(?:" + "|".join(alts) + r")(?![\w])", re.I)


# ------------------------------------------------------------------ pattern families
URGENCY = _rx(
    r"urgent(?:ly)?", r"immediate(?:ly)?", r"right away", r"asap", r"as soon as possible",
    r"within (?:the next )?\d+ ?(?:h|hrs?|hours?|days?|minutes?)", r"in (?:the next )?\d+ ?(?:hours?|hrs)",
    r"expires? (?:today|soon|in|on|within)", r"expir(?:ed|ing|ation)", r"final (?:notice|reminder|warning)",
    r"last (?:warning|reminder|chance|notice)", r"act now", r"action required", r"immediate action",
    r"time[- ]sensitive", r"limited time", r"today only", r"without delay", r"do not delay",
    r"before it'?s too late", r"respond (?:now|today|immediately)", r"attention required",
    # BCS
    r"hitno", r"odmah", r"smjesta", r"smesta", r"sto prije", r"sto pre", r"u roku od \d+ ?(?:h|sat[ai]?|dana?)",
    r"istic[ei]", r"istekl?[oai]", r"istek(?:ao|la)", r"poslj?ednj[ia] (?:rok|opomena|upozorenje|sansa)",
    r"zadnj[ia] (?:rok|opomena|upozorenje)", r"bez odlaganja", r"potrebna (?:je )?(?:hitna )?akcija",
    r"vas (?:nalog|racun) ce biti",
    # SV
    r"akut", r"omedelbart", r"bradskande", r"snarast", r"inom \d+ ?(?:timmar|dagar|h)", r"gar ut",
    r"loper ut", r"sista (?:dagen|paminnelsen|varningen|chansen)", r"ditt konto kommer att",
    r"atgard kravs",
    # DE
    r"dringend", r"sofort", r"umgehend", r"innerhalb von \d+ ?(?:stunden|tagen)", r"lauft ab",
    r"letzte mahnung",
)

MONEY = _rx(
    r"wire transfer", r"bank transfer", r"payments?", r"invoices?", r"iban", r"swift", r"refunds?",
    r"prize", r"lottery", r"bitcoin", r"btc", r"crypto(?:currency)?", r"gift ?cards?", r"inheritance",
    r"compensation", r"overdue", r"outstanding balance", r"remittance", r"unpaid",
    r"uplat[aeiu]", r"uplatite", r"platite", r"placanj[aeu]", r"faktur[aeiu]", r"povrat (?:novca|sredstava|poreza)",
    r"nagrad[aeiu]", r"dobit(?:ak|ka)", r"dobili ste", r"nasl(?:j)?edstv[oau]", r"dug(?:ovanj[aeu])?",
    r"betalning(?:en)?", r"aterbetalning", r"vinst", r"belopp", r"presentkort", r"skuld", r"forfallen",
    r"zahlung", r"rechnung", r"uberweisung", r"ruckerstattung",
)

# things a legitimate sender does not ask for by e-mail
CREDENTIAL_ASK = _rx(
    r"(?:verify|confirm|validate|re-?validate|re-?confirm|authenticate) (?:your|the) (?:account|identity|"
    r"password|details|information|info|billing|payment|card|mailbox|e-?mail account|ownership|credentials|"
    r"login|profile|bank|pin)",
    r"update (?:your|the) (?:payment|billing|account|card|bank(?:ing)?|personal|security|contact) "
    r"(?:method|details|information|info|data|settings)?",
    r"enter (?:your|the) (?:password|credentials|pin|card (?:number|details)|login|e-?mail password|otp|"
    r"verification code|security code)",
    r"(?:sign|log) in with (?:your|the)", r"(?:your|corporate|company|work|email|e-mail|office|network) credentials",
    r"keep (?:your |the )?(?:current|same|existing) password", r"re-?(?:activate|enable|authenticate) your",
    r"unlock your (?:account|card|mailbox)", r"restore (?:your )?(?:account|access|service)",
    r"(?:work|corporate|company|office|business) account", r"confirm (?:it is|it's|that it'?s) you",
    r"validate your (?:account|mailbox|e-?mail)", r"re-?enroll", r"re-?register",
    r"click (?:the link|here|below|the button)[^.]{0,40}to (?:verify|confirm|update|restore|unlock|"
    r"reactivate|secure|keep|validate|avoid|continue|release|retrieve)",
    r"(?:verify|confirm) (?:now|here|below|your account)", r"secure (?:your )?account (?:now|here|immediately)",
    r"security (?:check|verification) (?:is )?required", r"sign in to (?:avoid|keep|continue|prevent|restore|verify)",
    r"log ?in to (?:avoid|keep|continue|prevent|restore|verify)",
    # BCS
    r"potvrdite (?:svoj[eu]? |vas[eu]? )?(?:identitet|lozinku|podatke|karticu|pin|nalog|racun|e-?mail|adresu)",
    r"verifikujte (?:svoj |vas )?(?:nalog|racun|identitet)", r"verificirajte (?:svoj |vas )?(?:nalog|racun|identitet)",
    r"unesite (?:svoj[eu]? |vas[eu]? )?(?:lozinku|podatke|pin|broj kartice|kod)",
    r"azurirajte (?:svoje |vase )?(?:podatke|informacije|nalog|racun)",
    r"prijavite se (?:sluzbenim|svojim|vasim|sa svojim|sa vasim|da biste|kako biste)", r"sluzbenim nalogom",
    r"kliknite (?:na link|ovdje|ovde|ispod)[^.]{0,40}(?:potvrd|verifik|azurira|otkljuca|sacuva|izbjeg|izbeg)",
    r"otkljucajte (?:svoj |vas )?(?:nalog|racun|karticu)", r"ponovo aktivirajte",
    # SV
    r"bekrafta (?:din|ditt|dina) (?:identitet|losenord|uppgifter|konto|kort|e-?post)",
    r"verifiera (?:din|ditt|dina) (?:identitet|konto|uppgifter|e-?post)", r"ange (?:ditt|din) (?:losenord|kod|pin)",
    r"uppdatera (?:dina|din|ditt) (?:betalnings)?(?:uppgifter|information|konto|kort)",
    r"logga in (?:for att|med (?:ditt|din)|har|nu)", r"legitimera dig", r"aktivera (?:ditt|din) (?:konto|bankid) igen",
    # DE
    r"bestatigen sie (?:ihr|ihre) (?:konto|identitat|daten|passwort)", r"verifizieren sie (?:ihr|ihre)",
    r"aktualisieren sie (?:ihr|ihre) (?:daten|zahlungs\w+|konto)",
    # lure-specific phrasing
    r"devicelogin", r"device login", r"enter the code", r"scan the (?:qr|code)", r"skenirajte (?:qr|kod)",
    r"skanna (?:qr|koden)",
)

# normal in legitimate notifications too - weak
LOGIN_PROMPT = _rx(
    r"(?:log|sign) ?in to (?:your|the|view|see|access|review|check|manage)", r"(?:verify|confirm) your e-?mail(?: address)?",
    r"click (?:the link|here|below|the button)", r"prijavite se", r"kliknite (?:na link|ovdje|ovde)",
    r"logga in", r"klicka (?:har|pa lanken)", r"melden sie sich an", r"klicken sie hier",
)

GENERIC_GREETING = _rx(
    r"dear (?:customer|user|client|member|account holder|valued (?:customer|member|user|client)|"
    r"sir(?: or |/)madam|e-?mail user|subscriber|beneficiary|friend|recipient|colleague|employee|"
    r"cardholder|card holder|taxpayer|winner|web ?mail user)",
    r"hello (?:user|customer|client|member|dear)", r"hi (?:user|customer|dear)", r"dear (?:sir|madam)",
    r"basta (?:kund|anvandare|kontoinnehavare|medlem)", r"kara (?:kund|anvandare|medlem)",
    r"postovan[ia] (?:korisnic[eiu]|korisnik|klijent[ei]?|kupc[eiu]|kupac|clan[eu]?|gospodine/gospodjo)",
    r"drag[ia] (?:korisnic[eiu]|korisnik|klijent[ei]?|kupc[eiu])", r"cijenjen[ia] (?:korisnic[eiu]|klijent[ei]?)",
    r"sehr geehrter kunde", r"sehr geehrte(?:r)? (?:kunde|kundin|nutzer)",
)
_GREETING_WITH_ADDRESS = re.compile(r"(?im)^[ \t]*(?:dear|hi|hello|attention|attn|postovan[ia]|hej|hallo)[ \t]*:?[ \t]*"
                                    r"[\w.+\-]{1,64}@[\w\-]{1,63}\.[\w.\-]{2,40}")

THREAT = _rx(
    r"(?:account|access|mailbox|e-?mail|card|service|subscription|membership|domain|profile|page|wallet)"
    r"[^.!?\n]{0,40}(?:will be|has been|have been|is|was|is being|may be|could be|being)"
    r"[^.!?\n]{0,15}(?:suspended|blocked|terminated|closed|deactivated|disabled|locked|restricted|limited|"
    r"deleted|cancell?ed|frozen|removed|shut ?down|put on hold|placed on hold)",
    r"legal action", r"court (?:order|proceedings|notice)", r"law enforcement", r"arrest warrant",
    r"unauthori[sz]ed (?:access|transaction|login|log-?in|sign-?in|activity|charge|payment|purchase|use)",
    r"suspicious (?:activity|login|log-?in|sign-?in|transaction|attempt)", r"unusual (?:activity|sign-?in|login)",
    r"permanently (?:deleted|closed|disabled|removed|lost|suspended|blocked|locked)", r"lose (?:access|your account|your data)",
    r"avoid (?:suspension|termination|closure|deactivation|losing|service interruption|being locked|"
    r"account (?:closure|suspension)|disconnection|interruption)",
    r"failure to (?:comply|verify|respond|confirm|update|do so)", r"account (?:suspension|termination|closure|deactivation)",
    # BCS
    r"(?:nalog|racun|kartica|pristup|profil|usluga)[^.!?\n]{0,30}(?:ce biti|je|biti ce|bice)[^.!?\n]{0,12}"
    r"(?:obustavljen[ao]?|blokiran[ao]?|suspendovan[ao]?|suspendiran[ao]?|ugasen[ao]?|zatvoren[ao]?|"
    r"ogranicen[ao]?|deaktiviran[ao]?|obrisan[ao]?|ukinut[ao]?|zakljucan[ao]?)",
    r"tuzb[aeiu]", r"sudski postupak", r"izvrsitelj\w*", r"prinudn[aeu] naplat[aeu]", r"neovlasc?ten\w* pristup",
    r"sumnjiv[aeu] aktivnost\w*", r"trajno (?:obrisan|blokiran|ugasen)\w*",
    # SV
    r"(?:konto|kort|tjanst|abonnemang)\w*[^.!?\n]{0,30}(?:kommer att|har|blir)[^.!?\n]{0,12}"
    r"(?:stangas|sparras|sparrats|avslutas|blockeras|blockerats|begransas|begransats|raderas|inaktiveras)",
    r"rattsliga atgarder", r"inkasso", r"obehorig (?:atkomst|inloggning|transaktion)", r"misstankt aktivitet",
    # DE
    r"(?:konto|karte|zugang)[^.!?\n]{0,30}(?:gesperrt|eingeschrankt|geschlossen|deaktiviert)",
    r"rechtliche schritte", r"ungewohnliche aktivitat",
)

GIFT_CARD = _rx(
    r"(?:gift|itunes|google play|steam|amazon|apple|vanilla|visa|ebay|razer|xbox|playstation|paysafe)[ -]?cards?",
    r"e-?gift", r"gift ?vouchers?", r"presentkort", r"(?:poklon|gift)[ -]?kartic[aeiu]", r"poklon[ -]?bon\w*",
    r"vaucer\w*", r"paysafecard", r"scratch (?:the back|off|them)", r"send (?:me )?(?:the )?(?:card )?(?:codes?|pictures? of)",
)
GIFT_CARD_ASK = _rx(
    r"(?:buy|purchase|get|pick up|grab|order|kupi(?:te)?|nabavi(?:te)?|uzmi(?:te)?|kop|kopa|skaffa) (?:me |us |some |a few |\d+ |pet |sest |nekoliko |nagra )?"
    r"[\w ]{0,24}(?:gift ?cards?|vouchers?|presentkort|kartic[aeiu]|bon\w*|vaucer\w*)",
    r"(?:send|email|text|posalji(?:te)?|skicka) (?:me |mi |hit )?(?:the |a )?(?:card )?(?:codes?|kodove|koderna|pictures? of|photos? of|slike)",
    r"scratch (?:the back|off|them)", r"reveal the (?:codes?|pin)",
)
PAYMENT_REQUEST = _rx(
    r"(?:wire|bank|swift|urgent|outstanding|pending|immediate) (?:transfer|payment)", r"process (?:a|an|the|this) "
    r"(?:payment|transfer|wire|invoice)", r"make (?:a|the|this) (?:payment|transfer)", r"pay (?:this|the attached|"
    r"the enclosed|the outstanding) invoice", r"remit (?:payment|funds)", r"transfer (?:of )?funds", r"settle (?:this|the) invoice",
    r"send (?:the )?(?:payment|funds|money)", r"izvrsit[ie] (?:uplatu|placanje|transfer|prenos)",
    r"hitn[aou] (?:uplat[au]|placanje|transfer)", r"uplatit[ie] (?:na|iznos|sredstva)", r"platit[ie] (?:fakturu|racun) (?:danas|odmah|hitno)",
    r"gor (?:en|denna) (?:overforing|betalning)", r"betala (?:fakturan|omgaende|idag)", r"brådskande betalning",
    r"bradskande betalning", r"dringende (?:zahlung|uberweisung)",
)
BANK_CHANGE = _rx(
    r"(?:new|changed|updated|different|revised) (?:bank(?:ing)?|account|payment|remittance|beneficiary) "
    r"(?:details|information|info|account|instructions)", r"change (?:of|in|to) (?:our |the )?(?:bank(?:ing)?|account|payment) "
    r"(?:details|information|account)", r"(?:our|the) bank(?:ing)? (?:details|account|information) (?:have|has) (?:been )?changed",
    r"(?:update|updating|change|changing|amend) (?:our|the|your records with our) (?:bank(?:ing)?|account|payment) (?:details|information|account)",
    r"new (?:iban|account number|bank account)", r"(?:future|all|subsequent) (?:invoices|payments)[^.!?\n]{0,40}"
    r"(?:paid|sent|made|remitted|directed) to", r"account (?:is |being )?(?:under )?audit\w*", r"no longer (?:use|using|accept\w*)[^.!?\n]{0,30}account",
    r"promj?en[aeiu] (?:broja )?(?:ziro[ -]?)?racuna", r"nov[iaoe] (?:broj )?(?:ziro[ -]?)?racun\w*", r"promij?enili smo banku",
    r"novi podaci za (?:uplatu|placanje)", r"nov[iae] (?:bankovn[iae] )?(?:podaci|instrukcij[ae])", r"nya bankuppgifter",
    r"nytt (?:bankgiro|kontonummer|plusgiro|bankkonto)", r"bytt bank", r"andrade (?:bank|betalnings)uppgifter",
    r"neue bankverbindung", r"geanderte bankverbindung",
)
PAYROLL_CHANGE = _rx(
    r"(?:direct deposit|payroll|salary|pay ?check|pay ?cheque)[^.!?\n]{0,60}(?:change|update|updated|new|switch|"
    r"different|another|modify)", r"(?:change|update|switch|modify)[^.!?\n]{0,40}(?:direct deposit|payroll|salary) "
    r"(?:account|details|information|bank)?", r"update my (?:direct deposit|bank(?:ing)? (?:details|info\w*)|payroll)",
    r"(?:plat[aeu]|placu|zarad[aeu])[^.!?\n]{0,40}(?:nov[iaoe]|promj?en\w*|drug[iaoe]) racun\w*",
    r"(?:lon|lonen|loneutbetalning)[^.!?\n]{0,40}(?:nytt|andra|byta) (?:konto|bankkonto)",
)
BEC_PRETEXT = _rx(
    r"are you (?:available|at your desk|in the office|free|there|busy|around)", r"quick (?:favou?r|task|request|question for you)",
    r"i need (?:a|your) (?:favou?r|help with something|assistance with)", r"i need you to", r"need (?:this|it) done (?:today|now|asap)",
    r"keep (?:this|it) (?:confidential|between us|quiet|private|discreet)", r"strictly confidential", r"do(?:n't| not) "
    r"(?:tell (?:anyone|anybody|the)|mention (?:this|it)|discuss (?:this|it)|call (?:me|my))", r"can(?:'t|not| not) (?:talk|take (?:any )?calls|speak|be reached)",
    r"(?:i'?m|i am|currently) (?:in|at|heading into|going into|stuck in) (?:a |an )?(?:meeting|conference|board meeting|call)",
    r"reply (?:here|by e-?mail|to this e-?mail|via e-?mail) only", r"just (?:reply|e-?mail)", r"send me your (?:whatsapp|cell|mobile|phone|personal) (?:number)?",
    r"your (?:cell|mobile|whatsapp) number", r"i(?:'ll| will) reimburse", r"kindly (?:confirm|acknowledge|revert|treat)",
    r"treat (?:this )?as urgent", r"jesi li (?:slobod[ae]n|slobodna|dostup[ae]n|dostupna|u kancelariji|tu|za stolom)",
    r"jeste li (?:slobodni|dostupni|u kancelariji)", r"treba mi (?:jedna |tvoja |vasa )?(?:usluga|pomoc)",
    r"(?:strogo )?povj?erljivo", r"ne mogu (?:da )?(?:pricam|razgovaram|razgovarati|telefonirati)", r"na sastanku sam",
    r"nikome ne (?:govori|spominji)", r"ar du (?:ledig|tillganglig|pa kontoret|dar)", r"jag behover (?:en tjanst|din hjalp)",
    r"konfidentiellt", r"sitter i (?:ett )?mote", r"kan inte prata",
)
DEVICE_CODE = _rx(
    r"microsoft\.com/devicelogin", r"aka\.ms/devicelogin", r"oauth2/deviceauth", r"devicelogin", r"device[- ]login",
    r"device[- ]code", r"login\.microsoft\.com/device", r"microsoft\.com/link", r"enter (?:the|this|following|your) "
    r"(?:code|device code)[^.!?\n]{0,60}(?:sign|log|authenticat|verif|continue|access)",
    r"(?:use|enter) (?:the )?code [A-Z0-9]{3,5}-?[A-Z0-9]{3,5}",
)
CLICKFIX = _rx(
    r"(?:press|hit|hold|tap) (?:the )?(?:windows|win)(?: key| button)? ?\+ ?r", r"win(?:dows)? ?\+ ?r", r"ctrl ?\+ ?v",
    r"cmd ?\+ ?v", r"(?:paste|pasting) (?:it |the (?:code|command|text) )?(?:in|into) (?:the )?(?:run|terminal|powershell|"
    r"command prompt|cmd|dialog|box)", r"open (?:the )?(?:run dialog|run box|terminal|powershell|command prompt)",
    r"powershell(?:\.exe)? -", r"mshta(?:\.exe)? ", r"cmd(?:\.exe)? /c", r"iex ?\(", r"invoke-(?:expression|webrequest|restmethod)",
    r"verification steps?[^.!?\n]{0,60}(?:press|paste|copy)", r"copy (?:the )?(?:code|command)[^.!?\n]{0,40}(?:run|paste|terminal)",
)
QR_LURE = _rx(
    r"scan (?:the |this |attached |below |following |your )?(?:qr|code|barcode)", r"qr[- ]?(?:code|kod|koden)",
    r"skeniraj(?:te)? (?:qr|kod|kôd)", r"skanna (?:qr|koden|qr-koden)", r"scannen sie (?:den )?(?:qr|code)",
    r"using your (?:phone|mobile|smartphone)(?:'s)? camera", r"with your (?:phone|mobile|smartphone)(?:'s)? camera",
)
MAILBOX_LURE = _rx(
    r"(?:mailbox|inbox|e-?mail (?:account|storage)|storage|quota|web ?mail)[^.!?\n]{0,50}(?:full|exceeded|limit|"
    r"almost full|over quota|capacity|out of space|running out)", r"(?:password|passcode)[^.!?\n]{0,40}"
    r"(?:expire[sd]?|expiring|expiration|expiry|due to expire|about to expire)", r"(?:pending|undelivered|held|"
    r"quarantined|incoming|blocked|suspended|unreceived|failed) (?:messages?|e-?mails?|mails?)",
    r"(?:release|retrieve|recover|review|receive) (?:your |the |these |all )?(?:pending |held |quarantined |blocked |"
    r"undelivered )?(?:messages?|e-?mails?|mails?)(?: to (?:your )?inbox)?", r"(?:de-?activat\w*|shut ?down|terminat\w*|"
    r"clos\w*|suspen\w*)[^.!?\n]{0,30}(?:mailbox|e-?mail (?:account|address)|web ?mail)",
    r"(?:upgrade|update|verify|validate|re-?validate|confirm) (?:your )?(?:mailbox|web ?mail|e-?mail (?:account|quota|storage))",
    r"mail(?:box)? (?:migration|upgrade|verification|de-?activation|termination)", r"e-?mail (?:delivery|server) "
    r"(?:failure|error|problem|notification|report)", r"messages? (?:could not be|were not|was not|not) delivered",
    r"(?:lozink[aeu]|sifr[aeu])[^.!?\n]{0,30}(?:istic[ei]|istekl?[ao]|isteci)", r"sandu(?:c|č)\w*[^.!?\n]{0,30}(?:pun|prepun)\w*",
    r"postansko sanduce", r"kvot[aeu]", r"poruk[ae] (?:na cekanju|nisu isporucene)", r"losenord\w*[^.!?\n]{0,30}(?:gar ut|loper ut|har gatt ut)",
    r"e-?post(?:lada|konto)\w*[^.!?\n]{0,30}(?:full|stangs|uppgradera|verifiera)", r"postfach[^.!?\n]{0,30}(?:voll|gesperrt)",
    r"passwort[^.!?\n]{0,30}(?:lauft ab|abgelaufen)",
)
DOCUMENT_LURE = _rx(
    r"(?:shared|sent) (?:a |an |you a |you an )?(?:new )?(?:document|file|folder|secure (?:message|document|file))(?: with you)?",
    r"(?:review|view|sign|open|access|download) (?:and sign |the |your |this )?(?:attached |shared |secure[d]? |completed |pending )?"
    r"(?:document|contract|agreement|invoice|statement|proposal|purchase order|remittance|payment (?:advice|receipt|confirmation)|"
    r"fax|voice ?mail|voice ?message|scanned document|file|pdf)", r"you(?: have|'ve)? received (?:a |an )?(?:new )?"
    r"(?:fax|voice ?mail|voice ?message|secure message|encrypted message|document|file|e-?fax)",
    r"docusign", r"adobe sign", r"e-?signature", r"secured? (?:pdf|document|file)", r"(?:podij?eli\w*|poslao\w*) (?:vam |ti )?"
    r"(?:je )?(?:dokument|fajl|datoteku)", r"delat (?:ett )?dokument", r"granska och signera",
)
WALLET_PHRASE = _rx(
    r"seed phrase", r"recovery phrase", r"secret (?:recovery )?phrase", r"(?:12|24)[- ]word", r"private key",
    r"wallet (?:validation|verification|synchroni[sz]ation|connect\w*|migration|upgrade)", r"(?:validate|verify|connect|"
    r"synchroni[sz]e|sync|restore|migrate) (?:your )?wallet", r"claim (?:your )?(?:airdrop|tokens|rewards?)",
    r"mnemonic",
)
EXTORTION = _rx(
    r"i (?:have )?(?:hacked|infected|recorded|installed|gained access)", r"your (?:device|computer|pc|phone|webcam|"
    r"operating system|account) (?:was|has been|is) (?:hacked|infected|compromised|breached)", r"(?:bitcoin|btc) (?:wallet|address)",
    r"pay (?:me )?[^.!?\n]{0,40}(?:bitcoin|btc)", r"malware on (?:your|the)", r"(?:adult|porn\w*) (?:site|website|video|content)s?",
    r"i know your password", r"send (?:the|this) video to (?:all )?your contacts", r"trojan", r"remote (?:access|control) (?:tool|software)",
    r"hakova\w+ (?:sam|smo)", r"snimio sam", r"jag har (?:hackat|spelat in)",
)
# distinctive "419" markers only: single words like 'beneficiary' or '$3 million'
# are everyday business/news vocabulary
ADVANCE_FEE = _rx(
    r"next of kin", r"unclaimed (?:funds?|inheritance|estate|money)", r"compensation fund", r"consignment box",
    r"diplomat(?:ic)? (?:courier|agent|delivery)", r"barrister", r"western union", r"money ?gram", r"atm (?:visa )?card",
    r"deceased (?:client|customer|relative)", r"mutual benefit", r"donation of [\w$€£ ,.]{0,20}(?:million|usd|dollars|euros?)",
    r"(?:transfer|release|claim) (?:of )?(?:the|this|your) (?:fund|funds|inheritance|compensation)", r"(?:usd|\$|€|£) ?\d[\d,.]* ?million",
    r"\d[\d,.]* ?million (?:usd|dollars|euros?|pounds)", r"your (?:urgent )?(?:assistance|cooperation) (?:is|in)", r"strictly confidential",
    r"foreign (?:partner|beneficiary)", r"dormant account", r"god bless", r"nasl(?:j)?edstv[oau]", r"miliona? (?:eura|dolara)",
)
PRIZE_LURE = _rx(
    r"you(?: have|'ve)? won", r"you(?: have|'ve)? been (?:selected|chosen|randomly selected)[^.!?\n]{0,50}(?:prize|reward|gift|winner|win|receive|free)",
    r"congratulations[^.!?\n]{0,60}(?:won|winner|selected|eligible|reward)",
    r"claim (?:your|the) (?:prize|reward|gift|winnings?|bonus)", r"lucky winner", r"exclusive (?:reward|offer for you)",
    r"(?:survey|questionnaire)[^.!?\n]{0,50}(?:reward|gift|prize|\$\d+)", r"free (?:iphone|gift|voucher|samsung|ipad)",
    r"loyalty (?:reward|program reward|gift)", r"osvojili ste", r"cestitamo[^.!?\n]{0,40}(?:osvoji|dobit|nagrad)", r"preuzmite (?:svoju |vasu )?nagradu",
    r"dobitnik\w*", r"du har vunnit", r"grattis[^.!?\n]{0,40}(?:vunnit|vinnare|utvald)", r"hamta (?:din|ditt) (?:vinst|beloning|pris)",
    r"sie haben gewonnen",
)
DELIVERY = _rx(
    r"(?:package|parcel|shipment|delivery|item|order|posiljk\w*|paket\w*|forsandelse\w*|leverans\w*|sendung|paket)"
    r"[^.!?\n]{0,90}(?:held|on hold|pending|could not be delivered|couldn'?t be delivered|undeliverable|failed|suspended|"
    r"waiting|unable to deliver|returned to sender|incomplete address|missed|ceka|zadrzan\w*|nije (?:mogao|mogla|moguce|isporucen\w*)|"
    r"kunde inte levereras|stoppad|vantar|ej levererats|konnte nicht zugestellt)",
)
DELIVERY_FEE = _rx(
    r"(?:customs|shipping|delivery|redelivery|handling|import|clearance) (?:fee|charge|duty|tax|cost)s?", r"pay (?:the |a )?"
    r"(?:small )?(?:fee|customs|duty|shipping)", r"(?:fee|payment|charge) of [€$£]? ?\d+[.,]\d{2}", r"\d+[.,]\d{2} ?(?:eur|€|usd|\$|gbp|£|rsd|km|bam|sek|kr|kn|din)",
    r"carin\w*", r"naknad[aeu] (?:za )?(?:dostav\w*|carin\w*|obrad\w*)", r"uplatit[ie]", r"platit[ie] (?:carinu|dostavu|naknadu)",
    r"(?:tull|frakt|hanterings)avgift\w*", r"betala (?:avgiften|tullen|frakten)", r"reschedule (?:your )?(?:delivery|shipment)",
    r"schedule (?:a )?(?:new |re-?)delivery", r"confirm (?:your )?(?:shipping |delivery )?address", r"zollgebuhr\w*",
)
REFUND = _rx(
    r"tax refund", r"refund of", r"eligible (?:for|to receive) (?:a |an )?(?:tax )?refund", r"(?:pending|unclaimed|outstanding) refund",
    r"overpaid", r"reimbursement", r"povrat (?:poreza|pdv-?a?|sredstava|novca|preplate)", r"pretplat\w* (?:poreza)?", r"skatteaterbaring",
    r"aterbetalning", r"du har (?:pengar|en aterbetalning) att (?:fa|hamta)", r"ruckerstattung", r"steuererstattung",
)
REFUND_ASK = _rx(
    r"claim", r"submit", r"confirm", r"provide", r"(?:card|bank) (?:details|number|information)", r"podatke", r"kartic\w*", r"uppgifter",
    r"bankid", r"click", r"kliknite", r"klicka", r"form", r"obrazac", r"formular\w*",
)
CALLBACK_CONTEXT = _rx(
    r"subscription", r"renew(?:al|ed|s)?", r"auto[- ]?renew\w*", r"charged?", r"debited", r"invoice", r"order (?:confirmation|number|#|id)",
    r"purchase", r"transaction", r"billed", r"payment of", r"membership", r"pretplat\w*", r"naplacen\w*", r"prenumeration\w*", r"debiterats",
)
_DENIAL = (r"(?:did not|didn'?t|do not|don'?t|not) (?:authori[sz]e|make|place|recogni[sz]e|request|approve|initiate|order)\w*"
           r"|unauthori[sz]ed|not you|wasn'?t you|was not you|dispute|in error|by mistake|niste (?:vi|narucili|odobrili)"
           r"|inte (?:godkande|kande igen|gjorde)|ej godkant")
_CALL = (r"(?:call|contact|dial|reach|phone|ring|pozovite|nazovite|kontaktirajte|kontakta|toll[- ]?free|helpline|"
         r"help ?desk|support (?:team|line|desk)|billing (?:desk|department|team))")
CALLBACK_ACTION = re.compile(
    rf"(?is)(?:\b(?:{_DENIAL})\b[^\n]{{0,160}}\b{_CALL}\b|\b{_CALL}\b[^\n]{{0,160}}\b(?:{_DENIAL})\b)")
_PHONE_RE = re.compile(r"(?<![\w.])(?:\+|00)?\d{1,3}[\s.\-]?\(?\d{2,4}\)?[\s.\-]?\d{3,4}[\s.\-]?\d{3,4}(?![\w])")


# kept for backward compatibility (v0.9 exported these lists)
URGENCY_WORDS = ["urgent", "immediately", "expires", "limited time", "act now", "final notice"]
MONEY_PRESSURE = ["wire transfer", "payment", "invoice", "iban", "refund", "gift card"]
THREAT_WORDS = ["suspended", "blocked", "terminated", "legal action", "unauthorized access"]


def fold_text(text: str) -> str:
    """Lower-case, strip accents, transliterate Cyrillic, undo look-alike letters:
    the form every pattern in this module is written in."""
    return fold_for_matching(text)


def _n(rx: re.Pattern, t: str) -> int:
    """Number of DISTINCT phrases of a family present."""
    return len({m.group(0) for m in rx.finditer(t)})


def analyze_text(text: str, phones: list | None = None, html: dict | None = None) -> list[dict]:
    signals = []
    raw = (text or "")[:MAX_TEXT_CHARS]      # bounded work, whatever the mail's size
    t = fold_text(raw)

    def add(name, weight, detail):
        signals.append({"signal": name, "weight": weight, "detail": detail})

    u = _n(URGENCY, t)
    if u >= 2:
        add("text_urgency_high", 14, f"{u} urgency phrases")
    elif u == 1:
        add("text_urgency_low", 6, "One urgency phrase")

    m = _n(MONEY, t)
    if m >= 2:
        add("text_money_pressure", 8, f"{m} financial/pressure phrases")
    elif m == 1:
        add("text_money_pressure", 4, "One financial/pressure phrase")

    c = _n(CREDENTIAL_ASK, t)
    if c >= 1:
        add("text_credential_ask", 16, f"{c} credential-harvesting phrase(s)")
    elif _n(LOGIN_PROMPT, t):
        add("text_login_prompt", 4, "Asks you to click a link / sign in")

    if _GREETING_WITH_ADDRESS.search(t):
        add("text_generic_greeting", 10, "Greets you by your e-mail address instead of your name")
    elif _n(GENERIC_GREETING, t):
        add("text_generic_greeting", 6, "Generic greeting without a name")

    th = _n(THREAT, t)
    if th >= 1:
        add("text_threat", 12, f"{th} threat/sanction phrase(s)")

    # ---- business e-mail compromise
    gift = _n(GIFT_CARD, t)
    bank = _n(BANK_CHANGE, t)
    payroll = _n(PAYROLL_CHANGE, t)
    pay = _n(PAYMENT_REQUEST, t)
    pretext = _n(BEC_PRETEXT, t)
    if gift and (pretext or _n(GIFT_CARD_ASK, t)):
        add("text_gift_card_request", 20, "Asks you to buy gift cards / send voucher codes")
    if bank:
        add("text_bank_detail_change", 20, "Announces new bank details for payments (invoice-fraud pattern)")
    if payroll:
        add("text_payroll_change", 18, "Asks to redirect salary / direct deposit to another account")
    if pay and not (bank or gift):
        add("text_payment_request", 12 if pretext else 6, "Requests a payment or transfer")
    if pretext:
        add("text_bec_pretext", 12 if pretext >= 2 else 8,
            f"{pretext} social-engineering pretext phrase(s) (secrecy, 'are you available', can't talk)")

    # ---- technique-specific lures
    if _n(DEVICE_CODE, t):
        add("text_device_code_lure", 25, "Tells you to enter a code on a device-login page (device-code phishing)")
    if _n(CLICKFIX, t):
        add("text_clickfix", 25, "Instructs you to paste/run a command (ClickFix)")
    if _n(WALLET_PHRASE, t):
        add("text_wallet_phrase", 20, "Mentions wallet seed/recovery phrase or wallet validation")
    if _n(EXTORTION, t) >= 2:
        add("text_extortion", 20, "Extortion wording (claims of hacking / recordings, demands crypto)")
    af = _n(ADVANCE_FEE, t[:3000])          # a real 419 letter is short; news digests are not
    if af >= 4:
        add("text_advance_fee", 20, f"Advance-fee fraud wording ({af} distinct markers)")
    elif af == 3:
        add("text_advance_fee", 12, "Advance-fee fraud wording (3 distinct markers)")
    if _n(PRIZE_LURE, t):
        add("text_prize_lure", 12, "Prize / reward / 'you have been selected' lure")
    q = _n(QR_LURE, t)
    if q:
        add("text_qr_lure", 12, "Asks you to scan a QR code")
    mb = _n(MAILBOX_LURE, t)
    if mb:
        add("text_mailbox_lure", 14 if mb >= 2 else 10, "Mailbox / password-expiry / held-messages notice")
    if _n(DELIVERY, t) and _n(DELIVERY_FEE, t):
        add("text_delivery_fee_lure", 14, "Parcel is 'held' and a fee or address confirmation is requested")
    if _n(REFUND, t) and _n(REFUND_ASK, t) and (c or _n(LOGIN_PROMPT, t)):
        add("text_refund_lure", 12, "Promises a refund in exchange for your details")
    if _n(DOCUMENT_LURE, t):
        add("text_document_lure", 4, "Shared-document / e-signature / voicemail notice")

    has_phone = bool(phones) or bool(_PHONE_RE.search(raw))
    if has_phone and _n(CALLBACK_CONTEXT, t) and CALLBACK_ACTION.search(t):
        add("text_callback_lure", 18, "A charge or renewal notice that tells you to phone a number to cancel (callback phishing)")

    # ---- obfuscation
    mixed = mixed_script_words(raw)
    if len(mixed) >= 2:
        add("text_mixed_script", 15, f"{len(mixed)} words mix Latin with look-alike Cyrillic/Greek letters "
                                     f"(e.g. {mixed[0]!r})")
    if re.search(r"(?:\b\w ){6,}\w\b", raw) and re.search(r"(?i)(?:\b[a-z] ){6,}[a-z]\b", raw):
        add("text_spaced_letters", 8, "Words written with a space between every letter (filter evasion)")
    if html:
        if (html.get("invisible_in_words") or 0) >= 3:
            add("text_invisible_chars", 12, "Invisible characters inserted inside words (filter evasion)")
        vis, hid = html.get("visible_chars") or 0, html.get("hidden_chars") or 0
        if hid >= 400 and hid > 2 * max(vis, 1):
            add("html_hidden_text", 10, f"Far more hidden text ({hid} chars) than visible text ({vis} chars)")

    # ALL CAPS words (ignore product codes like YZY, QNTM, B2B)
    caps = [w for w in re.findall(r"\b[A-ZÄÖÅŠĐČĆŽ]{5,}\b", raw) if not any(ch.isdigit() for ch in w)]
    if len(caps) >= 5:
        add("text_excessive_caps", 4, f"{len(caps)} words in ALL CAPS")

    return signals
