"""Held-out probe sets - NEVER used for training.

They measure what the public corpora cannot: behaviour on MODERN everyday
mail (newsletters, notifications, receipts) and on 2025-2026 lure styles.
Add your own real examples here over time (anonymized).

MODERN_LEGIT / MODERN_PHISH   the original v0.8 probes (kept unchanged so
                              numbers stay comparable between versions)
V2_*                          added in v0.10: more samples and the project's
                              other languages (Bosnian/Croatian/Serbian, Swedish)

Honest limits: these are short texts written by the project, not sampled from
anyone's mailbox, and each set is small - quote the confidence interval that
evaluate.py prints, not the bare percentage.
"""

MODERN_LEGIT = [
    # newsletters / marketing
    "We have 1200 sneakers ON SALE\nNIKE ADIDAS JORDAN up to 60% off. Free shipping over 50 EUR. Shop now. Unsubscribe | Privacy policy",
    "This FALL Will Bring Some Heat\nNew arrivals from Puma, New Balance and Converse are here. Shop the collection. You are receiving this because you subscribed.",
    "Pocket 20% off the things you love with this coupon until Sunday!\nUse code SAVE20 at checkout on eligible items. Terms apply. Unsubscribe from marketing emails.",
    "Dolce & Gabbana Extra 20% Off\nYour favourite fragrances, now even better value. Limited time. View in browser. Manage preferences.",
    "30% OFF Discount Storm Proxies\nUpgrade your residential proxy plan this week and save 30%. Questions? Reply to this email.",
    "NOVA KOLEKCIJA koja mora biti tvoja!\nPogledaj najnovije modele patika i opreme. Besplatna dostava za porudžbine preko 5000 RSD. Odjava sa liste.",
    "Black Friday starts now\nDoorbuster deals on TVs, laptops and headphones. Prices valid while stocks last. See all deals.",
    "Your weekly digest: 5 stories we think you will like\nRead more on our blog. Update your email preferences or unsubscribe.",
    "Webinar invitation: Cloud cost optimisation best practices\nJoin our engineers on Thursday. Register for free. Can't make it? We'll send the recording.",
    "New Supreme x Nike drop\nThe latest release is live on the marketplace. Place a bid or buy now. Download the app.",
    # notifications
    "Logan mentioned you in Introducing of Coin\nLogan: hey check this out @you. Reply in Discord. Manage notification settings.",
    "You missed messages in Balkan SnaKe\nYou have 14 unread messages. Open Discord to catch up.",
    "New comment on your pull request #482\nmaria-dev commented: looks good, just one nit on line 40. View it on GitHub.",
    "Your Zoom meeting recording is ready\nThe cloud recording for Weekly sync is now available. Share it with participants from your Zoom web portal.",
    "Jane Doe shared a document with you\nQ3 planning notes. Open in Docs. You received this because Jane shared a file with you.",
    "Someone liked your post\nAna and 12 others liked your photo. See activity.",
    "Your verification code is 482913\nEnter this code to finish signing in. If you didn't request it, you can ignore this email.",
    "Security alert: new sign-in on Windows\nWe noticed a new sign-in to your account on a Windows device. If this was you, you don't need to do anything.",
    # transactional
    "Your order has shipped\nOrder #88213 is on its way and should arrive Thursday. Track your package in your account.",
    "Receipt for your payment\nThanks for your purchase. Amount paid 12.99 EUR. Monthly subscription. View invoice in your account settings.",
    "Your booking is confirmed\nCheck-in Friday 15:00, check-out Sunday 11:00. Manage your booking in the app.",
    "Your flight to Belgrade: online check-in is open\nCheck in now to choose your seat. Passenger locator form may be required at destination.",
    "Your data plan will expire soon\nYour 5GB plan expires in 3 days. Top up in the app to stay connected.",
    "We are updating our Client Agreement\nThe updated terms take effect next month. No action is required. Read the full agreement on our website.",
    "Your statement is ready\nYour monthly statement is now available in online banking. For your security we never ask for your password by email.",
    "Password changed\nThe password for your account was changed. If you made this change, no further action is needed.",
    # personal / work
    "Re: dinner on Saturday\nSounds great, see you at 8. I'll book the table.",
    "Minutes from today's meeting\nAttached are the notes and action items. Next sync is Tuesday.",
    "Pozdrav, šaljem ti ponudu\nU prilogu je ponuda koju smo dogovorili. Javi ako treba izmjena.",
    "Invoice 2026-044 for October\nPlease find attached our invoice for consulting services, payment terms 30 days as agreed in the contract.",
]

MODERN_PHISH = [
    "Action required: Microsoft 365 password expires today\nYour password will expire in 2 hours. Keep your current password by signing in here to avoid losing access to your mailbox.",
    "DocuSign: Please review and sign - Payroll adjustment Q4\nYou have received a document to review and sign. REVIEW DOCUMENT. This link expires in 24 hours.",
    "Zoom: You have a missed meeting recording from HR\nSign in with your work account to view the recording shared with you.",
    "Scan the QR code to keep your MFA active\nOur records show your multi-factor authentication must be re-enrolled. Scan the attached code with your phone to continue.",
    "Your mailbox storage is full\nIncoming messages are being held. Verify your account now to release 23 pending messages.",
    "Invoice overdue - final reminder\nPlease remit payment today. Our bank details have changed, use the new account in the attached PDF.",
    "Shared file: Salary_Increase_2026.pdf\nHR has shared a confidential document with you. Log in with your email credentials to view.",
    "Unusual sign-in activity\nWe detected a sign-in attempt from Russia. If this wasn't you, secure your account immediately by confirming your identity.",
    "Your package is held at customs\nA customs fee of 1.99 EUR is required. Pay now or the parcel will be returned to sender.",
    "Device verification required\nGo to microsoft.com/devicelogin and enter code XQ7-PLM2 to keep access to your company account.",
    "Hitno: vaš nalog će biti blokiran\nPotvrdite podatke za e-bankarstvo u roku od 24 sata klikom na link ispod.",
    "Quick favour\nAre you at your desk? I need you to buy 5 gift cards for a client today, I'll reimburse you. Keep this confidential. Sent from my iPhone",
    "Calendar invite: Mandatory compliance training\nAccept the invite and sign in to the training portal with your corporate credentials before Friday.",
    "Netflix: your payment was declined\nUpdate your billing information within 48 hours to avoid suspension of your membership.",
    "Tax refund notification\nYou are eligible for a tax refund of 412.50 EUR. Submit your bank card details to receive the refund.",
]


# ---------------------------------------------------------------------------
# v0.10 probe sets
# ---------------------------------------------------------------------------
V2_LEGIT_EN = [
    "Your parcel will arrive tomorrow\nHi Dana, your DPD driver will deliver between 10:14 and 11:14. Not in? Choose a safe place or a neighbour in the app.",
    "Standup notes 21 Nov\nDone: migrated the billing job. Today: finish the retry logic. Blockers: waiting on staging access from Tom.",
    "Your table at Trattoria Roma is booked\nSaturday 28 November, 20:00, 4 guests. If your plans change you can cancel up to 2 hours before.",
    "Receipt from the dentist\nThank you for your visit on 19 November. Treatment: check-up and cleaning. Paid by card: 65.00. Next recall in six months.",
    "Re: quote for the kitchen worktop\nHi, attached is the revised quote with the oak option. Price is valid until the end of the month, lead time about three weeks.",
    "Your electricity bill for October\nYour bill is 84.20. It will be collected by direct debit on 5 December, so there is nothing you need to do.",
    "Library: item due soon\nThe book you borrowed is due back on 30 November. You can renew it once from your library account or at the desk.",
    "Flight change notification\nYour flight on 3 December now departs at 07:25 instead of 06:55. Your seats and bags are unchanged. No action is needed.",
    "Welcome to the team!\nYour first day is Monday. Come to reception at 9, bring your ID for the badge. Laptop and accounts will be ready at your desk.",
    "Your monthly usage report\nYou used 412 GB of 1 TB this month. Top project: video-archive. View the full breakdown in your dashboard.",
    "Parent evening on Thursday\nDear parents, the autumn parent evening is on Thursday at 18:00 in the main hall. Year 5 teachers will be available afterwards.",
    "Order update: one item is delayed\nThe desk lamp in your order is out of stock until next week. We will ship the rest today and send the lamp separately at no extra cost.",
    "New sign-in to your account\nWe noticed a sign-in from Chrome on Windows in Vienna. If this was you, you can ignore this email. If not, change your password from the app's security settings.",
    "Your invoice from Hetzner\nInvoice R0041882 for November is attached. The amount of 23.68 EUR will be charged to your saved payment method on the due date.",
    "Minutes: housing association meeting\nPresent: 14 households. Decisions: the stairwell will be repainted in spring; the bike room gets a new lock. Next meeting in February.",
    "Reminder: car inspection\nYour vehicle inspection is booked for 2 December at 08:40. Please bring the registration certificate. Rescheduling is free up to 24 hours before.",
    "Your photos are ready\nThe 48 prints you ordered are ready for collection at the store. Bring this email or your order number.",
    "Re: Re: budget numbers\nThanks, that matches what finance sent. I will put the updated slide in the deck tonight and we can go through it at ten.",
    "Thanks for your donation\nYour gift of 25.00 will help us keep the shelter open this winter. This email is your receipt for tax purposes.",
    "Scheduled maintenance this weekend\nOnline banking will be unavailable on Sunday between 01:00 and 05:00 while we upgrade our systems. Cards and ATMs work as usual.",
    "Your ticket for the concert\nYour e-ticket is attached as a PDF. Doors open at 19:00. Show the barcode at the entrance, on your phone or printed.",
    "Course registration confirmed\nYou are registered for Intermediate Spanish, Tuesdays 18:30, starting 13 January. The course fee has been received.",
    "Pull request merged\nYour pull request 'Handle empty CSV rows' was merged into main by a maintainer. The change will be in the next release.",
    "Your prescription is ready\nYour prescription can be collected from the pharmacy from tomorrow 10:00. Remember to bring your ID.",
    "Happy holidays from all of us\nThank you for a great year working together. Our office is closed from 24 December to 2 January.",
]

V2_LEGIT_BCS = [
    "Potvrda narudžbe br. 20418\nPoštovana, vaša narudžba je zaprimljena i bit će isporučena u roku od 2-3 radna dana. Plaćanje pouzećem, iznos 64,90 KM.",
    "Podsjetnik: termin kod stomatologa\nPodsjećamo vas na termin u četvrtak u 16:30. Ako ne možete doći, molimo javite se dan ranije na broj ordinacije.",
    "Zapisnik sa sastanka\nU prilogu je zapisnik sa jučerašnjeg sastanka. Dogovoreno: Emir priprema ponudu do petka, Selma zove dobavljača.",
    "Račun za struju za oktobar\nVaš račun za električnu energiju iznosi 58,30 KM i dospijeva 20.11. Račun možete platiti kao i do sada, na šalteru ili putem e-bankarstva.",
    "Vaša pošiljka je isporučena\nPošiljka broj 17400098812 uručena je danas u 11:42. Hvala što koristite naše usluge.",
    "Re: ponuda za stolariju\nPoštovani, u prilogu je korigovana ponuda sa PVC stolarijom u boji antracit. Rok izrade je četiri sedmice od uplate avansa po ugovoru.",
    "Obavještenje o radovima\nZbog radova na vodovodnoj mreži sutra od 9 do 14 sati neće biti vode u ulicama Titova i Maršala Tita. Hvala na razumijevanju.",
    "Roditeljski sastanak\nPoštovani roditelji, roditeljski sastanak za III-2 održat će se u srijedu u 17:30 u učionici broj 12.",
    "Vaša rezervacija je potvrđena\nApartman Stari Grad, dolazak 27.11., odlazak 29.11., dvije osobe. Plaćanje na licu mjesta. Vidimo se!",
    "Promjena lozinke uspješna\nLozinka za vaš korisnički račun je upravo promijenjena. Ako ste vi izvršili promjenu, nije potrebna nikakva dalja radnja.",
    "Izvještaj za treći kvartal\nKolege, izvještaj za Q3 je u dijeljenom folderu. Molim komentare do srijede, u četvrtak ga šaljemo upravi.",
    "Hvala na kupovini\nVaš fiskalni račun i garantni list nalaze se u prilogu. Zamjena artikla moguća je u roku od 14 dana uz račun.",
    "Poziv na rođendan\nĆao! Slavimo Adnanov rođendan u subotu u 19h kod nas. Javi da li dolazite da znam za koliko ljudi da spremam.",
    "Uplata zaprimljena\nPotvrđujemo prijem vaše uplate od 120,00 KM po predračunu 2026-88. Roba će biti poslana sutra.",
    "Novi broj biltena je izašao\nU ovom broju: intervju sa predsjednicom udruženja, kalendar događaja za decembar i poziv volonterima.",
    "Raspored dežurstava za decembar\nU prilogu je raspored dežurstava. Molim sve da provjere svoje termine i jave eventualne zamjene do petka.",
    "Vaš zahtjev je zaprimljen\nVaš zahtjev za izdavanje uvjerenja zaprimljen je pod brojem 04-1182. Uvjerenje možete preuzeti na šalteru za pet radnih dana.",
    "Servis vozila\nPoštovani, vaše vozilo je spremno za preuzimanje. Urađen je mali servis i zamjena pakni. Ukupno 285 KM, račun u prilogu.",
    "Potvrda prijave na kurs\nUspješno ste prijavljeni na kurs njemačkog jezika A2. Nastava počinje 12. januara, ponedjeljkom i srijedom u 18 sati.",
    "Поштовани, у прилогу је понуда\nШаљем понуду за израду сајта коју смо договорили. Понуда важи 30 дана. Срдачан поздрав.",
]

V2_LEGIT_SV = [
    "Din beställning är på väg\nHej! Ditt paket har lämnat vårt lager och levereras till ditt ombud inom 1-3 vardagar. Du får ett sms när det kan hämtas.",
    "Kallelse till tandvården\nDu har en bokad tid hos tandhygienisten tisdag 1 december kl 14.20. Avboka senast 24 timmar innan om du inte kan komma.",
    "Protokoll från styrelsemötet\nBifogar protokollet från gårdagens möte. Nästa möte blir den 14 januari. Hör av er om något behöver justeras.",
    "Din elfaktura för oktober\nFakturan på 742 kr dras via autogiro den 28 november. Du behöver inte göra något.",
    "Föräldramöte på torsdag\nHej alla föräldrar i 4B! Välkomna på föräldramöte torsdag kl 18.00 i klassrummet. Vi bjuder på fika.",
    "Bekräftelse på din bokning\nTack för din bokning! Stuga 12, ankomst fredag 27 november, avresa söndag. Nyckeln hämtas i receptionen från kl 15.",
    "Lösenordet har ändrats\nLösenordet för ditt konto ändrades nyss. Om det var du behöver du inte göra något mer.",
    "Påminnelse: bilbesiktning\nDin bil ska besiktas senast den 31 december. Du har en bokad tid 9 december kl 07.50 på stationen i Solna.",
    "Sv: offert på badrumsrenovering\nHej, bifogar den uppdaterade offerten med klinker istället för plastmatta. Priset gäller till månadsskiftet.",
    "Kvitto på ditt köp\nTack för ditt köp. Summa 349 kr betalt med kort. Öppet köp i 30 dagar mot uppvisande av kvitto.",
    "Veckobrev vecka 48\nDen här veckan: simning på onsdag, glöm inte badkläder. Utvecklingssamtal bokas via appen. Trevlig helg!",
    "Driftstörning åtgärdad\nStörningen i bredbandet i ditt område är nu åtgärdad. Vi ber om ursäkt för besväret.",
    "Tack för din gåva\nDitt bidrag på 200 kr gör skillnad. Det här mejlet är ditt kvitto.",
    "Julbord med jobbet\nHej! Julbordet blir fredag 11 december kl 18 på Operakällaren. Anmäl specialkost till mig senast måndag.",
    "Din resa är bokad\nStockholm C - Göteborg C, avgång 08.24, vagn 5 plats 42. Biljetten finns i appen och som pdf i det här mejlet.",
]

V2_PHISH_EN = [
    "Mail delivery failure: 6 messages quarantined\nYour mailbox has reached its storage limit and 6 incoming messages are on hold. Release them to your inbox now or they will be removed in 24 hours.",
    "Payroll: confirm your bank details before the December run\nHR is updating payroll records. Log in with your network password to confirm your account or your salary will be delayed.",
    "Your Amazon account is on hold\nWe could not verify your billing address. Update your payment details within 48 hours or your order and account will be cancelled.",
    "Remittance advice attached\nPlease find the remittance copy for the wire made today. Open the secured file and sign in with your email to view the amount.",
    "IT notice: your password expires in 3 hours\nTo continue using the same password, validate your mailbox on the staff portal now. Failure to do so will lock your account.",
    "Re: overdue invoice 30118\nAs discussed, our bank has changed. Kindly remit the outstanding amount to the new account details in the attached letter today and send the payment slip.",
    "Unusual sign-in: Lagos, Nigeria\nSomeone just used your password to try to sign in. If this wasn't you, secure your account immediately by confirming your identity at the link below.",
    "You have a new encrypted message\nA secure message was sent to you by the accounts team. Enter your email password to decrypt and read it. The message expires today.",
    "Congratulations, you have been selected\nYou are today's lucky visitor. Answer three questions to claim your free iPhone 16. Only 2 left, claim your reward now.",
    "Your parcel could not be delivered\nThe address on your package is incomplete. Confirm your address and pay the 1.45 redelivery fee by card to schedule a new delivery.",
    "Quick task\nHi, are you available? I'm tied up in a board meeting and need you to get some gift cards for a client. Email me back, don't call. I will reimburse you today.",
    "Your Microsoft 365 licence has expired\nRenew your licence now to prevent your files and mailbox from being permanently deleted. Sign in with your work account to renew.",
    "Fax received: 3 pages\nYou have received a new fax document from the scanner. Preview the document by logging in with your Office credentials.",
    "HMRC: you are due a tax refund of 384.20\nA refund has been calculated for you. Submit your card details through the secure gateway to receive the payment within 3 working days.",
    "Wallet security notice\nYour wallet must be re-synchronised after the latest update. Enter your 12-word recovery phrase to validate your wallet and avoid losing your assets.",
    "Your subscription was renewed for 349.99\nThanks for renewing your antivirus protection. If you did not authorise this charge, call our support line right away to cancel and get a refund.",
    "Action needed: verify your device\nGo to the device login page and enter the code shown below to continue using Teams on your computer. The code is valid for 15 minutes.",
    "Your iCloud storage is full\nYour photos and videos will be deleted. Upgrade now and get 50 GB free by confirming your card details today.",
    "Account statement ready - please review\nYour statement could not be delivered. Download it by confirming your online banking user ID and password.",
    "Final warning: domain suspension\nYour domain will be suspended today because of an unpaid invoice. Pay now to avoid suspension and loss of your website and email.",
    "Shared with you: Q4 bonus list.xlsx\nThe finance director shared a confidential file with you. Sign in with your company email and password to open it.",
    "I recorded you\nI have access to your device and your webcam. I have a video of you. Send 1200 dollars in bitcoin to my address within two days or everyone in your contacts gets it.",
    "LinkedIn: your account will be restricted\nWe detected activity that violates our policy. Verify your account within 24 hours to avoid permanent restriction.",
    "Complete the human verification\nTo view the document press Windows key + R, paste the verification text with Ctrl + V and press Enter.",
    "Direct deposit update\nHi, I recently switched banks and would like my direct deposit changed before the next pay date. What information do you need from me?",
]

V2_PHISH_BCS = [
    "Vaš paket je zadržan\nPoštovani, vaša pošiljka čeka na carinjenje. Potrebno je platiti naknadu od 1,99 EUR karticom u roku od 24 sata ili će paket biti vraćen.",
    "Obavijest banke: kartica blokirana\nVaša kartica je privremeno blokirana zbog sumnjive transakcije. Potvrdite podatke kartice i PIN klikom na link kako biste je odblokirali.",
    "Hitno: nalog će biti ugašen\nVaš e-mail nalog bit će ugašen danas. Potvrdite svoju lozinku na portalu da biste zadržali pristup pošti.",
    "Povrat poreza\nOstvarili ste pravo na povrat poreza u iznosu od 386,40 KM. Unesite podatke o kartici u obrazac da biste primili uplatu.",
    "Jesi li u kancelariji?\nTreba mi hitna usluga, na sastanku sam i ne mogu telefonirati. Kupi šest poklon kartica i pošalji mi kodove mejlom, vratiću ti novac večeras.",
    "Promjena žiro računa dobavljača\nPoštovani, obavještavamo vas da smo promijenili banku. Molimo da sve buduće fakture plaćate na novi račun naveden u prilogu.",
    "Vaše sanduče je puno\nImate 9 poruka na čekanju koje nisu isporučene. Verifikujte svoj nalog da biste ih primili, u suprotnom će biti obrisane.",
    "Telekom: neuspjelo plaćanje računa\nVaša usluga će biti isključena. Ažurirajte podatke o plaćanju u roku od 12 sati da izbjegnete isključenje.",
    "Čestitamo, osvojili ste nagradu\nIzabrani ste kao dobitnik vaučera od 500 KM. Preuzmite svoju nagradu potvrdom podataka i plaćanjem dostave.",
    "Sigurnosno upozorenje\nNeko se pokušao prijaviti na vaš nalog iz Rusije. Ako to niste bili vi, odmah potvrdite identitet unosom lozinke.",
    "Faktura u prilogu - opomena pred tužbu\nNiste platili fakturu. Platite odmah putem linka, u suprotnom predmet ide izvršitelju.",
    "Dokument čeka vaš potpis\nPodijeljen vam je povjerljiv dokument o povećanju plate. Prijavite se službenim nalogom i lozinkom da ga otvorite.",
    "e-Uprava: neplaćena saobraćajna kazna\nImate neplaćenu kaznu od 30 EUR. Platite danas karticom da izbjegnete uvećanje iznosa i prinudnu naplatu.",
    "Vaš Netflix nalog je suspendovan\nPlaćanje nije uspjelo. Ažurirajte podatke kartice da nastavite gledati, u suprotnom se nalog briše.",
    "Molba za promjenu računa za platu\nPozdrav, promijenio sam banku, molim da mi platu za ovaj mjesec uplatite na novi račun. Neka ostane povjerljivo.",
    "Хитно: ваш налог је блокиран\nПотврдите своју лозинку и податке картице у року од 24 сата да бисте избегли трајно гашење налога.",
    "Skenirajte QR kod\nVaša dvofaktorska zaštita ističe. Skenirajte QR kod telefonom i prijavite se da je obnovite prije isteka.",
    "Zaključan pristup e-bankarstvu\nIz sigurnosnih razloga pristup je zaključan. Otključajte nalog unosom korisničkog imena, lozinke i koda iz SMS-a.",
    "Hakovao sam tvoj uređaj\nSnimio sam te preko kamere. Uplati 800 eura u bitcoinu u roku od 48 sati ili šaljem snimak svim tvojim kontaktima.",
    "Narudžba potvrđena: 899 EUR\nVaša kartica je terećena za 899 EUR. Ako niste vi naručili, pozovite odmah našu službu na broj ispod da otkažete.",
]

V2_PHISH_SV = [
    "Ditt paket väntar\nDin försändelse kunde inte levereras. Betala tullavgiften på 19 kr med kort inom 24 timmar, annars skickas paketet tillbaka.",
    "Ditt kort har spärrats\nVi har upptäckt misstänkt aktivitet. Bekräfta dina kortuppgifter och din kod via länken för att häva spärren.",
    "Skatteåterbäring väntar på dig\nDu har 3 420 kr att få tillbaka. Logga in med BankID och bekräfta ditt kontonummer inom tre dagar.",
    "Ditt konto stängs idag\nDin e-postlåda är full och kommer att stängas. Verifiera ditt konto och ange ditt lösenord för att behålla dina mejl.",
    "Är du ledig?\nJag sitter i möte och kan inte prata. Jag behöver att du köper presentkort till en kund idag, skicka koderna hit. Säg inget till någon ännu.",
    "Nya bankuppgifter\nHej, vi har bytt bank. Alla kommande fakturor ska betalas till vårt nya bankgiro enligt bifogat brev. Bekräfta att ni har uppdaterat.",
    "Din BankID har gått ut\nFörnya din BankID idag genom att logga in och bekräfta dina uppgifter, annars spärras dina tjänster vid midnatt.",
    "Obetald faktura - sista påminnelsen\nBetala omedelbart via länken för att undvika inkasso och rättsliga åtgärder.",
    "Grattis, du har vunnit\nDu är utvald att få ett presentkort på 5 000 kr. Hämta din vinst genom att bekräfta dina kortuppgifter.",
    "Swish: betalningen misslyckades\nDin betalning kunde inte genomföras. Verifiera ditt konto och ange din kod för att låsa upp Swish.",
    "Misstänkt inloggning\nNågon försökte logga in på ditt konto från utlandet. Bekräfta din identitet omedelbart genom att ange ditt lösenord.",
    "Ditt abonnemang har förnyats för 3 499 kr\nOm du inte godkände köpet, ring vår support direkt på numret nedan för att avbryta och få pengarna tillbaka.",
    "Skanna QR-koden\nDin tvåfaktorsinloggning måste förnyas. Skanna QR-koden med mobilen och logga in för att behålla åtkomsten.",
    "Dokument delat med dig\nEkonomichefen har delat ett konfidentiellt dokument om löneökning. Logga in med ditt arbetskonto och lösenord för att öppna.",
    "Byte av lönekonto\nHej, jag har bytt bank och vill att lönen betalas ut till mitt nya konto från och med nu. Vad behöver ni från mig?",
]


def all_probe_sets() -> dict:
    """name -> (texts, label). label 0 = legitimate, 1 = phishing."""
    return {
        "legit_v1_original": (MODERN_LEGIT, 0),
        "legit_v2_english": (V2_LEGIT_EN, 0),
        "legit_v2_bcs": (V2_LEGIT_BCS, 0),
        "legit_v2_swedish": (V2_LEGIT_SV, 0),
        "phish_v1_original": (MODERN_PHISH, 1),
        "phish_v2_english": (V2_PHISH_EN, 1),
        "phish_v2_bcs": (V2_PHISH_BCS, 1),
        "phish_v2_swedish": (V2_PHISH_SV, 1),
    }
