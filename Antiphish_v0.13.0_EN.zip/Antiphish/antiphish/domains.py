"""Domain / URL utilities shared by the heuristic checks (stdlib only, offline).

* registrable_domain()  - eTLD+1 with multi-tenant hosting suffixes treated
                          like public suffixes (evil.pages.dev != other.pages.dev)
* unwrap_redirect()     - pull the real target out of Safe Links, Proofpoint,
                          google.com/url, ad-click and generic open redirects
* skeleton()            - collapse look-alike characters (paypa1 -> paypal,
                          rnicrosoft -> microsoft, Cyrillic 'а' -> Latin 'a')
* lists of shorteners, IPFS gateways, free hosting, click trackers, abused TLDs

The platform lists were seeded from the link targets actually seen in the
2024-2025 Nazario phishing corpus (ipfs.io, r2.dev, pages.dev, workers.dev,
glitch.me, vercel.app, doubleclick redirects, ...) and vendor reporting on
trusted-platform abuse.
"""
from __future__ import annotations

import base64
import ipaddress
import re
import unicodedata
from urllib.parse import parse_qsl, unquote, urlsplit

# ------------------------------------------------------------------ suffixes
_SECOND_LEVEL = {"co", "com", "org", "net", "ac", "gov", "edu", "ne", "or", "go", "in", "mil",
                 "nom", "ltd", "plc", "me", "gob", "gv", "sch"}

# Multi-tenant platforms: every label left of these is a different customer.
PLATFORM_SUFFIXES = {
    # static / app hosting
    "github.io", "gitlab.io", "pages.dev", "workers.dev", "r2.dev", "vercel.app", "netlify.app",
    "web.app", "firebaseapp.com", "herokuapp.com", "onrender.com", "glitch.me", "repl.co",
    "replit.app", "replit.dev", "surge.sh", "fly.dev", "deno.dev", "railway.app", "render.com",
    "azurewebsites.net", "azurestaticapps.net", "azureedge.net", "cloudfront.net",
    "awsapprunner.com", "amplifyapp.com", "appspot.com", "run.app", "cloudfunctions.net",
    "ondigitalocean.app", "digitaloceanspaces.com", "backblazeb2.com", "wasabisys.com",
    "codesandbox.io", "stackblitz.io", "on-fleek.app", "fleek.co", "4everland.app",
    "trycloudflare.com", "ngrok.io", "ngrok-free.app", "ngrok.app", "loca.lt", "serveo.net",
    "pagekite.me", "translate.goog", "framer.app", "framer.website", "lovable.app", "bolt.new",
    "webflow.io", "vercel.dev", "nx.page", "edgeone.app", "edgeone.dev", "pinggy.link",
    # site builders
    "weebly.com", "wixsite.com", "wixstudio.com", "wordpress.com", "blogspot.com", "tumblr.com",
    "squarespace.com", "square.site", "godaddysites.com", "myshopify.com", "webnode.page",
    "webnode.com", "strikingly.com", "jimdosite.com", "jimdofree.com", "carrd.co", "notion.site",
    "site123.me", "mystrikingly.com", "yolasite.com", "webwave.dev", "gamma.site", "zohosites.com",
    "odoo.com", "mailchimpsites.com", "hubspotpagebuilder.com", "systeme.io", "typedream.app",
    "softr.app", "softr.io", "bubbleapps.io", "glideapp.io", "tiiny.site", "tiiny.co", "plesk.page",
    "hostingersite.com", "000webhostapp.com", "infinityfreeapp.com", "atwebpages.com", "rf.gd",
    # storage with public buckets
    "amazonaws.com", "blob.core.windows.net", "web.core.windows.net", "storage.googleapis.com",
    "linodeobjects.com", "r2.cloudflarestorage.com", "supabase.co", "nyc3.cdn.digitaloceanspaces.com",
    # dynamic DNS
    "duckdns.org", "ddns.net", "no-ip.org", "no-ip.biz", "hopto.org", "zapto.org", "sytes.net",
    "serveftp.com", "myftp.org", "dynu.net", "dynv6.net", "freeddns.org", "mooo.com", "sslip.io",
    "nip.io", "xip.io", "traefik.me",
    # Microsoft 365 tenants: anyone can create <name>.onmicrosoft.com / <name>.sharepoint.com
    "onmicrosoft.com", "sharepoint.com",
}
_MAX_PLATFORM_LABELS = max(s.count(".") + 1 for s in PLATFORM_SUFFIXES)

FREE_HOSTING = PLATFORM_SUFFIXES - {"amazonaws.com", "cloudfront.net", "azureedge.net",
                                    "storage.googleapis.com", "translate.goog", "onmicrosoft.com",
                                    "sharepoint.com"}
# tenant-controlled storage: only flagged when the link is an HTML page / bucket site
OBJECT_STORAGE = {"amazonaws.com", "storage.googleapis.com", "blob.core.windows.net",
                  "web.core.windows.net", "backblazeb2.com", "digitaloceanspaces.com",
                  "linodeobjects.com", "wasabisys.com", "r2.dev", "supabase.co"}
WILDCARD_DNS = {"sslip.io", "nip.io", "xip.io", "traefik.me"}
DYNAMIC_DNS = {"duckdns.org", "ddns.net", "no-ip.org", "no-ip.biz", "hopto.org", "zapto.org",
               "sytes.net", "serveftp.com", "myftp.org", "dynu.net", "dynv6.net", "freeddns.org",
               "mooo.com"}
TUNNELS = {"trycloudflare.com", "ngrok.io", "ngrok-free.app", "ngrok.app", "loca.lt", "serveo.net",
           "pagekite.me", "pinggy.link"}

IPFS_GATEWAYS = {"ipfs.io", "dweb.link", "cloudflare-ipfs.com", "cf-ipfs.com", "nftstorage.link",
                 "w3s.link", "infura-ipfs.io", "pinata.cloud", "mypinata.cloud", "fleek.co",
                 "on-fleek.app", "4everland.io", "ipfs.fleek.co", "gateway.ipfs.io", "ipfs.eth.aragon.network",
                 "hardbin.com", "via0.com", "crustwebsites.net", "ipfs.best-practice.se", "storry.tv",
                 "jorropo.net", "ipfs.runfission.com", "fleek.cool", "ipns.co", "astyanax.io"}

SHORTENERS = {
    "bit.ly", "bitly.com", "tinyurl.com", "t.co", "goo.gl", "ow.ly", "is.gd", "v.gd", "buff.ly",
    "adf.ly", "cutt.ly", "rb.gy", "shorturl.at", "t.ly", "tiny.cc", "rebrand.ly", "bl.ink", "s.id",
    "shorte.st", "qrco.de", "urlz.fr", "tny.im", "x.co", "soo.gd", "clck.ru", "kutt.it", "dub.sh",
    "n9.cl", "gg.gg", "2no.co", "lnk.to", "u.to", "shorturl.asia", "surl.li", "urlis.net", "t2m.io",
    "short.gy", "shrtco.de", "1url.cz", "zpr.io", "linktr.ee", "lnkd.in", "trib.al", "wp.me",
    "youtu.be", "amzn.to", "a.co", "g.co", "apple.co", "msft.it", "aka.ms", "fb.me", "redd.it",
    "qr.io", "me-qr.com", "qrs.ly", "l.ead.me", "scnv.io", "qr.link", "hoo.be", "bom.so", "cli.re",
    "tr.ee", "1drv.ms", "forms.gle", "goo.su", "ln.run", "encr.pw", "plu.sh", "shor.by",
}
# brand-owned short domains: a short link, but not an anonymous one
_BRAND_SHORTENERS = {"youtu.be", "amzn.to", "a.co", "g.co", "apple.co", "msft.it", "aka.ms",
                     "fb.me", "redd.it", "lnkd.in", "wp.me", "1drv.ms", "forms.gle", "t.co"}
ANON_SHORTENERS = SHORTENERS - _BRAND_SHORTENERS

# TLDs with a persistently high share of abuse (cheap/free registration)
HIGH_ABUSE_TLDS = {
    "tk", "ml", "ga", "cf", "gq", "xyz", "top", "club", "click", "link", "live", "cam", "rest",
    "icu", "buzz", "cfd", "sbs", "cyou", "quest", "monster", "bond", "lol", "mom", "pw", "su",
    "best", "beauty", "hair", "skin", "makeup", "autos", "boats", "motorcycles", "yachts", "vip",
    "win", "bid", "loan", "men", "stream", "download", "review", "country", "kim", "gdn", "racing",
    "party", "science", "date", "faith", "accountant", "cricket", "trade", "webcam", "zip", "mov",
    "work", "support", "fit", "lat", "pics", "christmas", "fun", "uno", "ooo", "surf",
}
# widely used legitimately AND heavily abused: weak hint only
MIXED_TLDS = {"online", "site", "store", "shop", "website", "space", "cc", "ws", "host", "press",
              "info", "biz", "life", "world", "today", "cloud", "pro"}

FREEMAIL_DOMAINS = {
    "gmail.com", "googlemail.com", "yahoo.com", "ymail.com", "rocketmail.com", "hotmail.com",
    "outlook.com", "live.com", "msn.com", "aol.com", "icloud.com", "me.com", "mac.com",
    "proton.me", "protonmail.com", "pm.me", "gmx.com", "gmx.net", "gmx.de", "web.de", "mail.com",
    "zoho.com", "zohomail.com", "yandex.com", "yandex.ru", "mail.ru", "inbox.ru", "list.ru",
    "bk.ru", "tutanota.com", "tuta.io", "tutamail.com", "fastmail.com", "hey.com", "qq.com",
    "163.com", "126.com", "sina.com", "naver.com", "daum.net", "hanmail.net", "seznam.cz",
    "email.cz", "wp.pl", "o2.pl", "interia.pl", "onet.pl", "libero.it", "virgilio.it", "orange.fr",
    "free.fr", "laposte.net", "t-online.de", "freenet.de", "mail.de", "posteo.de", "abv.bg",
    "inbox.lv", "ukr.net", "rambler.ru", "cock.li", "disroot.org", "mailfence.com", "hushmail.com",
    "yahoo.co.uk", "yahoo.de", "yahoo.fr", "yahoo.it", "yahoo.es", "yahoo.se", "hotmail.co.uk",
    "hotmail.de", "hotmail.fr", "hotmail.it", "hotmail.es", "hotmail.se", "live.se", "live.co.uk",
    "outlook.de", "outlook.fr", "outlook.es", "outlook.it", "outlook.sa", "live.fr", "live.de",
    "telia.com", "bredband.net", "comhem.se", "spray.se", "home.se", "glocalnet.net",
    "bih.net.ba", "net.hr", "inet.hr", "t-com.hr", "eunet.rs", "sbb.rs", "ptt.rs", "mts.rs",
    "open.telekom.rs", "beotel.net", "t-com.me", "teol.net", "blic.net", "hs-hkb.ba", "tel.net.ba",
    "yahoo.com.br", "bol.com.br", "uol.com.br", "terra.com.br", "comcast.net", "verizon.net",
    "att.net", "sbcglobal.net", "bellsouth.net", "cox.net", "charter.net", "earthlink.net",
    "btinternet.com", "sky.com", "talktalk.net", "virginmedia.com", "ntlworld.com", "blueyonder.co.uk",
    "duck.com", "simplelogin.com", "anonaddy.com", "mozmail.com", "skiff.com", "onmail.com",
}

# ESP / security-gateway click-tracking hosts: the visible text and the href
# legitimately differ here, so "link text != target" must not fire.
KNOWN_TRACKERS = {
    "sendgrid.net", "list-manage.com", "mailchimp.com", "mandrillapp.com", "mcusercontent.com",
    "rs6.net", "constantcontact.com", "hubspotlinks.com", "hubspotemail.net", "hubspot.com",
    "hs-sites.com", "hsforms.com", "hubspotstarter.net", "mailgun.org", "mailgun.net", "sparkpostmail.com",
    "klclick.com", "klclick1.com", "klclick2.com", "klclick3.com", "klaviyomail.com", "exacttarget.com",
    "sfmc-content.com", "salesforce.com", "force.com", "pardot.com", "mktoweb.com", "marketo.com",
    "mkt.com", "awstrack.me", "amazonses.com", "safelinks.protection.outlook.com", "outlook.com",
    "urldefense.com", "proofpoint.com", "urldefense.proofpoint.com", "mimecast.com",
    "mimecastprotect.com", "emailprotection.link", "cudasvc.com", "barracudanetworks.com",
    "sendibm1.com", "sendibm2.com", "sendibm3.com", "sendibt2.com", "sendibt3.com", "brevo.com",
    "sibforms.com", "sendinblue.com", "activehosted.com", "acemlna.com", "acemlnb.com", "acemlnc.com",
    "activecampaign.com", "cmail19.com", "cmail20.com", "createsend.com", "createsend1.com",
    "campaign-archive.com", "mjt.lu", "mailjet.com", "pstmrk.it", "postmarkapp.com", "customeriomail.com",
    "customer.io", "intercom-mail.com", "intercom.io", "intercom-clicks.com", "beehiiv.com",
    "substack.com", "convertkit.com", "ck.page", "convertkit-mail.com", "convertkit-mail2.com",
    "kit.com", "iterable.com", "braze.com", "emarsys.net", "omnisend.com", "soundestlink.com",
    "moosend.com", "zcsend.net", "zohocampaigns.com", "zoho.com", "sendpulse.com", "aweber.com",
    "dmtrk.net", "dotdigital.com", "mlsend.com", "mailerlite.com", "mailer.lite", "getresponse.com",
    "gr-cdn.com", "smore.com", "e2ma.net", "myemma.com", "cheetahmail.com", "responsys.net",
    "oraclecloud.com", "eloqua.com", "en25.com", "selligent.com", "emsecure.net", "adestra.com",
    "tripolis.com", "apsis.one", "apsis.com", "rule.se", "getanewsletter.com", "paloma.se",
    "ungapped.com", "mailmojo.no", "publit.io", "flowmailer.net", "smtp2go.com", "turbo-smtp.com",
    "elasticemail.com", "sparkpost.com", "mailtrack.io", "yesware.com", "mixmax.com", "streak.com",
    "outreach.io", "salesloft.com", "apollo.io", "lemlist.com", "woodpecker.co", "reply.io",
    "google.com", "googleadservices.com", "doubleclick.net", "facebook.com", "linkedin.com",
    "lnkd.in", "t.co", "twitter.com", "x.com", "youtube.com", "medium.com", "notion.so",
    "atlassian.net", "atlassian.com", "slack.com", "slack-redir.net", "zendesk.com", "freshdesk.com",
    "helpscout.net", "frontapp.com", "stripe.com", "shopify.com", "shopifyemail.com", "squarespace.com",
    "wix.com", "wixpress.com", "ascendbywix.com", "eventbrite.com", "meetup.com", "surveymonkey.com",
    "typeform.com", "docusign.net", "docusign.com", "adobesign.com", "echosign.com", "box.com",
    "dropbox.com", "wetransfer.com", "we.tl", "icloud.com", "apple.com", "amazon.com", "paypal.com",
    "ebay.com", "booking.com", "airbnb.com", "tripadvisor.com", "expedia.com", "uber.com",
    "spotify.com", "netflix.com", "github.com", "gitlab.com", "bitbucket.org", "trello.com",
    "asana.com", "monday.com", "clickup.com", "zoom.us", "webex.com", "gotomeeting.com",
    "microsoft.com", "office.com", "office365.com", "live.com", "sharepoint.com", "onedrive.com",
    "azure.net", "windows.net", "emails.azure.net", "customer.io", "userlist.com", "loops.so",
    "resend.com", "resend.dev", "plunk.com", "bentonow.com", "drip.com", "dripemail2.com",
    "ontraport.com", "infusionsoft.com", "keap.com", "kajabi.com", "kajabimail.net", "teachable.com",
    "thinkific.com", "gumroad.com", "patreon.com", "ghost.io", "buttondown.email", "revue.email",
    "tinyletter.com", "sailthru.com", "listrak.com", "bronto.com", "cordial.io", "attentive.com",
    "postscript.io", "yotpo.com", "trustpilot.com", "delighted.com", "qualtrics.com", "medallia.com",
    "digidip.net", "awin1.com", "tradedoubler.com", "adtraction.com", "partner-ads.com", "pjatr.com",
    "anrdoezrs.net", "jdoqocy.com", "tkqlhce.com", "dpbolvw.net", "kqzyfj.com", "linksynergy.com",
    "shareasale.com", "impact.com", "sjv.io", "pxf.io", "evyy.net", "go2cloud.org", "ojrq.net",
}

# redirectors whose query string carries the real destination
_REDIRECT_PARAMS = ("url", "u", "q", "adurl", "destination", "dest", "redirect", "redirect_url",
                    "redirect_uri", "redir", "r", "target", "to", "link", "goto", "next", "continue",
                    "returnurl", "return_url", "return", "rurl", "out", "href", "location", "ref_url",
                    "a", "l", "ru", "tu", "desturl", "targeturl", "forward", "site", "view")


# ------------------------------------------------------------------ hosts
def split_url(url: str):
    """urlsplit that tolerates scheme-less ('www.x.com/a') and sloppy input."""
    u = (url or "").strip()
    if u.startswith("//"):
        u = "http:" + u
    elif "://" not in u[:12]:
        u = "http://" + u
    try:
        return urlsplit(u)
    except Exception:
        return None


def host_of(url: str) -> str:
    """Lower-cased hostname without port / userinfo ('' when unparsable)."""
    p = split_url(url)
    if p is None:
        return ""
    try:
        return (p.hostname or "").lower().strip(".")
    except Exception:
        return ""


def domain_of(url: str) -> str:
    """Backward-compatible name used across the code base."""
    return host_of(url)


def tld_of(host: str) -> str:
    return host.rsplit(".", 1)[-1] if "." in host else ""


def _public_suffix_len(parts: list[str]) -> int:
    """Number of labels in the public suffix (approximation, no PSL file)."""
    if len(parts) >= 3 and parts[-2] in _SECOND_LEVEL and len(parts[-1]) == 2:
        return 2
    return 1


def registrable_domain(host_or_addr: str) -> str:
    """Approximate eTLD+1: mail.footshop.eu -> footshop.eu, reply.ebay.co.uk ->
    ebay.co.uk. Tenants of shared platforms keep their own identity:
    evil.pages.dev -> evil.pages.dev (not pages.dev)."""
    h = (host_or_addr or "").lower().strip().split("@")[-1].split(":")[0].strip(".>< \"'")
    parts = [p for p in h.split(".") if p]
    if len(parts) <= 2:
        return ".".join(parts)
    for n in range(min(_MAX_PLATFORM_LABELS, len(parts) - 1), 1, -1):
        if ".".join(parts[-n:]) in PLATFORM_SUFFIXES:
            return ".".join(parts[-(n + 1):])
    n = _public_suffix_len(parts)
    return ".".join(parts[-(n + 1):])


def platform_of(host: str) -> str | None:
    """The shared platform a host lives on ('pages.dev'), or None."""
    parts = [p for p in (host or "").lower().split(".") if p]
    for n in range(min(_MAX_PLATFORM_LABELS, len(parts)), 1, -1):
        suf = ".".join(parts[-n:])
        if suf in PLATFORM_SUFFIXES:
            return suf
    return None


def sld_of(host: str) -> str:
    """Second-level label of the registrable domain: mail.paypal.co.uk -> 'paypal'."""
    reg = registrable_domain(host)
    return reg.split(".")[0] if reg else ""


def is_ip_host(host: str) -> bool:
    """IPv4 in any spelling browsers accept (dotted, decimal, hex, octal) or IPv6."""
    h = (host or "").strip("[]")
    if not h:
        return False
    try:
        ipaddress.ip_address(h)
        return True
    except ValueError:
        pass
    if re.fullmatch(r"\d{1,3}(\.\d{1,3}){3}", h):
        return True
    if re.fullmatch(r"\d{8,10}", h):                         # 3232235777
        return int(h) <= 0xFFFFFFFF
    if re.fullmatch(r"0x[0-9a-f]{1,8}", h):                  # 0xC0A80101
        return True
    if re.fullmatch(r"(0x[0-9a-f]{1,2}|0[0-7]{1,3}|\d{1,3})(\.(0x[0-9a-f]{1,2}|0[0-7]{1,3}|\d{1,3})){3}", h) \
            and re.search(r"0x|(^|\.)0\d", h):               # 0xC0.0xA8.1.1 / 0300.0250.1.1
        return True
    return False


def decode_idna(host: str) -> str:
    """xn-- labels -> unicode (best effort)."""
    out = []
    for label in (host or "").split("."):
        if label.startswith("xn--"):
            try:
                label = label[4:].encode("ascii").decode("punycode")
            except Exception:
                pass
        out.append(label)
    return ".".join(out)


# ------------------------------------------------------------------ look-alikes
_CONFUSABLE = {
    # Cyrillic
    "а": "a", "е": "e", "о": "o", "р": "p", "с": "c", "у": "y", "х": "x", "і": "i", "ј": "j",
    "ѕ": "s", "һ": "h", "ԁ": "d", "ԛ": "q", "ԝ": "w", "в": "b", "к": "k", "м": "m", "н": "h",
    "т": "t", "г": "r", "п": "n", "ё": "e", "ӏ": "l", "ь": "b", "з": "3", "ү": "y", "є": "e",
    # Greek
    "α": "a", "ο": "o", "ρ": "p", "ε": "e", "ν": "v", "τ": "t", "ι": "i", "κ": "k", "υ": "u",
    "χ": "x", "η": "n", "μ": "u", "ω": "w", "β": "b", "γ": "y",
    # misc
    "ı": "i", "ɑ": "a", "ɡ": "g", "ⅼ": "l", "ｏ": "o", "ℓ": "l", "ƅ": "b", "ʀ": "r", "ᴏ": "o",
}
_LEET = {"0": "o", "1": "l", "3": "e", "4": "a", "5": "s", "7": "t", "8": "b", "9": "g",
         "@": "a", "$": "s", "!": "l", "|": "l"}


def fold_confusables(text: str) -> str:
    """Map look-alike letters of other scripts to Latin and strip accents:
    'pаypal' (Cyrillic а) -> 'paypal', 'verífy' -> 'verify'."""
    if not text:
        return ""
    t = "".join(_CONFUSABLE.get(ch, ch) for ch in text)
    t = unicodedata.normalize("NFKD", t)
    return "".join(ch for ch in t if not unicodedata.combining(ch))


# Serbian/Macedonian/Bulgarian/Russian Cyrillic -> Latin (for words written
# ENTIRELY in Cyrillic: that is language, not disguise)
_CYR2LAT = {
    "а": "a", "б": "b", "в": "v", "г": "g", "д": "d", "ђ": "dj", "е": "e", "ж": "z", "з": "z",
    "и": "i", "ј": "j", "к": "k", "л": "l", "љ": "lj", "м": "m", "н": "n", "њ": "nj", "о": "o",
    "п": "p", "р": "r", "с": "s", "т": "t", "ћ": "c", "у": "u", "ф": "f", "х": "h", "ц": "c",
    "ч": "c", "џ": "dz", "ш": "s", "й": "j", "ъ": "", "ы": "y", "ь": "", "э": "e", "ю": "ju",
    "я": "ja", "щ": "sc", "ё": "e", "ѓ": "g", "ќ": "k", "ѕ": "dz", "і": "i", "ї": "ji", "є": "je",
    "ґ": "g",
}
_HAS_CYR_OR_GREEK = re.compile(r"[\u0370-\u03ff\u0400-\u052f]")
# whole words, matched in ONE linear pass (a pattern like  \w*[cyrillic]\w*  would be
# quadratic on a long run of Latin letters - an easy way to stall the scanner)
_WORD_RE = re.compile(r"[^\W\d_]+")


def _fold_word(m: re.Match) -> str:
    w = m.group(0)
    if not _HAS_CYR_OR_GREEK.search(w):
        return w
    s = scripts_in(w)
    if s == {"cyrillic"}:
        return "".join(_CYR2LAT.get(ch, ch) for ch in w)       # transliterate real language
    return "".join(_CONFUSABLE.get(ch, ch) for ch in w)        # mixed word: undo the disguise


def fold_for_matching(text: str) -> str:
    """Canonical lower-case form used by the text patterns AND the ML model:
    * words fully in Cyrillic are transliterated ('хитно' -> 'hitno'),
    * words that MIX alphabets get their look-alikes mapped back ('Pаypal' -> 'paypal'),
    * accents are stripped ('plaćanje' -> 'placanje', 'lösenord' -> 'losenord')."""
    t = (text or "").lower()
    if _HAS_CYR_OR_GREEK.search(t):
        t = _WORD_RE.sub(_fold_word, t)
    t = t.replace("đ", "dj").replace("ß", "ss").replace("ø", "o").replace("æ", "ae").replace("ł", "l")
    t = unicodedata.normalize("NFKD", t)
    return "".join(ch for ch in t if not unicodedata.combining(ch))


def skeleton(token: str) -> str:
    """Canonical form in which look-alike spellings collide:
    paypa1 / paypaI / pаypal -> 'paypal'; rnicrosoft / micr0soft -> 'mlcrosoft'
    (both sides of a comparison must be skeletonized)."""
    t = fold_confusables((token or "").lower())
    t = "".join(_LEET.get(ch, ch) for ch in t)
    t = t.replace("rn", "m").replace("vv", "w").replace("cl", "d")
    t = t.replace("i", "l")
    return re.sub(r"(.)\1+", r"\1", t)      # paypall -> paypal, gooogle -> gogle


def scripts_in(text: str) -> set[str]:
    """Scripts used by the LETTERS of a string."""
    out = set()
    for ch in text or "":
        if not ch.isalpha():
            continue
        o = ord(ch)
        if o < 0x250 or 0x1E00 <= o <= 0x1EFF or 0xFF21 <= o <= 0xFF5A:
            out.add("latin")
        elif 0x370 <= o <= 0x3FF or 0x1F00 <= o <= 0x1FFF:
            out.add("greek")
        elif 0x400 <= o <= 0x52F:
            out.add("cyrillic")
        else:
            out.add("other")
    return out


def mixed_script_words(text: str, limit: int = 2000) -> list[str]:
    """Words that mix Latin with Cyrillic/Greek letters - nobody types those by
    accident; it is how 'Pаypal' slips past keyword filters."""
    out = []
    for w in re.findall(r"[^\W\d_]{4,}", (text or "")[:20000]):
        s = scripts_in(w)
        if "latin" in s and (("cyrillic" in s) or ("greek" in s)):
            out.append(w)
            if len(out) >= limit:
                break
    return out


def edit_distance_le1(a: str, b: str) -> bool:
    """True when a and b differ by at most one insert/delete/substitute/transpose."""
    if a == b:
        return True
    la, lb = len(a), len(b)
    if abs(la - lb) > 1:
        return False
    if la == lb:
        diff = [i for i in range(la) if a[i] != b[i]]
        if len(diff) == 1:
            return True
        return len(diff) == 2 and diff[1] == diff[0] + 1 and a[diff[0]] == b[diff[1]] \
            and a[diff[1]] == b[diff[0]]
    if la > lb:
        a, b, la, lb = b, a, lb, la
    i = j = 0
    skipped = False
    while i < la and j < lb:
        if a[i] == b[j]:
            i += 1
            j += 1
        elif skipped:
            return False
        else:
            skipped = True
            j += 1
    return True


# ------------------------------------------------------------------ redirect unwrapping
def _looks_like_url(v: str) -> bool:
    return bool(re.match(r"(?i)^https?://[^\s/]+\.[a-z0-9-]{2,}", v or ""))


def unwrap_redirect(url: str, max_depth: int = 3) -> str | None:
    """If `url` is a redirector / link-rewriter carrying its destination in the
    URL, return that destination (None otherwise). Nothing is fetched."""
    cur = url
    found = None
    for _ in range(max_depth):
        nxt = _unwrap_once(cur)
        if not nxt or nxt == cur:
            break
        found, cur = nxt, nxt
    return found


def _unwrap_once(url: str) -> str | None:
    url = (url or "")[:4096]
    p = split_url(url)
    if p is None:
        return None
    try:
        host = (p.hostname or "").lower()
    except Exception:
        return None
    path, query = p.path or "", p.query or ""

    # Proofpoint URL Defense v3: /v3/__https://target__;!!...
    if host.endswith("urldefense.com") or host.endswith("urldefense.proofpoint.com"):
        m = re.search(r"/v3/__(.+?)__;", url)
        if m:
            return m.group(1)
        qs = dict(parse_qsl(query, keep_blank_values=True))
        if "u" in qs:                                  # v2: -3A -> %3A, _ -> /
            v = re.sub(r"-([0-9A-Fa-f]{2})", r"%\1", qs["u"]).replace("_", "/")
            v = unquote(v)
            return v if _looks_like_url(v) else None
    # Google AMP / cache: google.com/amp/s/evil.com/x
    if "google." in host and path.startswith(("/amp/s/", "/amp/")):
        rest = path.split("/amp/", 1)[1]
        rest = rest[2:] if rest.startswith("s/") else rest
        cand = "https://" + rest
        return cand if _looks_like_url(cand) else None
    # Google Translate proxy: evil-example-com.translate.goog
    if host.endswith(".translate.goog"):
        label = host[: -len(".translate.goog")]
        cand = "https://" + label.replace("--", "\x00").replace("-", ".").replace("\x00", "-") + path
        return cand if _looks_like_url(cand) else None
    # Bing click: u=a1<base64url>
    if host.endswith("bing.com") and path.startswith("/ck/"):
        qs = dict(parse_qsl(query))
        v = qs.get("u", "")
        if v.startswith("a1"):
            try:
                raw = v[2:] + "=" * (-len(v[2:]) % 4)
                dec = base64.urlsafe_b64decode(raw).decode("utf-8", "ignore")
                return dec if _looks_like_url(dec) else None
            except Exception:
                return None
    # generic: a query parameter that is itself an absolute URL
    for key, val in parse_qsl(query, keep_blank_values=False):
        if key.lower() in _REDIRECT_PARAMS:
            v = val.strip()
            for _ in range(2):
                if _looks_like_url(v):
                    return v
                v = unquote(v)
            # base64-encoded destination (common in kit redirect chains)
            if len(v) >= 16 and re.fullmatch(r"[A-Za-z0-9+/_=-]+", v):
                try:
                    dec = base64.urlsafe_b64decode(v + "=" * (-len(v) % 4)).decode("utf-8", "ignore")
                    if _looks_like_url(dec):
                        return dec
                except Exception:
                    pass
    # destination glued into the path: /redirect/https://target or /r/?https://target
    m = re.search(r"(?i)[/=?](https?(?::|%3A)(?://|%2F%2F)[^\s]+)$", path + ("?" + query if query else ""))
    if m:
        v = unquote(m.group(1))
        if _looks_like_url(v) and host_of(v) != host:
            return v
    return None
