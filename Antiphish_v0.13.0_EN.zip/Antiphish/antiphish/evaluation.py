"""Honest evaluation of the text model and of the WHOLE detector.

    python evaluate.py              text model: held-out protocol + probe sets
    python evaluate.py --e2e        + full pipeline on held-out RAW mail (needs data/raw)
    python evaluate.py --json out.json

Protocol (nothing in a test slice is ever trained on)
-----------------------------------------------------
phishing   train: Nazario 2004-2023          test: Nazario 2024-2025 (newer campaigns)
                                             test: phishing_pot (another collector; optional)
legit      SpamAssassin  80 % / 20 % by content hash
           Enron         mailboxes are split: test mailboxes are never seen in training
           Apache lists  whole lists are held out
probe sets hand-written modern mail (eval_sets.py), EN / Bosnian-Croatian-Serbian / Swedish

What v0.9 reported, and why it was optimistic
---------------------------------------------
* "91 % of 2024-2025 phishing caught" was the text model at p >= 0.5, not the
  score a user sees. Measured through the real pipeline, 27 % of that mail was
  rated LOW.
* the model had learned the corpus owner's own address (see model.scrub_recipient),
  which the test mail shares.
* the legitimate test mail came from the same 2002 archive as the training mail.

The production model (train.py) is fitted on ALL data; the numbers printed here
come from the protocol model above and are therefore a fair estimate of it.
"""
from __future__ import annotations

import collections
import csv
import gzip
import hashlib
import json
import mailbox
import os
import random
import tarfile
import time

import numpy as np

from .config import DATA_DIR

TEST_ENRON_FRACTION = 5          # 1 mailbox in 5 is held out
TEST_LISTS = {"users@kafka.apache.org", "users@subversion.apache.org", "users@maven.apache.org"}
TEMPORAL_TEST_FROM = 2024


def _h(s: str) -> int:
    return int(hashlib.sha1(s.encode("utf-8", "ignore")).hexdigest(), 16)


def is_test_row(source: str, year: int, group: str, text: str) -> str | None:
    """-> name of the test slice this corpus row belongs to, or None for training."""
    if source == "nazario":
        return "phish_nazario_2024_25" if year >= TEMPORAL_TEST_FROM else None
    if source == "nazario_legacy":
        return None
    if source == "spamassassin":
        return "legit_spamassassin" if _h(text[:2000]) % 5 == 0 else None
    if source == "enron":
        return "legit_enron_new_mailboxes" if _h(group) % TEST_ENRON_FRACTION == 0 else None
    if source == "apache_lists":
        return "legit_lists_new_lists" if group in TEST_LISTS else None
    return None


def read_corpus(path: str | None = None) -> list[tuple]:
    from .model import CORPUS_PATH
    path = os.path.abspath(path or CORPUS_PATH)
    rows = []
    if not os.path.exists(path):
        return rows
    csv.field_size_limit(10_000_000)
    with open(path, newline="", encoding="utf-8") as f:
        for r in csv.reader(f):
            if len(r) < 2 or r[0] == "text":
                continue
            try:
                label = int(r[1])
            except ValueError:
                continue
            rows.append((r[0], label, r[2] if len(r) > 2 else "?",
                         int(r[3]) if len(r) > 3 and r[3].lstrip("-").isdigit() else 0,
                         r[4] if len(r) > 4 else ""))
    return rows


def protocol_split(rows: list[tuple]):
    train, test = [], collections.defaultdict(list)
    for t, label, src, year, group in rows:
        slice_name = is_test_row(src, year, group, t)
        if slice_name:
            test[slice_name].append((t, label))
        else:
            train.append((t, label, src))
    return train, dict(test)


# ------------------------------------------------------------------ metrics
def ece(y, p, bins: int = 10) -> float:
    y, p = np.asarray(y, dtype=float), np.asarray(p, dtype=float)
    edges = np.linspace(0, 1, bins + 1)
    tot = 0.0
    for lo, hi in zip(edges[:-1], edges[1:]):
        m = (p >= lo) & ((p < hi) if hi < 1 else (p <= hi))
        if m.any():
            tot += m.mean() * abs(y[m].mean() - p[m].mean())
    return float(tot)


def threshold_at_fpr(p_neg, target: float) -> float:
    """Smallest threshold whose false-positive rate on p_neg is <= target."""
    neg = np.sort(np.asarray(p_neg))[::-1]
    k = int(np.floor(target * len(neg)))
    return float(neg[k]) if k < len(neg) else 0.0


def wilson(k: int, n: int, z: float = 1.96) -> tuple[float, float]:
    """95 % Wilson interval for a proportion - small probe sets need error bars."""
    if n == 0:
        return (0.0, 1.0)
    ph = k / n
    den = 1 + z * z / n
    mid = (ph + z * z / (2 * n)) / den
    half = z * ((ph * (1 - ph) / n + z * z / (4 * n * n)) ** 0.5) / den
    return (max(0.0, mid - half), min(1.0, mid + half))


def fit_protocol_model(rows=None, verbose: bool = True):
    """Train the pipeline on the protocol TRAIN split (+ starter/synthetic)."""
    from .model import balance_corpus, build_pipeline, eval_training_extras
    rows = read_corpus() if rows is None else rows
    train, test = protocol_split(rows)
    train = balance_corpus(train, verbose=False)       # same class-balance guard as production
    cache = os.getenv("PROTOCOL_MODEL_CACHE", "")       # speeds up repeated runs while tuning rules
    if cache and os.path.exists(cache):
        import joblib
        if verbose:
            print(f"protocol model: loaded from {cache}")
        return joblib.load(cache), train, test
    ex_t, ex_y = eval_training_extras()
    X = [r[0] for r in train] + list(ex_t)
    y = np.array([r[1] for r in train] + [int(v) for v in ex_y])
    pipe = build_pipeline()
    t0 = time.time()
    pipe.fit(X, y)
    if verbose:
        print(f"protocol model: trained on {len(X)} texts "
              f"({int((y == 1).sum())} phishing / {int((y == 0).sum())} legit) in {time.time() - t0:.0f}s")
    if cache:
        import joblib
        joblib.dump(pipe, cache)
    return pipe, train, test


def evaluate_text_model(verbose: bool = True, pipe=None, rows=None) -> dict:
    from sklearn.metrics import average_precision_score, brier_score_loss, roc_auc_score

    from . import eval_sets
    rows = read_corpus() if rows is None else rows
    if not rows:
        print("data/corpus.csv missing - run: python scripts/build_corpus.py")
        return {}
    if pipe is None:
        pipe, _train, test = fit_protocol_model(rows, verbose)
    else:
        _train, test = protocol_split(rows)

    res: dict = {"slices": {}, "probes": {}}
    all_y, all_p = [], []
    for name, items in sorted(test.items()):
        p = pipe.predict_proba([t for t, _ in items])[:, 1]
        y = np.array([lab for _, lab in items])
        all_y += list(y)
        all_p += list(p)
        res["slices"][name] = {"n": len(items), "label": int(y[0]),
                               "rate@0.5": float((p >= 0.5).mean()), "mean_prob": float(p.mean())}
    all_y, all_p = np.array(all_y), np.array(all_p)

    # optional cross-collector phishing set (CC BY-NC, evaluation only)
    pot_path = os.path.join(DATA_DIR, "eval_phishing_pot.csv")
    pot = [r for r in read_corpus(pot_path)] if os.path.exists(pot_path) else []
    pot_p = None
    if pot:
        pot_p = pipe.predict_proba([r[0] for r in pot])[:, 1]
        res["slices"]["phish_phishing_pot"] = {"n": len(pot), "label": 1,
                                               "rate@0.5": float((pot_p >= 0.5).mean()),
                                               "mean_prob": float(pot_p.mean())}
        by_year = collections.defaultdict(list)
        for r, pv in zip(pot, pot_p):
            by_year[r[3]].append(pv)
        res["phishing_pot_by_year"] = {str(y): {"n": len(v), "rate@0.5": float((np.array(v) >= 0.5).mean())}
                                       for y, v in sorted(by_year.items()) if len(v) >= 30}

    neg = all_p[all_y == 0]
    pos = all_p[all_y == 1]
    thr1 = threshold_at_fpr(neg, 0.01)
    res["pooled"] = {
        "n_phish": int(len(pos)), "n_legit": int(len(neg)),
        "roc_auc": float(roc_auc_score(all_y, all_p)), "pr_auc": float(average_precision_score(all_y, all_p)),
        "recall@0.5": float((pos >= 0.5).mean()), "fpr@0.5": float((neg >= 0.5).mean()),
        "threshold@fpr1%": thr1, "recall@fpr1%": float((pos > thr1).mean()),
        "brier": float(brier_score_loss(all_y, all_p)), "ece": ece(all_y, all_p)}
    if pot_p is not None:
        res["pooled"]["phishing_pot_recall@fpr1%"] = float((pot_p > thr1).mean())

    for name, (texts, label) in eval_sets.all_probe_sets().items():
        p = pipe.predict_proba(list(texts))[:, 1]
        k = int((p >= 0.5).sum())
        lo, hi = wilson(k, len(texts))
        res["probes"][name] = {"n": len(texts), "label": label, "rate@0.5": k / len(texts),
                               "ci95": [round(lo, 3), round(hi, 3)], "mean_prob": float(p.mean()),
                               "worst": _worst(texts, p, label)}
    if verbose:
        print_text_report(res)
    return res


def _worst(texts, p, label, k: int = 4):
    order = np.argsort(-p) if label == 0 else np.argsort(p)
    return [[round(float(p[i]), 2), texts[i][:70].replace("\n", " / ")] for i in order[:k]]


def print_text_report(res: dict):
    print("\nTEXT MODEL - held-out slices  (phishing: share caught at p>=0.5 | legit: share falsely flagged)")
    for name, s in res["slices"].items():
        kind = "caught " if s["label"] == 1 else "flagged"
        print(f"  {name:30s} n={s['n']:5d}  {kind} {s['rate@0.5']:6.1%}   mean p={s['mean_prob']:.3f}")
    pl = res["pooled"]
    print(f"  pooled: ROC-AUC {pl['roc_auc']:.4f} | PR-AUC {pl['pr_auc']:.4f} | recall@0.5 {pl['recall@0.5']:.1%} "
          f"at FPR {pl['fpr@0.5']:.2%} | recall at 1% FPR {pl['recall@fpr1%']:.1%} | Brier {pl['brier']:.3f} | ECE {pl['ece']:.3f}")
    if "phishing_pot_by_year" in res:
        print("  phishing_pot by year:", {y: f"{v['rate@0.5']:.0%} (n={v['n']})" for y, v in res["phishing_pot_by_year"].items()})
    print("\nPROBE SETS (hand-written, never trained on) - small: read the 95% interval, not the point")
    for name, s in res["probes"].items():
        kind = "caught " if s["label"] == 1 else "flagged"
        print(f"  {name:26s} n={s['n']:3d}  {kind} {s['rate@0.5']:6.1%}  CI95 [{s['ci95'][0]:.0%}, {s['ci95'][1]:.0%}]"
              f"   mean p={s['mean_prob']:.2f}")
        for pv, txt in s["worst"][:3]:
            bad = (pv >= 0.5) if s["label"] == 0 else (pv < 0.5)
            if bad:
                print(f"       {'FALSE ALARM' if s['label'] == 0 else 'MISSED':11s} p={pv:.2f}  {txt!r}")


# ------------------------------------------------------------------ end-to-end (raw mail)
def _raw_dir() -> str:
    return os.getenv("CORPUS_RAW_DIR", os.path.join(DATA_DIR, "raw"))


def iter_raw_test_messages(max_per_slice: int = 0, seed: int = 7):
    """(slice, raw bytes) for every held-out RAW message available in data/raw."""
    from .email_parser import message_from_bytes_robust, parse_message  # noqa: F401
    raw_dir = _raw_dir()
    rng = random.Random(seed)
    slices: dict[str, list[bytes]] = collections.defaultdict(list)

    for y in (2024, 2025):
        p = os.path.join(raw_dir, f"nazario-{y}.mbox")
        if os.path.exists(p):
            for raw in mailbox.mbox(p, factory=lambda f: f.read()):
                slices["phish_nazario_2024_25"].append(raw)
    for name in ("20030228_easy_ham", "20030228_easy_ham_2", "20030228_hard_ham"):
        p = os.path.join(raw_dir, f"{name}.tar.bz2")
        if not os.path.exists(p):
            continue
        with tarfile.open(p, "r:bz2") as tf:
            for m in tf.getmembers():
                if m.isfile() and not m.name.endswith("cmds"):
                    slices["_sa_all"].append(tf.extractfile(m).read())
    p = os.path.join(raw_dir, "enron_subset.jsonl.gz")
    if os.path.exists(p):
        with gzip.open(p, "rt", encoding="utf-8") as f:
            for line in f:
                rec = json.loads(line)
                if _h(rec["user"]) % TEST_ENRON_FRACTION == 0:
                    slices["legit_enron_new_mailboxes"].append(rec["raw"].encode("latin-1"))
    for fn in sorted(os.listdir(raw_dir)) if os.path.isdir(raw_dir) else []:
        if fn.startswith("list-") and fn.endswith(".mbox"):
            lst = fn[5:].rsplit("-", 2)[0].replace("_at_", "@")
            if lst in TEST_LISTS:
                for raw in mailbox.mbox(os.path.join(raw_dir, fn), factory=lambda f: f.read()):
                    slices["legit_lists_new_lists"].append(raw)
    p = os.path.join(raw_dir, "phishing_pot.zip")
    if os.path.exists(p):
        import zipfile
        with zipfile.ZipFile(p) as z:
            names = sorted(n for n in z.namelist() if n.endswith(".eml"))
            rng.shuffle(names)
            for n in names[: (max_per_slice or 1500)]:
                slices["phish_phishing_pot"].append(z.read(n))

    # SpamAssassin: the split is decided on the PARSED text, exactly like the corpus
    return slices, rng


def collect_e2e_test_set(max_per_slice: int = 0) -> dict:
    """slice name -> list of raw messages that evaluate_e2e() scores.
    (Also used to run OTHER versions of the detector on exactly the same mail.)"""
    import sys

    from .email_parser import message_from_bytes_robust
    sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "scripts"))
    from build_corpus import _text as corpus_text  # the exact training-text builder

    slices, rng = iter_raw_test_messages(max_per_slice)
    out: dict[str, list[bytes]] = {}
    for name in sorted(slices):
        raws = slices[name]
        if max_per_slice and len(raws) > max_per_slice:
            raws = rng.sample(raws, max_per_slice)
        if name == "_sa_all":
            keep = []
            for raw in raws:
                try:
                    t = corpus_text(message_from_bytes_robust(raw))
                except Exception:
                    continue
                if len(t) > 40 and _h(t[:2000]) % 5 == 0:      # held-out fifth only
                    keep.append(raw)
            name, raws = "legit_spamassassin", keep
        out[name] = raws
    return dict(sorted(out.items()))


def evaluate_e2e(pipe=None, verbose: bool = True, max_per_slice: int = 0, dump: str = "") -> dict:
    """Run parse -> analyze_email on held-out raw mail with the protocol model."""
    from . import config, detector
    from .email_parser import message_from_bytes_robust, parse_message

    if pipe is None:
        pipe, _tr, _te = fit_protocol_model(verbose=verbose)
    test_set = collect_e2e_test_set(max_per_slice)
    if not any(test_set.values()):
        print(f"no raw mail in {_raw_dir()} - run: python scripts/build_corpus.py")
        return {}
    old_model, old_sandbox = detector._model, config.ATTACHMENT_SANDBOX
    detector._model, config.ATTACHMENT_SANDBOX = pipe, False
    res: dict = {"slices": {}}
    records = []
    try:
        for name, raws in test_set.items():
            label = 1 if name.startswith("phish") else 0
            levels = collections.Counter()
            sig_freq = collections.Counter()
            errors = 0
            for raw in raws:
                try:
                    parsed = parse_message(message_from_bytes_robust(raw))
                    r = detector.analyze_email(parsed, use_url_intel=False, use_llm=False)
                except Exception as e:                # count, never hide
                    errors += 1
                    levels["ERROR"] += 1
                    records.append({"slice": name, "error": f"{type(e).__name__}: {e}"[:200]})
                    continue
                levels[r["level"]] += 1
                for s in r["signals"]:
                    sig_freq[s["signal"]] += 1
                records.append({"slice": name, "score": r["score"], "level": r["level"],
                                "ml": r["ml_phishing_probability"],
                                "subject": (parsed.get("subject") or "")[:90],
                                "sender": (parsed.get("sender") or "")[:70],
                                "n_urls": len(r.get("urls_found") or []),
                                "signals": [f"{s['signal']}:{s['weight']}" for s in r["signals"]]})
            tot = sum(levels.values()) or 1
            d = {k: levels.get(k, 0) / tot for k in ("LOW", "SUSPICIOUS", "HIGH", "CRITICAL", "ERROR")}
            res["slices"][name] = {"n": tot, "label": label, "levels": {k: round(v, 4) for k, v in d.items()},
                                   "HIGH+": round(d["HIGH"] + d["CRITICAL"], 4),
                                   "SUSPICIOUS+": round(d["SUSPICIOUS"] + d["HIGH"] + d["CRITICAL"], 4),
                                   "errors": errors, "top_signals": sig_freq.most_common(14)}
    finally:
        detector._model, config.ATTACHMENT_SANDBOX = old_model, old_sandbox
    if dump:
        with open(dump, "w", encoding="utf-8") as f:
            for r in records:
                f.write(json.dumps(r, ensure_ascii=False) + "\n")
    if verbose:
        print_e2e_report(res)
    return res


def print_e2e_report(res: dict):
    print("\nFULL DETECTOR on held-out raw mail (the score a user actually sees)")
    print(f"  {'slice':30s} {'n':>5s}  {'LOW':>6s} {'SUSP':>6s} {'HIGH':>6s} {'CRIT':>6s}   headline")
    for name, s in res["slices"].items():
        lv = s["levels"]
        head = (f"caught (HIGH+) {s['HIGH+']:.1%}, missed as LOW {lv['LOW']:.1%}" if s["label"] == 1
                else f"false alarms: SUSPICIOUS+ {s['SUSPICIOUS+']:.1%}, HIGH+ {s['HIGH+']:.1%}")
        print(f"  {name:30s} {s['n']:5d}  {lv['LOW']:6.1%} {lv['SUSPICIOUS']:6.1%} {lv['HIGH']:6.1%} "
              f"{lv['CRITICAL']:6.1%}   {head}" + (f"  [{s['errors']} errors]" if s["errors"] else ""))


def main(argv=None):
    import sys
    argv = sys.argv[1:] if argv is None else argv
    out = {}
    pipe, _tr, _te = fit_protocol_model()
    out["text_model"] = evaluate_text_model(pipe=pipe)
    if "--e2e" in argv:
        n = 0
        if "--max" in argv:
            n = int(argv[argv.index("--max") + 1])
        out["e2e"] = evaluate_e2e(pipe=pipe, max_per_slice=n,
                                  dump=argv[argv.index("--dump") + 1] if "--dump" in argv else "")
    from .scenarios import run_scenarios
    out["scenarios"] = run_scenarios(pipe=pipe, verbose=True)
    if "--json" in argv:
        path = argv[argv.index("--json") + 1]
        with open(path, "w", encoding="utf-8") as f:
            json.dump(out, f, indent=1, ensure_ascii=False)
        print("\nsaved", path)
    return out


if __name__ == "__main__":
    main()
