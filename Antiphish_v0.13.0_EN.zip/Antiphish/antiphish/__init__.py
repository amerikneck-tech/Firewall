"""AntiPhish - AI-assisted phishing email detection MVP.

Combines:
  1. Heuristic signals (links, sender, authentication, recipient context, text, attachments)
  2. ML text classifier (TF-IDF word + character n-grams, calibrated linear model)
  3. optional LLM judge (Qwen)
into a single explainable 0-100 risk score.
"""

__version__ = "0.13.0"
