"""Central configuration: thresholds, weights, external API keys."""
from __future__ import annotations

import os


def _load_dotenv():
    """Load project-root .env file if present (no external dependency)."""
    path = os.path.join(os.path.dirname(__file__), "..", ".env")
    path = os.path.abspath(path)
    if not os.path.exists(path):
        return
    with open(path, encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line or line.startswith("#") or "=" not in line:
                continue
            key, _, value = line.partition("=")
            key, value = key.strip(), value.strip().strip('"').strip("'")
            os.environ.setdefault(key, value)


_load_dotenv()

# Risk levels
THRESHOLDS = {"SUSPICIOUS": 30, "HIGH": 60, "CRITICAL": 85}

# Scoring (see scorer.py): score = 100 * (1 - exp(-SCORE_K * evidence_points))
SCORE_K = float(os.getenv("SCORE_K", "0.035"))
# The text model contributes at most this many points when it is ~100% sure of
# phishing: alone it just reaches HIGH, never CRITICAL.
ML_MAX_POINTS = float(os.getenv("ML_MAX_POINTS", "28"))
# A pile of generic wording hints never counts for more than this.
SOFT_CAP = float(os.getenv("SOFT_CAP", "32"))
# Share of the context/soft evidence that still counts when the text model is
# sure the message is legitimate (rises linearly to 100% at p = 0.5).
SOFT_FLOOR = float(os.getenv("SOFT_FLOOR", "0.3"))

# External threat intel (set via environment variables or edit here)
VIRUSTOTAL_API_KEY = os.getenv("VT_API_KEY", "")
URLSCAN_API_KEY = os.getenv("URLSCAN_API_KEY", "")

# Freemail providers (legit for personal mail, suspicious for "IT dept").
# Single source of truth lives in domains.py; re-exported here for old imports.
from .domains import FREEMAIL_DOMAINS  # noqa: E402,F401

# --- Qwen LLM judge ---
# provider: "ollama" (local, free, default) or "dashscope" (Alibaba API)
QWEN_PROVIDER = os.getenv("QWEN_PROVIDER", "ollama")
QWEN_MODEL = os.getenv("QWEN_MODEL", "qwen2.5:7b")
QWEN_BASE_URL = os.getenv("QWEN_BASE_URL", "http://localhost:11434")
QWEN_API_KEY = os.getenv("DASHSCOPE_API_KEY", "")
# OpenAI-compatible endpoint of Alibaba Cloud Model Studio. API keys are bound to the
# region they were created in: a key from the international console (Singapore) needs
# DASHSCOPE_BASE_URL=https://dashscope-intl.aliyuncs.com/compatible-mode/v1
QWEN_API_BASE = os.getenv("DASHSCOPE_BASE_URL",
                          "https://dashscope.aliyuncs.com/compatible-mode/v1").rstrip("/")
LLM_TIMEOUT = int(os.getenv("LLM_TIMEOUT", "60"))

# --- Live inbox monitor (IMAP) ---
IMAP_HOST = os.getenv("IMAP_HOST", "")          # e.g. imap.gmail.com
IMAP_USER = os.getenv("IMAP_USER", "")
IMAP_PASSWORD = os.getenv("IMAP_PASSWORD", "")  # Gmail: app password!
POLL_SECONDS = int(os.getenv("POLL_SECONDS", "30"))
NOTIFY_MIN_LEVEL = "SUSPICIOUS"                 # kept for backward compat
# Alert only when risk score >= this (70 = HIGH and above). Override with env.
NOTIFY_MIN_SCORE = int(os.getenv("NOTIFY_MIN_SCORE", "70"))
# Set "1" to add Qwen LLM judgment to every scanned email (slower, smarter)
MONITOR_USE_LLM = os.getenv("MONITOR_USE_LLM", "0") == "1"

# --- Quarantine (move dangerous mail out of the inbox) ---
QUARANTINE_ENABLED = os.getenv("QUARANTINE", "1") == "1"
QUARANTINE_MIN_SCORE = int(os.getenv("QUARANTINE_MIN_SCORE", "90"))   # CRITICAL hard evidence
# ...and at least this many points of firm TECHNICAL evidence (firm-tier signals that are
# not text patterns and not the LLM's opinion). Since v0.10 wording plus the text model
# can lift a score above 90 on their own; moving mail out of the inbox automatically
# stays reserved for technical proof. 0 = score alone decides.
QUARANTINE_MIN_FIRM = int(os.getenv("QUARANTINE_MIN_FIRM", "40"))
QUARANTINE_FOLDER = os.getenv("QUARANTINE_FOLDER", "AntiPhish-Quarantine")
# On the very first start, also scan the newest N existing messages (0 = only new mail)
INITIAL_SCAN = int(os.getenv("INITIAL_SCAN", "20"))

# Scan attachments in an isolated worker process with timeout (recommended)
ATTACHMENT_SANDBOX = os.getenv("ATTACHMENT_SANDBOX", "1") == "1"

# --- Paths (override in Docker so data/models live on a persistent volume) ---
_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
DATA_DIR = os.getenv("DATA_DIR", os.path.join(_ROOT, "data"))
MODEL_PATH = os.getenv("ANTIPHISH_MODEL_PATH", os.path.join(_ROOT, "models", "model.joblib"))
