"""Structured HTML analysis for e-mail bodies (stdlib only).

v0.9 reduced HTML to text with a regex, which threw away every <a href> -
the place where real phishing keeps its link. This module walks the markup
once and returns what a mail client would show *and* what it would do:

    info = extract(html)
    info.text          text the reader sees
    info.hidden_text   text present in the markup but styled invisible
    info.links         [(href, anchor_text)]  clickable targets (a, area, VML buttons)
    info.forms         [{"action": ..., "password": bool, "inputs": n}]
    info.images        number of <img>
    info.data_images   [bytes] decoded data:image payloads (QR codes hide here)
    info.flags         set of structural observations ("script", "iframe", ...)

Nothing is fetched, rendered or executed.
"""
from __future__ import annotations

import base64
import binascii
import re
from dataclasses import dataclass, field
from html.parser import HTMLParser

# characters that render as nothing; used to split words so filters miss them
INVISIBLE_CHARS = "\u200b\u200c\u200d\u2060\ufeff\u00ad\u034f\u180e\u2061\u2062\u2063\u2064"
_INVISIBLE_RE = re.compile("[" + INVISIBLE_CHARS + "]")
_INVISIBLE_IN_WORD_RE = re.compile(r"(?<=\w)[" + INVISIBLE_CHARS + r"]+(?=\w)")

_SKIP_TAGS = {"script", "style", "head", "title", "noscript", "template", "svg", "math"}
_VOID_TAGS = {"area", "base", "br", "col", "embed", "hr", "img", "input", "link", "meta",
              "param", "source", "track", "wbr"}
_BLOCK_TAGS = {"p", "div", "br", "tr", "li", "h1", "h2", "h3", "h4", "h5", "h6", "table",
               "section", "article", "header", "footer", "blockquote", "td", "th", "ul", "ol",
               "center", "hr", "pre"}

_HIDDEN_STYLE_RE = re.compile(
    r"display\s*:\s*none|visibility\s*:\s*hidden|mso-hide\s*:\s*all|"
    r"(?<![-\w])opacity\s*:\s*0(?:\.0+)?\s*(?:;|$|!)|"
    r"font-size\s*:\s*0+(?:\.0+)?\s*(?:px|pt|em|rem|%)?\s*(?:;|$|!)|"
    r"max-height\s*:\s*0+(?:px)?\s*(?:;|$|!)|"
    r"(?<![-\w])(?:height|width)\s*:\s*0+(?:px)?\s*(?:;|$|!)[^\"']*overflow\s*:\s*hidden",
    re.I)

MAX_DATA_IMAGE_BYTES = 3 * 1024 * 1024
MAX_DATA_IMAGES = 6


@dataclass
class HtmlInfo:
    text: str = ""
    hidden_text: str = ""
    links: list = field(default_factory=list)       # [(href, anchor_text)]
    forms: list = field(default_factory=list)
    images: int = 0
    linked_images: int = 0                          # <a><img></a>
    data_images: list = field(default_factory=list)
    flags: set = field(default_factory=set)
    invisible_in_words: int = 0

    @property
    def urls(self) -> list:
        return [h for h, _ in self.links]


def strip_invisible(text: str) -> tuple[str, int]:
    """Remove zero-width / soft-hyphen characters.
    -> (clean text, how many sat INSIDE a word). Padding runs between spaces are
    normal in newsletters (pre-header filler) and are not counted."""
    if not text:
        return "", 0
    inside = len(_INVISIBLE_IN_WORD_RE.findall(text))
    return _INVISIBLE_RE.sub("", text), inside


class _Extractor(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.info = HtmlInfo()
        self._stack: list[tuple[str, bool, bool]] = []     # (tag, hidden, skip)
        self._visible: list[str] = []
        self._hidden: list[str] = []
        self._a_href: str | None = None
        self._a_text: list[str] = []
        self._a_has_img = False
        self._form: dict | None = None

    # -- state helpers
    def _is_hidden(self) -> bool:
        return any(h for _t, h, _s in self._stack)

    def _is_skipped(self) -> bool:
        return any(s for _t, _h, s in self._stack)

    def _emit(self, chunk: str):
        if not chunk:
            return
        (self._hidden if self._is_hidden() else self._visible).append(chunk)

    def _implicit_close(self, tag: str):
        """HTML closes <p>/<li>/<td>/<tr> implicitly. Without this an unclosed
        hidden cell would swallow the rest of the mail as 'hidden'."""
        if not self._stack:
            return
        top = self._stack[-1][0]
        if (tag == "p" and top == "p") or (tag == "li" and top == "li") \
                or (tag in ("td", "th") and top in ("td", "th")) \
                or (tag == "option" and top == "option"):
            self._stack.pop()
        elif tag == "tr":
            while self._stack and self._stack[-1][0] in ("td", "th", "tr"):
                self._stack.pop()

    def handle_comment(self, data):
        # Outlook-only markup lives in conditional comments (<!--[if mso]> ... <![endif]-->).
        # A link placed ONLY there is invisible to every scanner that skips comments.
        if "[if" in data[:40].lower():
            import html as _h
            for m in re.finditer(r"""(?is)\bhref\s*=\s*["']?([^"'\s>]+)""", data):
                self.info.links.append((_h.unescape(m.group(1)), ""))

    # -- tags
    def handle_starttag(self, tag, attrs):
        a = {k.lower(): (v or "") for k, v in attrs}
        style = a.get("style", "")
        # aria-hidden is deliberately NOT treated as hidden: it only hides from
        # screen readers, the text is still painted on screen
        hidden = bool(style and _HIDDEN_STYLE_RE.search(style)) or "hidden" in a
        skip = tag in _SKIP_TAGS
        self._implicit_close(tag)
        if tag in _BLOCK_TAGS:
            self._emit("\n")

        if tag == "a" or tag == "area" or tag.startswith("v:"):
            href = a.get("href", "").strip()
            if href:
                if tag == "a":
                    self._close_anchor()
                    self._a_href, self._a_text, self._a_has_img = href, [], False
                else:
                    self.info.links.append((href, a.get("alt", "") or a.get("title", "")))
        elif tag == "img":
            self.info.images += 1
            if self._a_href is not None:
                self._a_has_img = True
                alt = a.get("alt", "").strip()
                if alt:
                    self._a_text.append(alt)
            src = a.get("src", "").strip()
            if src[:11].lower() == "data:image/":
                self._data_image(src)
            elif src[:4].lower() == "cid:":
                self.info.flags.add("cid_image")
        elif tag == "form":
            self._form = {"action": a.get("action", "").strip(), "password": False, "inputs": 0}
            self.info.forms.append(self._form)
        elif tag == "input":
            t = a.get("type", "text").lower()
            if self._form is not None and t not in ("hidden", "submit", "button", "image"):
                self._form["inputs"] += 1
            if t == "password":
                self.info.flags.add("password_input")
                if self._form is not None:
                    self._form["password"] = True
        elif tag == "meta":
            if a.get("http-equiv", "").lower() == "refresh":
                m = re.search(r"url\s*=\s*['\"]?([^'\";\s>]+)", a.get("content", ""), re.I)
                if m:
                    self.info.flags.add("meta_refresh")
                    self.info.links.append((m.group(1), ""))
        elif tag == "base" and a.get("href"):
            self.info.flags.add("base_href")
        elif tag in ("iframe", "embed", "object"):
            self.info.flags.add("iframe")
            src = a.get("src") or a.get("data") or ""
            if src.strip().lower().startswith("http"):
                self.info.links.append((src.strip(), ""))
        elif tag == "script":
            self.info.flags.add("script")

        if any(k.startswith("on") and len(k) > 2 for k in a):
            self.info.flags.add("event_handler")
        if tag not in _VOID_TAGS:
            self._stack.append((tag, hidden, skip))

    def handle_startendtag(self, tag, attrs):
        self.handle_starttag(tag, attrs)
        if tag not in _VOID_TAGS and self._stack and self._stack[-1][0] == tag:
            self._stack.pop()

    def handle_endtag(self, tag):
        if tag == "a":
            self._close_anchor()
        elif tag == "form":
            self._form = None
        if tag in _BLOCK_TAGS:
            self._emit("\n")
        # pop to the matching open tag (tolerates the broken markup phishing kits produce)
        for i in range(len(self._stack) - 1, -1, -1):
            if self._stack[i][0] == tag:
                del self._stack[i:]
                break

    def handle_data(self, data):
        if self._is_skipped():
            return
        if self._a_href is not None and not self._is_hidden():
            self._a_text.append(data)
        self._emit(data)

    def _close_anchor(self):
        if self._a_href is None:
            return
        text = re.sub(r"\s+", " ", "".join(self._a_text)).strip()
        self.info.links.append((self._a_href, text))
        if self._a_has_img:
            self.info.linked_images += 1
        self._a_href, self._a_text, self._a_has_img = None, [], False

    def _data_image(self, src: str):
        if len(self.info.data_images) >= MAX_DATA_IMAGES:
            return
        head, _, payload = src.partition(",")
        if "base64" not in head.lower() or not payload:
            return
        if len(payload) > MAX_DATA_IMAGE_BYTES * 4 // 3:
            return
        try:
            self.info.data_images.append(base64.b64decode(payload, validate=False))
        except (binascii.Error, ValueError):
            pass

    def finish(self) -> HtmlInfo:
        self._close_anchor()
        vis, inside_v = strip_invisible("".join(self._visible))
        hid, _ = strip_invisible("".join(self._hidden))
        self.info.invisible_in_words = inside_v
        self.info.text = _squash(vis)
        self.info.hidden_text = _squash(hid)
        return self.info


def _squash(s: str) -> str:
    s = s.replace("\xa0", " ")
    s = re.sub(r"[ \t\r\f\v]+", " ", s)
    s = re.sub(r" ?\n ?", "\n", s)
    return re.sub(r"\n{2,}", "\n", s).strip()


def extract(html: str) -> HtmlInfo:
    """Parse an HTML body. Never raises: on a parser failure falls back to a
    regex strip so the caller always gets text."""
    p = _Extractor()
    try:
        p.feed(html or "")
        p.close()
        return p.finish()
    except Exception:
        info = p.info
        raw = re.sub(r"(?is)<(script|style|head|title)\b.*?</\1>", " ", html or "")
        import html as _h
        info.text = _squash(strip_invisible(_h.unescape(re.sub(r"(?s)<[^>]+>", " ", raw)))[0])
        for m in re.finditer(r"""(?is)<a\b[^>]*?href\s*=\s*["']?([^"'\s>]+)""", html or ""):
            info.links.append((_h.unescape(m.group(1)), ""))
        info.flags.add("malformed_html")
        return info


def html_to_text(html: str) -> str:
    """Visible text only (drop-in for the old regex helper)."""
    return extract(html).text
