"""Heuristic signal extraction: URLs, links, sender, authentication, recipient context.

Every check returns a list of signal dicts {"signal", "weight", "detail"} that
feed the scorer. Weights are "evidence points": ~10 = worth a second look,
~25-30 = one strong technical indicator (see scorer.py).

v0.10 rewrite - what changed and why (measured on the 2024-2025 Nazario mail):
* brands are matched through brands.py (official-domain registry, look-alike
  spellings) instead of raw substrings
* redirectors / link rewriters are unwrapped and the real target is checked
* trusted-platform abuse is recognised (IPFS gateways, pages.dev, r2.dev, ...)
* "the link text shows one site, the link opens another"
* authentication is judged by ALIGNMENT; a pass is no longer a strong
  legitimacy bonus (60% of the corpus phishing passes DMARC)
* recipient context: your own address in the subject, "IT Helpdesk" from a
  stranger's domain
"""
from __future__ import annotations

import ipaddress
import re

from .brands import (BRANDS, brand_claimed_by_display, brands_in_host, official_brand_of_host,
                     sender_is_official)
from .domains import SHORTENERS  # noqa: F401  (re-exported: v0.9 code imported it from here)
from .domains import (ANON_SHORTENERS, DYNAMIC_DNS, FREE_HOSTING, FREEMAIL_DOMAINS,
                      HIGH_ABUSE_TLDS, IPFS_GATEWAYS, KNOWN_TRACKERS, MIXED_TLDS, OBJECT_STORAGE,
                      TUNNELS, WILDCARD_DNS, decode_idna, domain_of, fold_confusables,
                      host_of, is_ip_host, platform_of, registrable_domain, scripts_in, split_url,
                      tld_of, unwrap_redirect)

# ---- names kept for backward compatibility with v0.9 imports
SUSPICIOUS_TLDS = {"." + t for t in HIGH_ABUSE_TLDS}
TRUSTED_BRANDS = sorted(BRANDS)
CREDENTIAL_WORDS = ["login", "logga", "signin", "sign in", "verify", "verifiera",
                    "account", "konto", "password", "lösenord", "credential", "confirm", "bekräfta"]

# weak URL signals: normal for newsletters / tracking links
WEAK_URL_SIGNALS = {"url_many_subdomains", "url_very_long", "url_no_https", "url_many_dashes",
                    "url_uncommon_tld"}

_CRED_HOST_WORDS = {"login", "signin", "logon", "secure", "security", "verify", "verification",
                    "account", "accounts", "update", "auth", "authenticate", "webmail", "support",
                    "billing", "wallet", "confirm", "recover", "recovery", "unlock", "validation",
                    "validate", "password", "reset", "helpdesk", "service", "portal", "sso",
                    "ebanking", "netbanking", "onlinebanking", "prijava", "potvrda", "nalog",
                    "inloggning", "loggain", "bekrafta", "verifiera"}
_CRED_PATH_RE = re.compile(r"(?i)(log-?in|sign-?in|verif|secur|account|update|auth|wallet|webscr|"
                           r"confirm|password|recover|unlock|validat|billing|prijava|potvrd)")
_EXEC_URL_RE = re.compile(r"(?i)\.(exe|scr|msi|bat|cmd|ps1|vbs|vbe|jse|wsf|hta|lnk|iso|img|"
                          r"vhd|vhdx|apk|jar|cpl|appx|msix|one|rdp|chm|reg)$")
_PAGE_URL_RE = re.compile(r"(?i)(\.(html?|shtml|php\d?|aspx?|jsp)(?:$|[?#])|/$|^$)")

# security gateways that rewrite every link: unwrap silently, never a red flag
_REWRITERS = ("safelinks.protection.outlook.com", "urldefense.com", "urldefense.proofpoint.com",
              "mimecast.com", "mimecastprotect.com", "cudasvc.com", "emailprotection.link",
              "safelink.emails.azure.net")

MAX_URLS_CHECKED = 60


def _sig(name: str, weight: int, detail: str) -> dict:
    return {"signal": name, "weight": weight, "detail": detail}


def extract_urls(text: str) -> list[str]:
    out = []
    for u in re.findall(r"https?://[^\s<>\"')\]]+|www\.[^\s<>\"')\]]+", text or ""):
        while u and u[-1] in ".,;:!?)]}'\"":
            u = u[:-1]
        if u:
            out.append(u)
    return out


def _extract_addr(header_value: str) -> str:
    """Pull the bare email address out of 'Name <addr@dom.com>' or 'addr@dom'."""
    v = header_value or ""
    m = re.search(r"<\s*([^<>\s]+@[^<>\s]+)\s*>", v)
    if not m:
        m = re.search(r"([\w.+\-']+@[\w\-]+(?:\.[\w\-]+)+)", v)
    if not m:
        return ""
    addr = m.group(1).lower().strip(".")
    return addr[:-8] if addr.endswith(".invalid") else addr


def _display_name(header_value: str) -> str:
    v = (header_value or "").strip()
    m = re.match(r"^(.*?)\s*<[^>]*>\s*$", v, re.S)
    if m:
        return m.group(1).strip().strip("\"'").strip()
    return "" if "@" in v else v.strip("\"'")


def _domain_of_addr(addr: str) -> str:
    return addr.rsplit("@", 1)[-1].lower().strip(".> ") if "@" in (addr or "") else ""


# ------------------------------------------------------------------ URLs
_DOC_NETS = [ipaddress.ip_network(n) for n in ("192.0.2.0/24", "198.51.100.0/24", "203.0.113.0/24")]


def _is_private_ip(host: str) -> bool:
    """Intranet / loopback address. The RFC 5737 documentation ranges count as
    public here: they never occur in real mail, only in examples and tests."""
    try:
        ip = ipaddress.ip_address(host.strip("[]"))
    except ValueError:
        return False
    if any(ip in net for net in _DOC_NETS):
        return False
    return ip.is_private or ip.is_loopback or ip.is_link_local


def check_url(url: str, _depth: int = 0) -> list[dict]:
    """Return list of hit signals for a single URL."""
    signals: list[dict] = []
    raw = (url or "").strip()
    p = split_url(raw)
    if p is None:
        return signals
    try:
        host = (p.hostname or "").lower().strip(".")
        port = p.port
    except ValueError:
        host, port = "", None
    if not host:
        return signals
    netloc = p.netloc or ""
    path = p.path or ""
    add = lambda n, w, d: signals.append(_sig(n, w, d))        # noqa: E731

    ip = is_ip_host(host)
    if ip:
        if _is_private_ip(host):
            signals.append({"signal": "url_ip_host", "weight": 8, "tier": "context",
                            "detail": f"Link to a private/intranet IP address: {host}"})
        else:
            add("url_ip_host", 24, f"URL uses a raw IP address instead of a domain: {host}")
    # real trick: https://paypal.com@evil.tk  ('@' before the host). An address
    # inside a tracking-link PATH (.../click/user@mail.com) is normal.
    if "@" in netloc:
        add("url_at_symbol", 20, f"URL contains @ before the host (hides the real destination {host})")
    if port and port not in (80, 443, 8080, 8443):
        add("url_nonstandard_port", 8, f"Link uses an unusual port: {host}:{port}")
    if p.scheme == "http":
        add("url_no_https", 5, "Plain HTTP instead of HTTPS")
    if len(raw) > 200:
        add("url_very_long", 3, f"Unusually long URL ({len(raw)} characters)")
    if _EXEC_URL_RE.search(path) and not p.query and "/cgi" not in path.lower():
        add("url_download_executable", 20, f"Link downloads a program/script file: {host}{path[-40:]}")
    if ip:
        return signals

    reg = registrable_domain(host)
    tld = tld_of(host)
    plat = platform_of(host)
    official = official_brand_of_host(host)
    sub_labels = host[: -len(reg)].strip(".").split(".") if host != reg and host.endswith(reg) else []
    sub_labels = [s for s in sub_labels if s]

    if len(sub_labels) >= 3 and not official:
        add("url_many_subdomains", 5, f"Many subdomains: {host}")
    sld_label = reg.split(".")[0]
    if not sld_label.startswith("xn--") and sld_label.count("-") >= 3:
        add("url_many_dashes", 5, f"Multiple dashes in domain: {reg}")

    # ---- internationalized names: only the deceptive kind is a red flag
    if "xn--" in host:
        decoded = decode_idna(host)
        folded = fold_confusables(decoded)
        mixed = any(len(scripts_in(lab) - {"other"}) > 1 for lab in decoded.split("."))
        imitates = folded != decoded and (official_brand_of_host(folded) or brands_in_host(folded))
        if mixed or imitates:
            add("url_punycode", 25, f"Look-alike internationalized domain (homograph): {host} "
                                    f"displays as {decoded}")

    # ---- shorteners
    if reg in ANON_SHORTENERS or host in ANON_SHORTENERS:
        add("url_shortener", 10, f"URL shortener hides the destination: {host}")

    # ---- top-level domain
    if tld in HIGH_ABUSE_TLDS and not official:
        add("url_suspicious_tld", 12, f"Suspicious TLD .{tld}: {host}")
    elif tld in MIXED_TLDS and not official:
        add("url_uncommon_tld", 4, f"Uncommon TLD .{tld}: {host}")

    # ---- brand impersonation in the host
    refs = brands_in_host(host)
    if refs:
        key, kind, conf = refs[0]
        if kind == "lookalike":
            add("url_lookalike_domain", 30,
                f"Domain imitates '{key}' with look-alike spelling: {host}")
        elif conf == "high":
            add("url_brand_spoof", 30, f"Brand '{key}' in a domain that is not theirs: {host}")
        else:
            add("url_brand_mention", 8, f"Brand name '{key}' appears in an unrelated domain: {host}")
    elif not official and any(lab in ("com", "net", "org", "gov", "co") for lab in sub_labels):
        add("url_embedded_domain", 12,
            f"Host pretends to be another domain (a TLD in the middle of the name): {host}")

    # ---- abuse of trusted hosting platforms
    is_ipfs = reg in IPFS_GATEWAYS or host in IPFS_GATEWAYS or any(
        host.endswith("." + g) for g in IPFS_GATEWAYS) or re.match(r"(?i)^/ip[fn]s/", path) \
        or ".ipfs." in host
    if is_ipfs:
        add("url_ipfs_gateway", 25, f"Link to content on IPFS (anonymous hosting used by phishing kits): {host}")
    elif plat and host != plat:
        if plat in WILDCARD_DNS:
            add("url_wildcard_dns", 25, f"Wildcard-DNS host that points at a bare IP address: {host}")
        elif plat in DYNAMIC_DNS or plat in TUNNELS:
            add("url_dynamic_dns", 18, f"Dynamic-DNS / tunnel host (throwaway infrastructure): {host}")
        elif plat in OBJECT_STORAGE:
            if _PAGE_URL_RE.search(path):
                add("url_free_hosting", 14, f"Web page served from a public storage bucket ({plat}): {host}")
        elif plat in FREE_HOSTING:
            add("url_free_hosting", 14, f"Page on a free hosting / app platform ({plat}): {host}")

    # ---- credential-bait words in the host itself
    if not official:
        toks = set(re.split(r"[.\-_]", host))
        hits = sorted(toks & _CRED_HOST_WORDS)
        if len(hits) >= 2:
            add("url_credential_keywords", 10, f"Host name built from login-bait words ({', '.join(hits[:4])}): {host}")
        # brand named in the PATH of an unrelated host, next to a login-ish word
        if not refs and path and len(path) > 3:
            low_path = fold_confusables(path.lower())
            for b in BRANDS.values():
                if b.weak or b.exact:
                    continue
                if any(len(t) >= 6 and t in low_path for t in b.tokens) and _CRED_PATH_RE.search(low_path):
                    add("url_brand_in_path", 12, f"Brand '{b.key}' in the path of an unrelated site: {host}")
                    break

    # ---- redirectors: analyze where the link really goes
    if _depth < 2:
        target = unwrap_redirect(raw)
        if target:
            t_host = host_of(target)
            t_reg = registrable_domain(t_host)
            if t_host and t_reg != reg:
                rewriter = any(host == r or host.endswith("." + r) for r in _REWRITERS)
                if not rewriter and official_brand_of_host(t_host) is None:
                    add("url_open_redirect", 10,
                        f"Link bounces through {host} to a different site: {t_host}")
                for s in check_url(target, _depth + 1):
                    s = dict(s)
                    s["detail"] = "[redirect target] " + s["detail"]
                    signals.append(s)
    return signals


def check_urls_aggregated(urls: list[str], sender: str = "") -> list[dict]:
    """Check all URLs but count each signal type ONCE.

    A newsletter with 40 tracking links must not score 40x 'long URL'.
    Weak signals on links that belong to the sender's own domain are ignored.
    """
    sender_dom = registrable_domain(_extract_addr(sender)) if sender else ""
    best: dict[str, dict] = {}
    counts: dict[str, int] = {}
    for u in (urls or [])[:MAX_URLS_CHECKED]:
        url_dom = registrable_domain(domain_of(u))
        same_org = bool(sender_dom) and url_dom == sender_dom
        for sig in check_url(u):
            if same_org and sig["signal"] in WEAK_URL_SIGNALS:
                continue
            name = sig["signal"]
            counts[name] = counts.get(name, 0) + 1
            if name not in best or sig["weight"] > best[name]["weight"]:
                best[name] = dict(sig)
    out = []
    for name, sig in best.items():
        if counts[name] > 1:
            sig["detail"] += f" (+{counts[name] - 1} more link(s))"
        out.append(sig)
    return out


_TEXT_DOMAIN_RE = re.compile(r"(?i)^(?:https?://)?(?:www\.)?((?:[a-z0-9\-]+\.)+[a-z]{2,24})(?:[/:?#].*)?$")


def check_links(links: list, sender: str = "", authenticated_bulk: bool = False) -> list[dict]:
    """'The text says paypal.com, the link opens something else.'

    links: [(href, anchor_text)] from the HTML body. ESP click-trackers and
    security link-rewriters legitimately differ from the visible text and are
    skipped, as are links to the sender's own domain.
    """
    sender_reg = registrable_domain(_extract_addr(sender)) if sender else ""
    best = None
    n = 0
    for href, text in (links or [])[:MAX_URLS_CHECKED * 2]:
        t = fold_confusables((text or "").strip())
        if not t or " " in t.strip() or len(t) > 120:
            continue
        m = _TEXT_DOMAIN_RE.match(t)
        if not m:
            continue
        text_host = m.group(1).lower()
        if tld_of(text_host) in ("html", "htm", "php", "pdf", "docx", "xlsx", "zip", "png", "jpg"):
            continue                                   # a file name, not a domain
        text_reg = registrable_domain(text_host)
        href_host = host_of(href)
        href_reg = registrable_domain(href_host)
        if not href_reg or text_reg == href_reg:
            continue
        target = unwrap_redirect(href)
        if target and registrable_domain(host_of(target)) == text_reg:
            continue
        if href_reg == sender_reg or href_reg in KNOWN_TRACKERS or host_of(href) in KNOWN_TRACKERS:
            continue
        # two official domains of the SAME brand (google.com text, goo.gl link) are fine
        brand = official_brand_of_host(text_host)
        if brand and official_brand_of_host(href_host) == brand:
            continue
        if brand:
            w = 30
        elif authenticated_bulk and text_reg == sender_reg:
            w = 8          # newsletter through an ESP tracker we don't know
        else:
            w = 20
        n += 1
        if best is None or w > best[0]:
            best = (w, text_host, href_host)
    if not best:
        return []
    w, text_host, href_host = best
    detail = f"Link text shows {text_host} but the link opens {href_host}"
    if n > 1:
        detail += f" (+{n - 1} more link(s))"
    return [_sig("url_text_mismatch", w, detail)]


# ------------------------------------------------------------------ sender
_ROLE_PATTERNS = {
    "ceo": re.compile(r"(?i)(?<!\w)(ceo|cfo|coo|cto|chief (executive|financial|operating) officer|"
                      r"managing director|president|chairman|founder|owner|direktor(ica)?|"
                      r"generalni direktor|vlasnik|predsjednik|predsednik|vd|verkställande direktör|"
                      r"styrelseordförande)(?!\w)"),
    "it": re.compile(r"(?i)(?<!\w)(it[\s\-_]*(support|help ?desk|service ?desk|department|dept|admin\w*|team|"
                     r"odjel|odeljenje|služba|sluzba|podrška|podrska|avdelning\w*)|help ?desk|service ?desk|"
                     r"(system|systems|server|network|mail|e-?mail|mailbox|domain|web ?mail|exchange)\s*"
                     r"(administrator|admin|team|support|server|service)|sys ?admin|administrator(ski tim)?|"
                     r"admin team|technical support|tech support|mail delivery\w*|"
                     r"mail ?server|e-?mail (security|notification|quarantine)|message center|"
                     r"security (team|center|centre|department|notification)|trusted server|"
                     r"tehnička podrška|tehnicka podrska|teknisk support)(?!\w)"),
    "billing": re.compile(r"(?i)(?<!\w)(billing|accounts? (payable|receivable|department|team)|accounting|"
                          r"finance (department|team)|payroll|human resources|hr (department|team|dept)|"
                          r"računovodstvo|racunovodstvo|finansije|financije|kadrovska|ekonomiavdelning\w*|"
                          r"löneavdelning\w*|lönekontor\w*)(?!\w)"),
    "support": re.compile(r"(?i)(?<!\w)(customer (service|support|care)|support team|fraud (department|team)|"
                          r"korisnička (podrška|služba)|korisnicka (podrska|sluzba)|kundtjänst|kundservice)(?!\w)"),
}


def infer_role(display: str, subject: str = "") -> str | None:
    """Corporate role a display name claims ('it' | 'ceo' | 'billing' | 'support')."""
    d = (display or "").strip()
    if not d or len(d.split()) > 5:        # a role title is short; a newsletter name is not
        return None
    for role in ("it", "ceo", "billing", "support"):
        if _ROLE_PATTERNS[role].search(d):
            return role
    return None


def check_sender(sender: str, reply_to: str | None = None, email: dict | None = None) -> list[dict]:
    """Sender / header heuristics."""
    signals = []
    email = email or {}
    add = lambda n, w, d: signals.append(_sig(n, w, d))        # noqa: E731
    display = _display_name(sender)
    addr = _extract_addr(sender)
    dom = _domain_of_addr(addr)
    reg = registrable_domain(dom)

    if re.search(r"(?i)(?<!\w)(urgent|hitno|akut|brådskande|dringend|action required|attention)(?!\w)", display):
        add("sender_urgent_word", 10, "Pressure word in the sender display name")
    local = addr.split("@")[0] if addr else ""
    if any(w in local for w in ("noreply", "no-reply", "no_reply", "donotreply", "support", "security",
                                "alert", "billing", "notification", "service")):
        add("sender_generic_role", 3, "Generic role address instead of a person")

    # mixed alphabets INSIDE the address or inside one display-name word. A name
    # written fully in Cyrillic (Петар Петровић) is perfectly normal.
    addr_decoded = decode_idna(addr)
    addr_mixed = any(len(scripts_in(part) - {"other"}) > 1
                     for part in re.split(r"[@.]", addr_decoded) if part)
    word_mixed = any(len(scripts_in(w) & {"latin", "cyrillic", "greek"}) > 1
                     for w in re.findall(r"[^\W\d_]{3,}", display))
    if addr_mixed or word_mixed:
        add("sender_mixed_alphabet", 18,
            "Look-alike letters from another alphabet mixed into the sender "
            + ("address" if addr_mixed else "name") + " (spoofing)")

    if dom:
        if is_ip_host(dom.strip("[]")):
            add("sender_ip_domain", 20, f"Sender address uses an IP literal instead of a domain: {dom}")
        else:
            refs = brands_in_host(dom)
            if refs:
                key, kind, conf = refs[0]
                if kind == "lookalike":
                    add("sender_lookalike_domain", 30,
                        f"Sender domain imitates '{key}' with look-alike spelling: {dom}")
                elif conf == "high":
                    add("sender_domain_brand_spoof", 22,
                        f"Sender domain uses the brand '{key}' but is not theirs: {dom}")
            if tld_of(dom) in HIGH_ABUSE_TLDS and official_brand_of_host(dom) is None:
                add("sender_suspicious_tld", 8, f"Sender domain on a high-abuse TLD: {dom}")

    if reply_to and sender and not email.get("_verified_platform"):
        # compare organisations, not hosts: emails.perfume.com == perfume.com
        rd_full = _domain_of_addr(_extract_addr(reply_to))
        rd = registrable_domain(rd_full)
        if reg and rd and reg != rd:
            is_list = bool(email.get("list_id") or email.get("list_unsubscribe")
                           or (email.get("precedence") or "") in ("list", "bulk", "junk"))
            reply_free = rd_full in FREEMAIL_DOMAINS or rd in FREEMAIL_DOMAINS
            from_free = dom in FREEMAIL_DOMAINS or reg in FREEMAIL_DOMAINS
            if is_list:
                pass       # mailing lists / helpdesks / ESPs route replies elsewhere by design
            elif reply_free and not from_free:
                add("reply_to_mismatch", 20,
                    f"Replies go to a free mailbox ({rd}) instead of the sender's domain ({reg})")
            else:
                # helpdesks, e-signature and invoicing services do this all day: context only
                signals.append({"signal": "reply_to_mismatch", "weight": 14, "tier": "context",
                                "detail": f"Reply-To domain ({rd}) differs from From domain ({reg})"})
    return signals


def check_auth(spf: str | None, dkim: str | None, dmarc: str | None,
               email: dict | None = None) -> list[dict]:
    """Authentication results (values like 'pass'/'fail'/'none').

    A pass is weak evidence of legitimacy (attackers authenticate their own
    domains); a DMARC failure is strong evidence of spoofing.
    """
    signals = []
    email = email or {}
    add = lambda n, w, d: signals.append(_sig(n, w, d))        # noqa: E731
    v = {k: (x or "").lower() for k, x in (("spf", spf), ("dkim", dkim), ("dmarc", dmarc))}
    policy = (email.get("dmarc_policy") or "").lower()

    if all(x == "pass" for x in v.values()):
        add("auth_all_pass", -3,
            "SPF, DKIM and DMARC all passed - the sender really controls this domain "
            "(which does not make the domain trustworthy)")

    if v["dmarc"] == "fail":
        w = 30 if policy in ("reject", "quarantine") else 25
        add("auth_dmarc_fail", w, "DMARC failed: the From domain did not authorise this message"
            + (f" (domain policy: {policy})" if policy else ""))
        if v["spf"] in ("fail", "softfail"):
            add("auth_spf_fail", 5, "SPF failed as well")
        if v["dkim"] == "fail":
            add("auth_dkim_fail", 5, "DKIM signature invalid as well")
    else:
        if v["spf"] == "fail":
            add("auth_spf_fail", 12, "SPF authentication failed (sending server not authorised)")
        elif v["spf"] == "softfail":
            add("auth_spf_fail", 6, "SPF soft-failed (sending server probably not authorised)")
        if v["dkim"] == "fail":
            add("auth_dkim_fail", 12, "DKIM signature invalid (message altered or forged)")
        if (email.get("compauth") or "").lower() == "fail":
            add("auth_compauth_fail", 15, "Microsoft composite authentication failed (likely spoofed)")

    missing = [k.upper() for k in ("spf", "dkim", "dmarc") if v[k] in ("none", "neutral")]
    if missing:
        add("auth_missing", min(8, 3 * len(missing)), f"Not configured for the sender domain: {', '.join(missing)}")
    return signals


def auth_aligned(email: dict) -> bool:
    """DMARC passed AND the authenticated domain is the From domain's organisation."""
    if (email.get("dmarc") or "").lower() != "pass":
        return False
    from_dom = registrable_domain(_extract_addr(email.get("sender", "")))
    doms = [email.get("dmarc_from") or ""] + list(email.get("dkim_domains") or [])
    if email.get("spf_domain") and (email.get("spf") or "").lower() == "pass":
        doms.append(email["spf_domain"])
    return bool(from_dom) and from_dom in {registrable_domain(d) for d in doms if d}


def check_display_name(sender: str) -> list[dict]:
    """'PayPal Support <paypal@gmail.com>' style spoofing."""
    signals = []
    display = _display_name(sender)
    addr = _extract_addr(sender)
    if not display or not addr:
        return signals
    dom = _domain_of_addr(addr)

    # an e-mail address written INTO the display name that differs from the real one
    m = re.search(r"[\w.+\-]+@([\w\-]+(?:\.[\w\-]+)+)", display)
    if m and registrable_domain(m.group(1)) != registrable_domain(dom):
        signals.append(_sig("sender_display_address_mismatch", 25,
                            f"Display name shows the address {m.group(0)} but the mail is from {addr}"))

    claim = brand_claimed_by_display(display)
    if claim:
        brand, strong = claim
        if not sender_is_official(brand, dom):
            freemail = dom in FREEMAIL_DOMAINS or registrable_domain(dom) in FREEMAIL_DOMAINS
            detail = (f"Display name '{display.strip()}' claims the brand '{brand.key}' "
                      f"but the address is {addr}")
            if strong:
                signals.append(_sig("sender_displayname_spoof", 16 if brand.weak else 28, detail))
            elif freemail or tld_of(dom) in HIGH_ABUSE_TLDS:
                signals.append(_sig("sender_displayname_spoof", 14, detail))
            elif not brand.weak:
                # the brand is only mentioned next to other words ("Monkey | Microsoft Teams"):
                # weak alone, telling together with a phishing-like text
                signals.append({"signal": "sender_displayname_spoof", "weight": 10, "tier": "context",
                                "detail": f"Display name '{display.strip()}' mentions the brand "
                                          f"'{brand.key}' but the address is {addr}"})
    return signals


def check_freemail_sender(sender: str, claimed_role: str | None = None,
                          subject: str = "") -> list[dict]:
    """Freemail domain used where a corporate sender is expected."""
    signals = []
    addr = _extract_addr(sender) or (sender or "").lower()
    if "@" not in addr:
        return signals
    domain = _domain_of_addr(addr)
    if domain not in FREEMAIL_DOMAINS and registrable_domain(domain) not in FREEMAIL_DOMAINS:
        return signals
    role = claimed_role or infer_role(_display_name(sender), subject)
    if role in ("it", "billing", "ceo", "support"):
        signals.append(_sig("sender_freemail_role", 20 if role in ("ceo", "it") else 16,
                            f"'{role}' role mail sent from a free mailbox ({domain})"))
    return signals


def check_recipient_context(email: dict) -> list[dict]:
    """Signals that need to know who the mail was sent TO."""
    signals = []
    to = [a for a in (email.get("to") or []) if "@" in a]
    if not to:
        return signals
    sender = email.get("sender", "")
    addr = _extract_addr(sender)
    sreg = registrable_domain(_domain_of_addr(addr))
    display = _display_name(sender)
    subject = (email.get("subject") or "")
    low_subj = subject.lower()
    rcpt = to[0].lower()
    rdom = _domain_of_addr(rcpt)
    rreg = registrable_domain(rdom)
    same_org = bool(sreg) and sreg == rreg
    rcpt_free = rdom in FREEMAIL_DOMAINS or rreg in FREEMAIL_DOMAINS

    if rcpt in low_subj and not same_org:
        signals.append(_sig("subject_contains_recipient", 14,
                            "Your own e-mail address is written into the subject line "
                            "(mass-personalised lure)"))
    if not same_org and not rcpt_free and rreg:
        org = rreg.split(".")[0]
        low_disp = display.lower()
        if rreg in low_disp or (len(org) >= 4 and re.search(rf"(?<![\w]){re.escape(org)}(?![\w])", low_disp)):
            signals.append(_sig("sender_impersonates_recipient_org", 27,
                                f"Display name '{display}' uses your own organisation's name "
                                f"but the mail comes from {sreg or 'another domain'}"))
        elif infer_role(display) == "it" and addr and \
                _domain_of_addr(addr) not in FREEMAIL_DOMAINS and sreg not in FREEMAIL_DOMAINS:
            signals.append(_sig("sender_internal_role_external", 10,
                                f"'{display}' presents itself as your IT/administration but "
                                f"writes from an outside domain ({sreg})"))
    return signals


def check_attachments(attachments: list[str]) -> list[dict]:
    """Dangerous attachment types (by name; the content scan is attachment_scan.py)."""
    signals = []
    exec_ext = (".exe", ".scr", ".js", ".jse", ".vbs", ".vbe", ".wsf", ".hta", ".lnk", ".bat",
                ".cmd", ".ps1", ".msi", ".iso", ".img", ".vhd", ".vhdx", ".jar", ".com", ".pif",
                ".cpl", ".dll", ".one", ".rdp", ".chm", ".reg", ".appx", ".msix", ".xll", ".msc")
    markup_ext = (".html", ".htm", ".shtml", ".xhtml", ".svg", ".mht", ".mhtml")
    macro_ext = (".docm", ".xlsm", ".pptm", ".dotm", ".xlam", ".xlsb")
    archive_ext = (".zip", ".rar", ".7z", ".gz", ".tgz", ".tar", ".ace", ".arj", ".cab", ".z", ".bz2")
    risky_names = ("invoice", "faktura", "payment", "scan", "dokument", "document",
                   "remittance", "shipment", "racun", "račun", "uplata", "ponuda", "order",
                   "receipt", "statement", "voicemail", "fax", "payroll", "salary", "betalning")
    for name in attachments or []:
        n = (name or "").lower().strip()
        if n.endswith(exec_ext):
            w, what = 25, "Executable / script attachment"
        elif n.endswith(markup_ext):
            w, what = 18, "HTML/SVG attachment (opens in the browser - classic credential-phishing carrier)"
        elif n.endswith(macro_ext):
            w, what = 20, "Macro-enabled Office attachment"
        elif n.endswith(archive_ext):
            w, what = 10, "Archive attachment"
        else:
            continue
        if any(k in n for k in risky_names):
            w += 6
            what += " with a bait name"
        signals.append(_sig("attachment_risky", w, f"{what}: {name}"))
    return signals
