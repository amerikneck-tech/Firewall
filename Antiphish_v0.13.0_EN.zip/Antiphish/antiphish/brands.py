"""Brand registry: who is commonly impersonated and which domains are really theirs.

v0.9 matched brand names as raw substrings: 's3.amazonaws.com',
'login.microsoftonline.com' and 'store.steampowered.com' were flagged as
"brand spoofing" while 'paypal.evil.tk' and 'paypa1.com' were not, and anyone
called Sebastian tripped the 'seb' (bank) rule. Here every brand has

    names    how it is written in display names / text
    tokens   how it appears inside host names
    domains  registrable domains the brand really uses (web + mail)
    exact    token must be a whole host token (short or dictionary words)
    weak     generic word (posta, booking): lower confidence

Coverage: global top targets plus Sweden and Bosnia/Serbia/Croatia, the
markets this project is tested in. Extend BRAND_DEFS for your own brands.
"""
from __future__ import annotations

import re
from dataclasses import dataclass
from functools import lru_cache

from .domains import (FREEMAIL_DOMAINS, HIGH_ABUSE_TLDS, edit_distance_le1, fold_confusables,
                      platform_of, registrable_domain, skeleton, tld_of)


@dataclass(frozen=True)
class Brand:
    key: str
    names: tuple
    tokens: tuple
    domains: frozenset
    exact: bool = False
    weak: bool = False


def _b(key, names, tokens, domains, exact=False, weak=False):
    return Brand(key, tuple(names), tuple(tokens), frozenset(domains), exact, weak)


# fmt: off
BRAND_DEFS = [
    # ---- payments / finance (global)
    _b("paypal", ["paypal"], ["paypal"], ["paypal.com", "paypal.me", "paypalobjects.com", "paypal-communication.com", "paypalcorp.com", "paypal-prepaid.com", "paypal-community.com", "xoom.com", "venmo.com"]),
    _b("visa", ["visa"], ["visa"], ["visa.com", "visa.co.uk", "visaeurope.com", "visa.se", "visa.de"], exact=True),
    _b("mastercard", ["mastercard"], ["mastercard"], ["mastercard.com", "mastercard.us", "mastercard.se", "mastercard.rs", "mastercard.ba", "mastercard.hr", "priceless.com"]),
    _b("amex", ["american express", "amex"], ["americanexpress", "amex"], ["americanexpress.com", "aexp.com", "amex.com", "americanexpress.se", "americanexpress.co.uk"], exact=True),
    _b("revolut", ["revolut"], ["revolut"], ["revolut.com", "revolut.me", "revolut.co.uk"], exact=True),
    _b("wise", ["wise", "transferwise"], ["wise", "transferwise"], ["wise.com", "transferwise.com"], exact=True),
    _b("stripe", ["stripe"], ["stripe"], ["stripe.com", "stripe.network", "stripecdn.com"], exact=True),
    _b("klarna", ["klarna"], ["klarna"], ["klarna.com", "klarna.se", "klarna.de", "klarna.net", "klarnacdn.net", "klarna.co.uk"]),
    _b("chase", ["chase bank", "jpmorgan chase"], ["chase"], ["chase.com", "jpmorgan.com", "jpmorganchase.com"], exact=True),
    _b("bankofamerica", ["bank of america"], ["bankofamerica", "bofa"], ["bankofamerica.com", "bofa.com", "ml.com"], exact=True),
    _b("wellsfargo", ["wells fargo"], ["wellsfargo"], ["wellsfargo.com", "wf.com", "wellsfargoadvisors.com"]),
    _b("citibank", ["citibank", "citi bank"], ["citibank"], ["citi.com", "citibank.com", "citigroup.com", "citibankonline.com"]),
    _b("hsbc", ["hsbc"], ["hsbc"], ["hsbc.com", "hsbc.co.uk", "hsbc.fr", "hsbc.com.hk", "hsbcnet.com"], exact=True),
    _b("barclays", ["barclays"], ["barclays"], ["barclays.com", "barclays.co.uk", "barclaycard.co.uk", "barclaysus.com"]),
    _b("santander", ["santander"], ["santander"], ["santander.com", "santander.co.uk", "santander.es", "santander.de", "santander.se", "santanderbank.com", "santanderconsumer.se"]),
    # ---- crypto
    _b("coinbase", ["coinbase"], ["coinbase"], ["coinbase.com", "cb.com"]),
    _b("binance", ["binance"], ["binance"], ["binance.com", "binance.us", "binance.org", "bnbstatic.com", "binance.me"]),
    _b("kraken", ["kraken"], ["kraken"], ["kraken.com"], exact=True),
    _b("metamask", ["metamask"], ["metamask"], ["metamask.io", "consensys.io", "consensys.net"]),
    _b("trustwallet", ["trust wallet", "trustwallet"], ["trustwallet"], ["trustwallet.com"]),
    _b("ledger", ["ledger live", "ledger wallet"], ["ledger"], ["ledger.com", "ledgerwallet.com"], exact=True),
    _b("trezor", ["trezor"], ["trezor"], ["trezor.io", "satoshilabs.com"]),
    _b("blockchaincom", ["blockchain.com"], ["blockchain"], ["blockchain.com", "blockchain.info"], exact=True, weak=True),
    # ---- big tech
    _b("microsoft", ["microsoft", "office 365", "office365", "microsoft 365", "microsoft365", "m365", "onedrive", "sharepoint", "ms teams", "microsoft teams", "outlook web", "azure"],
       ["microsoft", "office365", "microsoft365", "onedrive", "sharepoint", "microsoftonline", "msoffice", "o365", "m365"],
       ["microsoft.com", "microsoftonline.com", "office.com", "office365.com", "office.net", "live.com", "live.net", "outlook.com", "hotmail.com", "msn.com",
        "sharepoint.com", "sharepointonline.com", "onedrive.com", "azure.com", "azure.net", "windows.net", "windows.com", "windowsazure.com", "microsoft365.com",
        "microsoftstoreemail.com", "microsoftstore.com", "microsoftemail.com", "microsoftadvertising.com", "skype.com", "xbox.com", "bing.com", "msedge.net",
        "visualstudio.com", "dynamics.com", "powerbi.com", "powerapps.com", "aka.ms", "1drv.ms", "svc.ms", "msauth.net", "msftauth.net", "msftauthimages.net",
        "cloud.microsoft", "microsoft.us", "msecnd.net", "azureedge.net", "office365.us", "microsoftsupport.com", "msft.net", "microsoftazure.com",
        "emails.azure.net", "teams.cloud.microsoft", "sway.com", "yammer.com", "viva.com", "mspartner.microsoft.com", "microsoftpersonalcontent.com",
        "mail.onmicrosoft.com", "m365.cloud.microsoft", "static.microsoft"]),
    _b("outlook", ["outlook"], ["outlook"], ["outlook.com", "live.com", "office.com", "office365.com", "microsoft.com", "outlook.cn"], exact=True, weak=True),
    _b("google", ["google", "gmail", "google drive", "google docs", "google workspace", "youtube"], ["google", "gmail", "youtube", "googledrive", "googledocs"],
       ["google.com", "gmail.com", "googlemail.com", "youtube.com", "goo.gl", "g.co", "googleusercontent.com", "googleapis.com", "gstatic.com", "withgoogle.com",
        "googlegroups.com", "google.org", "googleadservices.com", "googlesyndication.com", "googletagmanager.com", "google-analytics.com", "doubleclick.net",
        "youtu.be", "ytimg.com", "ggpht.com", "googlevideo.com", "android.com", "chromium.org", "blogger.com", "page.link", "app.goo.gl", "forms.gle",
        "googleweblight.com", "google.dev", "googleblog.com", "chrome.com", "admob.com", "gmodules.com", "nest.com", "fitbit.com", "waze.com", "googlepay.com",
        "googleplay.com", "googlesource.com", "googlecode.com", "googledomains.com", "googlefiber.net", "gv.com", "abc.xyz", "x.company", "firebase.com",
        "firebase.google.com", "appsheet.com", "looker.com", "mandiant.com", "virustotal.com", "kaggle.com", "googlestore.com", "googlenestcommunity.com",
        "google", "youtube", "gmail", "goo.gle", "web.dev", "tensorflow.org", "golang.org", "go.dev", "dartlang.org", "flutter.dev", "googleoptimize.com",
        "c.googlers.com", "scholar.google.com", "accounts.google.com"]),
    _b("apple", ["apple", "apple id", "icloud", "itunes", "app store"], ["apple", "icloud", "itunes", "appleid"],
       ["apple.com", "icloud.com", "me.com", "mac.com", "itunes.com", "cdn-apple.com", "mzstatic.com", "apple.news", "apple.co", "appstore.com", "apple-cloudkit.com",
        "icloud-content.com", "apple.com.cn", "icloud.com.cn", "applemusic.com", "apple.tv", "beatsbydre.com", "shazam.com", "testflight.apple.com", "appleid.apple.com",
        "apple-mapkit.com", "aaplimg.com", "apple-dns.net", "apple"], exact=True),
    _b("amazon", ["amazon", "amazon prime", "aws", "prime video"], ["amazon", "amazonprime", "primevideo", "amzn"],
       ["amazon.com", "amazonaws.com", "amazonses.com", "amazon-adsystem.com", "media-amazon.com", "ssl-images-amazon.com", "awstrack.me", "amazonpay.com",
        "primevideo.com", "a.co", "amzn.to", "amzn.com", "amazon.jobs", "amazon.dev", "aws.com", "amazonwebservices.com", "awsstatic.com", "aws.dev",
        "amazontrust.com", "audible.com", "imdb.com", "twitch.tv", "wholefoodsmarket.com", "zappos.com", "ring.com", "amazonbusiness.com", "amazon.science",
        "aboutamazon.com", "amazonlogistics.com", "amazon-corp.com", "amazonworkmail.com", "awsapps.com", "amazoncognito.com", "cloudfront.net", "kindle.com",
        "amazonmusic.com", "amazonvideo.com", "amazonpayments.com", "pay.amazon.com", "amazon"]),
    _b("meta", ["facebook", "meta", "instagram", "whatsapp", "messenger"], ["facebook", "instagram", "whatsapp", "fbsecurity", "metabusiness"],
       ["facebook.com", "fb.com", "fb.me", "facebookmail.com", "fbcdn.net", "meta.com", "messenger.com", "instagram.com", "cdninstagram.com", "ig.me",
        "whatsapp.com", "whatsapp.net", "wa.me", "threads.net", "threads.com", "oculus.com", "workplace.com", "fbsbx.com", "metamail.com", "facebookblueprint.com",
        "internet.org", "facebook.net", "business.fb.com", "support.facebook.com", "mail.instagram.com", "metacareers.com", "about.meta.com", "meta.ai", "facebookenterprise.com"]),
    _b("linkedin", ["linkedin"], ["linkedin"], ["linkedin.com", "licdn.com", "lnkd.in", "linkedin.cn", "linkedinmail.com", "e.linkedin.com", "linkedin.at"]),
    _b("twitter", ["twitter"], ["twitter"], ["twitter.com", "x.com", "t.co", "twimg.com", "pscp.tv"]),
    _b("tiktok", ["tiktok"], ["tiktok"], ["tiktok.com", "tiktokv.com", "tiktokcdn.com", "bytedance.com", "tiktokglobalshop.com", "tiktokshop.com"]),
    _b("snapchat", ["snapchat"], ["snapchat"], ["snapchat.com", "snap.com", "sc-cdn.net"]),
    _b("telegram", ["telegram"], ["telegram"], ["telegram.org", "t.me", "telegram.me", "telesco.pe", "tdesktop.com"], exact=True),
    _b("discord", ["discord"], ["discord", "discordapp"], ["discord.com", "discordapp.com", "discord.gg", "discordapp.net", "discord.media", "discordstatus.com"], exact=True),
    # ---- streaming / shopping / travel
    _b("netflix", ["netflix"], ["netflix"], ["netflix.com", "nflxext.com", "nflximg.net", "nflxso.net", "nflxvideo.net", "netflix.net"]),
    _b("spotify", ["spotify"], ["spotify"], ["spotify.com", "scdn.co", "spotifycdn.com", "spotify.net", "byspotify.com", "spotify.link"]),
    _b("disney", ["disney+", "disney plus", "disneyplus"], ["disneyplus", "disney"], ["disneyplus.com", "disney.com", "go.com", "disneyonline.com", "starwars.com", "dssott.com", "disney-plus.net", "disney.se"], exact=True),
    _b("steam", ["steam"], ["steam", "steampowered", "steamcommunity"], ["steampowered.com", "steamcommunity.com", "steamstatic.com", "valvesoftware.com", "steamusercontent.com", "steamgames.com", "steam-chat.com", "s.team"], exact=True),
    _b("epicgames", ["epic games", "fortnite"], ["epicgames", "fortnite"], ["epicgames.com", "unrealengine.com", "fortnite.com", "epicgames.dev"]),
    _b("roblox", ["roblox"], ["roblox"], ["roblox.com", "rbxcdn.com", "roblox.cn"]),
    _b("playstation", ["playstation"], ["playstation"], ["playstation.com", "sonyentertainmentnetwork.com", "sony.com", "playstation.net", "sie.com"]),
    _b("ebay", ["ebay"], ["ebay"], ["ebay.com", "ebay.co.uk", "ebay.de", "ebay.fr", "ebay.it", "ebay.es", "ebay.com.au", "ebay.ca", "ebay.at", "ebay.ch", "ebay.nl", "ebay.ie", "ebay.pl", "ebaystatic.com", "ebayimg.com", "ebayinc.com", "kleinanzeigen.de"], exact=True),
    _b("aliexpress", ["aliexpress", "alibaba"], ["aliexpress", "alibaba"], ["aliexpress.com", "alibaba.com", "alicdn.com", "aliexpress.us", "aliexpress.ru", "alipay.com", "aliyun.com", "alibabacloud.com", "alibaba-inc.com", "aliexpress-media.com"]),
    _b("temu", ["temu"], ["temu"], ["temu.com", "temu.to", "kwcdn.com"], exact=True),
    _b("zalando", ["zalando"], ["zalando"], ["zalando.com", "zalando.se", "zalando.de", "zalando.hr", "zalando.si", "zalando.at", "zalando.co.uk", "zalando-lounge.com", "ztat.net", "zalando.net"]),
    _b("ikea", ["ikea"], ["ikea"], ["ikea.com", "ikea.net", "ikea.se", "ikea.rs", "ikea.hr", "ikea.ba", "ikea.si", "ikea.de", "ingka.com", "ikeacdn.com"], exact=True),
    _b("booking", ["booking.com"], ["booking"], ["booking.com", "bstatic.com", "bookingholdings.com", "booking.cn", "sg.booking.com", "partner.booking.com", "property.booking.com"], exact=True, weak=True),
    _b("airbnb", ["airbnb"], ["airbnb"], ["airbnb.com", "airbnb.se", "airbnb.co.uk", "airbnb.de", "airbnbmail.com", "muscache.com", "airbnb.org", "airbnb.rs", "airbnb.hr"]),
    _b("uber", ["uber"], ["uber"], ["uber.com", "ubereats.com", "uberinternal.com"], exact=True),
    _b("bolt", ["bolt"], ["bolt"], ["bolt.eu", "taxify.eu", "bolt.new"], exact=True, weak=True),
    _b("wolt", ["wolt"], ["wolt"], ["wolt.com"], exact=True),
    _b("glovo", ["glovo"], ["glovo"], ["glovoapp.com", "glovo.com"], exact=True),
    # ---- SaaS / documents / IT
    _b("docusign", ["docusign"], ["docusign"], ["docusign.com", "docusign.net", "docusign.eu"]),
    _b("adobe", ["adobe", "adobe sign", "acrobat sign", "adobe acrobat"], ["adobe", "adobesign", "acrobat"], ["adobe.com", "adobesign.com", "echosign.com", "adobelogin.com", "acrobat.com", "typekit.net", "adobe.io", "adobecc.com", "behance.net", "adobe.net", "adobeexchange.com", "frame.io", "adobedtm.com", "omtrdc.net", "adobestock.com", "photoshop.com"], exact=True),
    _b("dropbox", ["dropbox"], ["dropbox"], ["dropbox.com", "dropboxusercontent.com", "dropboxmail.com", "dropbox.email", "getdropbox.com", "hellosign.com", "docsend.com", "dropboxstatic.com", "dropboxapi.com", "dropbox.tech", "dropboxforum.com", "dropboxbusiness.com"]),
    _b("wetransfer", ["wetransfer"], ["wetransfer"], ["wetransfer.com", "we.tl", "wetransfer.net"]),
    _b("zoom", ["zoom"], ["zoom"], ["zoom.us", "zoom.com", "zoomgov.com", "zoom.video"], exact=True, weak=True),
    _b("slack", ["slack"], ["slack"], ["slack.com", "slack-edge.com", "slack-redir.net", "slackb.com", "slack-imgs.com", "slackhq.com"], exact=True, weak=True),
    _b("github", ["github"], ["github"], ["github.com", "githubusercontent.com", "github.io", "githubassets.com", "github.blog", "ghcr.io", "github.dev", "githubapp.com", "githubstatus.com"]),
    _b("atlassian", ["atlassian", "jira", "confluence"], ["atlassian"], ["atlassian.com", "atlassian.net", "jira.com", "bitbucket.org", "trello.com", "statuspage.io", "atl-paas.net"]),
    _b("hostinger", ["hostinger"], ["hostinger"], ["hostinger.com", "hostinger.rs", "hostinger.hr", "hostinger.se", "hostinger.co.uk", "hostinger.de", "hpanel.io", "hostingermail.com", "titan.email", "hostinger.io"]),
    _b("godaddy", ["godaddy"], ["godaddy"], ["godaddy.com", "secureserver.net", "godaddysites.com", "gdcorp.tools", "godaddy.net"]),
    _b("cpanel", ["cpanel"], [], ["cpanel.net", "cpanel.com"], weak=True),
    _b("wordpress", ["wordpress"], [], ["wordpress.com", "wordpress.org", "wp.com", "automattic.com", "gravatar.com", "wpengine.com", "wp.me", "jetpack.com"], weak=True),
    _b("norton", ["norton", "nortonlifelock", "norton 360"], ["norton", "nortonlifelock"], ["norton.com", "nortonlifelock.com", "gendigital.com", "symantec.com", "lifelock.com", "norton.se"], exact=True),
    _b("mcafee", ["mcafee"], ["mcafee"], ["mcafee.com", "mcafeesecure.com", "mcafeemobilesecurity.com", "mcafee.net"]),
    _b("geeksquad", ["geek squad", "geeksquad", "best buy"], ["geeksquad", "bestbuy"], ["geeksquad.com", "bestbuy.com", "bestbuy.ca"]),
    # ---- shipping
    _b("dhl", ["dhl", "dhl express"], ["dhl"], ["dhl.com", "dhl.de", "dhl.se", "dhl.rs", "dhl.ba", "dhl.hr", "dhl.co.uk", "dhl.fr", "dhl.it", "dhl.es", "dhl.nl", "dhl.at", "dhl.ch", "dhl.pl", "dpdhl.com", "deutschepost.de", "dhl-news.com", "dhlecommerce.com", "dhlparcel.nl", "dhl.dk", "dhl.no", "dhl.fi", "dhl.si", "dhl"], exact=True),
    _b("fedex", ["fedex"], ["fedex"], ["fedex.com", "fedex.co.uk", "tnt.com", "fedex.se", "fedexoffice.com"]),
    _b("ups", ["ups"], ["ups"], ["ups.com", "upsemail.com", "ups.se", "ups.de", "upscapital.com", "upsstore.com", "ups-scs.com"], exact=True),
    _b("usps", ["usps"], ["usps"], ["usps.com", "usps.gov", "uspis.gov"], exact=True),
    _b("dpd", ["dpd"], ["dpd"], ["dpd.com", "dpd.de", "dpd.co.uk", "dpd.hr", "dpd.rs", "dpd.si", "dpd.at", "dpd.ch", "dpd.pl", "dpd.nl", "dpd.ba", "dpdgroup.com", "dpd.se", "dpdlocal.co.uk"], exact=True),
    _b("gls", ["gls"], ["gls"], ["gls-group.com", "gls-group.eu", "gls-croatia.com", "gls-slovenia.com", "gls-serbia.com", "gls-hungary.com", "gls-pakete.de", "gls-italy.com", "gls-spain.es", "mygls.hr", "mygls.rs", "mygls.si", "gls.dk", "gls-sweden.com"], exact=True),
    _b("postnord", ["postnord"], ["postnord"], ["postnord.se", "postnord.com", "postnord.dk", "postnord.no", "postnord.fi", "postnord.net", "posten.se", "pn.se"]),
    _b("royalmail", ["royal mail"], ["royalmail"], ["royalmail.com", "royalmailgroup.com", "parcelforce.com"]),
    # ---- Sweden
    _b("swedbank", ["swedbank"], ["swedbank"], ["swedbank.se", "swedbank.com", "swedbank.ee", "swedbank.lv", "swedbank.lt", "swedbank.net", "swedbankrobur.se", "swedbankpay.se", "swedbankpay.com"]),
    _b("handelsbanken", ["handelsbanken"], ["handelsbanken"], ["handelsbanken.se", "handelsbanken.com", "handelsbanken.no", "handelsbanken.co.uk", "handelsbanken.nl", "handelsbanken.fi"]),
    _b("seb", ["seb"], ["seb"], ["seb.se", "sebgroup.com", "seb.ee", "seb.lv", "seb.lt", "sebgroup.lu", "seb.dk", "seb.no", "seb.fi", "seb.de", "sebkort.com"], exact=True),
    _b("nordea", ["nordea"], ["nordea"], ["nordea.se", "nordea.com", "nordea.fi", "nordea.no", "nordea.dk", "nordea.net", "nordea.ee"]),
    _b("danskebank", ["danske bank", "danskebank"], ["danskebank"], ["danskebank.se", "danskebank.com", "danskebank.dk", "danskebank.no", "danskebank.fi", "danskebank.co.uk"]),
    _b("lansforsakringar", ["länsförsäkringar", "lansforsakringar"], ["lansforsakringar"], ["lansforsakringar.se", "lf.se", "lfant.se"]),
    _b("icabanken", ["ica banken", "icabanken"], ["icabanken"], ["icabanken.se", "ica.se"]),
    _b("skatteverket", ["skatteverket"], ["skatteverket"], ["skatteverket.se"]),
    _b("forsakringskassan", ["försäkringskassan", "forsakringskassan"], ["forsakringskassan", "försäkringskassan"], ["forsakringskassan.se", "xn--frskringskassan-7hb7x.se"]),
    _b("bankid", ["bankid", "bank id"], ["bankid"], ["bankid.com", "bankid.no", "bankid.se"]),
    _b("swish", ["swish"], ["swish", "getswish"], ["swish.nu", "getswish.se", "getswish.net"], exact=True),
    _b("kivra", ["kivra"], ["kivra"], ["kivra.com", "kivra.se", "kivra.fi"], exact=True),
    _b("telia", ["telia"], ["telia"], ["telia.se", "telia.com", "telia.fi", "telia.no", "telia.dk", "telia.ee", "telia.lt", "teliacompany.com", "telia.net"], exact=True),
    _b("telenor", ["telenor"], ["telenor"], ["telenor.se", "telenor.com", "telenor.no", "telenor.dk", "telenor.rs", "telenor.net", "telenor.me"]),
    _b("tele2", ["tele2"], ["tele2"], ["tele2.se", "tele2.com", "tele2.net", "tele2.ee", "tele2.lv", "tele2.lt", "comviq.se"], exact=True),
    _b("polisen", ["polisen"], ["polisen"], ["polisen.se"], exact=True),
    _b("kronofogden", ["kronofogden"], ["kronofogden"], ["kronofogden.se"]),
    # ---- Bosnia / Serbia / Croatia / region
    _b("raiffeisen", ["raiffeisen"], ["raiffeisen", "raiffeisenbank"], ["raiffeisenbank.rs", "raiffeisenbank.ba", "rba.hr", "raiffeisen.at", "rbinternational.com", "raiffeisen.ch", "raiffeisen.hu", "raiffeisen.ro", "raiffeisen.bg", "raiffeisen.sk", "raiffeisen.cz", "rbi.co.at", "raiffeisen.de", "raiffeisenbank.at", "raiffeisen.net", "raiffeisen.si", "raiffeisen-kosovo.com", "raiffeisen.al", "rb.cz", "tatrabanka.sk", "raiffeisen.com", "raiffeisenonline.ro"]),
    _b("unicredit", ["unicredit"], ["unicredit", "unicreditbank"], ["unicreditbank.rs", "unicreditbank.ba", "unicredit.it", "unicredit.eu", "unicreditgroup.eu", "zaba.hr", "unicredit.ba", "unicreditbank.si", "unicreditbank.hu", "unicreditbank.cz", "unicredit.ro", "unicreditbulbank.bg", "hypovereinsbank.de", "bankaustria.at", "unicredit.de", "unicreditbank-bl.ba", "unicredit.com"]),
    _b("intesa", ["banca intesa", "intesa sanpaolo", "intesa"], ["bancaintesa", "intesasanpaolo", "intesa"], ["bancaintesa.rs", "intesasanpaolobanka.ba", "intesasanpaolo.com", "pbz.hr", "intesasanpaolobank.si", "intesasanpaolo.it", "bancaintesabeograd.com", "intesa.it"], exact=True),
    _b("nlb", ["nlb banka", "nlb komercijalna", "nlb"], ["nlb", "nlbbanka", "nlbkb"], ["nlb.si", "nlbkb.rs", "nlb.ba", "nlb-rs.ba", "nlbgroup.com", "nlbbanka.rs", "nlb.me", "nlb.mk", "nlbprishtina-kos.com", "nlb-fbih.ba", "nlbkb.com", "nlbskladi.si"], exact=True),
    _b("otpbanka", ["otp banka", "otp bank"], ["otpbanka", "otpbank", "otpsrbija"], ["otpbanka.rs", "otpbanka.hr", "otpbank.hu", "otpsrbija.rs", "otpbanka.si", "otpbank.ro", "otp.hu", "otpbanka.ba", "cbcg.me"]),
    _b("erstebank", ["erste banka", "erste bank"], ["erstebank", "erstegroup"], ["erstebank.rs", "erstebank.hr", "erstegroup.com", "erste.hr", "sparkasse.at", "erstebank.me", "erstebank.hu", "csas.cz", "slsp.sk", "bcr.ro", "george.hr", "erstebank.at"]),
    _b("addiko", ["addiko"], ["addiko"], ["addiko.com", "addiko.rs", "addiko.ba", "addiko.hr", "addiko.si", "addiko.me", "addiko-rs.ba", "addiko-fbih.ba", "addiko.at"]),
    _b("sparkasse", ["sparkasse"], ["sparkasse"], ["sparkasse.ba", "sparkasse.de", "sparkasse.at", "sparkasse.si", "sparkasse.hr", "sparkasse.mk", "sparkasse.com", "sparkasse.net"]),
    _b("procredit", ["procredit"], ["procredit", "procreditbank"], ["procreditbank.rs", "procreditbank.ba", "procredit-holding.com", "procreditbank.com", "procreditbank.hr", "pcb.ba", "procreditbank.bg", "procreditbank-kos.com", "procredit-group.com"]),
    _b("aikbanka", ["aik banka"], ["aikbanka"], ["aikbanka.rs", "aikgroup.rs"]),
    _b("postanska", ["poštanska štedionica", "postanska stedionica"], ["postanskastedionica"], ["posted.co.rs"]),
    _b("zaba", ["zagrebačka banka", "zagrebacka banka"], ["zagrebackabanka"], ["zaba.hr", "unicreditgroup.eu"]),
    _b("pbz", ["privredna banka zagreb", "pbz"], ["pbz"], ["pbz.hr", "pbzcard.hr", "pbz.net"], exact=True),
    _b("hpb", ["hrvatska poštanska banka", "hpb"], ["hpb"], ["hpb.hr"], exact=True),
    _b("posta", ["pošta srbije", "bh pošta", "hrvatska pošta", "pošte srpske", "pošta crne gore", "post express", "пошта србије", "поште српске"],
       ["postasrbije", "bhposta", "postesrpske", "postexpress", "hrvatskaposta"],
       ["posta.rs", "posta.ba", "postesrpske.com", "post.ba", "posta.hr", "posta.si", "postacg.me", "postexpress.rs", "postesrpske.ba", "hp-mostar.ba", "bhp.ba", "posta.co.rs", "epostshop.hr", "posta.mk", "postacg.com", "paket24.hr", "evropa.rs"], exact=True, weak=True),
    _b("mts", ["telekom srbija", "mts"], ["mts", "telekomsrbija"], ["mts.rs", "telekom.rs", "telekomsrbija.com", "mtel.ba", "mtel.me", "mtel.at", "mts.ba", "arenasport.rs", "mondo.rs", "open.telekom.rs", "mt.rs"], exact=True),
    _b("bhtelecom", ["bh telecom", "bhtelecom"], ["bhtelecom"], ["bhtelecom.ba", "bih.net.ba"]),
    _b("hteronet", ["ht eronet", "hteronet"], ["hteronet"], ["hteronet.ba", "ht.ba"]),
    _b("yettel", ["yettel"], ["yettel"], ["yettel.rs", "yettel.hu", "yettel.bg", "yettel.com", "yettelbank.rs"]),
    _b("telemach", ["telemach"], ["telemach"], ["telemach.ba", "telemach.hr", "telemach.si", "telemach.me", "unitedgroup.eu", "sbb.rs", "eon.tv"]),
    _b("hrvatskitelekom", ["hrvatski telekom"], ["hrvatskitelekom"], ["hrvatskitelekom.hr", "t.ht.hr", "ht.hr", "t-com.hr", "tportal.hr", "iskon.hr"]),
    _b("euprava", ["euprava", "e-uprava", "poreska uprava", "porezna uprava", "e-građani", "e-gradjani", "еуправа", "пореска управа"], ["euprava", "poreskauprava", "poreznauprava"],
       ["gov.rs", "euprava.gov.rs", "purs.gov.rs", "gov.hr", "porezna-uprava.gov.hr", "gov.ba", "pufbih.ba", "poreskaupravars.org", "uino.gov.ba", "vladars.net", "fbihvlada.gov.ba",
        "srbija.gov.rs", "mup.gov.rs", "mup.hr", "fina.hr", "apr.gov.rs", "nbs.rs", "hnb.hr", "cbbh.ba", "gov.me", "gov.si", "esrpska.com", "eid.gov.rs", "croso.gov.rs", "rfzo.rs", "hzzo.hr", "hzmo.hr", "mirovinsko.hr", "pio.rs", "ezdravlje.gov.rs"], exact=True),
    _b("d_express", ["d express", "dexpress", "daily express"], ["dexpress"], ["dexpress.rs", "dailyexpress.rs"]),
    _b("aks", ["aks express", "bex express", "city express", "euroexpress", "x express"], ["aksexpress", "bexexpress", "cityexpress", "euroexpress"], ["aks-express.com", "bex.rs", "cityexpress.rs", "euroexpress.ba", "x-express.ba", "aks.rs", "expressone.rs", "expressone.ba", "overseas.hr", "boxnow.hr", "boxnow.rs"]),
]
# fmt: on

BRANDS = {b.key: b for b in BRAND_DEFS}

# Ordinary words / other companies that are one edit (or one look-alike step)
# away from a brand token. Without this, 'finance' would be a Binance
# look-alike, 'applied' an Apple ID look-alike and 'express' a D Express one.
_BENIGN_NEAR = {"goggle", "goggles", "finance", "finances", "revolt", "revolute", "twister",
                "discard", "youtuber", "youtubers", "telegrams", "barclay", "uprava", "express",
                "xpress", "applied", "acrobats", "citybank", "tela", "tella", "bestbuys",
                "bookings", "instagrams", "facebooks", "swedbanks"}
# longer words that merely CONTAIN a brand token
_BENIGN_SUPERSTRINGS = {"amazonas", "amazonia", "amazonian", "amazonica", "googleplex",
                        "nordeast", "telenorway", "paypalme"}

_TRUSTED_SLD_TLDS = {"com", "net", "org", "eu", "se", "no", "dk", "fi", "de", "at", "ch", "fr",
                     "it", "es", "pt", "nl", "be", "ie", "uk", "pl", "cz", "sk", "hu", "ro", "bg",
                     "gr", "si", "hr", "ba", "rs", "me", "mk", "al", "us", "ca", "au", "nz", "jp",
                     "kr", "in", "br", "mx", "ar", "cl", "za", "ae", "sg", "hk", "tr", "il", "lt",
                     "lv", "ee", "is", "lu", "li", "cy", "mt", "gov", "edu", "int", "co"}


def host_tokens(host: str) -> tuple[list[str], list[str]]:
    """-> (raw tokens split on . - _ ; letter-only runs)."""
    raw = [t for t in re.split(r"[.\-_]", (host or "").lower()) if t]
    alpha = []
    for t in raw:
        alpha += re.findall(r"[a-z\u00c0-\u024f\u0400-\u04ff]+", t)
    return raw, alpha


def is_official_host(brand: Brand, host: str) -> bool:
    """Is this host really operated by the brand?"""
    host = (host or "").lower().strip(".")
    if not host:
        return False
    plat = platform_of(host)
    if plat and host != plat:
        # a tenant on a shared platform (x.github.io, bucket.s3.amazonaws.com,
        # corp.sharepoint.com) is controlled by the tenant, not by the platform's brand
        return False
    reg = registrable_domain(host)
    if reg in brand.domains or host in brand.domains:
        return True
    # sub-domain of an official multi-label entry (e.g. accounts.google.com)
    for d in brand.domains:
        if host.endswith("." + d):
            return True
    parts = reg.split(".")
    sld, tld = parts[0], parts[-1]
    # <brand>.<ordinary tld>: amazon.de, ikea.rs, dhl.ba ...
    if sld in brand.tokens and tld in _TRUSTED_SLD_TLDS and tld not in HIGH_ABUSE_TLDS:
        return True
    return False


@lru_cache(maxsize=4096)
def official_brand_of_host(host: str) -> str | None:
    """Brand key whose official infrastructure this host belongs to (or None)."""
    for b in BRAND_DEFS:
        if is_official_host(b, host):
            return b.key
    return None


@lru_cache(maxsize=4096)
def brands_in_host(host: str) -> tuple:
    """Brands referenced by a host that is NOT theirs.

    -> tuple of (brand_key, kind, confidence) with kind in
       'token'      brand is a whole token       paypal.evil.tk, secure-paypal.com
       'substring'  brand glued to other text    paypalsecure-login.top
       'lookalike'  spelled to look like it      paypa1.com, rnicrosoft.com
       'infra'      brand+word, no hyphen, .com  googleusercontent.com (unknown but plausible)
    confidence: 'high' | 'low'
    """
    host = (host or "").lower().strip(".")
    if not host or official_brand_of_host(host):
        return ()
    plat = platform_of(host)
    # the platform's own name is not a brand reference by the tenant:
    # evil.onmicrosoft.com does not "mention Microsoft", x.github.io not GitHub
    scan_host = host[: -len(plat) - 1] if plat and host != plat else host
    raw, alpha = host_tokens(scan_host)
    reg = registrable_domain(host)
    reg_labels = reg.split(".")
    sld = reg_labels[0] if reg_labels else ""
    tld = tld_of(host)
    # tokens of the public suffix itself are not brand references (x.co.uk, x.com.ba)
    suffix_tokens = set(reg_labels[1:]) if plat is None else set()
    out, seen = [], set()

    def add(key, kind, conf):
        if key not in seen:
            seen.add(key)
            out.append((key, kind, conf))

    labels_squashed = [lab.replace("-", "").replace("_", "") for lab in scan_host.split(".")]
    for b in BRAND_DEFS:
        hit, hit_tok = None, ""
        for tok in b.tokens:
            if tok in suffix_tokens:
                continue
            if tok in raw or tok in alpha:
                hit, hit_tok = "token", tok
                break
            if not b.exact and len(tok) >= 6 and any(
                    tok in lab and lab not in _BENIGN_SUPERSTRINGS for lab in labels_squashed):
                hit, hit_tok = "substring", tok
                break
        if hit:
            conf = "high"
            if b.weak:
                conf = "low"
            elif len(hit_tok) <= 3 and sld == hit_tok:
                # three-letter names are shared by unrelated firms (mts.ru, seb.fr ...):
                # <token>.<tld> alone proves nothing
                conf = "low"
            elif hit == "substring" and "-" not in sld and tld in ("com", "net", "org", "io") \
                    and plat is None and any(t in sld for t in b.tokens) \
                    and host.count(".") <= 2:
                # brand+word second-level domain without hyphens under a normal TLD:
                # the shape of real brand infrastructure (paypalobjects.com) - be modest
                hit, conf = "infra", "low"
            add(b.key, hit, conf)
            continue
        if b.weak:
            continue
        # look-alikes: only meaningful for brands long enough not to collide with words
        for tok in b.tokens:
            if len(tok) < 5:
                continue
            sk = skeleton(tok)
            for cand in raw:
                if cand == tok or cand in _BENIGN_NEAR or len(cand) < 4 or cand in suffix_tokens:
                    continue
                if abs(len(cand) - len(tok)) > 2:
                    continue
                csk = skeleton(cand)
                if csk == sk and cand != tok:
                    add(b.key, "lookalike", "high")
                    break
                if len(tok) >= 7 and not cand.isdigit() and edit_distance_le1(cand, tok) and cand != tok:
                    add(b.key, "lookalike", "high")
                    break
            if b.key in seen:
                break
    return tuple(out)


_GENERIC_DISPLAY_WORDS = {
    "support", "security", "team", "service", "services", "billing", "account", "accounts", "help",
    "helpdesk", "notification", "notifications", "inc", "llc", "ltd", "customer", "care", "center",
    "centre", "alert", "alerts", "info", "noreply", "no", "reply", "the", "from", "via", "official",
    "online", "international", "group", "bank", "banka", "express", "delivery", "mail", "email",
    "id", "pay", "payments", "payment", "store", "shop", "news", "update", "updates", "admin",
    "verification", "department", "dept", "desk", "protection", "secure", "member", "members",
    "com", "net", "corporation", "corp", "ab", "d.o.o", "doo", "a.d", "ad", "d.d", "dd", "tim",
    "podrška", "podrska", "obavještenje", "obavjestenje", "obaveštenje", "obavestenje", "kundtjänst",
    "kundservice", "sverige", "srbija", "hrvatska", "bih", "europe", "global", "business", "plus",
    "premium", "prime", "wallet", "cloud", "drive", "docs", "sign", "live", "and", "&", "-", "|", "web",
    "ventas", "soporte", "servicio", "equipo", "cliente", "clientes", "atendimento", "suporte", "equipe",
    "kundenservice", "kundendienst", "sicherheit", "konto", "ugyfelszolgalat", "assistance", "securite",
    "compte", "notificacion", "notificacao", "aviso", "seguridad", "seguranca", "banco", "bank", "your",
    "my", "new", "important", "urgent", "alert", "message", "messages", "center", "portal", "app", "tim",
    "team", "sluzba", "obavijest", "obavestenja", "racun", "nalog", "meddelande", "kund", "konto",
}


@lru_cache(maxsize=2048)
def _name_pattern(name: str):
    name = fold_confusables(name.lower())
    # no match right after a hyphen: 'Start-ups Weekly' is not UPS
    return re.compile(r"(?<![\w\-])" + re.escape(name).replace(r"\ ", r"[\s\-]*") + r"(?![\w])")


def brand_claimed_by_display(display: str):
    """-> (Brand, strong) when a display name presents itself as a brand.
    strong=True  : the name IS the brand (+ generic words): 'PayPal Support'
    strong=False : the brand is merely mentioned: 'Ana via Microsoft Teams'"""
    raw_low = re.sub(r"[_|/\\]+", " ", (display or "").lower()).strip(" \"'")
    d = fold_confusables(raw_low)
    if not d:
        return None
    best = None
    for b in BRAND_DEFS:
        for name in b.names:
            if not _name_pattern(name).search(d):
                continue
            rest = _name_pattern(name).sub(" ", d)
            words = [w for w in re.split(r"[\s,.:;()\[\]/\-!*]+", rest) if w]
            strong = all(w in _GENERIC_DISPLAY_WORDS or w.isdigit() for w in words)
            # 'Netflíx', 'PаyPal': the name only reads as the brand AFTER undoing
            # look-alike letters - that is disguise, whatever else is in the name
            if not strong and not _name_pattern(name).search(raw_low):
                strong = True
            if b.weak and not strong:
                continue
            cand = (b, strong)
            if best is None or (strong and not best[1]):
                best = cand
            break
    if best:
        return best
    # look-alike spelling in the display name: 'PaypaI', 'Micr0soft', 'Arnazon'
    for w in re.findall(r"[\w@$!|]{5,}", d):
        if w in _BENIGN_NEAR:
            continue
        sk = skeleton(w)
        for b in BRAND_DEFS:
            for tok in b.tokens:
                if len(tok) >= 6 and w != tok and sk == skeleton(tok):
                    return (b, True)
    return None


def brands_in_text(text: str, limit: int = 4000) -> list[str]:
    """Brand keys mentioned in a piece of text (subject / first part of the body)."""
    t = fold_confusables((text or "")[:limit].lower())
    out = []
    for b in BRAND_DEFS:
        if b.weak:
            continue
        if any(_name_pattern(n).search(t) for n in b.names):
            out.append(b.key)
    return out


def sender_is_official(brand: Brand, sender_domain: str) -> bool:
    """A freemail address is never an official brand sender, even gmail.com for Google."""
    d = (sender_domain or "").lower()
    if d in FREEMAIL_DOMAINS or registrable_domain(d) in FREEMAIL_DOMAINS:
        return False
    return is_official_host(brand, d)
