"""Generator of MODERN legitimate email samples (hard negatives).

Why: public legit corpora are from ~2002 (mailing lists). Modern phishing
imitates receipts, sign-in alerts and newsletters, so a model trained only on
old ham learns "looks like a receipt => phishing". These templates teach it
what the REAL versions look like (no credential ask, 'no action needed',
links to the brand's own domain, unsubscribe footers).

Wording intentionally differs from eval_sets.MODERN_LEGIT (held-out probe).
"""
from __future__ import annotations

import random

BRANDS = [("Zalando", "zalando.com"), ("Spotify", "spotify.com"), ("IKEA", "ikea.com"),
          ("Booking.com", "booking.com"), ("Bolt", "bolt.eu"), ("Wolt", "wolt.com"),
          ("Decathlon", "decathlon.com"), ("H&M", "hm.com"), ("Lidl", "lidl.com"),
          ("Steam", "steampowered.com"), ("Airbnb", "airbnb.com"), ("Uber", "uber.com"),
          ("Revolut", "revolut.com"), ("GitHub", "github.com"), ("Slack", "slack.com"),
          ("Notion", "notion.so"), ("Canva", "canva.com"), ("Asos", "asos.com"),
          ("Temu", "temu.com"), ("AliExpress", "aliexpress.com"), ("Ryanair", "ryanair.com"),
          ("Glovo", "glovoapp.com"), ("Duolingo", "duolingo.com"), ("LinkedIn", "linkedin.com"),
          ("Twitch", "twitch.tv"), ("Reddit", "reddit.com"), ("Etsy", "etsy.com"),
          ("Vinted", "vinted.com"), ("Telenor", "telenor.com"), ("A1", "a1.net")]
NAMES = ["Ana", "Marko", "Sara", "Ivan", "Elena", "Nikola", "Emma", "Lucas", "Mia", "Adnan",
         "Lejla", "Jonas", "Olivia", "Petar", "Amra", "Filip", "Nora", "Edin", "Lena", "Tarik"]
PRODUCTS = ["running shoes", "wireless headphones", "desk lamp", "winter jacket", "phone case",
            "coffee grinder", "backpack", "yoga mat", "gaming mouse", "water bottle", "book"]
CITIES = ["Sarajevo", "Belgrade", "Zagreb", "Vienna", "Stockholm", "Berlin", "Milan", "Ljubljana"]
FOOTERS = ["You're receiving this email because you signed up at {d}. Unsubscribe | Preferences",
           "Manage your email settings: https://www.{d}/settings/notifications",
           "© {brand}. All rights reserved. Privacy | Terms | Unsubscribe",
           "Don't want these emails? Update preferences at https://{d}/account",
           "This is an automated message from {brand}. Please do not reply.", ""]


def _r(seq):
    return random.choice(seq)


def _tpl():
    b, d = _r(BRANDS)
    n, p, c = _r(NAMES), _r(PRODUCTS), _r(CITIES)
    amt = f"{random.randint(3, 400)}.{random.randint(0, 99):02d}"
    cur = _r(["EUR", "USD", "BAM", "RSD", "SEK", "KM"])
    num = random.randint(10000, 999999)
    day = _r(["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"])
    pct = _r([10, 15, 20, 25, 30, 40, 50, 60, 70])
    url = f"https://www.{d}/{_r(['orders', 'account', 'deals', 'app', 'help', 'trips'])}/{num}"
    T = [
        # transactional
        f"{b}: order {num} confirmed\nHi {n}, thanks for shopping with us. We'll let you know when your {p} ships. Order total {amt} {cur}. Details: {url}",
        f"Good news, your {p} is on the way\nTracking number {num}. Estimated delivery {day}. Follow your parcel: {url}",
        f"Delivered: your {b} package\nYour order {num} was delivered today. Enjoy! Rate your experience in the app.",
        f"Your {b} receipt\nPaid {amt} {cur} with card ending {random.randint(1000, 9999)}. Billing period renews next month. Download PDF receipt from your account page.",
        f"Payment received - thank you\nWe received your payment of {amt} {cur} for invoice {num}. No further action is needed.",
        f"Your refund has been processed\nWe've refunded {amt} {cur} to your original payment method. It may take 5-10 business days to appear.",
        f"Your trip to {c} is booked\nBooking reference {num}. Check-in {day} from 14:00. Manage the reservation in the {b} app.",
        f"Your ride receipt\nThanks for riding with {b}, {n}. Trip total {amt} {cur}. Tip your driver in the app.",
        f"Subscription renewed\nYour {b} plan renewed automatically for {amt} {cur}. Change or cancel anytime in account settings.",
        f"Your {b} invoice is available\nInvoice {num} for {amt} {cur} is ready. You can view it at {url}. Questions? Contact our support team.",
        # security - the LEGIT versions (no credential ask)
        f"New login to your {b} account\nWe noticed a login from {c} on {day}. If this was you, you can ignore this message. If not, change your password from the app.",
        f"{num} is your {b} security code\nUse it to complete sign-in. The code expires in 10 minutes. We will never call you to ask for this code.",
        f"Your {b} password was updated\nThis confirms your password change. If you didn't do this, contact support through the official app.",
        f"Two-factor authentication enabled\nYou turned on 2FA for your {b} account. Great choice for keeping your account safe.",
        f"Confirm your email for {b}\nThanks for signing up, {n}! Tap the button to confirm this address and finish creating your account. If you didn't sign up, ignore this email.",
        f"Your monthly {b} statement\nYour statement for last month is available in the app. We will never ask for your PIN or password by email.",
        # newsletters / promos
        f"{pct}% off {p}s this weekend only\nOur biggest {b} sale of the season is here. Free returns. Shop now at https://www.{d}/sale",
        f"New arrivals just dropped\nFresh styles from your favourite brands at {b}. Be the first to shop the collection.",
        f"{n}, picked for you\nBased on your recent views: {p}, {_r(PRODUCTS)} and more. Prices from {amt} {cur}.",
        f"Last chance: {pct}% off ends at midnight\nDon't miss out on {b} deals. Use code SAVE{pct} at checkout.",
        f"What's new at {b} this month\nProduct updates, tips and stories from our community. Read the full newsletter on our blog.",
        f"Your {b} year in review\nYou listened, watched and explored a lot this year. See your personalised highlights.",
        f"Members-only early access\nAs a {b} member you get early access to our winter sale starting {day}.",
        f"Free shipping on everything\nThis week only at {b}: free delivery, no minimum order.",
        # social / app notifications
        f"{n} mentioned you in a comment\n\"@you what do you think about this?\" Reply in {b}.",
        f"{n} sent you a message\nOpen {b} to read and reply.",
        f"You have {random.randint(2, 40)} new notifications\nSee what you missed on {b}.",
        f"{n} invited you to a workspace\nJoin {n}'s team on {b} to start collaborating.",
        f"Your weekly {b} summary\nYou completed {random.randint(1, 20)} lessons this week. Keep your streak going!",
        f"{n} commented on your post\n\"Great photo from {c}!\" See the conversation.",
        f"Reminder: event on {day}\n{n} invited you to Team dinner in {c} at 19:00. Going? Yes / Maybe / No",
        # utilities / telco / services
        f"Your {b} bill is ready\nAmount due {amt} {cur}, due date {day}. Pay through the app or your usual bank transfer.",
        f"You've used 80% of your data\nYou have 1GB left until your plan resets. Add more data in the {b} app if needed.",
        f"Scheduled maintenance on {day}\n{b} services may be briefly unavailable between 02:00 and 04:00. No action is required.",
        f"We're updating our privacy policy\nThe changes take effect next month. You don't need to do anything. Read the summary on our website.",
        f"Your appointment is confirmed\nSee you on {day} at 10:30 in {c}. Need to reschedule? Use the link in your booking confirmation.",
        # work / personal
        f"Re: plan for {day}\nHi {n}, works for me. I'll bring the slides, see you at 10.",
        f"Notes from today's call\nThanks all. Summary and next steps attached. Next check-in on {day}.",
        f"Draft proposal for review\nHi {n}, attached is the first draft. Comments welcome before {day}.",
        f"Quick question about the report\n{n}, could you send me the numbers for {c} when you have a minute? Thanks!",
        f"Happy birthday {n}!\nWishing you a great day, let's celebrate on {day}.",
        f"Faktura {num}\nPozdrav {n}, u prilogu je faktura za prošli mjesec. Rok plaćanja 15 dana po ugovoru.",
        f"Vaša porudžbina {num} je poslata\nPaket stiže u {day}. Pratite pošiljku u aplikaciji {b}.",
        f"Sastanak u {day}\nĆao {n}, može u 11h kod nas u kancelariji? Javi.",
        f"Din beställning {num} har skickats\nLeverans beräknas till {day}. Spåra paketet i appen.",
        f"Novi popust {pct}% u {b}\nPogledaj ponudu za {p}. Odjava sa liste u dnu poruke.",
    ]
    body = _r(T)
    foot = _r(FOOTERS).format(d=d, brand=b)
    return (body + ("\n" + foot if foot else "")).strip()


def generate(n: int = 1500, seed: int = 7) -> list[str]:
    random.seed(seed)
    out = set()
    while len(out) < n:
        out.add(_tpl())
    return sorted(out)


# ---------------------------------------------------------------------------
# v0.10: more languages and the exact kinds of legitimate mail that phishing
# imitates (security notices, statements, document shares, IT notices,
# invoices, delivery updates). Fragment-assembled, like synth_phish.py, and
# worded differently from the probes in eval_sets.py.
# ---------------------------------------------------------------------------
_R2 = random.Random()


def _p(seq):
    return _R2.choice(seq)


_EN_FIRST = ["Hannah", "Oliver", "Priya", "Tom", "Grace", "Daniel", "Ines", "Felix", "Maya", "Ben", "Chloe", "Samir"]
_EN_ORG = ["the clinic", "the municipality", "our office", "the school", "the gym", "the housing co-op", "the library",
           "the accounting team", "the service desk", "the warehouse", "the university", "the insurance desk"]


def _en_hard_negative():
    k = _R2.random()
    n = _p(_EN_FIRST)
    b, d = _p(BRANDS)
    if k < 0.16:
        return _p([f"New device signed in to {b}", f"{b} sign-in from a new browser", "Security notice", f"Was this you, {n}?"]) + "\n" + _p([
            f"A new device was used to sign in to your {b} account.", f"Your {b} account was accessed from a browser we have not seen before.",
            "We spotted a login from a new location."]) + " " + _p([
            "If you recognise this, there is nothing you need to do.", "No action is required if this was you.",
            "You can review your devices any time under Settings > Security in the app.",
            "If it wasn't you, open the app and change your password under Security."]) + " " + _p([
            "We will never ask for your password by email.", "This message was sent to keep your account safe.", ""])
    if k < 0.30:
        return _p(["Your statement is available", f"{b} monthly summary", "New document in your online bank", "E-invoice ready"]) + "\n" + _p([
            "Your latest statement can now be viewed in online banking.", "A new document has been added to your digital mailbox.",
            f"Your {b} summary for last month is ready in the app.", "Your e-invoice has been delivered to your internet bank."]) + " " + _p([
            "Nothing needs to be done unless you have questions.", "The amount will be collected by direct debit as usual.",
            "For your safety we never send links that ask for your PIN or password.", "Open the app the usual way to read it."])
    if k < 0.44:
        return _p([f"{n} shared a file with you", f"{n} invited you to a folder", "Comment on your document", f"{n} mentioned you"]) + "\n" + _p([
            f"{n} has given you access to the file 'Notes {_R2.randint(1, 30)} March'.", f"{n} added you to the shared folder for the project.",
            f"{n} left a comment: 'looks good, small typo on page 2'.", f"{n} replied to your comment in the planning document."]) + " " + _p([
            "Open it in the app you already use.", "You are receiving this because you are a member of the workspace.",
            "Reply to this notification to answer.", "Manage notifications in your profile."])
    if k < 0.58:
        return _p(["Planned maintenance tonight", "IT notice: VPN update", "Reminder: password policy", "New printer on floor 3",
                   "Mailbox migration completed"]) + "\n" + _p([
            "The file server will be restarted tonight between 22:00 and 23:00.", "A new VPN client is available in Software Center.",
            "Passwords expire every 180 days; Windows will prompt you at sign-in when it is time.",
            "Your mailbox was moved to the new server last night; no action is needed from you.",
            "The helpdesk never asks for your password by email or phone."]) + " " + _p([
            "Save your work before you leave.", "Install it when it suits you.", "Contact the service desk on extension 4100 with questions.",
            "Thanks for your patience."])
    if k < 0.72:
        num = _R2.randint(1000, 99999)
        return _p([f"Invoice {num}", f"Statement for account {num}", f"Reminder: invoice {num}", f"Credit note {num}"]) + "\n" + _p([
            f"Hi {n}, please find invoice {num} attached for last month's work.", f"Attached is invoice {num} as agreed, payment terms 30 days.",
            f"Our records show invoice {num} is still open; if you have already paid, please ignore this note.",
            f"We have issued credit note {num} against your last order."]) + " " + _p([
            "Bank details are unchanged and printed on the invoice.", "Let me know if you need a purchase order number on it.",
            "Thanks for your business.", "Kind regards, " + _p(_EN_FIRST)])
    if k < 0.86:
        return _p(["Your parcel is on its way", "Delivery update", "Out for delivery today", "Collected - thank you"]) + "\n" + _p([
            "Your parcel left our depot this morning.", "The driver will deliver between 13:00 and 15:00.",
            "Your order has been handed to the carrier.", "Your parcel was collected from the pickup point."]) + " " + _p([
            "There is nothing to pay.", "Track it with the number in your order confirmation.", "You can change the delivery day in the carrier app.",
            "Thanks for shopping with us."])
    return _p(["Payslip available", "Your refund is on its way", "Subscription renewal notice", "Appointment confirmed"]) + "\n" + _p([
        "Your payslip for this month is available in the HR portal you normally use.", "We have refunded your return to the original payment method.",
        f"Your {b} plan renews next month at the same price; manage it under Settings.", f"Your appointment at {_p(_EN_ORG)} is confirmed."]) + " " + _p([
        "No action is needed.", "It can take a few working days to show on your statement.", "See you then.", "You can cancel any time in your account."])


_BCS_FIRST = ["Amila", "Dino", "Selma", "Haris", "Jelena", "Miloš", "Ivana", "Tarik", "Maja", "Nermin", "Sanja", "Goran"]
_BCS_ORG = ["Dom zdravlja", "Općina", "škola", "Elektrodistribucija", "Vodovod", "Toplane", "knjižara", "servis", "fakultet",
            "agencija", "računovodstveni biro", "stomatološka ordinacija", "auto-servis", "apoteka", "biblioteka"]


def _bcs_legit():
    k = _R2.random()
    n = _p(_BCS_FIRST)
    num = _R2.randint(1000, 99999)
    if k < 0.14:
        return _p([f"Narudžba {num} je potvrđena", "Vaša narudžba je poslana", f"Račun za narudžbu {num}", "Hvala na kupovini"]) + "\n" + _p([
            f"Zdravo {n}, zaprimili smo tvoju narudžbu broj {num}.", "Vaš paket je predan kurirskoj službi i stiže za dva radna dana.",
            "U prilogu se nalazi račun za vašu kupovinu.", "Narudžba je spakovana i čeka kurira."]) + " " + _p([
            "Plaćate pouzećem prilikom preuzimanja.", "Ništa dodatno nije potrebno uplatiti.", "Broj za praćenje nalazi se u potvrdi narudžbe.",
            "Za zamjenu veličine javite se u roku od 14 dana."])
    if k < 0.27:
        return _p([f"Faktura {num}", f"Predračun {num}", f"Podsjetnik za fakturu {num}", "Ponuda u prilogu"]) + "\n" + _p([
            f"Poštovani, u prilogu vam dostavljamo fakturu {num} za izvršene usluge.", "Šaljem ponudu kako smo se dogovorili na sastanku.",
            f"Prema našoj evidenciji faktura {num} još je otvorena; ako ste platili, zanemarite ovaj podsjetnik.",
            "Dostavljamo predračun, a robu šaljemo po evidentiranoj uplati."]) + " " + _p([
            "Podaci za plaćanje su isti kao i do sada i nalaze se na fakturi.", "Rok plaćanja je 15 dana.", "Stojimo na raspolaganju za sva pitanja.",
            "Srdačan pozdrav, " + _p(_BCS_FIRST)])
    if k < 0.40:
        return _p(["Izvod je dostupan", "Obavijest banke", "Novi dokument u e-bankarstvu", "Mjesečni izvještaj po kartici"]) + "\n" + _p([
            "Vaš izvod za prošli mjesec dostupan je u aplikaciji mobilnog bankarstva.", "U vašem e-bankarstvu nalazi se novi dokument.",
            "Izvještaj o potrošnji po kartici možete pogledati u aplikaciji."]) + " " + _p([
            "Banka nikada ne traži lozinku, PIN ili broj kartice putem e-pošte.", "Nije potrebna nikakva radnja s vaše strane.",
            "Aplikaciju otvorite na uobičajen način.", "Za pitanja pozovite broj sa poleđine kartice."])
    if k < 0.52:
        return _p(["Lozinka je promijenjena", "Nova prijava na nalog", "Potvrda e-mail adrese", "Vaš kod za prijavu"]) + "\n" + _p([
            "Lozinka vašeg naloga je uspješno promijenjena.", "Zabilježili smo prijavu sa novog uređaja.",
            f"Vaš jednokratni kod je {_R2.randint(100000, 999999)} i važi deset minuta.", "Hvala na registraciji, vaša adresa je potvrđena."]) + " " + _p([
            "Ako ste to bili vi, ne trebate ništa poduzimati.", "Ukoliko niste vi, promijenite lozinku u postavkama aplikacije.",
            "Kod nikome ne otkrivajte; mi vas nikada nećemo zvati da ga tražimo.", "Ovu poruku možete zanemariti ako ste sve već uradili."])
    if k < 0.64:
        o = _p(_BCS_ORG)
        return _p(["Podsjetnik na termin", "Obavještenje za građane", "Raspored za narednu sedmicu", "Poziv na sastanak"]) + "\n" + _p([
            f"Podsjećamo vas na zakazani termin ({o}) u utorak u 10:30.", "Zbog praznika radno vrijeme u petak je skraćeno do 13 sati.",
            "Roditeljski sastanak održat će se u četvrtak u 18 sati.", "Sjednica skupštine stanara je u ponedjeljak u 19 sati."]) + " " + _p([
            "Ako ne možete doći, javite se telefonom dan ranije.", "Hvala na razumijevanju.", "Dnevni red je u prilogu.", "Vidimo se."])
    if k < 0.76:
        return _p(["Račun za struju", "Račun za internet", "Obračun komunalnih usluga", "Račun za telefon"]) + "\n" + _p([
            f"Vaš račun za prošli mjesec iznosi {_R2.randint(20, 140)},{_R2.randint(0, 99):02d} KM.",
            f"Račun u iznosu od {_R2.randint(1500, 9000)} RSD dospijeva 20. u mjesecu.",
            "Novi račun je dostupan u aplikaciji i u prilogu ove poruke."]) + " " + _p([
            "Plaćanje vršite kao i do sada, na šalteru, u pošti ili e-bankarstvom.", "Ako imate trajni nalog, iznos će biti naplaćen automatski.",
            "Hvala što redovno izmirujete obaveze."])
    if k < 0.88:
        return _p(["Zapisnik sa sastanka", "Re: izvještaj", "Materijali za sutra", "Pitanje oko ponude", "Godišnji odmor"]) + "\n" + _p([
            f"Ćao {n}, šaljem zapisnik sa današnjeg sastanka.", "Kolege, materijali za sutrašnju prezentaciju su u dijeljenom folderu.",
            f"{n}, možeš li mi do srijede poslati brojke za treći kvartal?", "Molim da mi odobrite godišnji odmor od 15. do 26. jula.",
            "Pregledao sam ponudu, imam dvije sitne primjedbe."]) + " " + _p([
            "Javi ako nešto treba dopuniti.", "Hvala unaprijed.", "Čujemo se sutra.", "Pozdrav, " + _p(_BCS_FIRST)])
    return _p(["Novi popusti ove sedmice", "Katalog je stigao", "Akcija do nedjelje", "Bilten udruženja"]) + "\n" + _p([
        "Pogledajte ponudu sedmice u našim prodavnicama.", "Novi katalog važi do kraja mjeseca.",
        "Sniženje zimske kolekcije do 40 posto.", "U novom broju biltena čitajte o planovima za narednu godinu."]) + " " + _p([
        "Besplatna dostava za narudžbe preko 100 KM.", "Odjava sa liste je moguća u dnu poruke.", "Vidimo se u prodavnici.",
        "Ne želite više primati ove poruke? Odjavite se."])


_SV_FIRST = ["Anna", "Johan", "Sara", "Erik", "Emma", "Lars", "Elin", "Oskar", "Maja", "Nils", "Karin", "Viktor"]


def _sv_legit():
    k = _R2.random()
    n = _p(_SV_FIRST)
    num = _R2.randint(1000, 99999)
    if k < 0.15:
        return _p([f"Orderbekräftelse {num}", "Din beställning har skickats", "Tack för ditt köp", "Leveransbesked"]) + "\n" + _p([
            f"Hej {n}, vi har tagit emot din order {num}.", "Ditt paket har lämnats till transportören och kommer inom två vardagar.",
            "Kvittot på ditt köp finns bifogat.", "Din order är packad och väntar på upphämtning."]) + " " + _p([
            "Du behöver inte betala något mer.", "Spårningsnumret finns i orderbekräftelsen.", "Du får ett sms när paketet finns att hämta.",
            "Öppet köp gäller i 30 dagar."])
    if k < 0.29:
        return _p([f"Faktura {num}", f"Påminnelse faktura {num}", "Offert enligt överenskommelse", f"Kreditfaktura {num}"]) + "\n" + _p([
            f"Hej, bifogar faktura {num} för utfört arbete.", "Här kommer offerten som vi pratade om på mötet.",
            f"Enligt våra noteringar är faktura {num} obetald; har du redan betalat kan du bortse från detta.",
            "Vi har skickat en kreditfaktura för den returnerade varan."]) + " " + _p([
            "Bankgiro och betalningsuppgifter är samma som tidigare och står på fakturan.", "Betalningsvillkor 30 dagar netto.",
            "Hör av dig om du har frågor.", "Med vänlig hälsning, " + _p(_SV_FIRST)])
    if k < 0.43:
        return _p(["Ditt kontoutdrag finns nu", "Ny post i din digitala brevlåda", "Meddelande från banken", "Årsbesked"]) + "\n" + _p([
            "Ditt kontoutdrag för förra månaden finns nu i internetbanken.", "Du har fått ett nytt brev i din digitala brevlåda.",
            "Ditt årsbesked är klart och finns i appen."]) + " " + _p([
            "Banken ber aldrig om lösenord, koder eller kortnummer via mejl.", "Du behöver inte göra något.",
            "Logga in som vanligt i appen om du vill läsa det.", "Ring kundservice på numret på baksidan av kortet om du undrar något."])
    if k < 0.56:
        return _p(["Lösenordet är uppdaterat", "Ny inloggning på ditt konto", "Din engångskod", "Bekräftelse av e-postadress"]) + "\n" + _p([
            "Lösenordet för ditt konto har ändrats.", "Vi såg en inloggning från en ny enhet.",
            f"Din engångskod är {_R2.randint(100000, 999999)} och gäller i tio minuter.", "Tack för att du registrerade dig, din adress är bekräftad."]) + " " + _p([
            "Var det du behöver du inte göra något.", "Om det inte var du kan du byta lösenord under Inställningar i appen.",
            "Dela aldrig koden med någon; vi ringer aldrig och frågar efter den.", "Du kan bortse från det här mejlet om allt stämmer."])
    if k < 0.70:
        return _p(["Påminnelse om din tid", "Information till boende", "Schema för nästa vecka", "Kallelse till årsmöte"]) + "\n" + _p([
            "Vi påminner om din bokade tid på tisdag kl 10.30.", "På grund av helgdagen stänger vi kl 13 på fredag.",
            "Föräldramötet hålls på torsdag kl 18 i matsalen.", "Föreningens årsmöte äger rum måndag kl 19 i gemensamhetslokalen."]) + " " + _p([
            "Avboka senast dagen innan om du får förhinder.", "Tack för visad förståelse.", "Dagordning finns bifogad.", "Välkommen!"])
    if k < 0.84:
        return _p(["Protokoll från mötet", "Sv: rapporten", "Material till imorgon", "Fråga om offerten", "Semesteransökan"]) + "\n" + _p([
            f"Hej {n}, här kommer protokollet från dagens möte.", "Underlaget till presentationen imorgon ligger i den delade mappen.",
            f"{n}, kan du skicka siffrorna för tredje kvartalet till onsdag?", "Jag skulle vilja ha semester vecka 29 till 31.",
            "Jag har läst offerten och har två små synpunkter."]) + " " + _p([
            "Säg till om något ska ändras.", "Tack på förhand.", "Vi hörs imorgon.", "Hälsningar " + _p(_SV_FIRST)])
    return _p(["Veckans erbjudanden", "Nyhetsbrev", "Rea till och med söndag", "Medlemsnytt"]) + "\n" + _p([
        "Se veckans erbjudanden i våra butiker.", "Vinterrean har börjat med upp till 40 procent.",
        "I det här numret berättar vi om planerna för nästa år.", "Som medlem får du handla till förmånspris hela helgen."]) + " " + _p([
        "Fri frakt över 499 kr.", "Du kan avregistrera dig längst ner i mejlet.", "Varmt välkommen in.", "Vill du inte ha fler utskick? Avsluta prenumerationen."])


def generate_multilingual(n_en: int = 500, n_bcs: int = 700, n_sv: int = 450, seed: int = 23) -> list[str]:
    """Legitimate mail in the project's languages + English hard negatives."""
    from .synth_phish import to_cyrillic
    _R2.seed(seed)
    out: set[str] = set()

    def fill(target, maker, post=None):
        start, guard = len(out), 0
        while len(out) - start < target and guard < target * 40:
            guard += 1
            t = "\n".join(" ".join(part.split()) for part in maker().split("\n"))
            out.add(post(t) if post else t)

    fill(n_en, _en_hard_negative)
    fill(n_bcs, _bcs_legit)
    fill(n_bcs // 7, _bcs_legit, post=to_cyrillic)
    fill(n_sv, _sv_legit)
    return sorted(out)
