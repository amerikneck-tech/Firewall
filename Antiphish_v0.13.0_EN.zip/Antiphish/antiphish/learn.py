"""Feedback-driven retraining with a safety gate.

When the detector gets a mail wrong, label it (web UI button, or a row in
data/feedback.csv) and retrain. Over time the model learns YOUR traffic.

CSV format (no header needed, but fine if present):
  "email subject and body text",0        <- 0 = legit
  "email subject and body text",1        <- 1 = phishing

Usage:
  python -m antiphish.learn                 # retrain; install only if it passes the gate
  python -m antiphish.learn --stats         # show feedback composition and problems
  python -m antiphish.learn --force         # install even if the gate fails (not recommended)
  python -m antiphish.learn --rollback      # restore the previous model

The gate (new in v0.10)
-----------------------
Feedback is weighted x5 and comes from users, so a handful of wrong labels -
honest mistakes or deliberate poisoning - can quietly ruin the model. Before a
retrained model replaces the live one it must do at least as well as the live
model (within a small tolerance) on mail it has never been trained on:
the probe sets (eval_sets.py) and the scenario suite (scenarios.py).
A model that fails is kept as model.candidate.joblib for inspection; the live
model stays untouched. The previous live model is always kept as *.bak.
"""
from __future__ import annotations

import csv
import os
import shutil
import sys

import numpy as np

from .config import DATA_DIR, MODEL_PATH
from .model import dataset_summary, load_model, save_model, train

FEEDBACK_PATH = os.path.join(DATA_DIR, "feedback.csv")

# how much worse than the live model a candidate may be on each check
TOLERANCE = {"probe_legit_false_alarms": 2, "probe_phish_missed": 3,
             "scenario_legit_not_low": 1, "scenario_phish_not_caught": 1}
# absolute floor, used when there is no live model to compare with
ABSOLUTE = {"probe_legit_false_alarms": 12, "probe_phish_missed": 15,
            "scenario_legit_not_low": 4, "scenario_phish_not_caught": 6}
_SIDECARS = ("", ".sha256", ".meta.json")


def load_feedback() -> tuple[list[str], np.ndarray]:
    path = os.path.abspath(FEEDBACK_PATH)
    texts, labels = [], []
    if not os.path.exists(path):
        return texts, np.array([], dtype=int)
    csv.field_size_limit(10_000_000)
    with open(path, newline="", encoding="utf-8") as f:
        for row in csv.reader(f):
            if len(row) < 2 or row[0].lower() in ("text", ""):
                continue
            try:
                label = int(row[1].strip())
            except ValueError:
                continue
            if label in (0, 1):
                texts.append(row[0].strip())
                labels.append(label)
    return texts, np.array(labels, dtype=int)


def feedback_problems(texts: list[str], labels) -> list[str]:
    """Things a human should look at before trusting the feedback file."""
    out = []
    seen: dict[str, int] = {}
    conflicts = 0
    for t, lab in zip(texts, labels):
        key = " ".join(t.lower().split())[:500]
        if key in seen and seen[key] != int(lab):
            conflicts += 1
        seen.setdefault(key, int(lab))
    if conflicts:
        out.append(f"{conflicts} mail(s) are labelled BOTH phishing and legit - fix the contradictory rows")
    short = sum(1 for t in texts if len(t) < 30)
    if short:
        out.append(f"{short} row(s) are shorter than 30 characters (too little text to learn from)")
    n = len(texts)
    if n >= 20:
        share = float(np.mean(np.asarray(labels) == 1))
        if share > 0.9 or share < 0.1:
            out.append(f"labels are very one-sided ({share:.0%} phishing): the model needs both kinds")
    return out


def quality_checks(pipe) -> dict:
    """Score a model on mail it was never trained on. Lower is better everywhere."""
    from . import eval_sets
    from .scenarios import run_scenarios
    res = {"probe_legit_false_alarms": 0, "probe_phish_missed": 0}
    for _name, (texts, label) in eval_sets.all_probe_sets().items():
        p = pipe.predict_proba(list(texts))[:, 1]
        if label == 0:
            res["probe_legit_false_alarms"] += int((p >= 0.5).sum())
        else:
            res["probe_phish_missed"] += int((p < 0.5).sum())
    sc = run_scenarios(pipe=pipe)["rows"]
    res["scenario_legit_not_low"] = sum(1 for r in sc if r["kind"] == "legit" and r["level"] != "LOW")
    res["scenario_phish_not_caught"] = sum(1 for r in sc if r["kind"] == "phish"
                                           and r["level"] in ("LOW", "SUSPICIOUS"))
    return res


def gate(candidate: dict, live: dict | None) -> list[str]:
    """-> list of failed checks (empty = pass)."""
    failures = []
    for key, value in candidate.items():
        if live is not None:
            limit = live.get(key, 0) + TOLERANCE[key]
            if value > limit:
                failures.append(f"{key}: {value} (live model: {live.get(key)}, allowed up to {limit})")
        elif value > ABSOLUTE[key]:
            failures.append(f"{key}: {value} (allowed up to {ABSOLUTE[key]})")
    return failures


def _backup(path: str):
    for ext in _SIDECARS:
        if os.path.exists(path + ext):
            shutil.copy2(path + ext, path + ".bak" + ext)


def rollback(path: str | None = None) -> bool:
    path = os.path.abspath(path or MODEL_PATH)
    if not os.path.exists(path + ".bak"):
        print("No backup model found.")
        return False
    for ext in _SIDECARS:
        if os.path.exists(path + ".bak" + ext):
            shutil.copy2(path + ".bak" + ext, path + ext)
    print(f"Restored previous model -> {path}. "
          f"A running web app / monitor loads it automatically within ~30 seconds.")
    return True


def retrain(force: bool = False) -> int:
    """Train, check, and install only if the gate passes. Returns a process exit code."""
    path = os.path.abspath(MODEL_PATH)
    fb_texts, fb_y = load_feedback()
    if len(fb_texts) == 0:
        print("No feedback yet. Add rows to data/feedback.csv, then re-run.")
    else:
        print(f"Feedback: {len(fb_texts)} samples "
              f"({(fb_y == 1).sum()} phishing / {(fb_y == 0).sum()} legit) - weighted x5")
        for problem in feedback_problems(fb_texts, fb_y):
            print(f"  WARNING: {problem}")

    live_checks = None
    if os.path.exists(path):
        try:
            live_checks = quality_checks(load_model(path))
        except Exception as e:
            print(f"(live model could not be loaded for comparison: {e})")

    summary = dataset_summary()
    print(f"Training on {summary['total']} texts ({summary['phishing']} phishing / {summary['legit']} legit) ...")
    pipe = train()  # corpus.csv + starter + feedback.csv
    checks = quality_checks(pipe)
    failures = gate(checks, live_checks)

    print("Quality on unseen mail (lower is better):")
    for k, v in checks.items():
        was = f"   live model: {live_checks[k]}" if live_checks else ""
        print(f"  {k:28s} {v:3d}{was}")

    meta = {"training_data": summary, "quality_checks": checks, "feedback_rows": len(fb_texts)}
    os.makedirs(os.path.dirname(path), exist_ok=True)
    if failures and not force:
        cand = os.path.join(os.path.dirname(path), "model.candidate.joblib")
        save_model(pipe, cand, meta=dict(meta, gate_failures=failures))
        print("\nGATE FAILED - the live model was NOT replaced:")
        for f in failures:
            print(f"  - {f}")
        print(f"The retrained model is saved as {cand} for inspection.\n"
              "Most likely cause: wrong labels in data/feedback.csv (see WARNINGs above). "
              "Fix them and re-run, or use --force if you are sure.")
        return 3
    if failures:
        print("\nGATE FAILED but --force was given: installing anyway.")
    if os.path.exists(path):
        _backup(path)
    save_model(pipe, path, meta=meta)
    print(f"Model retrained -> {MODEL_PATH} (previous model kept as .bak). "
          f"A running web app / monitor loads it automatically within ~30 seconds.")
    return 0


if __name__ == "__main__":
    if "--stats" in sys.argv:
        t, y = load_feedback()
        print(f"feedback.csv: {len(t)} rows ({(y == 1).sum()} phishing / {(y == 0).sum()} legit)")
        for problem in feedback_problems(t, y):
            print(f"  WARNING: {problem}")
    elif "--rollback" in sys.argv:
        sys.exit(0 if rollback() else 1)
    else:
        sys.exit(retrain(force="--force" in sys.argv))
