"""Parse real .eml files (stdlib only) into the dict format the detector expects.

v0.10: the HTML body is parsed structurally (html_extract) instead of being
regex-stripped, so link targets, anchor texts, forms, hidden text and inline
images survive. Calendar parts and inline images are handed to the attachment
scanner, and Authentication-Results is parsed per method with alignment data.
"""
from __future__ import annotations

import email
import email.policy
import re
from email.header import decode_header, make_header
from email.utils import getaddresses

from .html_extract import extract as _extract_html, strip_invisible

MAX_URLS = 200
MAX_HTML_CHARS = 2_000_000            # markup parsed per HTML part
MAX_BODY_CHARS = 200_000              # text kept per message
MAX_INLINE_IMAGES = 8
MAX_INLINE_IMAGE_BYTES = 4 * 1024 * 1024
MIN_INLINE_IMAGE_BYTES = 300          # below this it's a spacer/tracking pixel

# named text parts with these extensions are payloads, not the message body
_MARKUP_ATTACHMENT_EXT = (".html", ".htm", ".shtml", ".xhtml", ".xht", ".svg", ".hta", ".mht",
                          ".mhtml", ".js", ".vbs", ".xml", ".ics")

_URL_RE = re.compile(r"https?://[^\s<>\"')\]]+|www\.[^\s<>\"')\]]+", re.I)


def _decode(s: str | None) -> str:
    if not s:
        return ""
    try:
        return str(make_header(decode_header(str(s))))
    except Exception:
        return str(s)


def _html_to_text(html: str) -> str:
    """Kept for backward compatibility - visible text of an HTML fragment."""
    return _extract_html(html).text


def parse_eml(path: str) -> dict:
    """Parse an .eml file -> email dict ready for analyze_email()."""
    with open(path, "rb") as f:
        raw = f.read()
    return parse_message(message_from_bytes_robust(raw))


def message_from_bytes_robust(raw: bytes):
    """Parse raw email bytes, repairing broken line endings first.

    .eml files saved by Windows tools in text mode often contain '\r\r\n'
    (CRLF converted to CR+CRLF), which breaks MIME boundaries so attachments
    disappear - exactly what an attacker would like. Normalize to CRLF.
    """
    while b"\r\r\n" in raw:
        raw = raw.replace(b"\r\r\n", b"\r\n")
    return email.message_from_bytes(raw, policy=email.policy.default)


def clean_url(u: str) -> str:
    """Trim the punctuation that sentence text glues onto a URL."""
    u = (u or "").strip().strip("<>\"'")
    while u and u[-1] in ".,;:!?)]}'\"":
        u = u[:-1]
    return u


def extract_text_urls(text: str) -> list[str]:
    return [clean_url(u) for u in _URL_RE.findall(text or "")]


# ------------------------------------------------------------------ authentication
_METHOD_RE = re.compile(r"^\s*(spf|dkim|dmarc|compauth|arc)\s*=\s*([a-z]+)", re.I)


def parse_auth_results(msg) -> dict:
    """Authentication-Results -> per-method verdicts plus the data needed to
    judge ALIGNMENT (which domain passed), not just 'something passed'.

    Only the TOP-MOST header is trusted: it is the one added by the final
    receiving server. Lower ones can be forged by the sender.
    """
    out = {"spf": None, "dkim": None, "dmarc": None, "compauth": None,
           "dmarc_from": None, "dmarc_policy": None, "dkim_domains": [],
           "spf_domain": None, "auth_source": None}
    headers = msg.get_all("Authentication-Results") or []
    source = "authentication-results"
    if not headers:
        headers = msg.get_all("ARC-Authentication-Results") or []
        source = "arc"
    if headers:
        raw = re.sub(r"\s+", " ", str(headers[0])).strip()
        out["auth_source"] = source
        dkim_results = []
        for clause in raw.split(";"):
            m = _METHOD_RE.match(clause)
            if not m:
                continue
            method, result = m.group(1).lower(), m.group(2).lower()
            low = clause.lower()
            if method == "dkim":
                d = re.search(r"header\.(?:d|i)\s*=\s*@?([\w.-]+)", low)
                dkim_results.append((result, d.group(1).strip(".") if d else None))
            elif method == "spf" and out["spf"] is None:
                out["spf"] = result
                d = re.search(r"smtp\.(?:mailfrom|helo)\s*=\s*\"?(?:[^@\s;\"]*@)?([\w.-]+)", low)
                if d:
                    out["spf_domain"] = d.group(1).strip(".")
            elif method == "dmarc" and out["dmarc"] is None:
                out["dmarc"] = result
                d = re.search(r"header\.from\s*=\s*([\w.-]+)", low)
                if d:
                    out["dmarc_from"] = d.group(1).strip(".")
                p = re.search(r"\b(?:p|policy)\s*=\s*([a-z]+)", low)
                if p:
                    out["dmarc_policy"] = p.group(1)
            elif method == "compauth" and out["compauth"] is None:
                out["compauth"] = result
        if dkim_results:
            passed = [d for r, d in dkim_results if r == "pass"]
            out["dkim"] = "pass" if passed else dkim_results[0][0]
            out["dkim_domains"] = [d for d in passed if d]
    if out["spf"] is None:
        rs = str(msg.get("Received-SPF") or "").strip().lower()
        m = re.match(r"([a-z]+)", rs)
        if m and m.group(1) in ("pass", "fail", "softfail", "neutral", "none", "temperror", "permerror"):
            out["spf"] = m.group(1)
            out["auth_source"] = out["auth_source"] or "received-spf"
    return out


# ------------------------------------------------------------------ helpers
def _part_text(part) -> str:
    try:
        c = part.get_content()
        return c if isinstance(c, str) else c.decode("utf-8", "replace")
    except Exception:
        try:
            payload = part.get_payload(decode=True) or b""
            return payload.decode(part.get_content_charset() or "utf-8", "replace")
        except Exception:
            return ""


def _part_bytes(part) -> bytes:
    try:
        return part.get_payload(decode=True) or b""
    except Exception:
        return b""


def _addresses(value) -> list[str]:
    try:
        return [a.lower() for _n, a in getaddresses([str(value)]) if "@" in a]
    except Exception:
        return []


MAX_MIME_DEPTH = 30
MAX_MIME_PARTS = 500


def _leaf_parts(msg, _top=True, _depth=0, _count=None):
    """Leaf MIME parts in document order. An attached message (message/rfc822)
    is yielded as ONE part and never walked into - its body is not this
    message's body. Nesting depth and part count are bounded: a "MIME bomb"
    must not exhaust the recursion limit or the CPU."""
    _count = _count if _count is not None else [0]
    ctype = (msg.get_content_type() or "").lower()
    if not _top and ctype.startswith("message/"):
        _count[0] += 1
        yield msg
        return
    if msg.is_multipart():
        if _depth >= MAX_MIME_DEPTH:
            return
        payload = msg.get_payload()
        for sub in payload if isinstance(payload, list) else []:
            if _count[0] >= MAX_MIME_PARTS:
                return
            if hasattr(sub, "get_content_type"):
                yield from _leaf_parts(sub, False, _depth + 1, _count)
    else:
        _count[0] += 1
        yield msg


def _inner_message_bytes(part) -> bytes:
    try:
        inner = part.get_payload()
        inner = inner[0] if isinstance(inner, list) else inner
        if hasattr(inner, "as_bytes"):
            return inner.as_bytes()
        if isinstance(inner, str):
            return inner.encode("utf-8", "replace")
    except Exception:
        pass
    try:
        return part.as_bytes()
    except Exception:
        return b""


def _uniq(seq, limit=None):
    seen, out = set(), []
    for x in seq:
        if x and x not in seen:
            seen.add(x)
            out.append(x)
            if limit and len(out) >= limit:
                break
    return out


def parse_message(msg) -> dict:
    """Parse an email.message.Message -> email dict for analyze_email()."""
    subject = _decode(msg.get("Subject"))
    sender = _decode(msg.get("From"))
    reply_to = _decode(msg.get("Reply-To")) or None
    auth = parse_auth_results(msg)

    plain_parts, html_parts = [], []
    attachments, payloads, inline_images = [], {}, {}

    def add_attachment(name: str, data: bytes):
        base, n = name, 2
        while name in payloads:               # keep duplicates apart
            name = f"{base} ({n})"
            n += 1
        attachments.append(name)
        payloads[name] = data

    def add_inline_image(name: str, data: bytes):
        if len(inline_images) >= MAX_INLINE_IMAGES:
            return
        if not (MIN_INLINE_IMAGE_BYTES <= len(data) <= MAX_INLINE_IMAGE_BYTES):
            return
        base, n = name, 2
        while name in inline_images or name in payloads:
            name = f"{base} ({n})"
            n += 1
        inline_images[name] = data

    parts = list(_leaf_parts(msg))

    for part in parts:
        ctype = (part.get_content_type() or "").lower()
        cdisp = (part.get_content_disposition() or "").lower()
        fname = part.get_filename()
        fname = _decode(fname) if fname else None
        low_name = (fname or "").lower()

        if ctype == "message/rfc822":
            # an attached e-mail is ONE attachment; the scanner opens it recursively
            add_attachment(fname or "attached.eml", _inner_message_bytes(part))
            continue
        if ctype.startswith("message/"):
            continue                                        # delivery-status etc.
        if ctype == "text/calendar" and cdisp != "attachment":
            # calendar-invite phishing: the .ics rides as an unnamed alternative part
            add_attachment(fname or "invite.ics", _part_bytes(part))
            continue
        if ctype.startswith("image/") and cdisp != "attachment":
            add_inline_image(fname or f"inline-image-{len(inline_images) + 1}", _part_bytes(part))
            continue
        # attachment = explicit disposition, OR any named non-text part, OR a named
        # markup/script part (attackers mark payloads "inline" to dodge scanners)
        is_att = cdisp == "attachment" or (fname and ctype not in ("text/plain", "text/html")) \
            or (fname and low_name.endswith(_MARKUP_ATTACHMENT_EXT))
        if is_att:
            add_attachment(fname or "unnamed", _part_bytes(part))
        elif ctype == "text/plain":
            plain_parts.append(_part_text(part))
        elif ctype == "text/html":
            html_parts.append(_part_text(part))
        elif not msg.is_multipart():
            plain_parts.append(_part_text(part))

    # ---- body: what the reader actually sees
    links, forms, flags = [], [], set()
    html_texts, hidden_texts = [], []
    n_images = n_linked_images = invisible_in_words = 0
    for h in html_parts:
        info = _extract_html(h[:MAX_HTML_CHARS])
        html_texts.append(info.text)
        hidden_texts.append(info.hidden_text)
        links += info.links
        forms += info.forms
        flags |= info.flags
        n_images += info.images
        n_linked_images += info.linked_images
        invisible_in_words += info.invisible_in_words
        for i, data in enumerate(info.data_images):
            add_inline_image(f"data-image-{len(inline_images) + 1}", data)

    plain_text, inside = strip_invisible("\n".join(t for t in plain_parts if t)[:MAX_BODY_CHARS * 2])
    invisible_in_words += inside
    plain_text = plain_text.strip()[:MAX_BODY_CHARS]
    html_text = "\n".join(t for t in html_texts if t).strip()[:MAX_BODY_CHARS]
    hidden_text = "\n".join(t for t in hidden_texts if t).strip()[:MAX_BODY_CHARS]

    if html_text and len(html_text) >= 40:
        body = html_text                       # clients render the HTML alternative
    elif html_text or plain_text:
        body = "\n".join(t for t in (html_text, plain_text) if t)
    else:
        body = ""
    if len(body) < 40 and len(hidden_text) > 200:
        # everything is "hidden": either an evasion trick or markup we misread -
        # analyze the hidden text rather than nothing
        body = (body + "\n" + hidden_text).strip()
        flags.add("mostly_hidden")

    # ---- links
    web_links, link_emails, phones = [], [], []
    for href, text in links:
        h = (href or "").strip()
        low = h.lower()
        if low.startswith(("http://", "https://")):
            web_links.append((clean_url(h), text))
        elif low.startswith("//") and len(h) > 4:
            web_links.append(("https:" + clean_url(h), text))
        elif low.startswith("mailto:"):
            link_emails += _addresses(h[7:].split("?")[0])
        elif low.startswith("tel:"):
            phones.append(re.sub(r"[^\d+]", "", h[4:]))
        elif low.startswith(("javascript:", "data:", "blob:", "file:", "vbscript:")):
            flags.add("link_" + low.split(":", 1)[0])
    text_urls = extract_text_urls(body)
    if plain_text and plain_text not in body:
        text_urls += extract_text_urls(plain_text)
    urls = _uniq([u for u, _ in web_links] + text_urls, MAX_URLS)

    to_addrs = _addresses(", ".join(str(v) for v in (msg.get_all("To") or [])))
    cc_addrs = _addresses(", ".join(str(v) for v in (msg.get_all("Cc") or [])))
    list_unsub = bool(msg.get("List-Unsubscribe"))

    return {
        "subject": subject,
        "body": body,
        "body_plain": plain_text,
        "hidden_text": hidden_text,
        "sender": sender,
        "to": to_addrs,
        "cc": cc_addrs,
        "reply_to": reply_to,
        "return_path": _decode(msg.get("Return-Path")) or None,
        "message_id": str(msg.get("Message-ID") or "") or None,
        "date": str(msg.get("Date") or "") or None,
        "spf": auth["spf"], "dkim": auth["dkim"], "dmarc": auth["dmarc"],
        "compauth": auth["compauth"],
        "dmarc_from": auth["dmarc_from"],
        "dmarc_policy": auth["dmarc_policy"],
        "dkim_domains": auth["dkim_domains"],
        "spf_domain": auth["spf_domain"],
        "auth_source": auth["auth_source"],
        "list_unsubscribe": list_unsub,
        "list_id": _decode(msg.get("List-Id")) or None,
        "precedence": (str(msg.get("Precedence") or "").strip().lower() or None),
        "auto_submitted": (str(msg.get("Auto-Submitted") or "").strip().lower() or None),
        "content_type": (msg.get_content_type() or "").lower(),
        "has_html": bool(html_parts),
        "urls": urls,
        "links": web_links[:MAX_URLS],
        "link_emails": _uniq(link_emails, 20),
        "phones": _uniq(phones, 10),
        "html": {"flags": sorted(flags), "forms": forms[:10], "images": n_images,
                 "linked_images": n_linked_images, "visible_chars": len(html_text),
                 "hidden_chars": len(hidden_text), "invisible_in_words": invisible_in_words},
        "attachments": attachments,
        "attachment_data": payloads,
        "inline_images": inline_images,
        "headers_raw": {k: _decode(v) for k, v in msg.items()},
    }
