"""ML text classifier: TF-IDF (word + character n-grams) + calibrated linear model.

Training data (see scripts/build_corpus.py and NOTICE.md):
  data/corpus.csv        public corpora (real phishing + real legitimate mail)
  starter lists below    short hand-written modern examples (EN / SV / BCS)
  synth_legit / synth_phish  generated modern mail in the project's languages
  data/feedback.csv      YOUR labelled mail (weighted x5)

v0.10
* normalize_text() is era-, script- and recipient-independent: Cyrillic is
  transliterated, look-alike letters and accents folded, URLs reduced to
  "urltoken tld_xx", the recipient's own name/domain replaced by placeholders.
  (v0.9 learned the corpus owner's address: 48% of its phishing training mail
  contained "jose"/"monkey.org", so adding those words to any text raised the
  phishing probability from 0.6% to 70%.)
* a model file carries metadata; a model built with other features is refused
  and rebuilt instead of silently mis-scoring.
"""
from __future__ import annotations

import csv
import json
import os
import re
import time

import joblib
import numpy as np
from sklearn.calibration import CalibratedClassifierCV
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.pipeline import Pipeline
from sklearn.svm import LinearSVC

from .domains import fold_for_matching
from .html_extract import INVISIBLE_CHARS

# bump when normalize_text()/features change: older model files are then rebuilt
FEATURE_VERSION = 4

_PHISHING = [
    "Urgent: Your account will be suspended verify your identity now",
    "Your PayPal account has been limited click the link below to log in",
    "Final notice: unpaid invoice attached please review payment",
    "You have won 50000 USD in our lottery claim your prize now",
    "Security alert: unauthorized access to your account confirm your password",
    "Dear customer your package could not be delivered update your address",
    "Your Netflix account expires today update your payment information",
    "Verify your Microsoft account within 24 hours or it will be closed",
    "Invoice attached: outstanding balance 1200 EUR pay immediately",
    "Your account has been compromised click here to secure it",
    "DHL: customs fee required for your shipment pay now",
    "Dear user confirm your email address to avoid termination",
    "You received a refund of 350 USD confirm your bank details",
    "Urgent wire transfer needed for the supplier invoice",
    "Your Apple ID has been locked verify your identity immediately",
    "Congratulations you are our lucky winner claim reward now",
    "Action required: your password expires in 24 hours",
    "Suspicious sign-in detected verify your account now",
    "Your Amazon order cannot be shipped update payment method",
    "Last warning: legal action will be taken unless you pay",
    "Account verification required: click the secure link below",
    "Your subscription will be cancelled confirm your billing info",
    "Unusual activity detected log in to your bank account now",
    "Confirm your identity to receive your tax refund",
    "Dear valued customer you must update your details immediately",
    "Payment declined: update your card to keep your account",
    "You've been selected for an exclusive offer act now",
    "Your mailbox storage is full verify your account to continue",
    "Bank security notice: your card has been blocked confirm pin",
    "New voice message: sign in to listen to your voicemail",
    # evasion: spaced / leetspeak / homoglyph variants
    "Your acc0unt will be sus pended ver1fy now within 24 h0urs",
    "P a y P a l: unauth0rized log in detected confirm y0ur identity",
    "Ver1fy your Micros0ft acc0unt or it will be cl0sed",
    "Your accοunt has unusuаl activity (lookalike letters) log in now",
    "C l i c k   h e r e   t o   v e r i f y   y o u r   a c c o u n t",
    "Your pаyment of 12OO EUR is pеnding cοnfirm yοur card",
    "Unusuаl sign-in tο yοur bank accοunt verify nοw",
    "Urgent: reset y0ur p@ssword in the next 24 hours",
    # QR / callback / vishing lures
    "Scan the QR code to verify your account and avoid suspension",
    "You missed a delivery scan the QR code to reschedule now",
    "Our fraud team called you call back immediately to avoid account closure",
    "Voicemail attachment: listen to secure message from your bank",
    "We tried to deliver your parcel twice scan QR to book redelivery",
    # BEC / business lures
    "Are you at your desk? I need a quick favor regarding a payment",
    "I'm heading into a meeting can you process the attached wire transfer today",
    "We have a new supplier send payment to the account in the attached invoice",
    "I need you to buy gift cards for the client event today keep it confidential",
    "Change of bank details: please update our account for future invoices",
    "The CEO approved this transfer please execute today it's urgent",
    "HR: your salary increase is ready confirm your details in the portal",
    "IT department: your mailbox will be migrated confirm password to continue",
    "Please review the attached purchase order and confirm delivery date",
    "Your direct deposit failed update your banking information today",
    # Swedish phishing
    "Akut: ditt konto kommer att stängas verifiera din identitet",
    "Du har vunnit 50000 SEK i vårt lotteri hämta din vinst nu",
    "Bekräfta ditt lösenord för att undvika att kontot spärras",
    "Faktura bifogad: betala omedelbart för att undvika påminnelseavgift",
    "Ditt paket kunde inte levereras betala fraktavgift nu",
    "Obehörig åtkomst upptäckt logga in för att skydda ditt konto",
    "Skatteverket: du har ett återbetalningskrav bekräfta dina uppgifter",
    "Uppdatera dina betalningsuppgifter innan ditt konto stängs",
    "Ditt BankID har gått ut verifiera det innan midnatt",
    "PostNord: din försändelse är stoppad betala hanteringsavgift",
    "Din Swish-betalning misslyckades bekräfta ditt konto",
    "Vi har blockerat ditt kort efter misstänkt aktivitet logga in nu",
    "Ditt Microsoft 365-konto kommer att inaktiveras bekräfta åtkomst",
    "Vinstmeddelande: du har vunnit en iPhone bekräfta leveransadress",
    "Betalningspåminnelse: faktura 4451 förfaller idag",
    # Serbian/Croatian phishing
    "Hitno: vaš nalog će biti obustavljen potvrdite identitet odmah",
    "Vaš račun je hakovan kliknite na link da ga zaštitite",
    "Faktura u prilogu platite odmah inače sledi tužba",
    "Dobili ste nagradu od 10000 EUR potvrdite podatke",
    "Vaš paket nije mogao biti dostavljen uplatite carinu",
    "Verifikujte svoj nalog u narednih 24 sata",
    "Vaša kartica je blokirana potvrdite PIN kod",
    "Poštanski servis: plaćanje po preuzimanju potrebno odmah",
    "Vaš nalog za e-bankaristvu zahteva verifikaciju",
    "Obaveštenje o nasleđu: potvrdite podatke za transfer sredstava",
]

# 2025-2026 lure styles (calendar, e-signature, file share, MFA/device-code,
# AiTM, callback, BEC). Wording differs from eval_sets.MODERN_PHISH.
_PHISHING += [
    "Meeting invitation: Annual performance review - accept and log in with your Office credentials to see the agenda",
    "New event: Benefits enrollment deadline. Open the invite and sign in to the HR portal to confirm your selection",
    "Calendar: Policy acknowledgement required. Click the event link and authenticate with your corporate account",
    "You have been invited to edit Budget_2026.xlsx on SharePoint. Sign in to open the document",
    "Adobe Sign: Contract amendment awaiting your signature. Review now, the envelope expires today",
    "Dropbox Transfer: 3 files were sent to you, enter your email password to download",
    "Your authenticator registration will be removed. Re-register MFA today by scanning the code below",
    "To keep using Teams, visit the device login page and enter the code shown in this message",
    "IT Helpdesk: we are migrating mailboxes tonight. Validate your account at the link to avoid data loss",
    "Voicemail received (0:47) from external caller. Listen to the message by signing in with your work email",
    "Your Norton subscription renewed for 399 USD. If you did not authorize this call our billing desk immediately",
    "PayPal invoice: you were charged 649.99 for a crypto purchase. To dispute, call the support number provided",
    "Hi, it's the CEO. I'm in a meeting, can you process an urgent payment to a new supplier? Don't call, just email",
    "Please update the bank account on file for our company, all future invoices must be paid to the new IBAN",
    "Payroll notice: your direct deposit details need confirmation before this month's salary is released",
    "Your Apple account was used to purchase a gift card, if this was not you sign in to cancel the order",
    "Facebook Meta: your page will be deleted for copyright violation. Submit an appeal using the form",
    "Coinbase: withdrawal request pending. Verify it was you or your wallet will be frozen",
    "Kalendarski poziv: obavezna obuka. Prihvatite poziv i prijavite se službenim nalogom",
    "Pošta: paket čeka carinjenje, uplatite 2,49 EUR karticom da ne bude vraćen pošiljaocu",
]

_LEGIT = [
    "Meeting moved to Tuesday at 10 please update your calendar",
    "Here is the quarterly report attached for your review",
    "Thanks for the call today, sending over the contract draft",
    "Reminder: team lunch on Friday at the usual place",
    "Your order 8842 has shipped and arrives Thursday",
    "Welcome aboard! Your onboarding starts Monday at 9",
    "Please review the attached proposal when you have time",
    "Invoice 2024-118 for consulting services, due in 30 days",
    "Happy birthday! Hope you have a great day",
    "The server maintenance window is Sunday 02:00-04:00",
    "New comment on your pull request, please take a look",
    "Your booking is confirmed for Friday 19:00, party of 4",
    "Newsletter: October product updates and webinar schedule",
    "Minutes from yesterday's sync are attached",
    "Can you send me the latest sales numbers by Wednesday",
    "Your password was changed successfully, no action needed",
    "Flight itinerary for your trip to Stockholm attached",
    "Reminder: dentist appointment next Monday 15:30",
    "The project kickoff is scheduled for next week",
    "HR: open enrollment for benefits ends next Friday",
    "Hvala na sastanku, šaljem zapisnik u prilogu",
    "Pozdrav, evo ponude koju smo diskutovali prošle nedelje",
    "Podsećanje: rok za izveštaj je petak",
    "Vaša porudžbina je poslata i stiže za 3 dana",
    "Tack för mötet, bifogar protokollet från idag",
    "Påminnelse: leveransen till kund sker på måndag",
    "Bokningen är bekräftad, välkommen på fredag",
    "Månadsrapporten för september är bifogad",
    "Vi ses på konferensen nästa vecka",
    "Din beställning har skickats och anländer på torsdag",
    # realistic everyday business noise (should stay LOW)
    "Follow-up on the budget discussion from last week",
    "The shared drive cleanup is scheduled for Saturday",
    "Please approve the vacation request in the HR portal",
    "WiFi will be unavailable in building B on Thursday evening",
    "New parking policy starts next month, see attached memo",
    "The client loved the demo, next steps call on Monday",
    "Don't forget to submit your expense reports by Friday",
    "Elevator maintenance tomorrow 08:00-09:00, use the stairs",
    "Coffee machine on floor 3 is broken, vendor called",
    "The design files are in the shared folder, let me know if you can't access",
    "Annual security training is due, complete it by month end",
    "Welcome to the team intro session on Wednesday at 14",
    "Printer on floor 2 is out of toner, replacement ordered",
    "The board meeting agenda is attached, 30 min slots please",
    "IT: VPN client update available, install at your convenience",
    "Reminder: submit timesheets before payroll cutoff on Friday",
    "The library book you reserved is ready for pickup",
    "Gym class schedule for next month is posted in the app",
    "Your package from the bookstore arrived at the front desk",
    "Team offsite moved to the lakeside venue, map attached",
    "Please review my vacation request for the first week of July",
    "The quarterly business review deck is ready for comments",
    "Car service reminder: your appointment is confirmed for Tuesday",
    "Neighborhood association: recycling schedule change next week",
    "School newsletter: parent-teacher conferences next month",
    "Your subscription receipt: thanks for your payment, no action needed",
    "Receipt for your order, thank you for shopping with us",
    "The webinar recording from yesterday is now available",
    "Backup completed successfully last night",
    "Your login from a new device was you, right? Just checking per policy",
]


from .config import DATA_DIR as _DATA_DIR
CORPUS_PATH = os.getenv("CORPUS_PATH", os.path.join(os.path.dirname(__file__), "..", "data", "corpus.csv"))
FEEDBACK_PATH = os.path.join(_DATA_DIR, "feedback.csv")


_INVIS_RE = re.compile("[" + INVISIBLE_CHARS + "]")
_URL_RE = re.compile(r"(?:https?://|www\.)([^/\s:?#]+)\S*")
# bounded repeats: an unbounded [\w.+-]+@ is quadratic on a long run without '@'
_EMAIL_RE = re.compile(r"[\w.+\-]{1,64}@[\w\-]{1,63}(?:\.[\w\-]{1,63}){1,6}")
MAX_MODEL_INPUT_CHARS = 12000        # the vectorizer keeps 4000 normalized characters
_IP_HOST_RE = re.compile(r"^\d{1,3}(?:\.\d{1,3}){3}$")

# local parts that are roles, not a person's identity - never scrubbed
_GENERIC_LOCALPARTS = {
    "info", "sales", "admin", "administrator", "support", "office", "contact", "mail", "email",
    "hello", "team", "help", "service", "billing", "accounts", "account", "finance", "hr", "jobs",
    "marketing", "news", "newsletter", "noreply", "no-reply", "postmaster", "webmaster", "root",
    "user", "test", "me", "all", "staff", "list", "lists", "dev", "security", "abuse", "orders",
    "order", "invoice", "invoices", "payments", "customer", "customers", "members", "kontakt",
    "prodaja", "racunovodstvo", "ured", "kancelarija", "podrska", "faktura", "kundtjanst",
}
_COMMON_ORG_WORDS = {"gmail", "googlemail", "yahoo", "hotmail", "outlook", "live", "icloud", "aol",
                     "proton", "protonmail", "mail", "email", "example", "company", "test", "msn",
                     "yandex", "gmx", "web", "zoho", "me", "mac"}


def scrub_recipient(text: str, to_addrs) -> str:
    """Replace the RECIPIENT's own identifiers with placeholders.

    Public phishing corpora are one person's mailbox: without this the model
    learns that person's name and domain as "phishing words". With it, the
    model learns the transferable pattern instead - "this mail addresses me by
    my e-mail address / talks about my own domain" - and the same substitution
    is applied to every scanned mail, whoever receives it.
    """
    if not text or not to_addrs:
        return text or ""
    if isinstance(to_addrs, str):
        to_addrs = [to_addrs]
    out = text[:60000]
    for addr in list(to_addrs)[:3]:
        addr = (addr or "").strip().lower()
        if "@" not in addr:
            continue
        local, _, dom = addr.partition("@")
        dom = dom.strip(".")
        if not dom:
            continue
        out = re.sub(re.escape(addr), " recipientaddress ", out, flags=re.I)
        labels = dom.split(".")
        org = labels[-2] if len(labels) >= 2 else ""
        if len(labels) >= 3 and labels[-2] in ("co", "com", "org", "net", "ac", "gov", "edu") \
                and len(labels[-1]) == 2:
            org = labels[-3]
        if org and org not in _COMMON_ORG_WORDS:
            out = re.sub(r"(?<![\w@.])" + re.escape(dom) + r"(?![\w])", " recipientdomain ", out, flags=re.I)
            if len(org) >= 4:
                out = re.sub(r"(?<![\w@.\-])" + re.escape(org) + r"(?![\w.\-@])", " recipientorg ", out, flags=re.I)
        for piece in [local] + [x for x in re.split(r"[._\-+]", local) if x != local]:
            if len(piece) >= 4 and piece not in _GENERIC_LOCALPARTS and not piece.isdigit():
                out = re.sub(r"(?<![\w@.\-])" + re.escape(piece) + r"(?![\w@])", " recipientname ", out, flags=re.I)
    return out


def _url_token(m: re.Match) -> str:
    host = m.group(1).lower().strip(".")
    if _IP_HOST_RE.match(host):
        return " urltoken urlip "
    tld = host.rsplit(".", 1)[-1] if "." in host else ""
    return f" urltoken tld{tld} " if tld.isalpha() and len(tld) <= 12 else " urltoken "


def normalize_text(t: str) -> str:
    """Make text era-, script- and identity-independent: the model must learn
    LANGUAGE patterns, not that '2002 mail = legit' or one victim's address.
    Applied identically at train and predict: it is the first step of the pipeline."""
    t = _INVIS_RE.sub("", (t or "")[:MAX_MODEL_INPUT_CHARS])
    t = fold_for_matching(t)                       # lower, Cyrillic->Latin, look-alikes, accents
    t = _URL_RE.sub(_url_token, t)                 # keep only "a link to a .xx site"
    t = _EMAIL_RE.sub(" emailtoken ", t)
    t = re.sub(r"\b(19|20)\d\d\b", " yeartoken ", t)
    t = re.sub(r"\d+", "0", t)
    t = re.sub(r"[=_*~\-#|.]{3,}", " ", t)          # ascii separators
    return re.sub(r"\s+", " ", t)[:4000]


def load_starter(n_synth: int = 1500):
    """Hand-written starter samples + generated modern mail (hard negatives and
    lures in the project's languages)."""
    from .synth_legit import generate, generate_multilingual
    from .synth_phish import generate as generate_phish
    legit = _LEGIT * 3 + generate(n_synth) + generate_multilingual()
    phish = _PHISHING * 3 + generate_phish()
    texts = phish + legit
    labels = [1] * len(phish) + [0] * len(legit)
    return texts, np.array(labels)


def eval_training_extras():
    """Non-corpus training data, exposed for the evaluation harness."""
    return load_starter()


def _read_csv(path, with_meta=False):
    rows = []
    path = os.path.abspath(path)
    if not os.path.exists(path):
        return rows
    csv.field_size_limit(10_000_000)
    with open(path, newline="", encoding="utf-8") as f:
        for r in csv.reader(f):
            if len(r) < 2 or r[0] == "text":
                continue
            try:
                label = int(r[1])
            except ValueError:
                continue
            if label in (0, 1):
                rows.append((r[0], label, r[2] if len(r) > 2 else "feedback",
                             int(r[3]) if len(r) > 3 and r[3].isdigit() else 0))
    return rows


FEEDBACK_WEIGHT = 5
# Measured: adding the 5,600 legacy phishing mails WITHOUT the Enron business
# mail made the model flag 24% of held-out business mail (0.7% with both).
# If a legitimate source failed to download, the phishing side is trimmed to
# keep the classes balanced instead of silently shipping that model.
MAX_PHISH_PER_LEGIT = 1.25


def balance_corpus(rows: list, verbose: bool = True) -> list:
    """Drop oldest-era phishing (nazario_legacy) until phishing <= 1.25 x legit."""
    n_ph = sum(1 for r in rows if r[1] == 1)
    n_lg = len(rows) - n_ph
    limit = int(MAX_PHISH_PER_LEGIT * n_lg)
    if n_lg == 0 or n_ph <= limit:
        return rows
    excess = n_ph - limit
    legacy = [i for i, r in enumerate(rows) if r[1] == 1 and r[2] == "nazario_legacy"]
    # deterministic: evenly spaced, so every legacy mailbox/year stays represented
    drop = set(legacy[:: max(1, len(legacy) // excess)][:excess]) if legacy else set()
    if verbose:
        import logging
        logging.getLogger("antiphish").warning(
            "corpus is unbalanced (%d phishing / %d legit): dropping %d legacy phishing samples. "
            "A legitimate-mail source is probably missing - re-run scripts/build_corpus.py.",
            n_ph, n_lg, len(drop))
    return [r for i, r in enumerate(rows) if i not in drop]


def load_dataset(include_feedback: bool = True, with_meta: bool = False):
    """Real corpus (data/corpus.csv) + starter samples + your feedback.
    Falls back to the starter corpus if corpus.csv was not built yet."""
    rows = balance_corpus(_read_csv(CORPUS_PATH))
    st, sy = load_starter()
    rows += [(t, int(y), "starter", 2026) for t, y in zip(st, sy)]
    if include_feedback:
        # your own mail is the most valuable data -> weight x5
        rows += [(t, y, "feedback", 2026) for t, y, *_ in _read_csv(FEEDBACK_PATH)] * FEEDBACK_WEIGHT
    texts = [r[0] for r in rows]
    y = np.array([r[1] for r in rows])
    if with_meta:
        return texts, y, [r[2] for r in rows]
    return texts, y


def normalize_batch(texts) -> list[str]:
    """Pipeline step: normalize every document exactly once (both vectorizers
    then work on the result). Module-level so the fitted model can be pickled."""
    return [normalize_text(t) for t in texts]


def _identity(t: str) -> str:
    return t


def build_pipeline() -> Pipeline:
    from sklearn.pipeline import FeatureUnion
    from sklearn.preprocessing import FunctionTransformer
    features = FeatureUnion([
        ("word", TfidfVectorizer(preprocessor=_identity, lowercase=False, ngram_range=(1, 2),
                                 min_df=2, max_df=0.9, max_features=60000,
                                 sublinear_tf=True)),
        # char n-grams resist obfuscation: 'P a y P a l', 'verífy', 'acc0unt'
        ("char", TfidfVectorizer(preprocessor=_identity, lowercase=False, analyzer="char_wb",
                                 ngram_range=(3, 5), min_df=3, max_features=80000,
                                 sublinear_tf=True)),
    ])
    # Linear SVM chosen on the held-out protocol (evaluation.py): at 1% false
    # positives it caught 96.5% of 2024-2025 phishing vs 94.6% for the v0.9
    # logistic regression, with better calibration and much faster training.
    # Calibration turns the SVM margin into a probability (needed for risk scoring).
    # It wraps only the classifier, so the text is normalized and vectorized once
    # instead of once per calibration fold.
    clf = CalibratedClassifierCV(LinearSVC(C=1.0, class_weight="balanced", random_state=0),
                                 cv=3, method="sigmoid", ensemble=False)
    return Pipeline([("normalize", FunctionTransformer(normalize_batch)),
                     ("features", features), ("clf", clf)])


def evaluate(pipe=None, verbose: bool = True) -> dict:
    """Honest evaluation - see antiphish/evaluation.py."""
    from .evaluation import evaluate_text_model
    return evaluate_text_model(verbose=verbose)


def train(include_feedback: bool = True):
    texts, y = load_dataset(include_feedback=include_feedback)
    pipe = build_pipeline()
    pipe.fit(texts, y)
    return pipe


def dataset_summary(include_feedback: bool = True) -> dict:
    """Counts per source/label of what train() would use (for the model card)."""
    texts, y, src = load_dataset(include_feedback=include_feedback, with_meta=True)
    out: dict = {}
    for s_, lab in zip(src, y):
        d = out.setdefault(s_, {"phishing": 0, "legit": 0})
        d["phishing" if lab == 1 else "legit"] += 1
    return {"total": len(texts), "phishing": int((y == 1).sum()), "legit": int((y == 0).sum()),
            "by_source": out, "corpus_present": os.path.exists(os.path.abspath(CORPUS_PATH))}


def _sha256(path: str) -> str:
    import hashlib
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def save_model(pipe, path: str, meta: dict | None = None):
    """Save model + SHA256 sidecar (verified on load) + metadata ("model card")."""
    import sklearn

    from . import __version__
    tmp = path + ".tmp"
    joblib.dump(pipe, tmp)
    _owner_writable_only(tmp)
    os.replace(tmp, path)                       # atomic: a reader never sees half a file
    with open(path + ".sha256", "w") as f:
        f.write(_sha256(path))
    card = {"antiphish_version": __version__, "feature_version": FEATURE_VERSION,
            "sklearn_version": sklearn.__version__,
            "trained_at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())}
    card.update(meta or {})
    with open(path + ".meta.json", "w", encoding="utf-8") as f:
        json.dump(card, f, indent=1, ensure_ascii=False)
    for ext in (".sha256", ".meta.json"):
        _owner_writable_only(path + ext)


def _owner_writable_only(path: str):
    """A model file is a pickle: whoever can write it runs code in the scanner. Do not
    leave the permissions to the caller's umask ("docker exec" can run with umask 0)."""
    try:
        os.chmod(path, 0o644)
    except OSError:
        pass    # e.g. a Windows/network file system without POSIX permissions


class ModelIntegrityError(RuntimeError):
    pass


def model_meta(path: str) -> dict:
    try:
        with open(path + ".meta.json", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {}


def load_model(path: str):
    """joblib/pickle can execute code -> refuse a model file whose hash does
    not match the sidecar written by save_model(). A model trained with a
    different feature pipeline or scikit-learn version is refused as well: it
    would load, and then score every mail wrongly without any error."""
    side = path + ".sha256"
    if not os.path.exists(side):
        raise ModelIntegrityError(f"Missing {side} - retrain with: python train.py")
    with open(side) as f:
        expected = f.read().strip()
    if _sha256(path) != expected:
        raise ModelIntegrityError(f"Model file {path} was modified (hash mismatch) - refusing to load")
    meta = model_meta(path)
    if meta.get("feature_version") != FEATURE_VERSION:
        raise ModelIntegrityError(
            f"Model {path} was trained with feature version {meta.get('feature_version')!r}, "
            f"this code needs {FEATURE_VERSION} - retrain with: python train.py")
    import sklearn
    if meta.get("sklearn_version") and meta["sklearn_version"] != sklearn.__version__:
        raise ModelIntegrityError(
            f"Model {path} was trained with scikit-learn {meta['sklearn_version']}, "
            f"installed is {sklearn.__version__} - retrain with: python train.py")
    return joblib.load(path)
