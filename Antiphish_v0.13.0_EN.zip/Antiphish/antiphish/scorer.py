"""Scoring: heuristic signals + ML probability -> risk score 0..100 and a level.

Everything is expressed in *evidence points* and squashed once:

    score = 100 * (1 - exp(-K * points))            K = 0.035
    10 pts -> 30 (SUSPICIOUS)   26 pts -> 60 (HIGH)   54 pts -> 85 (CRITICAL)

Why v0.9 was replaced
---------------------
v0.9 computed 0.55*heuristic + 0.45*ML with heuristic = 100*(1-exp(-0.035*sum)).
* a NEGATIVE sum exploded: SPF+DKIM+DMARC pass (-15) alone turned into -69, so an
  authenticated phishing mail with ML=0.99 scored 7 (LOW). Half of the 2024-2025
  corpus phishing passes all three checks.
* no component could reach HIGH alone: 200 points of evidence with ML=0 gave 54.9.

The model here: three tiers of evidence
---------------------------------------
firm      technical indicators (look-alike domain, DMARC failure, credential form,
          executable in an archive, device-code lure ...). Counted in full;
          nothing can argue them away.
context   facts that are suspicious in a phishing mail and ordinary elsewhere
          (free hosting, URL shortener, redirect, Reply-To on another domain,
          "parcel held, pay a fee" wording). Counted in proportion to how
          phishing-like the text model finds the message.
soft      generic wording (urgency, money, "log in"). As context, and capped:
          a pile of weak hints is still weak.
ML        adds up to ML_MAX points when confident of phishing. Alone it tops out
          just inside HIGH; CRITICAL needs technical evidence.
mitigation negative signals (authenticated newsletter, verified brand sender)
          reduce the context + soft + ML part only.

    factor = SOFT_FLOOR + (1 - SOFT_FLOOR) * min(1, p / 0.5)       p = ML probability
    points = firm + max(0, (context + min(soft, SOFT_CAP)) * factor + ML - mitigation)
"""
from __future__ import annotations

import math

from .config import ML_MAX_POINTS, SCORE_K, SOFT_CAP, SOFT_FLOOR, THRESHOLDS

# generic wording and cosmetic URL hints: individually common in legitimate mail
SOFT_SIGNALS = {
    "text_urgency_low", "text_urgency_high", "text_money_pressure", "text_credential_ask",
    "text_login_prompt", "text_generic_greeting", "text_threat", "text_excessive_caps",
    "text_document_lure", "text_payment_request", "text_bec_pretext", "text_spaced_letters",
    "url_no_https", "url_very_long", "url_many_subdomains", "url_many_dashes", "url_uncommon_tld",
    "sender_generic_role", "auth_missing", "calendar_invite_links",
}
# suspicious only in company: weighted by how phishing-like the text is
CONTEXT_SIGNALS = {
    "url_free_hosting", "url_shortener", "url_open_redirect", "url_suspicious_tld",
    "url_nonstandard_port", "url_credential_keywords", "url_brand_in_path", "url_brand_mention",
    "url_private_ip", "sender_suspicious_tld", "sender_internal_role_external",
    "sender_urgent_word", "reply_to_other_domain",
    "html_body_form", "html_body_active_content", "html_body_redirect", "html_image_only_link",
    "html_hidden_text", "text_advance_fee", "text_refund_lure", "text_delivery_fee_lure",
    "text_prize_lure", "text_qr_lure", "text_mailbox_lure",
}


def tier_of(sig: dict) -> str:
    """'firm' | 'context' | 'soft' (an explicit sig['tier'] wins over the tables)."""
    t = sig.get("tier")
    if t in ("firm", "context", "soft"):
        return t
    name = sig["signal"]
    if name in SOFT_SIGNALS:
        return "soft"
    if name in CONTEXT_SIGNALS:
        return "context"
    return "firm"


def is_soft(name: str) -> bool:
    """True for anything that is not firm evidence (kept for older callers)."""
    return name in SOFT_SIGNALS or name in CONTEXT_SIGNALS


def ml_factor(ml_prob: float) -> float:
    """How much of the context/soft evidence counts, given the text model's view."""
    p = min(max(float(ml_prob), 0.0), 1.0)
    return SOFT_FLOOR + (1.0 - SOFT_FLOOR) * min(1.0, p / 0.5)


def ml_points(ml_prob: float, scale: float = 1.0) -> float:
    """Evidence points the text model adds on its own."""
    p = min(max(float(ml_prob), 0.0), 1.0)
    return ML_MAX_POINTS * max(0.0, (p - 0.5) / 0.5) * scale


def level_for(score: float) -> str:
    if score < THRESHOLDS["SUSPICIOUS"]:
        return "LOW"
    if score < THRESHOLDS["HIGH"]:
        return "SUSPICIOUS"
    if score < THRESHOLDS["CRITICAL"]:
        return "HIGH"
    return "CRITICAL"


def points_to_score(points: float) -> float:
    return 100.0 * (1.0 - math.exp(-SCORE_K * max(0.0, points)))


def breakdown(signals: list[dict], ml_prob: float, ml_scale: float = 1.0) -> dict:
    """The arithmetic behind a score (shown in reports and used by tests)."""
    firm = context = soft_raw = mitigation = 0.0
    for s in signals:
        w = s["weight"]
        if w < 0:
            mitigation -= w
        elif w > 0:
            t = tier_of(s)
            if t == "firm":
                firm += w
            elif t == "context":
                context += w
            else:
                soft_raw += w
    soft = min(float(SOFT_CAP), soft_raw)
    f = ml_factor(ml_prob)
    ml = ml_points(ml_prob, ml_scale)
    reducible = max(0.0, (context + soft) * f + ml - mitigation)
    total = firm + reducible
    return {"firm": round(firm, 1), "context": round(context, 1), "soft": round(soft, 1),
            "soft_uncapped": round(soft_raw, 1), "ml_factor": round(f, 2), "ml": round(ml, 1),
            "mitigation": round(mitigation, 1), "points": round(total, 1)}


def score_signals(signals: list[dict], ml_prob: float, n_urls: int = 1,
                  ml_scale: float = 1.0) -> tuple[float, list[dict], str]:
    b = breakdown(signals, ml_prob, ml_scale)
    final = points_to_score(b["points"])
    final = round(max(0.0, min(final, 100.0)), 1)
    return final, signals, level_for(final)
