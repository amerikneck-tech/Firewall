"""Main orchestrator: pass an email dict (or parsed .eml content) -> verdict."""
from __future__ import annotations

import json
import os
import re
import threading as _threading

from .brands import official_brand_of_host
from .checks import (check_url, check_urls_aggregated, check_links, registrable_domain,  # noqa: F401
                     _extract_addr, _domain_of_addr, check_sender, check_auth, check_display_name,
                     check_freemail_sender, check_attachments, check_recipient_context,
                     extract_urls, auth_aligned, domain_of)
from .config import MODEL_PATH as _MODEL_PATH
from .config import THRESHOLDS
from .domains import FREEMAIL_DOMAINS, platform_of
from .features import analyze_text
from .model import load_model, scrub_recipient, train
from .scorer import breakdown, score_signals, tier_of

_model = None
_model_lock = _threading.Lock()
_model_mtime: float | None = None      # set only when _get_model() itself loaded the file
_model_checked = 0.0
MODEL_RECHECK_SECONDS = 30

MAX_INLINE_IMAGES_SCANNED = 8
MAX_BODY_CHARS = 200_000


def _file_mtime(path: str) -> float | None:
    try:
        return os.path.getmtime(path)
    except OSError:
        return None


def _get_model():
    """The text model, loaded once. A model file replaced on disk (after
    `python -m antiphish.learn`) is picked up within MODEL_RECHECK_SECONDS -
    no restart needed. A model injected by tests/evaluation is left alone."""
    global _model, _model_mtime, _model_checked
    path = os.path.abspath(_MODEL_PATH)
    if _model is not None:
        import time
        now = time.monotonic()
        if _model_mtime is None or now - _model_checked < MODEL_RECHECK_SECONDS:
            return _model
        _model_checked = now
        mt = _file_mtime(path)
        if mt is None or mt == _model_mtime:
            return _model
        with _model_lock:
            try:
                fresh = load_model(path)
                _model, _model_mtime = fresh, mt
                import logging
                logging.getLogger("antiphish").info("reloaded retrained model from %s", path)
            except Exception as e:           # half-written / invalid file: keep serving the old one
                import logging
                logging.getLogger("antiphish").warning("new model file not usable yet (%s)", e)
        return _model
    with _model_lock:
        if _model is not None:
            return _model
        loaded = None
        if os.path.exists(path):
            try:
                loaded = load_model(path)
            except Exception as e:  # tampered/missing hash/version mismatch
                import logging
                logging.getLogger("antiphish").warning(
                    "Model not loaded (%s) - retraining a fresh model", e)
        if loaded is None:
            # no usable model file: train once and SAVE it, so the next start is instant
            from .model import save_model
            loaded = train()
            try:
                os.makedirs(os.path.dirname(path), exist_ok=True)
                save_model(loaded, path)
            except OSError:
                pass
        _model_mtime = _file_mtime(path)
        _model = loaded
    return _model


def reload_model():
    """Drop the cached model so the next scan loads the file again."""
    global _model, _model_mtime
    with _model_lock:
        _model, _model_mtime = None, None


def analyze_email(email: dict, use_url_intel: bool = True, use_llm: bool = False) -> dict:
    """email: dict with keys
    subject, body, sender, reply_to (optional),
    spf/dkim/dmarc (optional: 'pass'|'fail'|'none'),
    urls (optional), attachments (optional list),
    claimed_role (optional: 'it'|'billing'|'ceo'|'support')
    plus everything email_parser.parse_message() adds (links, to, html, ...).
    """
    subject = (email.get("subject", "") or "")[:2000]
    body = (email.get("body", "") or "")[:MAX_BODY_CHARS]
    sender = (email.get("sender", "") or "")[:1000]
    text = f"{subject} {body}".strip()
    html = email.get("html") or {}

    # a brand's own notification platform, proven by aligned DMARC: "Ana (via Google
    # Docs) <...@google.com>" with Reply-To: ana@gmail.com is how these mails work
    platform_ctx = dict(email, _verified_platform=_is_verified_brand_domain(email))

    signals = []
    signals += analyze_text(text, phones=email.get("phones"), html=html)
    signals += check_sender(sender, email.get("reply_to"), platform_ctx)
    signals += check_display_name(sender)
    signals += check_freemail_sender(sender, email.get("claimed_role"), subject)
    signals += check_auth(email.get("spf"), email.get("dkim"), email.get("dmarc"), email)
    signals += check_recipient_context(email)
    signals += check_attachments(email.get("attachments"))
    signals += _html_body_signals(email, html)

    # content-level attachment scan (PDF text, embedded URLs, VT hash)
    payloads = dict(email.get("attachment_data") or {})
    inline = email.get("inline_images") or {}
    attachment_findings: list[str] = []
    if payloads or inline:
        from .attachment_scan import (analyze_attachment, analyze_attachment_isolated,
                                      passwords_from_text)
        from .config import ATTACHMENT_SANDBOX
        passwords = passwords_from_text(text)  # "zip password: 1234" in the body

        def scan(fname, data):
            if ATTACHMENT_SANDBOX:
                return analyze_attachment_isolated(fname, data, passwords=passwords)
            return analyze_attachment(fname, data, model=_get_model(), passwords=passwords)

        for fname, data in payloads.items():
            sigs, findings = scan(fname, data)
            signals += sigs
            attachment_findings += findings
        # images embedded in the body: only interesting when they hide something
        # (QR code, executable posing as a picture) - logos stay out of the report
        for fname, data in list(inline.items())[:MAX_INLINE_IMAGES_SCANNED]:
            sigs, findings = scan(fname, data)
            if sigs:
                for s in sigs:
                    s = dict(s)
                    s["detail"] = s["detail"].replace(fname, f"image in the message body ({fname})")
                    signals.append(s)
                attachment_findings += findings

    urls = email.get("urls") or extract_urls(body + " " + subject)
    url_signals = check_urls_aggregated(urls, sender)
    bulk_candidate = bool(email.get("list_unsubscribe")) and auth_aligned(email)
    url_signals += check_links(email.get("links"), sender, authenticated_bulk=bulk_candidate)
    if use_url_intel and urls:
        from .urlintel import url_reputation
        for u in urls[:3]:  # limit API calls
            url_signals += url_reputation(u)
    signals += url_signals
    signals = _merge_correlated(_dedupe(signals))

    model = _get_model()
    # same recipient-neutral text the model was trained on (see model.scrub_recipient)
    ml_text = scrub_recipient(f"{subject}\n{body}".strip(), email.get("to"))
    ml_prob = float(model.predict_proba([ml_text])[0][1]) if ml_text.strip() else 0.0

    # Trust that is EARNED, never assumed from "DMARC passed" alone (most modern
    # phishing passes it). Both discounts vanish as soon as one firm indicator exists.
    ml_scale = 1.0
    bulk = _legit_bulk_sender(email, signals) if ml_prob < BULK_TRUST_MAX_ML else None
    if bulk:
        signals.append(bulk)
        ml_scale = 0.6   # the text model can over-flag marketing language
    brand = _verified_brand_sender(email, signals)
    if brand:
        signals.append(brand)
        ml_scale = min(ml_scale, 0.5)

    if use_llm:
        from .llm_judge import judge_email
        # what the scanner concludes on its own - the LLM is a second opinion on top of it
        _own_score, _, own_level = score_signals(signals, ml_prob, ml_scale=ml_scale)
        att_sigs = [f"{x['signal']}: {x['detail']}" for x in signals
                    if x["signal"].startswith(("attachment", "archive", "office", "pdf",
                                               "html", "svg", "qr", "rtf", "calendar"))]
        llm_sigs = judge_email(subject, body, sender,
                               attachment_report="\n".join(att_sigs + attachment_findings),
                               context=_llm_context(email, urls, signals))
        strong = _strong_signals(signals)          # all firm evidence (LLM excluded)
        # corroboration must be TECHNICAL: text heuristics read the same words the
        # LLM reads, so counting them would double-count one piece of evidence
        technical = [n for n in strong if not n.startswith("text_")]
        authed = _authenticated_aligned(email)
        for ls in llm_sigs:
            ls = dict(ls)
            if ls["weight"] < 0 and strong:
                # prompt-injection guard: "clean" can't cancel hard evidence
                ls["weight"] = 0
                ls["detail"] += f" [ignored: conflicts with {strong[0]}]"
            elif ls["weight"] < 0 and own_level in ("HIGH", "CRITICAL"):
                # ...nor talk the scanner out of a HIGH rating. The model reads text the
                # sender wrote ("this message is safe"), and small models call most
                # phishing legitimate (measured: qwen2.5:3b, 49 of 51 scenarios). It may
                # clear a mail that is merely SUSPICIOUS, nothing more.
                ls["weight"] = 0
                ls["detail"] += f" [ignored: the scanner's own evidence already rates this mail {own_level}]"
            elif ls["weight"] > 0 and not technical:
                # LLM alone, no technical corroboration -> tie-breaker only
                cap = 8 if authed else 15
                if ls["weight"] > cap:
                    ls["weight"] = cap
                    ls["detail"] += (" [uncorroborated: sender authenticated, weight capped]"
                                     if authed else " [uncorroborated: weight capped]")
            ls.pop("red_flags", None); ls.pop("confidence", None)
            signals.append(ls)

    score, signals, level = score_signals(signals, ml_prob, ml_scale=ml_scale)

    # Hard evidence overrides the text-based ML blend: an .exe in a zip is
    # dangerous no matter how innocent the email text looks.
    hard = [x for x in signals if x["signal"] in HARD_EVIDENCE]
    if hard and score < 90:
        score = max(score, 90.0)
        level = "CRITICAL"
        signals.append({"signal": "hard_evidence_override", "weight": 0,
                        "detail": f"Score raised to CRITICAL due to: {hard[0]['signal']}"})

    for sg in signals:                       # shown in the UI: which evidence is "context"
        if sg["weight"] > 0:
            sg.setdefault("tier", tier_of(sg))

    return {
        "score": score,
        "level": level,
        "thresholds": THRESHOLDS,
        "ml_phishing_probability": round(ml_prob, 3),
        "score_breakdown": breakdown([s for s in signals if s["signal"] != "hard_evidence_override"],
                                     ml_prob, ml_scale),
        "urls_found": urls,
        "attachment_findings": attachment_findings,
        "signals": sorted(signals, key=lambda s: -s["weight"]),
        "verdict": _verdict_text(level),
    }


HARD_EVIDENCE = {
    "attachment_executable", "attachment_type_mismatch", "attachment_double_extension",
    "attachment_rtlo_trick", "attachment_vt_malicious", "url_vt_malicious",
    "url_urlscan_malicious", "html_smuggling", "office_remote_template", "office_dde",
    "archive_zip_bomb",
}

# kept for backward compatibility (v0.9 names); the live rule is _strong_signals()
STRONG_SIGNALS = {
    "text_credential_ask", "text_threat", "url_ip_host", "url_brand_spoof", "url_punycode",
    "url_at_symbol", "sender_displayname_spoof", "sender_mixed_alphabet", "reply_to_mismatch",
    "url_vt_malicious", "url_vt_flagged", "url_urlscan_malicious", "attachment_risky",
}
STRONG_PREFIXES = ("attachment_", "archive_", "office_", "pdf_", "html_", "svg_",
                   "qr_", "rtf_", "auth_")
FIRM_MIN_WEIGHT = 8
# List-Unsubscribe + aligned DMARC is something any sender can set up (a quarter of
# the corpus phishing rated LOW in testing had exactly that). The newsletter
# discount is therefore small and is not given when the text model is this sure.
BULK_TRUST_MAX_ML = 0.85


def _dedupe(signals: list[dict]) -> list[dict]:
    """The same finding can arrive twice (body link + the same link in a PDF):
    keep the strongest instance of each (signal, detail) pair."""
    seen: dict[tuple, dict] = {}
    order = []
    for s in signals:
        key = (s["signal"], s.get("detail", ""))
        if key not in seen:
            seen[key] = s
            order.append(key)
        elif s["weight"] > seen[key]["weight"]:
            seen[key] = s
    return [seen[k] for k in order]


# groups of signals that are different views of ONE fact; only the strongest
# member keeps its full weight, the others are reduced so one observation is
# not counted two or three times
_CORRELATED = [
    ("sender_displayname_spoof", "sender_domain_brand_spoof", "sender_lookalike_domain",
     "sender_display_address_mismatch"),
    ("sender_impersonates_recipient_org", "sender_internal_role_external", "sender_freemail_role"),
    ("text_bank_detail_change", "text_payment_request"),
]
_CORRELATED_RESIDUAL = 6


def _merge_correlated(signals: list[dict]) -> list[dict]:
    for group in _CORRELATED:
        members = [s for s in signals if s["signal"] in group and s["weight"] > 0]
        if len(members) < 2:
            continue
        top = max(members, key=lambda s: s["weight"])
        for s in members:
            if s is not top and s["weight"] > _CORRELATED_RESIDUAL:
                s["weight"] = _CORRELATED_RESIDUAL
                s["detail"] += " [same finding as " + top["signal"] + ", counted once]"
    return signals


_TRANSACTION_SUBJECT = re.compile(
    r"(?i)\b(order|invoice|receipt|payment|subscription|renewal|renewed|purchase|transaction|billing|"
    r"statement|confirmation|shipment|refund|charged|narud[zž]b\w*|faktur\w*|ra[cč]un\w*|uplat\w*|"
    r"pretplat\w*|potvrd\w*|best[aä]llning\w*|faktura|kvitto|betalning\w*|orderbekr[aä]ftelse)\b")


def _html_body_signals(email: dict, html: dict) -> list[dict]:
    """What the HTML body *does* (forms, script links, picture-only lures)."""
    out = []
    if not html:
        return out
    flags = set(html.get("flags") or [])
    forms = html.get("forms") or []
    if any(f.get("password") for f in forms) or "password_input" in flags:
        out.append({"signal": "html_body_credential_form", "weight": 30,
                    "detail": "The message body itself contains a password field"})
    elif any((f.get("action") or "").lower().startswith("http") for f in forms):
        out.append({"signal": "html_body_form", "weight": 6,
                    "detail": "The message body contains a form that posts to a web site"})
    # (file: links are left out: they turn up in ordinary technical mail)
    bad_links = sorted(f for f in flags if f in ("link_javascript", "link_data", "link_vbscript",
                                                 "link_blob"))
    if bad_links:
        out.append({"signal": "html_script_link", "weight": 15,
                    "detail": "Links use " + ", ".join(b.split("_", 1)[1] + ":" for b in bad_links)
                              + " instead of a normal web address"})
    if "meta_refresh" in flags:
        out.append({"signal": "html_body_redirect", "weight": 12,
                    "detail": "The message body tries to redirect automatically"})
    if "script" in flags or "iframe" in flags:
        out.append({"signal": "html_body_active_content", "weight": 6,
                    "detail": "The message body contains script / iframe markup"})
    # the whole lure is a picture: nothing for a text filter to read
    plain = len(email.get("body_plain") or "")
    if email.get("has_html") and (html.get("visible_chars") or 0) < 80 and plain < 80 \
            and ((html.get("images") or 0) >= 1 or "cid_image" in flags):
        if (html.get("linked_images") or 0) >= 1:
            out.append({"signal": "html_image_only_link", "weight": 12,
                        "detail": "The message is just a clickable picture with almost no text "
                                  "(hides the wording from filters)"})
        elif _TRANSACTION_SUBJECT.search(email.get("subject") or ""):
            dom = _domain_of_addr(_extract_addr(email.get("sender", "")))
            free = dom in FREEMAIL_DOMAINS or registrable_domain(dom) in FREEMAIL_DOMAINS
            out.append({"signal": "image_only_message", "weight": 24 if free else 16,
                        "detail": "An 'order / invoice / payment' notice that is only a picture"
                                  + (" and comes from a free mailbox" if free else "")
                                  + " (fake-invoice callback scams hide their text in an image)"})
    return out


def _authenticated_aligned(email: dict) -> bool:
    return auth_aligned(email)


def _plain(text: str, limit: int = 170) -> str:
    """One harmless line for the LLM prompt: finding details quote sender-controlled
    strings (display names, domains), so nothing that could look like markup or a
    new instruction block is passed on."""
    return re.sub(r"\s+", " ", re.sub(r"[^\w .,:;@/'()+%=&?#\[\]-]", " ", text or ""))[:limit].strip()


def _llm_context(email: dict, urls: list[str], signals: list[dict]) -> str:
    """Facts from our own scanner, so the LLM doesn't judge text in a vacuum.

    v0.10.1: says what KIND of domain the sender uses and lists the findings with
    their details instead of bare signal names. Measured with qwen2.5:3b on the 101
    scenarios: phishing recognised 2/51 before, 45/51 after; legitimate 50/50 both."""
    from_dom = registrable_domain(_extract_addr(email.get("sender", "")))
    brand = official_brand_of_host(from_dom) if from_dom else None
    if from_dom in FREEMAIL_DOMAINS:
        kind = "a free mailbox provider - anyone can open an address there"
    elif brand:
        kind = f"a real domain of '{brand}'"
    else:
        kind = "not a domain of any brand known to the scanner"
    lines = [f"- From domain: {from_dom or 'unknown'} ({kind})",
             f"- Authentication: SPF={email.get('spf') or '?'} DKIM={email.get('dkim') or '?'} "
             f"DMARC={email.get('dmarc') or '?'}; aligned with From domain: "
             f"{'YES' if _authenticated_aligned(email) else 'NO/unknown'}",
             f"- List-Unsubscribe header (bulk/newsletter): "
             f"{'yes' if email.get('list_unsubscribe') else 'no'}"]
    doms = []
    for u in urls:
        d = registrable_domain(domain_of(u))
        if d and d not in doms:
            doms.append(d)
    if doms:
        tagged = [f"{d} ({'same as sender' if d == from_dom else 'other'})" for d in doms[:8]]
        lines.append("- Link domains: " + ", ".join(tagged))
    else:
        lines.append("- Link domains: none")
    found = sorted((x for x in signals if x["weight"] >= 10), key=lambda x: -x["weight"])[:8]
    if found:
        lines.append("- Red flags found by the scanner (quoted parts come from the email):")
        lines += [f"    * {x['signal']}: {_plain(x['detail'])}" for x in found]
    else:
        lines.append("- Red flags found by the scanner: none")
    return "\n".join(lines)


# wording that a genuine newsletter does not contain
_LURE_TEXT = {"text_credential_ask", "text_threat", "text_mailbox_lure", "text_refund_lure",
              "text_delivery_fee_lure", "text_prize_lure", "text_advance_fee"}


def _strong_signals(signals: list[dict]) -> list[str]:
    """Firm evidence: positive, full-weight tier, not the LLM's own opinion."""
    out = []
    for sg in signals:
        n = sg["signal"]
        if sg["weight"] < FIRM_MIN_WEIGHT or n.startswith("llm_"):
            continue
        if tier_of(sg) == "firm":
            out.append(n)
    return out


def _lure_wording(signals: list[dict]) -> list[str]:
    return [sg["signal"] for sg in signals if sg["weight"] > 0 and sg["signal"] in _LURE_TEXT]


def _legit_bulk_sender(email: dict, signals: list[dict]) -> dict | None:
    """Legitimate bulk sender (newsletter): authenticated + aligned to the From
    domain + List-Unsubscribe + NOT ONE firm indicator and no lure wording.
    (Attackers send through ESPs too: 14% of the 2024-2025 corpus phishing carries
    List-Unsubscribe, 60% passes DMARC.)"""
    if not email.get("list_unsubscribe"):
        return None
    if not auth_aligned(email):
        return None
    if _strong_signals(signals) or _lure_wording(signals):
        return None
    from_dom = registrable_domain(_extract_addr(email.get("sender", "")))
    return {"signal": "legit_bulk_sender", "weight": -12,
            "detail": f"Authenticated newsletter from {from_dom} (DMARC aligned, List-Unsubscribe, "
                      f"no phishing indicators)"}


def _is_verified_brand_domain(email: dict) -> str | None:
    """Brand key when the mail provably comes from that brand's own domain."""
    if not auth_aligned(email):
        return None
    dom = _domain_of_addr(_extract_addr(email.get("sender", "")))
    if not dom or dom in FREEMAIL_DOMAINS or registrable_domain(dom) in FREEMAIL_DOMAINS:
        return None
    if platform_of(dom):
        return None
    return official_brand_of_host(dom)


def _verified_brand_sender(email: dict, signals: list[dict]) -> dict | None:
    """Mail that provably comes from a known brand's own domain (DMARC aligned).
    Platform abuse exists (real PayPal invoices carrying a scam note), so this is
    a discount on WORDING, cancelled by any firm indicator - not a free pass."""
    brand = _is_verified_brand_domain(email)
    if not brand or _strong_signals(signals):
        return None
    dom = _domain_of_addr(_extract_addr(email.get("sender", "")))
    return {"signal": "sender_verified_brand", "weight": -12,
            "detail": f"Authenticated mail from {registrable_domain(dom)}, an official '{brand}' domain"}


def analyze_eml(path: str, use_url_intel: bool = True, use_llm: bool = False) -> dict:
    """Analyze a raw .eml file directly."""
    from .email_parser import parse_eml
    return analyze_email(parse_eml(path), use_url_intel=use_url_intel, use_llm=use_llm)


def _verdict_text(level: str) -> str:
    return {
        "LOW": "No strong phishing indicators detected. Normal caution applies.",
        "SUSPICIOUS": "Some suspicious patterns detected. Verify the sender before clicking any links.",
        "HIGH": "Likely phishing. Do not click links or open attachments. Report to IT security.",
        "CRITICAL": "Almost certainly phishing. Block the sender, report the message, and do not interact.",
    }[level]


def export_json(result: dict, path: str):
    with open(path, "w", encoding="utf-8") as f:
        json.dump(result, f, indent=2, ensure_ascii=False)
