"""Generator of phishing-lure training text for what the public corpora lack.

The Nazario corpus is one English-speaking researcher's inbox: almost no
Bosnian/Croatian/Serbian or Swedish, and very little business-email-compromise
(BEC has no links, so it rarely lands in a phishing collection). Without
examples the text model scores such mail as "legitimate".

Each sample is assembled from independent fragments (opening + problem +
demand + pressure + closing), so the model sees many combinations instead of
memorising whole sentences. Wording intentionally differs from eval_sets.py
(the held-out probes). The texts are short lure descriptions for training a
detector: no working link, kit, sender infrastructure or template markup.

Honest limits: generated text teaches vocabulary and structure of a lure
family; it is not a substitute for real labelled mail. Feed real examples
through data/feedback.csv.
"""
from __future__ import annotations

import random

R = random.Random()


def _c(seq):
    return R.choice(seq)


# =============================================================== Bosnian / Croatian / Serbian
_BCS_BRANDS_BANK = ["Raiffeisen banka", "UniCredit banka", "Intesa banka", "NLB banka", "Sparkasse banka",
                    "OTP banka", "Addiko banka", "ProCredit banka", "Erste banka", "Poštanska štedionica",
                    "vaša banka", "PBZ", "Zagrebačka banka", "ASA banka", "BBI banka"]
_BCS_BRANDS_POST = ["Pošta Srbije", "BH Pošta", "Hrvatska pošta", "Pošte Srpske", "DHL", "GLS", "DPD",
                    "Post Express", "D Express", "AKS Express", "City Express", "Euroexpress"]
_BCS_BRANDS_SVC = ["Netflix", "Telekom", "mts", "BH Telecom", "A1", "Yettel", "Telemach", "PayPal",
                   "Facebook", "Instagram", "Microsoft", "Apple", "Google", "Elektroprivreda", "EPS",
                   "Revolut", "Booking", "OLX", "KupujemProdajem", "Njuškalo"]
_BCS_GREET = ["Poštovani,", "Poštovani korisniče,", "Poštovani klijente,", "Dragi korisniče,", "Cijenjeni korisniče,",
              "Poštovana/i,", "Zdravo,", "Obavještenje:", "Važno obavještenje.", "Poštovani kupče,", ""]
_BCS_DEADLINE = ["u roku od 24 sata", "u roku od 48 sati", "još danas", "do kraja dana", "u naredna 3 dana",
                 "odmah", "bez odlaganja", "što prije", "u roku od 12 sati", "najkasnije do sutra"]
_BCS_CLOSE = ["Hvala na razumijevanju.", "S poštovanjem, Služba za korisnike", "Tim za sigurnost", "Korisnička podrška",
              "Ovo je automatska poruka, ne odgovarajte na nju.", "Srdačan pozdrav, Odjel sigurnosti", "", "Vaš tim podrške",
              "Hvala što koristite naše usluge.", "Odeljenje za bezbednost"]
_BCS_AMT = ["1,99 EUR", "2,49 EUR", "3,20 KM", "189 RSD", "2,99 EUR", "4,50 KM", "1,45 EUR", "299 RSD", "0,99 EUR"]
_BCS_BIG = ["386,40 KM", "412,00 EUR", "28.500 RSD", "640,00 KM", "1.250,00 EUR", "215,30 EUR", "74.900 RSD"]


def _bcs_account():
    b = _c(_BCS_BRANDS_BANK + _BCS_BRANDS_SVC)
    problem = _c([
        f"Primijetili smo neuobičajenu prijavu na vaš {b} nalog.",
        f"Vaš {b} račun je privremeno ograničen zbog sigurnosne provjere.",
        f"Pristup vašem nalogu ({b}) je zaključan nakon više neuspjelih pokušaja prijave.",
        "Sistem je zabilježio sumnjivu transakciju na vašoj kartici.",
        f"Vaši podaci u sistemu {b} nisu ažurirani i nalog će biti deaktiviran.",
        "Detektovana je neovlaštena aktivnost na vašem korisničkom računu.",
        f"Vaša kartica izdata od {b} je suspendovana iz bezbednosnih razloga.",
        f"Nismo uspjeli potvrditi vaš identitet za uslugu {b}.",
        "Vaš profil ne ispunjava nove sigurnosne zahtjeve i biće ugašen.",
        "Zabilježen je pokušaj pristupa vašem nalogu sa nepoznatog uređaja.",
    ])
    demand = _c([
        "Potvrdite svoj identitet unosom korisničkog imena i lozinke.",
        "Verifikujte nalog klikom na link ispod i unesite podatke kartice.",
        "Prijavite se putem sigurnog linka i potvrdite lozinku.",
        "Ažurirajte svoje podatke i potvrdite PIN kod da biste nastavili.",
        "Unesite broj kartice, datum isteka i CVV radi provjere.",
        "Otključajte nalog potvrdom podataka na stranici za prijavu.",
        "Kliknite ovdje da ponovo aktivirate pristup i potvrdite kod iz SMS poruke.",
        "Potvrdite lozinku kako biste zadržali pristup svom nalogu.",
        "Potrebno je da verifikujete svoj račun putem obrasca u nastavku.",
    ])
    threat = _c([
        f"Ako to ne učinite {_c(_BCS_DEADLINE)}, nalog će biti trajno ugašen.",
        f"U suprotnom će račun biti blokiran {_c(_BCS_DEADLINE)}.",
        f"Rok za potvrdu ističe {_c(_BCS_DEADLINE)}.",
        f"Neizvršavanje provjere {_c(_BCS_DEADLINE)} dovodi do suspenzije usluge.",
        "Bez potvrde nećete moći koristiti karticu niti e-bankarstvo.",
        "Nakon isteka roka svi podaci biće obrisani.",
    ])
    subj = _c([f"Hitno: {b} nalog", "Sigurnosno upozorenje", "Vaš račun je ograničen", "Potrebna verifikacija",
               "Obavještenje o blokadi", f"{b}: potvrdite podatke", "Važno: neobična aktivnost", "Upozorenje: kartica blokirana",
               "Zaključan pristup", "Posljednje upozorenje"])
    return f"{subj}\n{_c(_BCS_GREET)} {problem} {demand} {threat} {_c(_BCS_CLOSE)}"


def _bcs_parcel():
    b = _c(_BCS_BRANDS_POST)
    num = f"{_c(['RR', 'CP', 'LX', 'EE'])}{R.randint(100000000, 999999999)}{_c(['RS', 'BA', 'HR', 'CN'])}"
    problem = _c([
        f"Vaša pošiljka {num} nije mogla biti isporučena jer adresa nije potpuna.",
        f"Paket broj {num} zadržan je na carini.",
        f"Kurir nije uspio dostaviti vašu pošiljku {num}.",
        "Vaš paket čeka u skladištu, ali troškovi dostave nisu plaćeni.",
        f"Pošiljka {num} je spremna za isporuku, potrebna je potvrda adrese.",
        "Dostava je obustavljena zbog neplaćene naknade za obradu.",
        "Imamo paket na vaše ime koji ne možemo uručiti bez dodatne uplate.",
    ])
    demand = _c([
        f"Uplatite naknadu od {_c(_BCS_AMT)} karticom da biste zakazali novu dostavu.",
        f"Platite carinske troškove u iznosu od {_c(_BCS_AMT)} putem linka.",
        f"Potvrdite adresu i platite {_c(_BCS_AMT)} za ponovnu isporuku.",
        f"Potrebna je doplata od {_c(_BCS_AMT)}; unesite podatke kartice na stranici.",
        "Ažurirajte adresu dostave i potvrdite plaćanje.",
    ])
    threat = _c([f"U suprotnom paket se vraća pošiljaocu {_c(_BCS_DEADLINE)}.",
                 "Pošiljka se čuva još 48 sati, nakon toga se vraća.",
                 f"Rok za uplatu ističe {_c(_BCS_DEADLINE)}.", "Nakon isteka roka naplaćuje se ležarina."])
    subj = _c([f"{b}: pošiljka čeka", "Vaš paket je zadržan", "Neuspjela dostava", "Obavijest o pošiljci",
               f"{b} - potrebna uplata", "Paket na carini", "Potvrdite adresu dostave"])
    return f"{subj}\n{_c(_BCS_GREET)} {problem} {demand} {threat} {_c([b, 'Služba dostave', 'Kurirska služba', ''])}"


def _bcs_refund_prize():
    who = _c(["Poreska uprava", "Porezna uprava", "Uprava za indirektno oporezivanje", "e-Uprava", "Elektroprivreda",
              "vaš operater", "Fond PIO", "Ministarstvo finansija", "Lidl", "Konzum", "Bingo", "IKEA", "dm"])
    kind = R.random()
    if kind < 0.5:
        body = _c([
            f"Nakon obračuna utvrđeno je da imate pravo na povrat u iznosu od {_c(_BCS_BIG)}.",
            f"Preplatili ste račun i ostvarili povrat sredstava od {_c(_BCS_BIG)}.",
            f"{who} vam vraća iznos od {_c(_BCS_BIG)} po osnovu preplate.",
            f"Na vaše ime evidentiran je neisplaćen povrat poreza od {_c(_BCS_BIG)}.",
        ]) + " " + _c([
            "Popunite obrazac i unesite podatke kartice na koju želite uplatu.",
            "Potvrdite broj računa i podatke kartice kako bismo izvršili isplatu.",
            "Kliknite na link i unesite podatke za povrat novca.",
            "Za isplatu je potrebna verifikacija kartice i lozinke za e-bankarstvo.",
        ])
        subj = _c(["Povrat sredstava", "Obavijest o povratu poreza", f"{who}: isplata na čekanju", "Imate pravo na povrat",
                   "Preplata - povrat novca"])
    else:
        body = _c([
            f"Čestitamo! Izabrani ste kao dobitnik vaučera u vrijednosti od {_c(_BCS_BIG)}.",
            "Vaš broj je izvučen u nagradnoj igri i osvojili ste novi telefon.",
            f"Povodom godišnjice {who} dijeli nagrade vjernim kupcima - vi ste među dobitnicima.",
            "Odgovorite na tri pitanja u anketi i preuzmite poklon.",
        ]) + " " + _c([
            f"Da preuzmete nagradu potvrdite podatke i platite dostavu od {_c(_BCS_AMT)}.",
            "Preuzmite nagradu unosom podataka kartice radi provjere identiteta.",
            f"Ponuda važi {_c(_BCS_DEADLINE)}, potvrdite svoje podatke.",
            "Ostala su još samo dva poklona, požurite i potvrdite adresu i karticu.",
        ])
        subj = _c(["Čestitamo, osvojili ste nagradu", "Dobitnik ste!", f"{who} nagradna igra", "Vaš poklon čeka",
                   "Izabrani ste"])
    return f"{subj}\n{_c(_BCS_GREET)} {body} {_c(_BCS_CLOSE)}"


def _bcs_bec():
    k = R.random()
    if k < 0.34:
        body = _c(["Jesi li tu?", "Da li si dostupna?", "Jeste li u kancelariji?", "Imaš li minut?", "Trebam te nakratko."]) + " " + _c([
            "U sastanku sam i ne mogu razgovarati telefonom.", "Trenutno sam na konferenciji, piši mi ovdje.",
            "Ne mogu se javiti, na putu sam.", "Zauzet sam do kraja dana, komuniciramo mejlom."]) + " " + _c([
            f"Treba da kupiš {R.randint(3, 10)} poklon kartica (Apple ili Google Play) za partnere.",
            "Potrebno mi je nekoliko vaučera za klijente, uzmi ih danas na kiosku.",
            "Nabavi poklon kartice u vrijednosti 500 eura i pošalji mi kodove.",
            "Kupi Paysafe kartice i slikaj mi kodove sa poleđine."]) + " " + _c([
            "Vratiću ti novac čim izađem.", "Refundiraću odmah poslije.", "Neka ovo ostane između nas za sada.",
            "Nemoj nikome govoriti, to je iznenađenje.", "Hitno je, javi kad završiš."])
        subj = _c(["Brza usluga", "Jesi li slobodna?", "Hitno", "Molba", "Kratko pitanje", "Treba mi pomoć"])
    elif k < 0.7:
        body = _c(["Poštovani,", "Poštovani partneri,", "Dobar dan,"]) + " " + _c([
            "obavještavamo vas da je naša firma promijenila poslovnu banku.",
            "zbog revizije naš dosadašnji račun više nije u upotrebi.",
            "od ovog mjeseca uplate primamo isključivo na novi žiro račun.",
            "došlo je do promjene instrukcija za plaćanje."]) + " " + _c([
            "Molimo da otvorenu fakturu platite na novi IBAN iz priloga.",
            "Sve buduće uplate izvršite na račun naveden u nastavku.",
            "Ažurirajte naše podatke u vašem sistemu i potvrdite prijem.",
            "Uplatu po predračunu izvršite danas na novi račun i pošaljite potvrdu."]) + " " + _c([
            "Hvala na saradnji.", "Molimo za hitnu potvrdu.", "Srdačan pozdrav, računovodstvo", ""])
        subj = _c(["Promjena računa", "Novi podaci za uplatu", "RE: faktura - novi žiro račun", "Obavijest o promjeni banke",
                   "Hitno: instrukcije za plaćanje"])
    else:
        body = _c(["Zdravo,", "Pozdrav,", "Poštovani,"]) + " " + _c([
            "otvorio sam račun u drugoj banci i želim da mi se plata ubuduće isplaćuje tamo.",
            "promijenila sam banku, možete li mi ažurirati račun za isplatu zarade?",
            "molim da mi platu za ovaj mjesec uplatite na novi tekući račun.",
            "treba da promijenim račun na koji mi liježe plata."]) + " " + _c([
            "Šta je potrebno da dostavim?", "Javite da li stižemo prije sljedeće isplate.",
            "Poslaću broj računa čim potvrdite.", "Molim da ostane povjerljivo."])
        subj = _c(["Promjena računa za platu", "Isplata zarade", "Novi tekući račun", "Molba - plata"])
    return f"{subj}\n{body}"


def _bcs_mailbox_doc():
    k = R.random()
    if k < 0.5:
        body = _c([
            "Vaše poštansko sanduče je dostiglo ograničenje prostora.",
            f"Imate {R.randint(3, 14)} poruka koje nisu isporučene i čekaju na serveru.",
            "Lozinka vaše e-pošte ističe danas.",
            "Vaš e-mail nalog biće deaktiviran zbog neaktivnosti.",
            "Administrator je zakazao nadogradnju vašeg sandučeta.",
            "Server e-pošte je zadržao dolazne poruke zbog sigurnosne provjere.",
        ]) + " " + _c([
            "Potvrdite nalog da biste oslobodili poruke.",
            "Zadržite postojeću lozinku prijavom na portal.",
            "Verifikujte sanduče unosom adrese i lozinke.",
            "Prijavite se da povećate kvotu i preuzmete poruke.",
            "Kliknite da nastavite koristiti isti nalog.",
        ]) + " " + _c([f"Poruke se brišu {_c(_BCS_DEADLINE)}.", "U suprotnom nalog će biti zatvoren.",
                       "Nakon isteka roka pristup neće biti moguć.", ""])
        subj = _c(["Sanduče je puno", "Poruke na čekanju", "Lozinka ističe", "Obavijest administratora",
                   "Deaktivacija naloga", "IT podrška: potrebna akcija"])
    else:
        body = _c([
            "Podijeljen vam je dokument putem sigurnog portala.",
            "Primili ste dokument na potpis.",
            "Računovodstvo vam je poslalo povjerljiv fajl sa obračunom.",
            "Imate novu glasovnu poruku u trajanju od 0:42.",
            "Skenirani dokument sa štampača je spreman za pregled.",
            "Direktor je podijelio s vama tabelu sa bonusima.",
        ]) + " " + _c([
            "Prijavite se službenim nalogom i lozinkom da ga otvorite.",
            "Za pregled unesite lozinku e-pošte.",
            "Otvorite dokument i potvrdite identitet svojim korisničkim podacima.",
            "Preslušajte poruku nakon prijave poslovnim nalogom.",
            "Skenirajte QR kod telefonom i prijavite se da pregledate dokument.",
        ]) + " " + _c(["Link važi 24 sata.", "Dokument ističe danas.", "", "Pristup je moguć samo danas."])
        subj = _c(["Dokument podijeljen s vama", "Nova glasovna poruka", "Dokument za potpis", "Obračun plate",
                   "Skenirani dokument", "Povjerljivo: bonusi"])
    return f"{subj}\n{_c(_BCS_GREET)} {body}"


def _bcs_misc():
    k = R.random()
    if k < 0.4:
        svc = _c(["antivirus zaštitu", "godišnju pretplatu", "premium paket", "produženu garanciju", "zaštitu uređaja"])
        body = (f"Vaša kartica je terećena za {_c(_BCS_BIG)} za {svc}. " + _c([
            "Ako niste odobrili ovu transakciju, pozovite odmah naš centar na broj ispod.",
            "Ukoliko ovo niste vi naručili, nazovite podršku da otkažete i dobijete povrat.",
            "Za otkazivanje i povrat novca kontaktirajte nas telefonom u roku od 24 sata."])
            + f" Telefon: +387 {R.randint(30, 66)} {R.randint(100, 999)} {R.randint(100, 999)}")
        subj = _c(["Potvrda naplate", "Račun za pretplatu", "Obnova pretplate", "Narudžba potvrđena"])
    elif k < 0.7:
        body = _c([
            "Hakovao sam vaš uređaj i imam pristup kameri.", "Instalirao sam program na vaš računar dok ste posjećivali sajt za odrasle.",
            "Imam snimak vas i listu svih vaših kontakata.", "Znam vašu lozinku i pratim vas mjesecima."]) + " " + _c([
            f"Uplatite {R.randint(500, 1500)} eura u bitcoinu na adresu ispod.",
            "Platite u kriptovaluti i sve brišem.", "Imate 48 sati da pošaljete novac na moj bitcoin novčanik."]) + " " + _c([
            "U suprotnom snimak šaljem svima.", "Ne pokušavajte da me kontaktirate.", "Vrijeme teče od otvaranja ove poruke."])
        subj = _c(["Imam vaš snimak", "Vaš uređaj je hakovan", "Plati ili objavljujem", "Posljednja opomena"])
    else:
        body = _c([
            "Vaša dvofaktorska autentifikacija ističe.", "Potrebno je ponovo registrovati aplikaciju za autentifikaciju.",
            "Vaš uređaj mora biti potvrđen da biste nastavili koristiti Teams.",
            "Novi sigurnosni standard zahtijeva potvrdu uređaja."]) + " " + _c([
            "Skenirajte QR kod kamerom telefona i prijavite se.",
            "Otvorite stranicu za prijavu uređaja i unesite kod iz poruke.",
            "Potvrdite uređaj unosom koda i svoje lozinke.",
            "Skenirajte kod ispod da zadržite pristup."]) + " " + _c([f"Rok: {_c(_BCS_DEADLINE)}.", "Kod važi 15 minuta.", ""])
        subj = _c(["Obnovite MFA", "Potvrda uređaja", "Skenirajte kod", "Sigurnosna provjera"])
    return f"{subj}\n{_c(_BCS_GREET)} {body}"


_SR_CYR = str.maketrans({
    "a": "а", "b": "б", "c": "ц", "d": "д", "e": "е", "f": "ф", "g": "г", "h": "х", "i": "и", "j": "ј",
    "k": "к", "l": "л", "m": "м", "n": "н", "o": "о", "p": "п", "r": "р", "s": "с", "t": "т", "u": "у",
    "v": "в", "z": "з", "č": "ч", "ć": "ћ", "š": "ш", "ž": "ж", "đ": "ђ",
    "A": "А", "B": "Б", "C": "Ц", "D": "Д", "E": "Е", "F": "Ф", "G": "Г", "H": "Х", "I": "И", "J": "Ј",
    "K": "К", "L": "Л", "M": "М", "N": "Н", "O": "О", "P": "П", "R": "Р", "S": "С", "T": "Т", "U": "У",
    "V": "В", "Z": "З", "Č": "Ч", "Ć": "Ћ", "Š": "Ш", "Ž": "Ж", "Đ": "Ђ"})


def to_cyrillic(text: str) -> str:
    """Rough Latin -> Serbian Cyrillic (lj/nj/dž digraphs first)."""
    t = text.replace("lj", "љ").replace("Lj", "Љ").replace("nj", "њ").replace("Nj", "Њ")
    t = t.replace("dž", "џ").replace("Dž", "Џ")
    return t.translate(_SR_CYR)


# =============================================================== Swedish
_SV_BANK = ["Swedbank", "Handelsbanken", "SEB", "Nordea", "Länsförsäkringar", "ICA Banken", "Danske Bank", "din bank",
            "Skandia", "SBAB"]
_SV_POST = ["PostNord", "DHL", "Schenker", "Bring", "Instabox", "Budbee", "UPS", "Early Bird"]
_SV_SVC = ["Netflix", "Spotify", "Telia", "Telenor", "Tele2", "Tre", "Klarna", "Swish", "BankID", "Kivra",
           "Microsoft", "Apple", "Facebook", "Blocket", "Tradera", "Vattenfall", "Fortum"]
_SV_GREET = ["Hej,", "Hej!", "Bästa kund,", "Kära kund,", "Viktigt meddelande.", "Till kontoinnehavaren,", ""]
_SV_DEADLINE = ["inom 24 timmar", "inom 48 timmar", "redan idag", "senast imorgon", "inom tre dagar", "omgående",
                "före midnatt", "så snart som möjligt"]
_SV_CLOSE = ["Med vänlig hälsning, Kundtjänst", "Säkerhetsavdelningen", "Tack för ditt samarbete.", "Detta är ett automatiskt meddelande.",
             "Vänliga hälsningar, Supportteamet", ""]
_SV_AMT = ["19 kr", "29 kr", "24,50 kr", "39 kr", "12 kr", "49 kr"]
_SV_BIG = ["3 420 kr", "4 812 kr", "1 950 kr", "7 300 kr", "2 640 kr"]


def _sv_account():
    b = _c(_SV_BANK + _SV_SVC)
    problem = _c([
        f"Vi har upptäckt en ovanlig inloggning på ditt {b}-konto.",
        f"Ditt konto hos {b} har tillfälligt begränsats.",
        "Ditt kort har spärrats efter en misstänkt transaktion.",
        f"Dina uppgifter hos {b} behöver uppdateras, annars inaktiveras kontot.",
        "Någon har försökt komma åt ditt konto från en okänd enhet.",
        f"Din åtkomst till {b} har låsts efter flera misslyckade försök.",
        "Ditt BankID har upphört att gälla.",
        "Vi kunde inte verifiera din identitet.",
    ])
    demand = _c([
        "Bekräfta din identitet genom att logga in med BankID.",
        "Verifiera ditt konto och ange dina kortuppgifter via länken.",
        "Logga in och bekräfta ditt lösenord för att fortsätta.",
        "Uppdatera dina uppgifter och ange koden från din säkerhetsdosa.",
        "Ange kortnummer, giltighetstid och CVC för kontroll.",
        "Lås upp kontot genom att bekräfta dina uppgifter.",
        "Förnya ditt BankID genom att legitimera dig här.",
    ])
    threat = _c([
        f"Gör du inte detta {_c(_SV_DEADLINE)} stängs kontot permanent.",
        f"Annars spärras dina tjänster {_c(_SV_DEADLINE)}.",
        f"Tidsfristen går ut {_c(_SV_DEADLINE)}.",
        "Utan bekräftelse kan du inte använda kortet eller internetbanken.",
        "Efter det raderas alla uppgifter.",
    ])
    subj = _c([f"Viktigt: ditt {b}-konto", "Säkerhetsvarning", "Ditt konto är begränsat", "Verifiering krävs",
               "Ditt kort är spärrat", f"{b}: bekräfta dina uppgifter", "Åtgärd krävs", "Sista varningen"])
    return f"{subj}\n{_c(_SV_GREET)} {problem} {demand} {threat} {_c(_SV_CLOSE)}"


def _sv_parcel_refund():
    k = R.random()
    if k < 0.5:
        b = _c(_SV_POST)
        body = _c([
            "Ditt paket kunde inte levereras eftersom adressen är ofullständig.",
            "Din försändelse ligger kvar i tullen.",
            "Budet kunde inte lämna ditt paket.",
            "Ditt paket väntar på terminalen men frakten är inte betald.",
            "Leveransen har stoppats på grund av en obetald avgift.",
        ]) + " " + _c([
            f"Betala avgiften på {_c(_SV_AMT)} med kort för att boka ny leverans.",
            f"Betala tullavgiften på {_c(_SV_AMT)} via länken.",
            f"Bekräfta adressen och betala {_c(_SV_AMT)} för ny utkörning.",
            "Uppdatera leveransadressen och bekräfta betalningen.",
        ]) + " " + _c([f"Annars returneras paketet {_c(_SV_DEADLINE)}.", "Paketet sparas i 48 timmar.",
                       f"Betalningen måste göras {_c(_SV_DEADLINE)}."])
        subj = _c([f"{b}: ditt paket väntar", "Misslyckad leverans", "Paket i tullen", f"{b} - betalning krävs",
                   "Bekräfta leveransadress"])
    elif k < 0.8:
        who = _c(["Skatteverket", "Försäkringskassan", "Pensionsmyndigheten", "ditt elbolag", "CSN", "Kronofogden"])
        body = _c([
            f"Efter en ny beräkning har du rätt till en återbetalning på {_c(_SV_BIG)}.",
            f"Du har betalat för mycket och får tillbaka {_c(_SV_BIG)}.",
            f"{who} har en utbetalning på {_c(_SV_BIG)} som väntar på dig.",
        ]) + " " + _c([
            "Fyll i formuläret och ange kortet du vill ha pengarna på.",
            "Bekräfta ditt kontonummer och dina kortuppgifter för utbetalning.",
            "Logga in med BankID och bekräfta dina uppgifter.",
        ]) + " " + _c([f"Erbjudandet gäller {_c(_SV_DEADLINE)}.", "Annars förfaller beloppet.", ""])
        subj = _c(["Du har pengar att få tillbaka", f"{who}: utbetalning väntar", "Återbetalning", "Besked om skatteåterbäring"])
    else:
        who = _c(["ICA", "Coop", "Lidl", "IKEA", "Elgiganten", "Telia", "Postkodlotteriet"])
        body = _c([
            f"Grattis! Du har valts ut och vunnit ett presentkort på {_c(_SV_BIG)}.",
            "Ditt nummer har dragits och du har vunnit en ny mobil.",
            f"{who} firar jubileum och delar ut gåvor till trogna kunder.",
            "Svara på tre frågor och hämta din belöning.",
        ]) + " " + _c([
            f"Hämta vinsten genom att bekräfta dina uppgifter och betala frakten på {_c(_SV_AMT)}.",
            "Ange dina kortuppgifter för att verifiera din identitet.",
            f"Erbjudandet gäller {_c(_SV_DEADLINE)}.",
        ])
        subj = _c(["Grattis, du har vunnit", "Du är utvald", f"{who} utlottning", "Din gåva väntar"])
    return f"{subj}\n{_c(_SV_GREET)} {body} {_c(_SV_CLOSE)}"


def _sv_bec_mailbox():
    k = R.random()
    if k < 0.3:
        body = _c(["Är du på plats?", "Har du en minut?", "Är du tillgänglig?", "Sitter du vid datorn?"]) + " " + _c([
            "Jag sitter i möte och kan inte ringa.", "Jag är på konferens, skriv här.", "Jag kan inte ta samtal just nu."]) + " " + _c([
            f"Jag behöver att du köper {R.randint(3, 10)} presentkort till kunder idag.",
            "Köp presentkort för 5 000 kr och skicka koderna till mig.",
            "Skaffa några Google Play-kort i butiken och fota koderna."]) + " " + _c([
            "Du får tillbaka pengarna i eftermiddag.", "Håll det mellan oss tills vidare.", "Det brådskar, hör av dig när det är klart."])
        subj = _c(["Snabb fråga", "Är du ledig?", "Brådskande", "En tjänst"])
    elif k < 0.55:
        body = _c(["Hej,", "Hej ekonomi,", "Bästa kund,"]) + " " + _c([
            "vi har bytt bank och vårt gamla bankgiro används inte längre.",
            "på grund av revision ska alla betalningar gå till ett nytt konto.",
            "våra betalningsuppgifter har ändrats från och med denna månad."]) + " " + _c([
            "Betala den öppna fakturan till det nya kontonumret i bilagan.",
            "Uppdatera våra uppgifter i ert system och bekräfta.",
            "Gör betalningen idag till det nya kontot och skicka kvittot."])
        subj = _c(["Nya betalningsuppgifter", "Byte av bankgiro", "SV: faktura - nytt konto", "Ändrade bankuppgifter"])
    elif k < 0.7:
        body = _c(["Hej,", "Hej lön,"]) + " " + _c([
            "jag har öppnat konto i en annan bank och vill ha lönen dit framöver.",
            "kan ni ändra mitt lönekonto innan nästa utbetalning?",
            "jag behöver byta konto för löneutbetalningen."]) + " " + _c(["Vad behöver ni från mig?", "Hinner vi före nästa lön?", ""])
        subj = _c(["Byte av lönekonto", "Löneutbetalning", "Nytt konto för lön"])
    else:
        body = _c([
            "Din e-postlåda har nått sin lagringsgräns.",
            f"Du har {R.randint(3, 14)} meddelanden som inte kunnat levereras.",
            "Lösenordet till din e-post går ut idag.",
            "Ett dokument har delats med dig via en säker portal.",
            "Du har fått ett röstmeddelande.",
            "Din tvåfaktorsautentisering måste förnyas.",
        ]) + " " + _c([
            "Verifiera kontot för att släppa meddelandena.",
            "Behåll ditt nuvarande lösenord genom att logga in på portalen.",
            "Logga in med ditt arbetskonto och lösenord för att öppna.",
            "Skanna QR-koden med mobilen och logga in.",
            "Ange ditt e-postlösenord för att fortsätta.",
        ]) + " " + _c([f"Meddelandena raderas {_c(_SV_DEADLINE)}.", "Annars stängs kontot.", "Länken gäller i 24 timmar.", ""])
        subj = _c(["Brevlådan är full", "Väntande meddelanden", "Lösenordet går ut", "Dokument delat med dig",
                   "Nytt röstmeddelande", "Förnya din inloggning"])
    return f"{subj}\n{body}"


def _sv_misc():
    k = R.random()
    if k < 0.5:
        body = (f"Ditt kort har debiterats {_c(_SV_BIG)} för " + _c(["antivirusskydd", "årsabonnemang", "premiumtjänst", "förlängd garanti"])
                + ". " + _c([
                    "Om du inte godkände köpet, ring vår kundtjänst omedelbart på numret nedan.",
                    "Känner du inte igen köpet? Ring supporten för att avbryta och få pengarna tillbaka.",
                    "Kontakta oss per telefon inom 24 timmar för återbetalning."])
                + f" Telefon: 08-{R.randint(100, 999)} {R.randint(10, 99)} {R.randint(10, 99)}")
        subj = _c(["Bekräftelse på betalning", "Ditt abonnemang har förnyats", "Kvitto", "Orderbekräftelse"])
    else:
        body = _c(["Jag har hackat din enhet och har tillgång till din kamera.", "Jag har spelat in dig och har alla dina kontakter.",
                   "Jag vet ditt lösenord."]) + " " + _c([
            f"Betala {R.randint(5, 15)} 000 kr i bitcoin till adressen nedan.", "Du har 48 timmar på dig att betala i kryptovaluta."]) + " " + _c([
            "Annars skickar jag videon till alla.", "Försök inte kontakta mig."])
        subj = _c(["Jag har din video", "Din enhet är hackad", "Betala annars", "Sista chansen"])
    return f"{subj}\n{_c(_SV_GREET)} {body}"


# =============================================================== English: families missing from phishing corpora
def _en_bec():
    k = R.random()
    name = _c(["Sarah", "Michael", "David", "Jennifer", "Robert", "Emma", "James", "Laura"])
    if k < 0.3:
        body = _c(["Are you in the office?", "Do you have a moment?", "Are you free right now?", "Quick one."]) + " " + _c([
            "I'm about to step into a meeting and won't be able to take calls.", "I'm travelling and can only do email.",
            "I'm in back-to-back sessions today.", "My phone is off, reply here."]) + " " + _c([
            f"I need {R.randint(4, 12)} gift cards purchased for a staff surprise.",
            "Could you pick up some Apple gift cards for our clients this afternoon?",
            "Please purchase Google Play cards worth 1000 and email me the codes.",
            "Grab a few Amazon cards, scratch the backs and send me pictures of the codes."]) + " " + _c([
            "I'll sort out the reimbursement tonight.", "Please keep it to yourself for now.", "It's a surprise so don't mention it to anyone.",
            "Let me know the moment it's done."])
        subj = _c(["Request", "Are you around?", "Favour needed", "Task for today", "Need your help", "Urgent errand"])
    elif k < 0.6:
        body = _c(["Hello,", "Good morning,", "Dear accounts team,", "Hi,"]) + " " + _c([
            "please be advised that our company has changed its banking provider.",
            "due to an ongoing audit our previous account cannot receive payments.",
            "our remittance information has been updated effective immediately.",
            "we have switched banks and the old account is being closed."]) + " " + _c([
            "Kindly direct the payment for the open invoice to the new account in the attached letter.",
            "All upcoming payments should be made to the beneficiary details below.",
            "Please amend your records with our new IBAN and confirm once done.",
            "Send today's transfer to the updated account and share the payment confirmation."]) + " " + _c([
            "Thank you for your prompt attention.", "Kindly acknowledge receipt.", "Regards, Credit Control", ""])
        subj = _c(["Change of bank details", "Updated remittance information", "RE: invoice - new account", "Banking update",
                   "Payment instructions changed"])
    elif k < 0.8:
        body = _c(["Hi,", "Hello,", f"Hi, {name} here."]) + " " + _c([
            "I've opened an account with a different bank and want my salary paid there going forward.",
            "can you update the account my pay goes into before the next run?",
            "I need to change my direct deposit information.",
            "my old account is being closed, please switch my payroll to the new one."]) + " " + _c([
            "What do you need from me?", "Will this make the next payroll?", "I can send the account and routing number now.",
            "Please keep this between us until it's processed."])
        subj = _c(["Payroll change", "Direct deposit", "Update my bank info", "Salary account"])
    else:
        body = _c(["Hi,", "Hello,"]) + " " + _c([
            "I need a wire sent to a new vendor before the cut-off today.",
            "we are closing an acquisition and I need a payment processed quietly.",
            "please arrange an urgent transfer, I'll forward the paperwork later.",
            "can you handle an outgoing payment for me this morning?"]) + " " + _c([
            "I'm in meetings all day so email only.", "This is confidential until the announcement.",
            "Don't loop anyone else in yet.", "Tell me how soon you can get it out."])
        subj = _c(["Wire today", "Confidential", "Payment request", "Time sensitive"])
    return f"{subj}\n{body}"


def _en_modern():
    k = R.random()
    if k < 0.25:
        prod = _c(["Norton 360", "McAfee Total Protection", "Geek Squad Protection Plan", "Windows Defender Pro", "PayPal", "Bitcoin purchase",
                   "Amazon Prime", "antivirus licence"])
        body = (f"Your order for {prod} has been processed and {_c(['$289.99', '$349.00', '$499.99', '$399.50', '£279.00'])} was billed to your card. "
                + _c(["If you did not place this order, call our cancellation team right away.",
                      "Did not authorize this? Contact the billing desk by phone within 24 hours for a refund.",
                      "To dispute this charge speak to an agent on the number below.",
                      "If this wasn't you, phone our helpline immediately to stop the charge."])
                + f" +1 ({R.randint(800, 888)}) {R.randint(200, 999)}-{R.randint(1000, 9999)}")
        subj = _c(["Order confirmation", "Your invoice", "Subscription renewed", "Payment receipt", "Thank you for your purchase"])
    elif k < 0.45:
        body = _c([
            "Your authenticator registration is about to lapse.", "New security policy: every account must re-enrol in two-step verification.",
            "Your device needs to be approved before you can keep using Teams.", "Your session requires re-authentication."]) + " " + _c([
            "Scan the QR code with your phone camera and sign in.", "Open the device sign-in page and type the code from this message.",
            "Use your phone to scan the code below and complete the sign-in.", "Enter the device code and then your work password."]) + " " + _c([
            "The code is valid for 15 minutes.", "Complete this before end of day.", ""])
        subj = _c(["Re-enrol your authenticator", "Device approval needed", "Scan to keep access", "Security set-up"])
    elif k < 0.6:
        body = _c([
            "To prove you are not a robot, complete the steps below.", "The document is protected. Follow the verification steps to open it.",
            "A browser error occurred. Fix it in three steps."]) + " " + _c([
            "Press the Windows key and R, then paste with Ctrl+V and press Enter.",
            "Open the Run box, paste the command we copied for you and confirm.",
            "Open PowerShell, paste the text from your clipboard and run it."])
        subj = _c(["Verification required", "Fix required to view file", "Confirm you are human"])
    elif k < 0.8:
        body = _c([
            "A voicemail was left for you.", "You have a secure fax waiting.", "Finance shared the bonus sheet with you.",
            "A contract is waiting for your e-signature.", "The scanner sent you a document."]) + " " + _c([
            "Sign in with your work email and password to listen.", "Enter your mailbox password to view the pages.",
            "Open it with your company login.", "Authenticate with your Office account to review and sign."]) + " " + _c([
            "The item is removed after 24 hours.", "Access expires today.", ""])
        subj = _c(["New voicemail", "Incoming fax", "File shared with you", "Signature requested", "Scan from printer"])
    else:
        body = _c([
            "Your wallet needs to be validated after the network upgrade.", "We detected a pending withdrawal from your exchange account.",
            "Your hardware wallet firmware is outdated and funds are at risk."]) + " " + _c([
            "Enter your recovery phrase to re-sync.", "Confirm the 24-word seed to secure your assets.",
            "Connect your wallet and approve the verification."]) + " " + _c(["Unverified wallets will be frozen.", "Act before the snapshot.", ""])
        subj = _c(["Wallet validation", "Withdrawal pending", "Firmware update required", "Secure your assets"])
    return f"{subj}\n{body}"


def generate(n_bcs: int = 700, n_sv: int = 450, n_en: int = 350, seed: int = 11) -> list[str]:
    """Deterministic list of generated lure texts (subject\\nbody)."""
    R.seed(seed)
    out: set[str] = set()

    def fill(target, makers, post=None):
        guard = 0
        start = len(out)
        while len(out) - start < target and guard < target * 40:
            guard += 1
            t = " ".join(_c(makers)().split(" "))
            t = "\n".join(" ".join(part.split()) for part in t.split("\n"))
            if post:
                t = post(t)
            out.add(t)

    fill(n_bcs, [_bcs_account, _bcs_account, _bcs_parcel, _bcs_refund_prize, _bcs_bec, _bcs_mailbox_doc, _bcs_misc])
    fill(n_bcs // 7, [_bcs_account, _bcs_parcel, _bcs_mailbox_doc, _bcs_refund_prize], post=to_cyrillic)
    fill(n_sv, [_sv_account, _sv_account, _sv_parcel_refund, _sv_parcel_refund, _sv_bec_mailbox, _sv_misc])
    fill(n_en, [_en_bec, _en_bec, _en_modern])
    return sorted(out)
