"""Download public e-mail corpora and build data/corpus.csv for training.

Sources (licences and caveats: NOTICE.md)
-----------------------------------------
PHISHING
  nazario         Jose Nazario phishing corpus 2015-2025 (CC-BY-4.0)
  nazario_legacy  the same author's 2004-2015 mailboxes (CC-BY-4.0) - phishing
                  from the SAME era as the public legitimate corpora, so the
                  model cannot separate the classes by "old mail vs new mail"
LEGITIMATE
  spamassassin    SpamAssassin public corpus (easy_ham, easy_ham_2, hard_ham)
  enron           business mail of ~50 Enron employees (CMU release) - invoices,
                  payments, IT notices: the hard negatives for BEC detection
  apache_lists    public Apache mailing lists 2024-2026 - modern legitimate mail

Raw messages are never redistributed; this script downloads them from the
original publishers. Every source is optional at run time: a failed download
is reported and skipped, it never throws the whole corpus away (v0.9 fell back
to the 280-sample starter set if a single file was unreachable).

Usage
-----
    python scripts/build_corpus.py                # download + build
    python scripts/build_corpus.py --offline      # only files already in data/raw
    python scripts/build_corpus.py --no-enron --no-lists     # small/fast build
    python scripts/build_corpus.py --with-phishing-pot       # + evaluation-only set (CC BY-NC!)

Output
------
data/corpus.csv            text,label,source,year,group   (label 1 = phishing, 0 = legit)
data/corpus_manifest.json  what was downloaded (sizes, sha256) and counted
Your own data/feedback.csv is merged in at training time (antiphish.learn).
"""
from __future__ import annotations

import csv
import gzip
import hashlib
import json
import mailbox
import os
import re
import sys
import tarfile
import time
import urllib.error
import urllib.request

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
sys.path.insert(0, ROOT)
from antiphish.email_parser import parse_message, message_from_bytes_robust  # noqa: E402
from antiphish.model import normalize_text, scrub_recipient  # noqa: E402

DATA = os.getenv("CORPUS_DATA_DIR", os.path.join(ROOT, "data"))
RAW = os.path.join(DATA, "raw")
OUT = os.path.join(DATA, "corpus.csv")
MANIFEST = os.path.join(DATA, "corpus_manifest.json")
UA = {"User-Agent": "antiphish-corpus-builder/0.10 (+research; contact: repo owner)"}

NAZARIO_YEARS = range(2015, 2026)
NAZARIO_URL = "https://monkey.org/~jose/phishing/phishing-{y}"
NAZARIO_LEGACY = ["phishing0.mbox", "phishing1.mbox", "phishing2.mbox", "phishing3.mbox",
                  "20051114.mbox", "private-phishing4.mbox"]
NAZARIO_LEGACY_URL = "https://monkey.org/~jose/phishing/{f}"
SA_URL = "https://spamassassin.apache.org/old/publiccorpus/{n}.tar.bz2"
SA_SETS = ["20030228_easy_ham", "20030228_easy_ham_2", "20030228_hard_ham"]
ENRON_URL = "https://www.cs.cmu.edu/~enron/enron_mail_20150507.tar.gz"
ENRON_PER_USER = int(os.getenv("ENRON_PER_USER", "60"))
ENRON_MAX = int(os.getenv("ENRON_MAX", "3000"))
ENRON_FOLDERS = {"inbox", "sent", "sent_items", "_sent_mail", "notes_inbox", "_sent"}
ENRON_CACHE = "enron_subset.jsonl.gz"
LISTS_URL = "https://lists.apache.org/api/mbox.lua?list={list}&date={month}"
# (list, months) - user-facing and announcement lists: questions, replies, release notes
APACHE_LISTS = [
    ("users@httpd.apache.org", ["2024-03", "2024-09", "2025-02", "2025-06", "2025-10", "2026-02", "2026-05"]),
    ("users@tomcat.apache.org", ["2024-05", "2025-01", "2025-09", "2026-03"]),
    ("announce@apache.org", ["2024-06", "2025-03", "2025-11", "2026-04"]),
    ("users@maven.apache.org", ["2024-04", "2025-05", "2026-01"]),
    ("user@spark.apache.org", ["2024-08", "2025-07", "2026-06"]),
    ("users@kafka.apache.org", ["2024-10", "2025-08", "2026-07"]),
    ("dev@community.apache.org", ["2024-11", "2025-12", "2026-08"]),
    ("users@subversion.apache.org", ["2024-02", "2025-04", "2026-09"]),
]
LISTS_PER_FILE = int(os.getenv("LISTS_PER_FILE", "120"))
PHISHING_POT_URL = "https://codeload.github.com/rf-peixoto/phishing_pot/zip/refs/heads/main"
MAX_CHARS = 4000
MIN_CHARS = 40

log_lines: list[str] = []


def log(msg: str):
    print(msg, flush=True)
    log_lines.append(msg)


# ------------------------------------------------------------------ download
def _download(url: str, dest: str, retries: int = 3, timeout: int = 180) -> bool:
    """Fetch url -> dest (atomic). True on success or when already present."""
    if os.path.exists(dest) and os.path.getsize(dest) > 0:
        return True
    for attempt in range(1, retries + 1):
        try:
            log(f"downloading {url}" + (f" (attempt {attempt})" if attempt > 1 else ""))
            req = urllib.request.Request(url, headers=UA)
            tmp = dest + ".part"
            with urllib.request.urlopen(req, timeout=timeout) as r, open(tmp, "wb") as f:
                while True:
                    chunk = r.read(1 << 20)
                    if not chunk:
                        break
                    f.write(chunk)
            if os.path.getsize(tmp) == 0:
                raise OSError("empty response")
            os.replace(tmp, dest)
            return True
        except (urllib.error.URLError, OSError, TimeoutError, ValueError) as e:
            log(f"  WARNING: {url} failed: {e}")
            time.sleep(2 * attempt)
    return False


def _sha256(path: str) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


# ------------------------------------------------------------------ text
def _recipients(msg) -> list[str]:
    from email.utils import getaddresses
    vals = []
    for h in ("To", "Delivered-To", "X-Original-To", "Envelope-To", "X-Delivered-To"):
        vals += [str(v) for v in (msg.get_all(h) or [])]
    try:
        return [a.lower() for _n, a in getaddresses(vals) if "@" in a][:3]
    except Exception:
        return []


def _text(msg) -> str:
    """The text the model is trained on: subject + visible body, recipient-neutral."""
    try:
        d = parse_message(msg)
    except Exception:
        return ""
    t = f"{d.get('subject', '')}\n{d.get('body', '')}".strip()
    t = scrub_recipient(t, d.get("to") or _recipients(msg))
    return t[:MAX_CHARS]


def _year(msg, default: int) -> int:
    m = re.search(r"\b(19[89]\d|20[0-3]\d)\b", str(msg.get("Date") or ""))
    return int(m.group(1)) if m else default


def dedup_key(text: str) -> str:
    """Near-duplicate key: the same campaign with other names/numbers collapses."""
    return hashlib.sha1(normalize_text(text)[:700].encode("utf-8", "ignore")).hexdigest()


# ------------------------------------------------------------------ sources
def _mbox_messages(path: str):
    box = mailbox.mbox(path, factory=lambda f: f.read())
    for raw in box:
        try:
            yield message_from_bytes_robust(raw)
        except Exception:
            continue


def nazario_rows():
    for y in NAZARIO_YEARS:
        path = os.path.join(RAW, f"nazario-{y}.mbox")
        if not os.path.exists(path):
            continue
        n = 0
        for msg in _mbox_messages(path):
            t = _text(msg)
            if len(t) > MIN_CHARS:
                n += 1
                yield t, 1, "nazario", y, str(y)
        log(f"  nazario {y}: {n}")


def nazario_legacy_rows():
    for f in NAZARIO_LEGACY:
        path = os.path.join(RAW, f"nazario-legacy-{f}")
        if not os.path.exists(path):
            continue
        n = 0
        for msg in _mbox_messages(path):
            t = _text(msg)
            if len(t) > MIN_CHARS:
                n += 1
                yield t, 1, "nazario_legacy", _year(msg, 2006), f
        log(f"  nazario legacy {f}: {n}")


def spamassassin_rows():
    for name in SA_SETS:
        path = os.path.join(RAW, f"{name}.tar.bz2")
        if not os.path.exists(path):
            continue
        n = 0
        try:
            with tarfile.open(path, "r:bz2") as tf:
                for m in tf.getmembers():
                    if not m.isfile() or m.name.endswith("cmds"):
                        continue
                    raw = tf.extractfile(m).read()
                    t = _text(message_from_bytes_robust(raw))
                    if len(t) > MIN_CHARS:
                        n += 1
                        yield t, 0, "spamassassin", 2002, name.split("_", 1)[1]
        except (tarfile.TarError, OSError, EOFError) as e:
            log(f"  WARNING: {name} unreadable: {e}")
        log(f"  spamassassin {name}: {n}")


def _enron_stream(fileobj):
    """(user, raw bytes) from the CMU tarball, capped per user, stopping early."""
    per_user: dict[str, int] = {}
    total = 0
    with tarfile.open(fileobj=fileobj, mode="r|gz") as tf:
        for m in tf:
            if not m.isfile():
                continue
            parts = m.name.split("/")
            if len(parts) < 4 or parts[2] not in ENRON_FOLDERS:
                continue
            user = parts[1]
            if per_user.get(user, 0) >= ENRON_PER_USER:
                continue
            f = tf.extractfile(m)
            if f is None:
                continue
            raw = f.read(400_000)
            per_user[user] = per_user.get(user, 0) + 1
            total += 1
            yield user, raw
            if total >= ENRON_MAX:
                return


def fetch_enron(offline: bool) -> bool:
    """Stream the CMU archive and keep a small per-user sample in data/raw
    (the full 443 MB tarball is never stored)."""
    cache = os.path.join(RAW, ENRON_CACHE)
    if os.path.exists(cache) and os.path.getsize(cache) > 0:
        return True
    local = os.getenv("ENRON_TARBALL", "")
    if offline and not local:
        return False
    try:
        if local and os.path.exists(local):
            log(f"reading Enron sample from {local}")
            src = open(local, "rb")
        else:
            log(f"streaming {ENRON_URL} (stops after {ENRON_MAX} messages)")
            src = urllib.request.urlopen(urllib.request.Request(ENRON_URL, headers=UA), timeout=180)
        n = 0
        tmp = cache + ".part"
        with src, gzip.open(tmp, "wt", encoding="utf-8") as out:
            for user, raw in _enron_stream(src):
                out.write(json.dumps({"user": user, "raw": raw.decode("latin-1")}) + "\n")
                n += 1
        if n < 200:
            raise OSError(f"only {n} messages read")
        os.replace(tmp, cache)
        return True
    except Exception as e:                                   # network, truncated archive ...
        log(f"  WARNING: Enron sample unavailable: {type(e).__name__}: {e}")
        return False


def enron_rows():
    cache = os.path.join(RAW, ENRON_CACHE)
    if not os.path.exists(cache):
        return
    n, users = 0, set()
    with gzip.open(cache, "rt", encoding="utf-8") as f:
        for line in f:
            try:
                rec = json.loads(line)
                msg = message_from_bytes_robust(rec["raw"].encode("latin-1"))
            except Exception:
                continue
            t = _text(msg)
            if len(t) > MIN_CHARS:
                n += 1
                users.add(rec["user"])
                yield t, 0, "enron", _year(msg, 2001), rec["user"]
    log(f"  enron: {n} from {len(users)} mailboxes")


def lists_rows():
    for lst, months in APACHE_LISTS:
        for month in months:
            path = os.path.join(RAW, f"list-{lst.replace('@', '_at_')}-{month}.mbox")
            if not os.path.exists(path):
                continue
            n = 0
            for msg in _mbox_messages(path):
                if n >= LISTS_PER_FILE:
                    break
                t = _text(msg)
                if len(t) > MIN_CHARS:
                    n += 1
                    yield t, 0, "apache_lists", int(month[:4]), lst
            log(f"  list {lst} {month}: {n}")


def phishing_pot_rows():
    """EVALUATION ONLY (CC BY-NC 4.0): never written to corpus.csv."""
    import zipfile
    path = os.path.join(RAW, "phishing_pot.zip")
    if not os.path.exists(path):
        return
    n = 0
    with zipfile.ZipFile(path) as z:
        for name in sorted(z.namelist()):
            if not name.endswith(".eml"):
                continue
            try:
                msg = message_from_bytes_robust(z.read(name))
            except Exception:
                continue
            t = _text(msg)
            if len(t) > MIN_CHARS:
                n += 1
                yield t, 1, "phishing_pot", _year(msg, 2024), os.path.basename(name)
    log(f"  phishing_pot: {n}")


# ------------------------------------------------------------------ main
def main(argv=None):
    argv = sys.argv[1:] if argv is None else argv
    offline = "--offline" in argv
    use_enron = "--no-enron" not in argv
    use_lists = "--no-lists" not in argv
    use_legacy = "--no-legacy" not in argv
    with_pot = "--with-phishing-pot" in argv
    os.makedirs(RAW, exist_ok=True)
    files: dict[str, dict] = {}
    failed: list[str] = []

    def get(url, name):
        dest = os.path.join(RAW, name)
        ok = os.path.exists(dest) and os.path.getsize(dest) > 0
        if not ok and not offline:
            ok = _download(url, dest)
        if ok:
            files[name] = {"url": url, "bytes": os.path.getsize(dest), "sha256": _sha256(dest)}
        else:
            failed.append(name)
        return ok

    for y in NAZARIO_YEARS:
        get(NAZARIO_URL.format(y=y), f"nazario-{y}.mbox")
    if use_legacy:
        for f in NAZARIO_LEGACY:
            get(NAZARIO_LEGACY_URL.format(f=f), f"nazario-legacy-{f}")
    for n in SA_SETS:
        get(SA_URL.format(n=n), f"{n}.tar.bz2")
    if use_lists:
        for lst, months in APACHE_LISTS:
            for month in months:
                get(LISTS_URL.format(list=lst, month=month),
                    f"list-{lst.replace('@', '_at_')}-{month}.mbox")
    if use_enron:
        if fetch_enron(offline):
            p = os.path.join(RAW, ENRON_CACHE)
            files[ENRON_CACHE] = {"url": ENRON_URL, "bytes": os.path.getsize(p), "sha256": _sha256(p),
                                  "note": f"sample: <= {ENRON_PER_USER} msgs/mailbox, <= {ENRON_MAX} total"}
        else:
            failed.append(ENRON_CACHE)
    if with_pot:
        get(PHISHING_POT_URL, "phishing_pot.zip")

    sources = [nazario_rows()]
    if use_legacy:
        sources.append(nazario_legacy_rows())
    sources.append(spamassassin_rows())
    if use_enron:
        sources.append(enron_rows())
    if use_lists:
        sources.append(lists_rows())

    seen, rows, counts = set(), [], {}
    for src in sources:
        for t, label, name, year, group in src:
            h = dedup_key(t)
            if h in seen:
                continue  # drop duplicates (same campaign sent many times)
            seen.add(h)
            rows.append((t, label, name, year, group))
            c = counts.setdefault(name, {"phishing": 0, "legit": 0})
            c["phishing" if label else "legit"] += 1

    ph = sum(r[1] for r in rows)
    lg = len(rows) - ph
    if ph < 500 or lg < 500:
        log(f"ERROR: corpus too small ({ph} phishing / {lg} legit) - not writing {OUT}. "
            f"Missing: {', '.join(failed) or 'nothing?'}")
        return 2

    tmp = OUT + ".tmp"
    with open(tmp, "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(["text", "label", "source", "year", "group"])
        w.writerows(rows)
    os.replace(tmp, OUT)

    if with_pot:
        ev = os.path.join(DATA, "eval_phishing_pot.csv")
        pot, pot_seen = [], set()
        for r in phishing_pot_rows():
            k = dedup_key(r[0])
            if k in seen or k in pot_seen:
                continue               # already in the training corpus / same campaign again
            pot_seen.add(k)
            pot.append(r)
        with open(ev, "w", newline="", encoding="utf-8") as f:
            w = csv.writer(f)
            w.writerow(["text", "label", "source", "year", "group"])
            w.writerows(pot)
        log(f"wrote {ev}: {len(pot)} phishing (EVALUATION ONLY - CC BY-NC 4.0, not used for training)")

    with open(MANIFEST, "w", encoding="utf-8") as f:
        json.dump({"built_at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
                   "emails": len(rows), "phishing": ph, "legit": lg, "by_source": counts,
                   "missing_files": failed, "files": files}, f, indent=1)
    log(f"wrote {OUT}: {len(rows)} emails ({ph} phishing / {lg} legit)")
    for name, c in counts.items():
        log(f"   {name:16s} phishing {c['phishing']:6d}   legit {c['legit']:6d}")
    if failed:
        log(f"NOTE: {len(failed)} source file(s) missing and skipped: {', '.join(failed[:8])}"
            + (" ..." if len(failed) > 8 else ""))
    return 0


if __name__ == "__main__":
    sys.exit(main())
