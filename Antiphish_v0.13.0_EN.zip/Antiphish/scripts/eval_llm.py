"""How good is the configured Qwen model as a second opinion?

Runs every scenario (antiphish/scenarios*.py) through the detector twice - without and with the
LLM judge - and prints what the model said and what that changed. One LLM call per scenario
(101 calls: about 15 minutes with qwen2.5:3b on 4 CPU cores).

    python scripts/eval_llm.py                  # all scenarios
    python scripts/eval_llm.py --group dev      # the half that may be used for tuning
    python scripts/eval_llm.py --json out.jsonl # keep every answer

In Docker:  docker compose exec -u app web python scripts/eval_llm.py

Use it before offering "AI provjera" to users with another model: a judge that calls most
phishing legitimate (qwen2.5:3b with the v0.10.0 prompt: 49 of 51) is worse than no judge.
Do not tune the prompt on the "holdout" group - look at it only to confirm.
"""
from __future__ import annotations

import argparse
import json
import os
import sys
import time

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
sys.path.insert(0, ROOT)
from antiphish import config, detector, llm_judge  # noqa: E402
from antiphish.email_parser import message_from_bytes_robust, parse_message  # noqa: E402
from antiphish.scenarios import all_scenarios  # noqa: E402

CAUGHT = ("HIGH", "CRITICAL")


def run(group: str | None = None, limit: int | None = None, progress=None) -> list[dict]:
    """-> one row per scenario: the model's verdict and the level without / with it."""
    last: dict = {}
    calls = {}
    for name in ("_call_ollama", "_call_dashscope"):
        orig = getattr(llm_judge, name)

        def spy(prompt, _orig=orig):
            t = time.time()
            raw = _orig(prompt)
            last.update(seconds=round(time.time() - t, 1), raw=raw)
            return raw
        calls[name] = orig
        setattr(llm_judge, name, spy)
    old_sandbox, config.ATTACHMENT_SANDBOX = config.ATTACHMENT_SANDBOX, False
    rows = []
    try:
        scenarios = [s for s in all_scenarios() if not group or s.group == group][:limit]
        for i, sc in enumerate(scenarios, 1):
            parsed = parse_message(message_from_bytes_robust(sc.raw))
            base = detector.analyze_email(dict(parsed), use_url_intel=False, use_llm=False)
            last.clear()
            judged = detector.analyze_email(dict(parsed), use_url_intel=False, use_llm=True)
            verdict = llm_judge._extract_json(last.get("raw") or "") or {}
            rows.append({
                "name": sc.name, "kind": sc.kind, "group": sc.group,
                "answered": "is_phishing" in verdict, "says_phishing": verdict.get("is_phishing"),
                "confidence": verdict.get("confidence"), "summary": verdict.get("summary"),
                "seconds": last.get("seconds"),
                "level_without": base["level"], "score_without": base["score"],
                "level_with": judged["level"], "score_with": judged["score"],
                "llm_signals": [(s["signal"], s["weight"]) for s in judged["signals"]
                                if s["signal"].startswith("llm_")]})
            if progress:
                progress(i, len(scenarios), rows[-1])
    finally:
        config.ATTACHMENT_SANDBOX = old_sandbox
        for name, orig in calls.items():
            setattr(llm_judge, name, orig)
    return rows


def summarize(rows: list[dict]) -> dict:
    out = {}
    for group in sorted({r["group"] for r in rows}) + ["all"]:
        sel = [r for r in rows if group == "all" or r["group"] == group]
        phish = [r for r in sel if r["kind"] == "phish"]
        legit = [r for r in sel if r["kind"] == "legit"]
        secs = sorted(r["seconds"] for r in sel if r["seconds"] is not None)
        out[group] = {
            "phish": len(phish), "legit": len(legit),
            "no_answer": sum(not r["answered"] for r in sel),
            "phish_called_phishing": sum(r["says_phishing"] is True for r in phish),
            "legit_called_phishing": sum(r["says_phishing"] is True for r in legit),
            "phish_caught_without": sum(r["level_without"] in CAUGHT for r in phish),
            "phish_caught_with": sum(r["level_with"] in CAUGHT for r in phish),
            "legit_low_without": sum(r["level_without"] == "LOW" for r in legit),
            "legit_low_with": sum(r["level_with"] == "LOW" for r in legit),
            "seconds_median": secs[len(secs) // 2] if secs else None,
            "seconds_max": secs[-1] if secs else None,
        }
    return out


def report(rows: list[dict]) -> str:
    lines = [f"Qwen judge: provider={config.QWEN_PROVIDER} model={config.QWEN_MODEL}", ""]
    for group, s in summarize(rows).items():
        lines += [
            f"[{group}]  {s['phish']} phishing + {s['legit']} legitimate scenarios"
            + (f"   (no usable answer: {s['no_answer']})" if s["no_answer"] else ""),
            f"   the model called phishing 'phishing':      {s['phish_called_phishing']}/{s['phish']}",
            f"   the model called legitimate 'phishing':    {s['legit_called_phishing']}/{s['legit']}   (should be 0)",
            f"   phishing rated HIGH/CRITICAL:  without {s['phish_caught_without']}/{s['phish']}  ->  with the judge {s['phish_caught_with']}/{s['phish']}",
            f"   legitimate rated LOW:          without {s['legit_low_without']}/{s['legit']}  ->  with the judge {s['legit_low_with']}/{s['legit']}",
            f"   seconds per mail: median {s['seconds_median']}, slowest {s['seconds_max']}", ""]
    changed = [r for r in rows if r["level_without"] != r["level_with"]]
    if changed:
        lines.append("Level changed by the judge:")
        for r in changed:
            lines.append(f"   [{r['kind']}] {r['name']}: {r['level_without']} {r['score_without']:.0f} -> "
                         f"{r['level_with']} {r['score_with']:.0f}   {r['llm_signals']}")
    wrong = [r for r in rows if r["answered"] and (r["kind"] == "phish") != bool(r["says_phishing"])]
    if wrong:
        lines.append("Wrong opinions:")
        for r in wrong:
            lines.append(f"   [{r['kind']}] {r['name']}: says {'phishing' if r['says_phishing'] else 'legitimate'} "
                         f"({r['confidence']}%) - {(r['summary'] or '')[:110]}")
    return "\n".join(lines)


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description=__doc__.split("\n\n")[0])
    ap.add_argument("--group", choices=["dev", "holdout"])
    ap.add_argument("--limit", type=int)
    ap.add_argument("--json", help="write one JSON line per scenario to this file")
    args = ap.parse_args(argv)
    ok, status = llm_judge.llm_status()
    print(f"LLM status: {status}")
    if not ok:
        print("The model is not reachable - nothing to measure.")
        return 2

    def progress(i, n, row):
        said = "no answer" if not row["answered"] else ("phishing" if row["says_phishing"] else "legitimate")
        print(f"  {i:3d}/{n} {row['kind']:5s} {row['name'][:44]:44s} -> {said:10s} {row['seconds'] or 0:5.1f}s", flush=True)

    rows = run(args.group, args.limit, progress)
    if args.json:
        with open(args.json, "w", encoding="utf-8") as f:
            for r in rows:
                f.write(json.dumps(r, ensure_ascii=False) + "\n")
    print("\n" + report(rows))
    return 0


if __name__ == "__main__":
    sys.exit(main())
