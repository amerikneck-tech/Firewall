"""Measure AntiPhish on YOUR OWN mail - and turn its mistakes into training data.

Public corpora cannot tell you how the detector behaves on your inbox. This can:

    # 1) export mail you know is fine (Gmail: Google Takeout -> .mbox; Outlook/Thunderbird: .eml files)
    python scripts/scan_folder.py ~/Downloads/known_good.mbox --expect legit

    # 2) same for a folder of phishing you collected (spam folder exports)
    python scripts/scan_folder.py ~/phish_samples/ --expect phishing

    # 3) add every WRONG verdict to data/feedback.csv, then retrain
    python scripts/scan_folder.py ~/Downloads/known_good.mbox --expect legit --add-feedback
    python -m antiphish.learn

Nothing leaves the machine: no VirusTotal lookups, no LLM (unless --intel is given).
Texts written to feedback.csv are recipient-neutral (your own address and name
are replaced by placeholders, exactly as at scan time).
"""
from __future__ import annotations

import argparse
import collections
import csv
import mailbox
import os
import sys

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
sys.path.insert(0, ROOT)
from antiphish.config import DATA_DIR  # noqa: E402
from antiphish.detector import analyze_email  # noqa: E402
from antiphish.email_parser import message_from_bytes_robust, parse_message  # noqa: E402
from antiphish.model import scrub_recipient  # noqa: E402

LEVELS = ("LOW", "SUSPICIOUS", "HIGH", "CRITICAL")


def iter_raw(path: str):
    """(name, raw bytes) for every message in an .mbox file or a folder of .eml files."""
    if os.path.isdir(path):
        for base, _dirs, files in os.walk(path):
            for fn in sorted(files):
                if fn.lower().endswith((".eml", ".msg.eml", ".txt")):
                    full = os.path.join(base, fn)
                    try:
                        with open(full, "rb") as f:
                            yield os.path.relpath(full, path), f.read()
                    except OSError as e:
                        print(f"  cannot read {full}: {e}")
    elif os.path.isfile(path):
        if path.lower().endswith(".eml"):
            with open(path, "rb") as f:
                yield os.path.basename(path), f.read()
        else:
            for i, raw in enumerate(mailbox.mbox(path, factory=lambda f: f.read())):
                yield f"#{i + 1}", raw
    else:
        raise SystemExit(f"not found: {path}")


def is_wrong(level: str, expect: str | None) -> bool:
    if expect == "legit":
        return level != "LOW"
    if expect == "phishing":
        return level in ("LOW", "SUSPICIOUS")
    return False


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("path", help=".mbox file, .eml file or folder with .eml files")
    ap.add_argument("--expect", choices=["legit", "phishing"], help="what this mail really is")
    ap.add_argument("--add-feedback", action="store_true",
                    help="append WRONG verdicts to data/feedback.csv with the --expect label")
    ap.add_argument("--add-all", action="store_true", help="with --add-feedback: add every mail, not only the wrong ones")
    ap.add_argument("--limit", type=int, default=0, help="stop after N messages")
    ap.add_argument("--csv", help="write one row per mail (name, score, level, subject, sender, signals)")
    ap.add_argument("--intel", action="store_true", help="allow VirusTotal/urlscan lookups (needs API keys)")
    ap.add_argument("--show", type=int, default=25, help="how many wrong verdicts to print")
    a = ap.parse_args(argv)
    if a.add_feedback and not a.expect:
        ap.error("--add-feedback needs --expect legit|phishing")

    counts = collections.Counter()
    wrong, rows, feedback = [], [], []
    errors = n = 0
    for name, raw in iter_raw(a.path):
        if a.limit and n >= a.limit:
            break
        try:
            parsed = parse_message(message_from_bytes_robust(raw))
            r = analyze_email(parsed, use_url_intel=a.intel, use_llm=False)
        except Exception as e:
            errors += 1
            print(f"  ERROR {name}: {type(e).__name__}: {e}")
            continue
        n += 1
        counts[r["level"]] += 1
        top = [f"{s['signal']}({s['weight']:+})" for s in r["signals"] if s["weight"]][:6]
        rec = (name, r["score"], r["level"], (parsed.get("subject") or "")[:80],
               (parsed.get("sender") or "")[:60], " ".join(top))
        rows.append(rec)
        bad = is_wrong(r["level"], a.expect)
        if bad:
            wrong.append(rec)
        if a.add_feedback and (bad or a.add_all):
            text = f"{parsed.get('subject', '')}\n{parsed.get('body', '')}".strip()
            text = scrub_recipient(text, parsed.get("to"))[:6000]
            if len(text) >= 30:
                feedback.append((text, 1 if a.expect == "phishing" else 0))
        if n % 200 == 0:
            print(f"  ... {n} scanned", flush=True)

    print(f"\nScanned {n} message(s)" + (f", {errors} unreadable" if errors else ""))
    for lv in LEVELS:
        share = counts[lv] / n if n else 0
        print(f"  {lv:11s} {counts[lv]:6d}  {share:6.1%}")
    if a.expect and n:
        kind = "false alarms (not LOW)" if a.expect == "legit" else "under-rated (LOW or SUSPICIOUS)"
        print(f"\nExpected: {a.expect}.  {kind}: {len(wrong)} of {n} = {len(wrong) / n:.1%}")
        for name, score, level, subj, sender, sigs in sorted(wrong, key=lambda x: -x[1])[: a.show]:
            print(f"  {score:5.1f} {level:10s} {subj!r} | {sender!r}\n        {sigs}")
        if len(wrong) > a.show:
            print(f"  ... and {len(wrong) - a.show} more (use --csv to get all)")

    if a.csv:
        with open(a.csv, "w", newline="", encoding="utf-8") as f:
            w = csv.writer(f)
            w.writerow(["name", "score", "level", "subject", "sender", "signals"])
            w.writerows(rows)
        print(f"\nwrote {a.csv}")
    if feedback:
        path = os.path.join(DATA_DIR, "feedback.csv")
        os.makedirs(os.path.dirname(path), exist_ok=True)
        with open(path, "a", newline="", encoding="utf-8") as f:
            csv.writer(f).writerows(feedback)
        print(f"\nadded {len(feedback)} row(s) to {path}  ->  now run: python -m antiphish.learn")
    return 0


if __name__ == "__main__":
    sys.exit(main())
