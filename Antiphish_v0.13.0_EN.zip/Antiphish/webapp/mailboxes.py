"""Connected mailboxes: the providers offered on the "Connect email" page and the
IMAP side of reading a mailbox.

Reading is strictly read-only: the folder is opened with EXAMINE and messages are
fetched with BODY.PEEK[], so nothing is marked as read, moved or deleted.
"""
from __future__ import annotations

import email.utils
import imaplib
import logging
import re
import socket
import ssl

from antiphish.providers import mail_ssl_context

from . import config, netguard

log = logging.getLogger("antiphish.mailbox")

IMAP_TIMEOUT = 25          # seconds for connect and for every command


# ------------------------------------------------------------------ providers
# kind "imap":  address + (app) password over IMAP
# kind "graph": Microsoft sign-in (OAuth 2.0), mail is read through Microsoft Graph
PROVIDERS = {
    "gmail": {
        "name": "Gmail", "kind": "imap", "host": "imap.gmail.com", "letter": "G",
        "domains": ("gmail.com", "googlemail.com"),
        "secret_label": "App password (16 letters)",
        "strip_spaces": True,
        "link": "https://myaccount.google.com/apppasswords",
        "steps": [
            "On your Google account enable <b>2-Step Verification</b> (if it isn't already).",
            "Open <b>myaccount.google.com/apppasswords</b> and sign in.",
            "Enter a name, e.g. <i>AntiPhish</i>, and click <b>Create</b>.",
            "Google shows a 16-letter password – copy it and paste it here.",
        ],
        "note": "Your regular Google password doesn't work here – for apps like this one Google only allows "
                "a special \"app password\". You can revoke it anytime on the same page.",
        "auth_hint": "Gmail refused the sign-in. Check that you pasted the app password (16 letters), "
                     "not your regular Google password, and that 2-Step Verification is enabled.",
    },
    "microsoft": {
        "name": "Outlook / Hotmail / Microsoft 365", "kind": "graph", "letter": "O",
        "domains": ("outlook.com", "hotmail.com", "live.com", "msn.com"),
    },
    "yahoo": {
        "name": "Yahoo Mail", "kind": "imap", "host": "imap.mail.yahoo.com", "letter": "Y",
        "domains": ("yahoo.com", "ymail.com", "rocketmail.com"),
        "secret_label": "App password",
        "strip_spaces": True,
        "link": "https://login.yahoo.com/account/security",
        "steps": [
            "Open <b>login.yahoo.com/account/security</b>.",
            "Choose <b>Generate app password</b>.",
            "Enter a name, e.g. <i>AntiPhish</i>, and confirm.",
            "Copy the password shown and paste it here.",
        ],
        "note": "Your regular Yahoo password doesn't work here – an app password is required.",
        "auth_hint": "Yahoo refused the sign-in. An app password is required, not your regular Yahoo password.",
    },
    "icloud": {
        "name": "iCloud Mail", "kind": "imap", "host": "imap.mail.me.com", "letter": "i",
        "domains": ("icloud.com", "me.com", "mac.com"),
        "secret_label": "App password (xxxx-xxxx-xxxx-xxxx)",
        "strip_spaces": True,
        "link": "https://account.apple.com",
        "steps": [
            "Open <b>account.apple.com</b> and sign in.",
            "<b>Sign-In and Security</b> → <b>App-Specific Passwords</b>.",
            "Create a new password named <i>AntiPhish</i>.",
            "Copy it (with the dashes) and paste it here.",
        ],
        "note": "Your regular Apple password doesn't work here – an app password is required.",
        "auth_hint": "iCloud refused the sign-in. An app-specific password is required (App-Specific Password).",
    },
    "hostinger": {
        "name": "Hostinger Email", "kind": "imap", "host": "imap.hostinger.com", "letter": "H",
        "domains": (),
        "secret_label": "Mailbox password",
        "strip_spaces": False,
        "steps": [
            "Enter the full mailbox address (e.g. <i>name@your-domain.com</i>).",
            "Enter that mailbox's password (the one from hPanel → Emails).",
        ],
        "note": "",
        "auth_hint": "Hostinger refused the sign-in. Check the mailbox address and password (hPanel → Emails).",
    },
    "imap": {
        "name": "Other email (IMAP)", "kind": "imap", "host": "", "letter": "@",
        "domains": (),
        "secret_label": "Password (or app password)",
        "strip_spaces": False,
        "steps": [
            "Enter the mailbox address and password.",
            "Enter your provider's IMAP server (e.g. <i>imap.your-domain.com</i>) – it's in the provider's "
            "instructions for setting up mail apps.",
            "If the account uses two-step sign-in, create an app password with the provider.",
        ],
        "note": "The connection is always encrypted (IMAP over TLS, port 993) and the server certificate is verified.",
        "auth_hint": "The server refused the sign-in. Check the address and password; with two-step sign-in "
                     "an app password is required.",
    },
}
PROVIDER_ORDER = ["gmail", "microsoft", "yahoo", "icloud", "hostinger", "imap"]


def provider_for_address(addr: str) -> str | None:
    domain = (addr or "").rsplit("@", 1)[-1].strip().lower()
    for key, p in PROVIDERS.items():
        if domain in p.get("domains", ()):
            return key
    return None


def microsoft_configured() -> bool:
    return bool(config.MS_CLIENT_ID and config.MS_CLIENT_SECRET)


_EMAIL_RE = re.compile(r"^[^@\s<>\"',;]{1,64}@[a-z0-9.-]{3,253}$", re.I)


def clean_email(addr: str) -> str | None:
    addr = (addr or "").strip()
    return addr.lower() if _EMAIL_RE.match(addr) else None


def clean_secret(provider: str, secret: str) -> str:
    """App passwords are shown in groups ("abcd efgh ijkl mnop"); the spaces are not part of them."""
    secret = (secret or "").strip()
    if PROVIDERS.get(provider, {}).get("strip_spaces"):
        secret = re.sub(r"\s+", "", secret)
    return secret


def secret_aad(user_id: int, addr: str) -> str:
    """What a stored secret is bound to (see crypto.py)."""
    return f"mailbox:{user_id}:{addr.strip().lower()}"


# ------------------------------------------------------------------ errors
class MailboxError(Exception):
    """A problem with a user's mailbox. `kind` decides what happens next:
    auth -> wrong / revoked password (do not keep trying), tls / host -> the server
    cannot be used as given, network / protocol -> try again later."""

    def __init__(self, kind: str, message: str):
        super().__init__(message)
        self.kind = kind
        self.message = message


# ------------------------------------------------------------------ IMAP
class _PinnedIMAP4SSL(imaplib.IMAP4_SSL):
    """IMAP over TLS to an address that was checked beforehand; the certificate is
    verified against the host NAME the user gave."""

    def __init__(self, host: str, port: int, ip: str, ssl_context, timeout: float):
        self._ip = ip
        super().__init__(host, port, ssl_context=ssl_context, timeout=timeout)

    def _create_socket(self, timeout):
        sock = socket.create_connection((self._ip, self.port), timeout)
        return self.ssl_context.wrap_socket(sock, server_hostname=self.host)


_TEMPORARY_WORDS = ("unavailable", "temporar", "too many", "try again", "throttl", "rate limit",
                    "system error", "server error")


def open_imap(host: str, login: str, password: str, port: int | None = None, provider: str = "imap"):
    """Connect + log in. Raises MailboxError with a message meant for the user."""
    port = port or config.MAILBOX_PORT
    if port != config.MAILBOX_PORT:
        raise MailboxError("host", "Only encrypted IMAP on port 993 is allowed.")
    try:
        ips = netguard.resolve_checked(host, port)
    except netguard.HostNotAllowed as e:
        raise MailboxError("host", str(e)) from None
    host = netguard.clean_host(host)
    mail, last = None, None
    for ip in ips[:3]:
        try:
            mail = _PinnedIMAP4SSL(host, port, ip, mail_ssl_context(), IMAP_TIMEOUT)
            break
        except ssl.SSLCertVerificationError as e:
            log.warning("certificate of %s not accepted: %s", host, getattr(e, "verify_message", e))
            raise MailboxError("tls", f"The certificate of server '{host}' is not valid for that name. "
                                      "Use the server name given by your mail provider.") from None
        except (OSError, imaplib.IMAP4.error) as e:      # refused, timed out, not an IMAP server
            last = e
    if mail is None:
        log.info("no IMAP connection to %s:%s (%s)", host, port, type(last).__name__)
        raise MailboxError("network", f"Cannot connect to '{host}' (port {port}). Check the server "
                                      "name; if it's correct, try again in a few minutes.")
    try:
        mail.login(login, password)
    except imaplib.IMAP4.abort as e:
        _quiet_logout(mail)
        raise MailboxError("network", "The connection to the mail server was interrupted. Try again.") from e
    except imaplib.IMAP4.error as e:
        # the server's own text is not shown: it can contain anything
        _quiet_logout(mail)
        if any(w in str(e).lower() for w in _TEMPORARY_WORDS):
            # "NO [UNAVAILABLE] Temporary System Error", "Too many simultaneous connections" ...:
            # the password is not the problem
            raise MailboxError("network", "The mail server is not accepting sign-ins right now. Try again "
                                          "in a few minutes.") from None
        hint = PROVIDERS.get(provider, PROVIDERS["imap"]).get("auth_hint") or PROVIDERS["imap"]["auth_hint"]
        raise MailboxError("auth", hint) from None
    except (OSError, UnicodeError) as e:
        _quiet_logout(mail)
        if isinstance(e, UnicodeError):
            raise MailboxError("auth", "The address or password contains a character the mail server does not accept.") from None
        raise MailboxError("network", "The connection to the mail server was interrupted. Try again.") from e
    return mail


def _quiet_logout(mail):
    try:
        mail.logout()
    except Exception:
        try:
            mail.shutdown()
        except Exception:
            pass


def _uidvalidity(mail) -> str:
    typ, data = mail.response("UIDVALIDITY")
    val = data[0] if data else None
    if isinstance(val, bytes):
        val = val.decode("ascii", "replace")
    return str(val or "0")


_UID_RE = re.compile(rb"\bUID (\d+)")
_SIZE_RE = re.compile(rb"\bRFC822\.SIZE (\d+)")
_DATE_RE = re.compile(rb'\bINTERNALDATE "([^"]+)"')


class ImapReader:
    """One read-only visit to the INBOX of a connected mailbox."""

    def __init__(self, host: str, login: str, password: str, port: int | None = None,
                 provider: str = "imap"):
        self.mail = open_imap(host, login, password, port, provider)
        try:
            typ, data = self.mail.select("INBOX", readonly=True)        # EXAMINE: nothing can be changed
            if typ != "OK":
                raise MailboxError("protocol", "The mail server does not allow opening the inbox (INBOX).")
            self.exists = int(data[0] or 0) if data and data[0] else 0
            self.uidvalidity = _uidvalidity(self.mail)
        except MailboxError:
            self.close()
            raise
        except (imaplib.IMAP4.error, OSError, ValueError) as e:
            self.close()
            raise MailboxError("protocol", "The mail server did not respond as expected. Try again.") from e

    def close(self):
        _quiet_logout(self.mail)

    def __enter__(self):
        return self

    def __exit__(self, *exc):
        self.close()

    def _wrap(self, fn, *args):
        try:
            return fn(*args)
        except imaplib.IMAP4.abort as e:
            raise MailboxError("network", "The connection to the mail server was interrupted.") from e
        except (imaplib.IMAP4.error, OSError) as e:
            raise MailboxError("protocol", "The mail server did not respond as expected.") from e

    def newest_uids(self, n: int) -> list[int]:
        """UIDs of the newest n messages, oldest first."""
        if n <= 0 or self.exists <= 0:
            return []
        start = max(1, self.exists - n + 1)
        typ, data = self._wrap(self.mail.fetch, f"{start}:*", "(UID)")
        uids = []
        for item in data or []:
            m = _UID_RE.search(item if isinstance(item, bytes) else b"")
            if m:
                uids.append(int(m.group(1)))
        return sorted(set(uids))[-n:]

    def max_uid(self) -> int:
        uids = self.newest_uids(1)
        return uids[-1] if uids else 0

    def uids_after(self, last_uid: int) -> list[int]:
        """UIDs greater than last_uid, oldest first."""
        typ, data = self._wrap(self.mail.uid, "SEARCH", None, f"UID {int(last_uid) + 1}:*")
        raw = data[0].split() if typ == "OK" and data and data[0] else []
        # "N:*" also returns the newest message when nothing is newer than N
        return sorted(int(u) for u in raw if int(u) > last_uid)

    def describe(self, uids: list[int]) -> dict[int, dict]:
        """{uid: {"size": bytes, "date": unix time or None}} without downloading the mail."""
        if not uids:
            return {}
        typ, data = self._wrap(self.mail.uid, "FETCH", ",".join(str(u) for u in uids),
                               "(UID RFC822.SIZE INTERNALDATE)")
        out = {}
        for item in data or []:
            if not isinstance(item, bytes):
                continue
            u, s, d = _UID_RE.search(item), _SIZE_RE.search(item), _DATE_RE.search(item)
            if not u:
                continue
            when = None
            if d:
                try:
                    when = email.utils.mktime_tz(email.utils.parsedate_tz(
                        d.group(1).decode("ascii", "replace").replace("-", " ", 2)))
                except Exception:
                    when = None
            out[int(u.group(1))] = {"size": int(s.group(1)) if s else 0, "date": when}
        return out

    def fetch(self, uid: int, max_bytes: int | None = None) -> bytes | None:
        """The whole message, unread flag untouched (PEEK). With max_bytes the server is
        asked for at most that much + 1: whatever size it REPORTED, more than that
        never comes down the line - the caller can tell by the length it was too big."""
        part = "BODY.PEEK[]" if not max_bytes else f"BODY.PEEK[]<0.{int(max_bytes) + 1}>"
        typ, data = self._wrap(self.mail.uid, "FETCH", str(uid), f"({part})")
        if typ != "OK":
            return None
        return next((p[1] for p in (data or []) if isinstance(p, tuple) and len(p) > 1), None)


def test_login(host: str, login: str, password: str, port: int | None = None,
               provider: str = "imap") -> int:
    """Used when a mailbox is being connected: can we log in and open the INBOX?
    -> number of messages in it. Raises MailboxError."""
    with ImapReader(host, login, password, port, provider) as reader:
        return reader.exists
