"""Outlook.com / Hotmail / Microsoft 365 mailboxes.

Microsoft no longer accepts a password from third-party programs, so these
mailboxes are connected with Microsoft sign-in (OAuth 2.0 authorization code flow
with PKCE) and read through Microsoft Graph with the delegated, read-only
permission Mail.Read. AntiPhish never sees the user's Microsoft password; it keeps
the refresh token (encrypted, see crypto.py), which the user can revoke at any time
at account.microsoft.com -> Privacy -> Apps and services.

Needs an app registration of the operator's own (MS_CLIENT_ID / MS_CLIENT_SECRET,
see deploy/DEPLOY.md). Protocol reference:
  learn.microsoft.com/entra/identity-platform/v2-oauth2-auth-code-flow
  learn.microsoft.com/graph/api/user-list-messages , .../graph/outlook-get-mime-message

NOTE: this module was written from Microsoft's documentation and tested against a
stand-in server that follows it (tests/test_v011.py) - not against Microsoft itself.
"""
from __future__ import annotations

import base64
import hashlib
import logging
import secrets
import time
from urllib.parse import quote, urlencode

import requests

from . import config
from .mailboxes import MailboxError

log = logging.getLogger("antiphish.mailbox")

SCOPES = "offline_access User.Read Mail.Read"
HTTP_TIMEOUT = (10, 40)            # connect, read
_IMMUTABLE = {"Prefer": 'IdType="ImmutableId"'}     # ids that survive a move between folders


def redirect_uri() -> str:
    return f"{config.BASE_URL}/mailboxes/microsoft/callback"


def _token_url() -> str:
    return f"{config.MS_LOGIN_BASE}/{config.MS_TENANT}/oauth2/v2.0/token"


# ------------------------------------------------------------------ sign-in
def new_login() -> dict:
    """-> {"state", "verifier", "url"}: keep state+verifier in the session, send the user to url."""
    state = secrets.token_urlsafe(24)
    verifier = secrets.token_urlsafe(64)                      # 86 characters (PKCE allows 43-128)
    challenge = base64.urlsafe_b64encode(hashlib.sha256(verifier.encode("ascii")).digest()) \
        .decode("ascii").rstrip("=")
    query = urlencode({
        "client_id": config.MS_CLIENT_ID,
        "response_type": "code",
        "redirect_uri": redirect_uri(),
        "response_mode": "query",
        "scope": SCOPES,
        "state": state,
        "code_challenge": challenge,
        "code_challenge_method": "S256",
        "prompt": "select_account",
    }, quote_via=quote)
    return {"state": state, "verifier": verifier,
            "url": f"{config.MS_LOGIN_BASE}/{config.MS_TENANT}/oauth2/v2.0/authorize?{query}"}


def _token_request(data: dict) -> dict:
    data = dict(data, client_id=config.MS_CLIENT_ID, client_secret=config.MS_CLIENT_SECRET)
    try:
        r = requests.post(_token_url(), data=data, timeout=HTTP_TIMEOUT)
    except requests.RequestException as e:
        raise MailboxError("network", "Microsoft sign-in is currently unavailable. Try again.") from e
    try:
        body = r.json()
    except ValueError:
        body = {}
    if r.status_code != 200 or "access_token" not in body:
        err = str(body.get("error") or f"http_{r.status_code}")
        # the description names the cause (AADSTS code) and holds no secrets - for the operator's log
        log.warning("Microsoft token endpoint refused (%s): %s", err,
                    str(body.get("error_description") or "")[:300].replace("\r\n", " "))
        if err in ("invalid_grant", "interaction_required", "consent_required"):
            raise MailboxError("auth", "Microsoft requires a new sign-in for this account (access has expired "
                                       "or was revoked). Reconnect the mailbox.")
        if err in ("invalid_client", "unauthorized_client"):
            raise MailboxError("config", "Microsoft refused the app credentials (MS_CLIENT_ID / "
                                         "MS_CLIENT_SECRET). The administrator should check the configuration.")
        if r.status_code >= 500 or err == "temporarily_unavailable":
            raise MailboxError("network", "Microsoft sign-in is currently unavailable. Try again.")
        raise MailboxError("protocol", "Microsoft sign-in failed. Try again.")
    return body


def redeem_code(code: str, verifier: str) -> dict:
    """Authorization code -> {"access_token", "refresh_token", "expires_at"}."""
    body = _token_request({"grant_type": "authorization_code", "code": code,
                           "redirect_uri": redirect_uri(), "code_verifier": verifier,
                           "scope": SCOPES})
    if not body.get("refresh_token"):
        raise MailboxError("protocol", "Microsoft did not issue lasting access (offline_access). Try again.")
    return _tokens(body)


def refresh(refresh_token: str) -> dict:
    """-> new tokens. Microsoft may hand out a NEW refresh token: the caller must store it."""
    body = _token_request({"grant_type": "refresh_token", "refresh_token": refresh_token,
                           "scope": SCOPES})
    out = _tokens(body)
    out["refresh_token"] = body.get("refresh_token") or refresh_token
    return out


def _tokens(body: dict) -> dict:
    return {"access_token": body["access_token"], "refresh_token": body.get("refresh_token"),
            "expires_at": time.time() + max(60, int(body.get("expires_in") or 3600) - 120)}


# ------------------------------------------------------------------ Graph
class Throttled(MailboxError):
    def __init__(self, retry_after: int):
        super().__init__("network", "Microsoft is currently rate-limiting requests. Continuing soon.")
        self.retry_after = retry_after


def _get(path_or_url: str, access_token: str, params: dict | None = None, stream: bool = False):
    url = path_or_url if path_or_url.startswith("http") else f"{config.MS_GRAPH_BASE}{path_or_url}"
    if not url.startswith(config.MS_GRAPH_BASE + "/"):
        # a "next page" link is followed only when it stays on the Graph server
        raise MailboxError("protocol", "Unexpected response from the Microsoft server.")
    try:
        r = requests.get(url, params=params, stream=stream, timeout=HTTP_TIMEOUT,
                         headers={"Authorization": f"Bearer {access_token}", **_IMMUTABLE})
    except requests.RequestException as e:
        raise MailboxError("network", "Microsoft Graph is currently unavailable.") from e
    if r.status_code == 401:
        raise MailboxError("token", "The access token has expired.")
    if r.status_code == 403:
        log.warning("Graph 403 for %s: %s", url.split("?")[0], r.text[:300])
        raise MailboxError("auth", "Microsoft does not allow reading this mailbox (the Mail.Read permission "
                                   "is missing or the organization blocked access). Reconnect the mailbox.")
    if r.status_code in (429, 503, 504):
        try:
            wait = int(r.headers.get("Retry-After") or 60)
        except ValueError:
            wait = 60
        raise Throttled(min(max(wait, 10), 3600))
    if r.status_code == 404:
        return None
    if r.status_code != 200:
        log.warning("Graph %s for %s: %s", r.status_code, url.split("?")[0], r.text[:300])
        raise MailboxError("protocol", "Microsoft Graph returned an unexpected response.")
    return r


def whoami(access_token: str) -> str:
    """The address of the mailbox that was just connected."""
    r = _get("/me", access_token, {"$select": "mail,userPrincipalName"})
    body = r.json() if r is not None else {}
    addr = (body.get("mail") or body.get("userPrincipalName") or "").strip().lower()
    if "@" not in addr:
        raise MailboxError("protocol", "Microsoft did not return the mailbox address.")
    return addr


def newest(access_token: str, n: int) -> list[dict]:
    """The newest n inbox messages, oldest first: [{"id", "received"}]."""
    if n <= 0:
        return []
    r = _get("/me/mailFolders/inbox/messages", access_token,
             {"$select": "id,receivedDateTime", "$orderby": "receivedDateTime desc", "$top": str(min(n, 100))})
    items = (r.json() if r is not None else {}).get("value") or []
    return [{"id": m["id"], "received": m.get("receivedDateTime") or ""} for m in reversed(items) if m.get("id")]


def since(access_token: str, cursor: str, limit: int) -> list[dict]:
    """Inbox messages received at or after `cursor` (an ISO time), oldest first.
    "At or after": two mails can arrive in the same second - the caller skips what it already has."""
    r = _get("/me/mailFolders/inbox/messages", access_token,
             {"$select": "id,receivedDateTime", "$filter": f"receivedDateTime ge {cursor}",
              "$orderby": "receivedDateTime asc", "$top": str(min(max(limit, 1), 100))})
    items = (r.json() if r is not None else {}).get("value") or []
    return [{"id": m["id"], "received": m.get("receivedDateTime") or ""} for m in items if m.get("id")]


def mime(access_token: str, message_id: str, max_bytes: int) -> bytes | None:
    """The message as it was sent (RFC 822). None: gone meanwhile, or larger than max_bytes."""
    r = _get(f"/me/messages/{quote(message_id, safe='')}/$value", access_token, stream=True)
    if r is None:
        return None
    try:
        chunks, total = [], 0
        for chunk in r.iter_content(64 * 1024):
            total += len(chunk)
            if total > max_bytes:
                return None
            chunks.append(chunk)
        return b"".join(chunks)
    except requests.RequestException as e:
        raise MailboxError("network", "Veza sa Microsoft Graph je prekinuta.") from e
    finally:
        r.close()


def parse_time(iso: str) -> float | None:
    """'2026-11-23T10:15:00Z' -> unix time."""
    try:
        import calendar
        return float(calendar.timegm(time.strptime(iso[:19], "%Y-%m-%dT%H:%M:%S")))
    except Exception:
        return None
