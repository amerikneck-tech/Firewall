"""DNS shield - a DNS firewall the user's devices talk to over DNS-over-HTTPS (RFC 8484).

An agent on the device (or any DoH client) sends raw DNS wire-format queries to
/dns-query/<token>. The token identifies the device; the query is then:

  1. parsed (only the question section - enough to know the domain being asked about),
  2. checked against the user's rules (block / allow, with *. suffix matching),
  3. either answered on the spot (NXDOMAIN for blocked domains - no upstream traffic
     at all) or forwarded byte-for-byte to the upstream resolver (config.DNSFW_UPSTREAM),
     with a TCP retry if the UDP answer comes back truncated.

Every query is written to the device log so the dashboard can show live traffic.
The server never runs an open resolver: without a valid device token there is no answer.
"""
from __future__ import annotations

import base64
import hashlib
import logging
import re
import secrets
import socket
import struct
import time

from . import config, db

log = logging.getLogger("antiphish.dnsfw")

# Always blocked, no rule needed: an end-to-end test domain so a fresh setup can be
# verified ("if this domain does not resolve, blocking works").
TEST_BLOCKED_DOMAIN = "dns-shield-test.invalid"

MAX_QUERY_BYTES = 4096
_DOMAIN_CHARS = re.compile(r"^[a-z0-9.-]+$")


# ------------------------------------------------------------------ wire format
class QueryError(Exception):
    """The bytes are not a DNS query we can read (truncated, weird compression...)."""


def _read_name(msg: bytes, off: int) -> tuple[str, int]:
    """Read a possibly-compressed domain name. Returns (domain, offset after the name).
    Pointers (0xC0) are followed for reading but the 'after' offset stays at the
    pointer's end, per RFC 1035 4.1.4."""
    labels, jumped, end_off, hops = [], False, off, 0
    while True:
        if off >= len(msg):
            raise QueryError("truncated name")
        length = msg[off]
        if length & 0xC0 == 0xC0:                      # compression pointer
            if off + 1 >= len(msg):
                raise QueryError("truncated pointer")
            ptr = ((length & 0x3F) << 8) | msg[off + 1]
            if not jumped:
                end_off = off + 2
            off, jumped = ptr, True
            hops += 1
            if hops > 16:
                raise QueryError("pointer loop")
            continue
        if length & 0xC0:
            raise QueryError("unknown label type")
        off += 1
        if length == 0:
            if not jumped:
                end_off = off
            break
        if off + length > len(msg):
            raise QueryError("truncated label")
        labels.append(msg[off:off + length].decode("ascii", errors="replace"))
        off += length
    return ".".join(labels).lower(), end_off


def parse_query(msg: bytes) -> dict:
    """Parse a DNS query's header + first question. Raises QueryError if unreadable."""
    if len(msg) < 12:
        raise QueryError("shorter than a DNS header")
    qid, flags, qdcount, _an, _ns, _ar = struct.unpack("!HHHHHH", msg[:12])
    if flags & 0x8000:
        raise QueryError("this is a response, not a query")
    if qdcount < 1:
        raise QueryError("no question")
    qname, off = _read_name(msg, 12)
    if off + 4 > len(msg):
        raise QueryError("truncated question")
    qtype, qclass = struct.unpack("!HH", msg[off:off + 4])
    return {"id": qid, "flags": flags, "qname": qname, "qtype": qtype, "qclass": qclass,
            "question_end": off + 4}


def nxdomain_response(query: bytes, q: dict) -> bytes:
    """A valid NXDOMAIN answer built from the query itself (same id + question)."""
    flags = 0x8000 | (q["flags"] & 0x0100) | 0x0080 | 0x0003   # QR + RD echoed + RA + RCODE 3
    head = struct.pack("!HHHHHH", q["id"], flags, 1, 0, 0, 0)
    return head + query[12:q["question_end"]]


def servfail_response(query: bytes, q: dict) -> bytes:
    flags = 0x8000 | (q["flags"] & 0x0100) | 0x0080 | 0x0002   # RCODE 2
    head = struct.pack("!HHHHHH", q["id"], flags, 1, 0, 0, 0)
    return head + query[12:q["question_end"]]


def _forward_udp(query: bytes, host: str, port: int, timeout: float) -> bytes:
    with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as s:
        s.settimeout(timeout)
        s.sendto(query, (host, port))
        data, _ = s.recvfrom(65535)
        return data


def _forward_tcp(query: bytes, host: str, port: int, timeout: float) -> bytes:
    with socket.create_connection((host, port), timeout=timeout) as s:
        s.settimeout(timeout)
        s.sendall(struct.pack("!H", len(query)) + query)
        raw = _recv_exact(s, 2)
        (size,) = struct.unpack("!H", raw)
        return _recv_exact(s, size)


def _recv_exact(s: socket.socket, n: int) -> bytes:
    out = b""
    while len(out) < n:
        chunk = s.recv(n - len(out))
        if not chunk:
            raise OSError("upstream closed the connection")
        out += chunk
    return out


def forward(query: bytes) -> bytes:
    """Ask the upstream resolver. UDP first; on a truncated answer retry over TCP."""
    resp = _forward_udp(query, config.DNSFW_UPSTREAM, config.DNSFW_UPSTREAM_PORT,
                        config.DNSFW_TIMEOUT)
    if len(resp) >= 4 and (resp[2] & 0x02):                    # TC bit -> retry over TCP
        resp = _forward_tcp(query, config.DNSFW_UPSTREAM, config.DNSFW_UPSTREAM_PORT,
                            config.DNSFW_TIMEOUT)
    return resp


# ------------------------------------------------------------------ domains & rules
def clean_domain(text: str) -> str:
    """Normalize a user-typed domain or rule pattern; '' if it is not usable."""
    d = (text or "").strip().lower().rstrip(".")
    if d.startswith("*."):
        d = d[2:]
    if not d or len(d) > 253 or not _DOMAIN_CHARS.match(d) or ".." in d:
        return ""
    return d


def normalize_pattern(text: str) -> tuple[str, str]:
    """A rule is 'example.com' (exact) or '*.example.com' (the domain + every subdomain).
    Returns (pattern, scope) with scope 'exact' | 'suffix'; ('','') if invalid."""
    raw = (text or "").strip().lower().rstrip(".")
    if raw.startswith("*."):
        d = clean_domain(raw)
        return (f"*.{d}", "suffix") if d else ("", "")
    d = clean_domain(raw)
    return (d, "exact") if d else ("", "")


def match_rule(domain: str, pattern: str, scope: str) -> bool:
    if scope == "exact":
        return domain == pattern
    base = pattern[2:]
    return domain == base or domain.endswith("." + base)


def decide(domain: str, rules) -> tuple[str, str]:
    """The user's rules: an 'allow' always beats a 'block' (personal whitelist).
    Returns (action, pattern_that_decided)."""
    block_hit = ""
    for r in rules:
        if match_rule(domain, r["pattern"], r["scope"]):
            if r["action"] == "allow":
                return "allowed", r["pattern"]
            block_hit = block_hit or r["pattern"]
    if block_hit:
        return "blocked", block_hit
    return "allowed", ""


# ------------------------------------------------------------------ device tokens
def new_device_token() -> tuple[str, str]:
    """The token is the device's only credential; the server stores just its hash."""
    token = "apdns_" + secrets.token_urlsafe(24)
    return token, hashlib.sha256(token.encode()).hexdigest()


def token_hash(token: str) -> str:
    return hashlib.sha256((token or "").encode()).hexdigest()


# ------------------------------------------------------------------ rate limiting & seen (in-memory)
_rl: dict[int, tuple[float, int]] = {}        # device_id -> (window_start, count)
_seen: dict[int, float] = {}                  # device_id -> last last_seen db write


def rate_limited(device_id: int) -> bool:
    now = time.time()
    start, n = _rl.get(device_id, (now, 0))
    if now - start >= 60:
        start, n = now, 0
    n += 1
    _rl[device_id] = (start, n)
    return n > config.DNSFW_QUERIES_PER_MIN


def touch_seen(device_id: int, ip: str):
    """last_seen is written at most once a minute per device - not on every query."""
    now = time.time()
    if now - _seen.get(device_id, 0) >= 60:
        _seen[device_id] = now
        db.touch_device(device_id, ip)


# ------------------------------------------------------------------ the main entry
def handle_wire_query(raw: bytes, device) -> bytes:
    """One DoH exchange: raw DNS query in, raw DNS answer out. Side effect: a log line.
    Never raises for DNS-shaped problems - a DNS error answer is always returned."""
    try:
        q = parse_query(raw)
    except QueryError:
        raise                                     # the route turns this into HTTP 400
    domain = q["qname"]
    action, rule = "allowed", ""
    if domain == TEST_BLOCKED_DOMAIN:
        action, rule = "blocked", "built-in test"
    else:
        action, rule = decide(domain, db.list_dns_rules(device["user_id"]))
    try:
        if action == "blocked":
            answer = nxdomain_response(raw, q)
        else:
            answer = forward(raw)
    except OSError as e:
        log.warning("dns upstream failed for %s: %s", domain, e)
        answer = servfail_response(raw, q)
        action, rule = "error", "upstream unreachable"
    db.log_dns_event(device["id"], domain, q["qtype"], action, rule)
    return answer


def b64url_decode(text: str) -> bytes:
    """RFC 8484 GET: the ?dns= parameter is base64url without padding."""
    pad = "=" * (-len(text) % 4)
    return base64.urlsafe_b64decode(text + pad)
