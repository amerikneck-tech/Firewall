"""AntiPhish web app (FastAPI).

Run locally:   uvicorn webapp.main:app --reload
Production:    see deploy/DEPLOY.md (Docker + Caddy HTTPS)
"""
from __future__ import annotations

import hmac
import json
import logging
import os
import re
import time
from contextlib import asynccontextmanager
from email.utils import parseaddr

from fastapi import Depends, FastAPI, File, Form, HTTPException, Request, UploadFile
from fastapi.responses import HTMLResponse, JSONResponse, RedirectResponse, Response
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from starlette.middleware.sessions import SessionMiddleware

from . import billing, config, crypto, db, dnsfw, mailbox_worker, mailboxes, msgraph, scanning, security
from .explain import explain_signal, level_info
from .mailboxes import MailboxError

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(name)s: %(message)s")
log = logging.getLogger("antiphish.web")

HERE = os.path.dirname(__file__)


@asynccontextmanager
async def lifespan(_app):
    db.init()
    if config.SECRET_KEY_IS_RANDOM:
        log.warning("SECRET_KEY not set - using a random key (sessions reset on restart). "
                    "Set SECRET_KEY in .env for production!")
    db.purge_old_text(config.RETAIN_TEXT_HOURS)
    if config.MAILBOX_ENABLED and config.MAILBOX_WORKER:
        if crypto.available():
            mailbox_worker.start_background()
        else:
            log.warning("connected mailboxes are switched off until SECRET_KEY is set in .env")
    db.purge_old_dns_events(config.DNSFW_LOG_RETENTION_DAYS)
    yield
    mailbox_worker.stop_background()
    try:
        from antiphish.attachment_scan import shutdown_sandbox
        shutdown_sandbox()
    except Exception:
        pass


app = FastAPI(title="AntiPhish", docs_url=None, redoc_url=None, openapi_url=None, lifespan=lifespan)
app.add_middleware(SessionMiddleware, secret_key=config.SECRET_KEY,
                   session_cookie="ap_session", max_age=config.SESSION_DAYS * 86400,
                   same_site="lax", https_only=config.HTTPS_ONLY_COOKIES)
app.mount("/static", StaticFiles(directory=os.path.join(HERE, "static")), name="static")
templates = Jinja2Templates(directory=os.path.join(HERE, "templates"))
templates.env.filters["defang"] = security.defang
templates.env.filters["dt"] = lambda ts: time.strftime("%d.%m.%Y %H:%M", time.localtime(ts or 0))
templates.env.globals["level_info"] = level_info


def _ago(ts) -> str:
    """'5 min ago' - short relative time for lists."""
    if not ts:
        return "never"
    d = max(0, time.time() - ts)
    if d < 60:
        return "just now"
    if d < 3600:
        return f"{int(d // 60)} min ago"
    if d < 86400:
        return f"{int(d // 3600)} h ago"
    if d < 7 * 86400:
        n = int(d // 86400)
        return f"{n} {'day' if n == 1 else 'days'} ago"
    return time.strftime("%d.%m.%Y", time.localtime(ts))


templates.env.filters["ago"] = _ago


@app.middleware("http")
async def security_headers(request: Request, call_next):
    resp = await call_next(request)
    resp.headers["Content-Security-Policy"] = (
        "default-src 'self'; img-src 'self' data:; style-src 'self'; script-src 'self'; "
        "form-action 'self' https://checkout.stripe.com; frame-ancestors 'none'; base-uri 'none'")
    resp.headers["X-Content-Type-Options"] = "nosniff"
    resp.headers["X-Frame-Options"] = "DENY"
    resp.headers["Referrer-Policy"] = "no-referrer"
    resp.headers["Permissions-Policy"] = "camera=(), microphone=(), geolocation=()"
    if config.HTTPS_ONLY_COOKIES:
        resp.headers["Strict-Transport-Security"] = "max-age=31536000"
    return resp


# ------------------------------------------------------------------ helpers
class Redirect(Exception):
    def __init__(self, url):
        self.url = url


@app.exception_handler(Redirect)
async def _redirect_handler(request, exc: Redirect):
    return RedirectResponse(exc.url, status_code=303)


def client_ip(request: Request) -> str:
    return request.client.host if request.client else "?"


def csrf_token(request: Request) -> str:
    tok = request.session.get("csrf")
    if not tok:
        tok = security.new_csrf()
        request.session["csrf"] = tok
    return tok


def check_csrf(request: Request, token: str):
    if not security.csrf_ok(request.session.get("csrf"), token):
        raise HTTPException(status_code=400, detail="Invalid security token (CSRF). Refresh the page.")


def current_user(request: Request):
    uid = request.session.get("uid")
    user = db.get_user(uid) if uid else None
    if not user or user["disabled"] or request.session.get("pwh") != user["password_hash"][-12:]:
        request.session.clear()
        raise Redirect("/login")
    return user


def admin_user(user=Depends(current_user)):
    if not user["is_admin"]:
        raise HTTPException(status_code=403, detail="Samo za administratore.")
    return user


def render(request: Request, name: str, ctx: dict | None = None, status: int = 200):
    ctx = dict(ctx or {})
    ctx.setdefault("user", None)
    ctx["csrf"] = csrf_token(request)
    ctx["flash"] = request.session.pop("flash", None)
    ctx["config"] = config
    ctx.setdefault("nav", "")
    return templates.TemplateResponse(request, name, ctx, status_code=status)


def flash(request: Request, msg: str, kind: str = "info"):
    request.session["flash"] = {"msg": msg, "kind": kind}


# ------------------------------------------------------------------ auth
@app.get("/login", response_class=HTMLResponse)
def login_page(request: Request):
    return render(request, "login.html")


@app.post("/login")
def login(request: Request, email: str = Form(...), password: str = Form(...),
          csrf: str = Form("")):
    check_csrf(request, csrf)
    addr = email.strip().lower()
    key = f"login:{client_ip(request)}:{addr}"
    acct_key = f"login-acct:{addr}"
    if db.count(key, 900) >= config.LOGIN_MAX_ATTEMPTS \
            or db.count(acct_key, 900) >= config.LOGIN_MAX_ATTEMPTS_PER_ACCOUNT:
        return render(request, "login.html",
                      {"error": "Too many failed attempts. Wait 15 minutes."}, 429)
    user = db.get_user_by_email(email)
    ok = security.verify_password(password, user["password_hash"] if user else security.DUMMY_HASH)
    if not user or not ok or user["disabled"]:
        db.hit(key, 900)
        db.hit(acct_key, 900)
        return render(request, "login.html", {"error": "Wrong email or password."}, 401)
    db.clear(key)
    request.session.clear()
    request.session.update({"uid": user["id"], "pwh": user["password_hash"][-12:],
                            "csrf": security.new_csrf()})
    return RedirectResponse("/", status_code=303)


@app.post("/logout")
def logout(request: Request, csrf: str = Form("")):
    check_csrf(request, csrf)
    request.session.clear()
    return RedirectResponse("/login", status_code=303)


# ------------------------------------------------------------------ overview
PAGE_SIZE = 25
_SOURCES = {"mailbox": "mailbox", "upload": "file", "paste": "text", "email": "forwarded"}
_BADGES = {"LOW": "low", "SUSPICIOUS": "suspicious", "HIGH": "high", "CRITICAL": "critical"}


WORKER_SILENT_AFTER = 150        # seconds without a sign of life from the mailbox checker


def _worker_silent() -> bool:
    age = mailbox_worker.heartbeat_age()
    return age is None or age > WORKER_SILENT_AFTER


def mailbox_view(mb, worker_silent: bool = False) -> dict:
    """What the pages show about a connected mailbox (never the secret)."""
    prov = mailboxes.PROVIDERS.get(mb["provider"], mailboxes.PROVIDERS["imap"])
    status = mb["status"]
    tone, label = {
        "new": ("info", "First check in progress…"),
        "ok": ("ok", "Active"),
        "no_credits": ("warn", "Paused – no credits"),
        "reauth": ("bad", "Reconnect needed"),
    }.get(status, ("warn", "Temporary problem"))
    detail = mb["status_detail"]
    if worker_silent and status != "reauth":
        # say so instead of showing "active" while nothing is being checked
        tone, label = "warn", "Checking is not running"
        detail = "Mailbox checking on the server is not running. If it persists, contact the administrator."
    return {"id": mb["id"], "email": mb["email"], "provider": mb["provider"], "kind": mb["kind"],
            "provider_name": prov["name"], "letter": prov["letter"], "status": status,
            "tone": tone, "label": label, "detail": detail,
            "last_check": mb["last_check"], "last_ok": mb["last_ok"], "created_at": mb["created_at"],
            "n_scans": mb["n_scans"] if "n_scans" in mb.keys() else 0,
            "busy": not worker_silent and (status == "new" or bool(mb["scan_requested"])
                                           or mb["lease_until"] > time.time())}


def _user_boxes(user) -> list[dict]:
    if not config.MAILBOX_ENABLED:
        return []
    rows = db.list_mailboxes(user["id"])
    silent = bool(rows) and _worker_silent()
    return [mailbox_view(b, silent) for b in rows]


def scan_view(row) -> dict:
    """One line of the message list: who, what, how risky and the main reason."""
    name, addr = parseaddr(row["sender"] or "")
    title, css, _advice = level_info(row["level"])
    reason = ""
    try:
        signals = json.loads(row["result_json"]).get("signals", []) if "result_json" in row.keys() else []
    except ValueError:
        signals = []
    top = next((s for s in signals if s.get("weight", 0) > 0), None)
    if top and row["level"] != "LOW":
        reason = explain_signal(top["signal"]) or top["signal"]
    elif row["level"] == "LOW":
        reason = "No strong phishing signals."
    return {"id": row["id"], "who": name or addr or (row["sender"] or "—"), "addr": addr if name else "",
            "subject": row["subject"] or "(no subject)", "score": row["score"], "level": row["level"],
            "level_title": title, "badge": _BADGES.get(row["level"], ""), "css": css,
            "reason": reason[:160], "when": row["shown_at"],
            "source": _SOURCES.get(row["source"], row["source"]), "feedback": row["feedback"]}


@app.get("/", response_class=HTMLResponse)
def dashboard(request: Request, user=Depends(current_user), f: str = "", m: int = 0, p: int = 1):
    boxes = _user_boxes(user)
    group = f if f in ("danger", "suspicious", "low") else None
    mailbox_id = m if any(b["id"] == m for b in boxes) else None
    total = db.count_scans(user["id"], group, mailbox_id)
    pages = max(1, -(-total // PAGE_SIZE))
    page = min(max(1, p), pages)
    rows = db.list_scans(user["id"], PAGE_SIZE, (page - 1) * PAGE_SIZE, group, mailbox_id, with_result=True)
    counts = db.level_counts(user["id"], time.time() - 30 * 86400, mailbox_id)
    any_scans = bool(rows) or bool(group or mailbox_id) or db.count_scans(user["id"]) > 0
    return render(request, "dashboard.html", {
        "user": user, "nav": "home", "boxes": boxes, "items": [scan_view(r) for r in rows],
        "counts": counts, "danger": counts["HIGH"] + counts["CRITICAL"], "group": group or "",
        "mailbox_id": mailbox_id or 0, "page": page, "pages": pages, "total": total,
        "any_scans": any_scans, "providers": _provider_tiles(),
        "latest": db.latest_scan_time(user["id"]),
    })


@app.get("/api/status")
def api_status(request: Request, user=Depends(current_user)):
    """For the overview page: has anything new been checked, is a check running?"""
    boxes = _user_boxes(user)
    return JSONResponse({"latest": db.latest_scan_time(user["id"]),
                         "busy": any(b["busy"] for b in boxes),
                         "boxes": [{"id": b["id"], "status": b["status"]} for b in boxes]},
                        headers={"Cache-Control": "no-store"})


@app.get("/check", response_class=HTMLResponse)
def check_page(request: Request, user=Depends(current_user)):
    return render(request, "check.html", {"user": user, "nav": "check", "llm": scanning.llm_ready()})


@app.post("/scan")
async def scan(request: Request, user=Depends(current_user), csrf: str = Form(""),
               mode: str = Form("quick"), raw: str = Form(""),
               file: UploadFile | None = File(None)):
    check_csrf(request, csrf)
    limit = config.MAX_UPLOAD_MB * 1024 * 1024
    data, source = b"", "paste"
    if file is not None and file.filename:
        name = file.filename.lower()
        if name.endswith(".msg"):
            flash(request, "Outlook .msg is not supported. In Outlook choose 'Save as' / 'Download' "
                           "in .eml format.", "error")
            return RedirectResponse("/check", status_code=303)
        data = await file.read(limit + 1)
        source = "upload"
    elif raw.strip():
        data = raw.encode("utf-8", errors="replace")
    if not data:
        flash(request, "Attach a .eml file or paste the email content.", "error")
        return RedirectResponse("/check", status_code=303)
    if len(data) > limit:
        flash(request, f"The file is larger than {config.MAX_UPLOAD_MB} MB.", "error")
        return RedirectResponse("/check", status_code=303)
    mode = "ai" if mode == "ai" and scanning.llm_ready() else "quick"
    try:
        parsed, has_headers = scanning.parse_input(data)
        from starlette.concurrency import run_in_threadpool
        scan_id = await run_in_threadpool(scanning.run_scan, user, parsed, source, mode, has_headers)
    except scanning.ScanError as e:
        flash(request, str(e), "error")
        return RedirectResponse("/check", status_code=303)
    return RedirectResponse(f"/r/{scan_id}", status_code=303)


@app.get("/r/{scan_id}", response_class=HTMLResponse)
def result(request: Request, scan_id: str, user=Depends(current_user)):
    row = db.get_scan(scan_id, None if user["is_admin"] else user["id"])
    if not row:
        raise HTTPException(status_code=404, detail="Result not found.")
    res = json.loads(row["result_json"])
    signals = [dict(s, help=explain_signal(s["signal"])) for s in res.get("signals", [])]
    with db.conn() as con:
        fb = con.execute("SELECT label FROM feedback WHERE scan_id=?", (scan_id,)).fetchone()
    return render(request, "result.html", {
        "user": user, "row": row, "res": res,
        "positive": [s for s in signals if s["weight"] > 0],
        "negative": [s for s in signals if s["weight"] < 0],
        # what the AI said when it did not move the score (unsure, or overruled by evidence)
        "ai_info": [s for s in signals if s["weight"] == 0 and s["signal"].startswith("llm_")],
        "feedback": fb["label"] if fb else None,
        "can_feedback": bool(row["text"]) or fb is not None,
        "own": row["user_id"] == user["id"],
        "source": _SOURCES.get(row["source"], row["source"]),
        "arrived": row["msg_date"],
    })


@app.post("/r/{scan_id}/feedback")
def feedback(request: Request, scan_id: str, user=Depends(current_user), csrf: str = Form(""),
             label: int = Form(...), comment: str = Form("")):
    check_csrf(request, csrf)
    row = db.get_scan(scan_id, user["id"])
    if not row:
        raise HTTPException(status_code=404)
    if label not in (0, 1):
        raise HTTPException(status_code=400)
    with db.conn() as con:
        existing = con.execute("SELECT text FROM feedback WHERE scan_id=?", (scan_id,)).fetchone()
    text = row["text"] or (existing["text"] if existing else None)
    if not text:
        flash(request, "This email's text has already been deleted (privacy), feedback is no longer possible.", "error")
        return RedirectResponse(f"/r/{scan_id}", status_code=303)
    db.save_feedback(scan_id, user["id"], label, text, comment)
    flash(request, "Thank you! The feedback was saved and will be used for model learning.", "ok")
    return RedirectResponse(f"/r/{scan_id}", status_code=303)


@app.get("/history")
def history(request: Request, user=Depends(current_user)):
    return RedirectResponse("/", status_code=303)       # the history is the overview page now


# ------------------------------------------------------------------ account
@app.get("/account", response_class=HTMLResponse)
def account(request: Request, user=Depends(current_user)):
    return render(request, "account.html", {"user": user, "nav": "account"})


@app.post("/account/password")
def change_password(request: Request, user=Depends(current_user), csrf: str = Form(""),
                    current: str = Form(...), new: str = Form(...)):
    check_csrf(request, csrf)
    if not security.verify_password(current, user["password_hash"]):
        flash(request, "The current password is incorrect.", "error")
        return RedirectResponse("/account", status_code=303)
    problem = security.password_problems(new)
    if problem:
        flash(request, problem, "error")
        return RedirectResponse("/account", status_code=303)
    h = security.hash_password(new)
    db.set_password(user["id"], h)
    request.session["pwh"] = h[-12:]   # other sessions of this user are logged out
    flash(request, "Lozinka je promijenjena.", "ok")
    return RedirectResponse("/account", status_code=303)


# ------------------------------------------------------------------ admin
@app.get("/admin", response_class=HTMLResponse)
def admin(request: Request, user=Depends(admin_user)):
    return render(request, "admin.html", {
        "user": user, "nav": "admin", "users": db.list_users(), "fb": db.feedback_stats(),
        "recent": db.recent_feedback(30), "llm": scanning.llm_ready(),
        "boxes": [dict(b) for b in db.all_mailboxes()] if config.MAILBOX_ENABLED else [],
        "worker_age": mailbox_worker.heartbeat_age(), "ms_ready": mailboxes.microsoft_configured(),
        "crypto_ready": crypto.available(), "ms_redirect": msgraph.redirect_uri()})


@app.post("/admin/users")
def admin_create_user(request: Request, user=Depends(admin_user), csrf: str = Form(""),
                      email: str = Form(...), password: str = Form(...),
                      credits: int = Form(config.DEFAULT_CREDITS)):
    check_csrf(request, csrf)
    problem = security.password_problems(password)
    if problem or "@" not in email:
        flash(request, problem or "Invalid email.", "error")
    elif db.get_user_by_email(email):
        flash(request, "A user with that email already exists.", "error")
    else:
        db.create_user(email, security.hash_password(password), credits)
        flash(request, f"User {email} has been created.", "ok")
    return RedirectResponse("/admin", status_code=303)


@app.post("/admin/users/{uid}/credits")
def admin_credits(request: Request, uid: int, user=Depends(admin_user), csrf: str = Form(""),
                  credits: int = Form(...)):
    check_csrf(request, csrf)
    db.set_credits(uid, credits)
    flash(request, "Credits updated.", "ok")
    return RedirectResponse("/admin", status_code=303)


@app.post("/admin/users/{uid}/toggle")
def admin_toggle(request: Request, uid: int, user=Depends(admin_user), csrf: str = Form("")):
    check_csrf(request, csrf)
    target = db.get_user(uid)
    if target and target["id"] != user["id"]:
        db.set_disabled(uid, not target["disabled"])
    return RedirectResponse("/admin", status_code=303)


@app.post("/admin/feedback/export")
def admin_export(request: Request, user=Depends(admin_user), csrf: str = Form("")):
    check_csrf(request, csrf)
    from .manage import export_feedback
    n = export_feedback()
    flash(request, f"{n} new examples added to data/feedback.csv. "
                   f"To retrain: python -m antiphish.learn "
                   f"(the new model loads itself, no restart needed).", "ok")
    return RedirectResponse("/admin", status_code=303)


# ------------------------------------------------------------------ connected mailboxes
CONNECT_ATTEMPTS = 10            # per user / 15 min: this page must not become a password-guessing tool


def _provider_tiles() -> list[dict]:
    return [{"key": k, "name": mailboxes.PROVIDERS[k]["name"], "letter": mailboxes.PROVIDERS[k]["letter"]}
            for k in mailboxes.PROVIDER_ORDER]


def _mailboxes_on():
    if not config.MAILBOX_ENABLED:
        raise HTTPException(status_code=404, detail="Mailbox connection is disabled.")


def _connect_ctx(user, provider: str, **extra) -> dict:
    return dict({"user": user, "nav": "mailboxes", "key": provider, "p": mailboxes.PROVIDERS[provider],
                 "ms_ready": mailboxes.microsoft_configured(), "crypto_ready": crypto.available(),
                 "form": {}, "error": None, "ms_redirect": msgraph.redirect_uri()}, **extra)


@app.get("/mailboxes", response_class=HTMLResponse)
def mailboxes_page(request: Request, user=Depends(current_user)):
    _mailboxes_on()
    boxes = _user_boxes(user)
    return render(request, "mailboxes.html", {
        "user": user, "nav": "mailboxes", "boxes": boxes, "providers": _provider_tiles(),
        "can_add": len(boxes) < config.MAILBOXES_PER_USER})


@app.get("/mailboxes/connect/{provider}", response_class=HTMLResponse)
def mailbox_connect_page(request: Request, provider: str, user=Depends(current_user), email: str = ""):
    _mailboxes_on()
    if provider not in mailboxes.PROVIDERS:
        raise HTTPException(status_code=404, detail="Nepoznat mail provajder.")
    # "Reconnect" brings the address along
    return render(request, "connect.html",
                  _connect_ctx(user, provider, form={"email": mailboxes.clean_email(email) or ""}))


@app.post("/mailboxes/connect/{provider}")
def mailbox_connect(request: Request, provider: str, user=Depends(current_user), csrf: str = Form(""),
                    email: str = Form(""), secret: str = Form(""), host: str = Form(""),
                    login: str = Form("")):
    check_csrf(request, csrf)
    _mailboxes_on()
    prov = mailboxes.PROVIDERS.get(provider)
    if not prov or prov["kind"] != "imap":
        raise HTTPException(status_code=404, detail="Nepoznat mail provajder.")
    form = {"email": email.strip()[:254], "host": host.strip()[:253], "login": login.strip()[:254]}

    def again(msg: str, status: int = 400):
        return render(request, "connect.html", _connect_ctx(user, provider, form=form, error=msg), status)

    if not crypto.available():
        return again("Mailbox connection is not possible until the administrator sets SECRET_KEY on the server.", 503)
    addr = mailboxes.clean_email(email)
    if not addr:
        return again("Enter the full mailbox email address.")
    password = mailboxes.clean_secret(provider, secret)
    if not password or len(password) > 256:
        return again("Enter the password.")
    imap_host = prov["host"] or form["host"]
    if not imap_host:
        return again("Enter the IMAP server (e.g. imap.your-domain.com).")
    existing = [b for b in db.list_mailboxes(user["id"]) if b["email"] == addr]
    if not existing and db.count_mailboxes(user["id"]) >= config.MAILBOXES_PER_USER:
        return again(f"You already have {config.MAILBOXES_PER_USER} connected mailboxes, the maximum per account.")
    if db.hit(f"mbconnect:{user['id']}", 900) > CONNECT_ATTEMPTS:
        return again("Too many connection attempts. Wait 15 minutes.", 429)
    imap_login = form["login"] or addr
    try:
        imap_host = mailboxes.netguard.clean_host(imap_host)
        try:
            mailboxes.test_login(imap_host, imap_login, password, config.MAILBOX_PORT, provider)
        except MailboxError as e:
            # Apple documents the iCloud IMAP user name as the part before the @ and says to try
            # the full address if that fails - so one more try with the other form
            if not (provider == "icloud" and e.kind == "auth" and not form["login"]):
                raise
            imap_login = addr.split("@", 1)[0]
            mailboxes.test_login(imap_host, imap_login, password, config.MAILBOX_PORT, provider)
    except mailboxes.netguard.HostNotAllowed as e:
        return again(str(e))
    except MailboxError as e:
        return again(e.message)
    enc = crypto.encrypt(password, mailboxes.secret_aad(user["id"], addr))
    db.create_mailbox(user["id"], addr, provider, "imap", enc, host=imap_host,
                      port=config.MAILBOX_PORT, login="" if imap_login == addr else imap_login)
    log.info("user %s connected a %s mailbox", user["id"], provider)
    flash(request, f"Mailbox {addr} is connected. Checking the newest messages – results will "
                   f"arrive in a moment.", "ok")
    return RedirectResponse("/", status_code=303)


@app.get("/mailboxes/microsoft/start")
def microsoft_start(request: Request, user=Depends(current_user)):
    _mailboxes_on()
    if not mailboxes.microsoft_configured() or not crypto.available():
        return RedirectResponse("/mailboxes/connect/microsoft", status_code=303)
    if db.hit(f"mbconnect:{user['id']}", 900) > CONNECT_ATTEMPTS:
        flash(request, "Too many connection attempts. Wait 15 minutes.", "error")
        return RedirectResponse("/mailboxes", status_code=303)
    login = msgraph.new_login()
    request.session["ms_oauth"] = {"state": login["state"], "verifier": login["verifier"],
                                   "ts": int(time.time())}
    return RedirectResponse(login["url"], status_code=303)


@app.get("/mailboxes/microsoft/callback")
def microsoft_callback(request: Request, user=Depends(current_user), code: str = "", state: str = "",
                       error: str = "", error_description: str = ""):
    _mailboxes_on()
    saved = request.session.pop("ms_oauth", None)

    def back(msg: str, kind: str = "error"):
        flash(request, msg, kind)
        return RedirectResponse("/mailboxes", status_code=303)

    # the answer must belong to a sign-in THIS browser session started a moment ago -
    # otherwise somebody else's Microsoft account could be attached to this user
    if not saved or not state or not hmac.compare_digest(str(saved.get("state", "")), state) \
            or time.time() - saved.get("ts", 0) > 900:
        return back("Microsoft sign-in was not completed (it expired or was not started from this "
                    "page). Try again.")
    if error:
        if error == "access_denied":
            return back("Mailbox access was not approved – nothing was connected.")
        log.warning("Microsoft sign-in returned %s: %s", re.sub(r"[^a-z_]", "", error.lower())[:40],
                    error_description[:300].replace("\r\n", " "))
        return back("Microsoft did not complete the sign-in. Try again; if it persists, contact the administrator.")
    if not code or not crypto.available():
        return back("Microsoft sign-in was not completed. Try again.")
    try:
        tokens = msgraph.redeem_code(code, saved["verifier"])
        addr = msgraph.whoami(tokens["access_token"])
    except MailboxError as e:
        return back(e.message)
    existing = [b for b in db.list_mailboxes(user["id"]) if b["email"] == addr]
    if not existing and db.count_mailboxes(user["id"]) >= config.MAILBOXES_PER_USER:
        return back(f"You already have {config.MAILBOXES_PER_USER} connected mailboxes, the maximum per account.")
    enc = crypto.encrypt(tokens["refresh_token"], mailboxes.secret_aad(user["id"], addr))
    mid = db.create_mailbox(user["id"], addr, "microsoft", "graph", enc)
    mailbox_worker._tokens[mid] = tokens             # saves one token request on the first check
    log.info("user %s connected a microsoft mailbox", user["id"])
    flash(request, f"Mailbox {addr} is connected. Checking the newest messages – results will "
                   f"arrive in a moment.", "ok")
    return RedirectResponse("/", status_code=303)


@app.post("/mailboxes/{mailbox_id}/scan")
def mailbox_scan_now(request: Request, mailbox_id: int, user=Depends(current_user), csrf: str = Form(""),
                     back: str = Form("")):
    check_csrf(request, csrf)
    _mailboxes_on()
    if db.hit(f"mbnow:{user['id']}", 60) > 6:
        flash(request, "A check has already been requested – wait a moment.", "info")
    elif db.request_mailbox_scan(mailbox_id, user["id"]):
        flash(request, "Mailbox check started.", "ok")
    else:
        flash(request, "This mailbox needs to be reconnected first.", "error")
    return RedirectResponse("/mailboxes" if back == "mailboxes" else "/", status_code=303)


@app.post("/mailboxes/{mailbox_id}/disconnect")
def mailbox_disconnect(request: Request, mailbox_id: int, user=Depends(current_user),
                       csrf: str = Form(""), delete_scans: str = Form("")):
    check_csrf(request, csrf)
    _mailboxes_on()
    mb = db.get_mailbox(mailbox_id, user["id"])
    if not mb:
        raise HTTPException(status_code=404, detail="Mailbox not found.")
    db.delete_mailbox(mailbox_id, user["id"], delete_scans=bool(delete_scans))
    mailbox_worker._tokens.pop(mailbox_id, None)
    log.info("user %s disconnected a %s mailbox", user["id"], mb["provider"])
    extra = "" if mb["kind"] == "graph" else " You can now also revoke the app password with your mail provider."
    flash(request, f"Mailbox {mb['email']} has been disconnected and the stored access deleted from the server.{extra}", "ok")
    return RedirectResponse("/mailboxes", status_code=303)


# ------------------------------------------------------------------ buying credits
def _billing_on():
    if not config.BILLING_ENABLED:
        raise HTTPException(status_code=404, detail="Buying credits is not enabled.")


@app.get("/billing", response_class=HTMLResponse)
def billing_page(request: Request, user=Depends(current_user)):
    _billing_on()
    return render(request, "billing.html", {
        "user": user, "nav": "billing", "packages": billing.packages(), "provider": config.BILLING_PROVIDER,
        "test_mode": billing.test_mode(), "purchases": db.list_purchases(user["id"])})


@app.post("/billing/buy/{package_id}")
def billing_buy(request: Request, package_id: str, user=Depends(current_user), csrf: str = Form("")):
    check_csrf(request, csrf)
    _billing_on()
    pkg = billing.get_package(package_id)
    if not pkg:
        raise HTTPException(status_code=404, detail="Unknown package.")
    if config.BILLING_PROVIDER == "stripe":
        try:
            return RedirectResponse(billing.stripe_checkout_url(user, pkg), status_code=303)
        except billing.BillingError as e:
            flash(request, str(e), "error")
            return RedirectResponse("/billing", status_code=303)
    return RedirectResponse(f"/billing/sim/{billing.sim_create(user, pkg)}", status_code=303)


@app.get("/billing/sim/{sid}", response_class=HTMLResponse)
def billing_sim_page(request: Request, sid: str, user=Depends(current_user)):
    _billing_on()
    pkg = billing.sim_validate(sid, user)
    if not pkg:
        raise HTTPException(status_code=404, detail="This test payment session is not valid - start again.")
    return render(request, "billing_sim.html", {"user": user, "nav": "billing", "pkg": pkg, "sid": sid})


@app.post("/billing/sim/{sid}/pay")
def billing_sim_pay(request: Request, sid: str, user=Depends(current_user), csrf: str = Form("")):
    check_csrf(request, csrf)
    _billing_on()
    pkg = billing.sim_validate(sid, user)
    if not pkg:
        raise HTTPException(status_code=404, detail="This test payment session is not valid - start again.")
    if billing.credit_purchase(f"sim:{sid}", user["id"], pkg, "simulator"):
        flash(request, f"Test payment received – {pkg['credits']} credits added to your account.", "ok")
    else:
        flash(request, "This test payment was already processed – credits are added only once.", "info")
    return RedirectResponse("/billing/success", status_code=303)


@app.get("/billing/success", response_class=HTMLResponse)
def billing_success(request: Request, user=Depends(current_user)):
    _billing_on()
    return render(request, "billing_success.html",
                  {"user": user, "nav": "billing", "provider": config.BILLING_PROVIDER})


@app.post("/billing/webhook")
async def billing_webhook(request: Request):
    """Stripe calls this (server-to-server: no session, no CSRF). Register it in the Stripe
    dashboard: Developers → Webhooks → add endpoint <BASE_URL>/billing/webhook,
    event checkout.session.completed → put the signing secret into STRIPE_WEBHOOK_SECRET."""
    if not config.BILLING_ENABLED or config.BILLING_PROVIDER != "stripe":
        raise HTTPException(status_code=404, detail="Not found.")
    payload = await request.body()
    event = billing.verify_stripe_webhook(payload, request.headers.get("stripe-signature", ""))
    if event is None:
        raise HTTPException(status_code=400, detail="Invalid signature.")
    purchase = billing.stripe_purchase_from_event(event)
    if purchase:
        user_id, package_id = purchase
        pkg = billing.get_package(package_id)
        if pkg and db.get_user(user_id):
            billing.credit_purchase(f"stripe:{event.get('id', '')}", user_id, pkg, "stripe")
        else:
            log.warning("stripe payment for unknown user/package: %s", event.get("id"))
    return JSONResponse({"received": True})


# ------------------------------------------------------------------ DNS shield
def _dnsfw_on():
    if not config.DNSFW_ENABLED:
        raise HTTPException(status_code=404, detail="DNS shield is not enabled.")


def _doh_answer(raw: bytes, device, ip: str) -> Response:
    try:
        answer = dnsfw.handle_wire_query(raw, device)
    except dnsfw.QueryError:
        raise HTTPException(status_code=400, detail="Not a DNS query.")
    dnsfw.touch_seen(device["id"], ip)
    return Response(answer, media_type="application/dns-message",
                    headers={"Cache-Control": "no-store"})


def _doh_device(token: str, request: Request):
    """Token auth for the DoH endpoint: no session, no CSRF - the token IS the login.
    Unknown or switched-off devices get a plain 404, so the endpoint never behaves
    like an open resolver."""
    _dnsfw_on()
    device = db.get_device_by_token(dnsfw.token_hash(token))
    if not device or not device["active"]:
        raise HTTPException(status_code=404, detail="Not found.")
    if dnsfw.rate_limited(device["id"]):
        raise HTTPException(status_code=429, detail="Too many queries.")
    db_user = db.get_user(device["user_id"])
    if not db_user or db_user["disabled"]:
        raise HTTPException(status_code=404, detail="Not found.")
    return device


@app.post("/dns-query/{token}")
async def doh_post(token: str, request: Request):
    device = _doh_device(token, request)
    if request.headers.get("content-type", "").split(";")[0].strip() != "application/dns-message":
        raise HTTPException(status_code=415, detail="Expected application/dns-message.")
    raw = await request.body()
    if not raw or len(raw) > dnsfw.MAX_QUERY_BYTES:
        raise HTTPException(status_code=400, detail="Bad DNS message size.")
    from starlette.concurrency import run_in_threadpool
    return await run_in_threadpool(_doh_answer, raw, device, client_ip(request))


@app.get("/dns-query/{token}")
async def doh_get(token: str, request: Request, dns: str = ""):
    """RFC 8484 GET form: ?dns=<base64url query, no padding>."""
    device = _doh_device(token, request)
    try:
        raw = dnsfw.b64url_decode(dns) if dns else b""
    except Exception:
        raw = b""
    if not raw or len(raw) > dnsfw.MAX_QUERY_BYTES:
        raise HTTPException(status_code=400, detail="Bad DNS message.")
    from starlette.concurrency import run_in_threadpool
    return await run_in_threadpool(_doh_answer, raw, device, client_ip(request))


# -------------------------------------------------------------- DNS shield pages
def _shield_ctx(request: Request, user, **extra):
    return dict({"user": user, "nav": "shield", "devices": db.list_devices(user["id"]),
                 "rules": db.list_dns_rules(user["id"]),
                 "stats": db.dns_stats(user["id"], time.time() - 7 * 86400),
                 "can_add": db.count_devices(user["id"]) < config.DNSFW_DEVICES_PER_USER,
                 "test_domain": dnsfw.TEST_BLOCKED_DOMAIN}, **extra)


@app.get("/shield", response_class=HTMLResponse)
def shield_page(request: Request, user=Depends(current_user)):
    _dnsfw_on()
    return render(request, "shield.html", _shield_ctx(request, user))


@app.post("/shield/devices")
def shield_add_device(request: Request, user=Depends(current_user), csrf: str = Form(""),
                      name: str = Form("")):
    check_csrf(request, csrf)
    _dnsfw_on()
    name = name.strip()[:80]
    if not name:
        flash(request, "Give the device a name (e.g. 'My laptop').", "error")
        return RedirectResponse("/shield", status_code=303)
    if db.count_devices(user["id"]) >= config.DNSFW_DEVICES_PER_USER:
        flash(request, f"You already have {config.DNSFW_DEVICES_PER_USER} devices, the maximum "
                       f"per account. Remove one to add a new one.", "error")
        return RedirectResponse("/shield", status_code=303)
    token, thash = dnsfw.new_device_token()
    db.create_device(user["id"], name, thash)
    log.info("user %s added a DNS shield device '%s'", user["id"], name)
    # the only place and the only moment the token is shown - the server stores its hash
    flash(request, f"Device added. DoH address for the agent: "
                   f"{config.BASE_URL}/dns-query/{token}", "ok")
    return RedirectResponse("/shield", status_code=303)


@app.get("/shield/devices/{device_id}", response_class=HTMLResponse)
def shield_device_page(request: Request, device_id: int, user=Depends(current_user),
                       f: str = ""):
    _dnsfw_on()
    device = db.get_device(device_id, user["id"])
    if not device:
        raise HTTPException(status_code=404, detail="Device not found.")
    return render(request, "shield_device.html", {
        "user": user, "nav": "shield", "d": device,
        "events": db.list_dns_events(device_id, 100, f or None), "filter": f,
        "test_domain": dnsfw.TEST_BLOCKED_DOMAIN})


@app.post("/shield/devices/{device_id}/toggle")
def shield_device_toggle(request: Request, device_id: int, user=Depends(current_user),
                         csrf: str = Form("")):
    check_csrf(request, csrf)
    _dnsfw_on()
    device = db.get_device(device_id, user["id"])
    if not device:
        raise HTTPException(status_code=404, detail="Device not found.")
    db.set_device_active(device_id, user["id"], not device["active"])
    flash(request, "Protection switched on." if not device["active"]
          else "Protection paused – the device no longer gets answers from this server.",
          "ok" if not device["active"] else "info")
    return RedirectResponse(f"/shield/devices/{device_id}", status_code=303)


@app.post("/shield/devices/{device_id}/delete")
def shield_device_delete(request: Request, device_id: int, user=Depends(current_user),
                         csrf: str = Form("")):
    check_csrf(request, csrf)
    _dnsfw_on()
    device = db.get_device(device_id, user["id"])
    if not device:
        raise HTTPException(status_code=404, detail="Device not found.")
    db.delete_device(device_id, user["id"])
    flash(request, f"Device '{device['name']}' removed; its token stops working immediately.", "ok")
    return RedirectResponse("/shield", status_code=303)


@app.post("/shield/rules")
def shield_add_rule(request: Request, user=Depends(current_user), csrf: str = Form(""),
                    pattern: str = Form(""), action: str = Form("block")):
    check_csrf(request, csrf)
    _dnsfw_on()
    pat, scope = dnsfw.normalize_pattern(pattern)
    if not pat or action not in ("block", "allow"):
        flash(request, "Enter a domain like 'example.com' or '*.example.com'.", "error")
    elif not db.add_dns_rule(user["id"], pat, scope, action):
        flash(request, f"The rule {pat} already exists.", "info")
    else:
        flash(request, f"Rule added: {pat} → {'block' if action == 'block' else 'allow'}.", "ok")
    return RedirectResponse("/shield", status_code=303)


@app.post("/shield/rules/{rule_id}/delete")
def shield_delete_rule(request: Request, rule_id: int, user=Depends(current_user),
                       csrf: str = Form("")):
    check_csrf(request, csrf)
    _dnsfw_on()
    db.delete_dns_rule(rule_id, user["id"])
    flash(request, "Rule removed.", "ok")
    return RedirectResponse("/shield", status_code=303)


# ------------------------------------------------------------------ misc
@app.get("/privacy", response_class=HTMLResponse)
def privacy(request: Request):
    uid = request.session.get("uid")
    return render(request, "privacy.html", {"user": db.get_user(uid) if uid else None, "nav": "privacy"})


@app.get("/healthz")
def healthz():
    db.init()
    return JSONResponse({"ok": True})


@app.get("/robots.txt")
def robots():
    return Response("User-agent: *\nDisallow: /\n", media_type="text/plain")
