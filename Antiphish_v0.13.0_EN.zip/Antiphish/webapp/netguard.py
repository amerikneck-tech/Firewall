"""Checks on a mail server name typed in by a user.

"Connect to this host for me" is a classic way to make a server talk to things
only it can reach (other containers, the cloud metadata address, the database on
localhost ...). A user-supplied IMAP host is therefore accepted only when

* it is a real host name (no IP literal, no single-label name such as "ollama"),
* EVERY address it resolves to is a public one, and
* the connection then goes to exactly the address that was checked (the caller
  connects to the returned IP and verifies the certificate against the name), so
  a DNS answer that changes between the check and the connection gains nothing.

The port is not the user's choice at all: IMAP over TLS, 993.
"""
from __future__ import annotations

import ipaddress
import re
import socket

from . import config

_HOST_RE = re.compile(r"^(?=.{4,253}$)([a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z]{2,24}$")


class HostNotAllowed(Exception):
    """User-facing reason why a mail server name is refused."""


def clean_host(host: str) -> str:
    host = (host or "").strip().lower().rstrip(".")
    if not _HOST_RE.match(host):
        raise HostNotAllowed("The mail server name is invalid (example: imap.your-domain.com).")
    return host


# IPv6 ranges that are only a wrapper around an IPv4 address (NAT64, 6to4, Teredo): on a
# network that translates them, 64:ff9b::a9fe:a9fe IS 169.254.169.254. No mail provider
# publishes such an address for its IMAP server, so they are simply not accepted.
_V4_IN_V6 = [ipaddress.ip_network(n) for n in ("64:ff9b::/96", "64:ff9b:1::/48", "2002::/16", "2001::/32")]


def _is_public(ip: str) -> bool:
    try:
        addr = ipaddress.ip_address(ip)
    except ValueError:
        return False
    if getattr(addr, "ipv4_mapped", None):
        addr = addr.ipv4_mapped
    if addr.version == 6 and any(addr in net for net in _V4_IN_V6):
        return False
    return bool(addr.is_global) and not addr.is_multicast


def resolve_checked(host: str, port: int | None = None) -> list[str]:
    """-> the addresses to connect to. Raises HostNotAllowed."""
    host = clean_host(host)
    port = port or config.MAILBOX_PORT
    try:
        infos = socket.getaddrinfo(host, port, type=socket.SOCK_STREAM)
    except (socket.gaierror, UnicodeError):
        raise HostNotAllowed(f"Server '{host}' was not found. Check the mail server name.") from None
    ips = []
    for info in infos:
        ip = info[4][0]
        if ip not in ips:
            ips.append(ip)
    if not ips:
        raise HostNotAllowed(f"Server '{host}' was not found. Check the mail server name.")
    if not config.MAILBOX_ALLOW_PRIVATE_HOSTS and not all(_is_public(ip) for ip in ips):
        # one private address among public ones is enough to refuse: which one gets
        # used would otherwise be up to whoever controls that DNS name
        raise HostNotAllowed("This mail server is not allowed (the address is not public).")
    # IPv4 first: many small servers have no IPv6 route out
    ips.sort(key=lambda ip: ":" in ip)
    return ips
