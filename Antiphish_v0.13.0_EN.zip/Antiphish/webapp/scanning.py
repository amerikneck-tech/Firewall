"""Scan service shared by the web UI and the forward-to-scan mailbox.

Turns raw input (.eml bytes / pasted source / plain text) into the detector's
email dict, enforces credits + concurrency, stores the result."""
from __future__ import annotations

import email
import email.policy
import logging
import re
import secrets
import threading
import time

from antiphish.detector import analyze_email
from antiphish.email_parser import parse_message, message_from_bytes_robust
from antiphish.model import scrub_recipient

from . import config, db

log = logging.getLogger("antiphish.web")
_slots = threading.BoundedSemaphore(max(1, config.SCAN_CONCURRENCY))


class ScanError(Exception):
    """User-facing error (message is shown to the user)."""


class NoCredits(ScanError):
    """The user cannot pay for this scan."""


class Busy(ScanError):
    """No free scanning slot right now - the same request can succeed a minute later."""


_HEADER_RE = re.compile(rb"^(from|subject|received|return-path|message-id|date|to|mime-version)\s*:",
                        re.I | re.M)


def looks_like_raw_email(data: bytes) -> bool:
    head = data[:5000]
    return len(_HEADER_RE.findall(head)) >= 2


def parse_input(data: bytes) -> tuple[dict, bool]:
    """-> (email dict, has_headers). Plain text is analyzed as a body only."""
    if looks_like_raw_email(data):
        msg = message_from_bytes_robust(data)
        return parse_message(msg), True
    text = data.decode("utf-8", errors="replace")
    lines = text.strip().splitlines()
    subject = ""
    if lines and len(lines[0]) < 150:
        subject = lines[0]
    return {"subject": subject, "body": text, "sender": "", "attachments": [],
            "attachment_data": {}}, False


def unwrap_forward(msg) -> tuple[object, str]:
    """For forwarded mail: prefer an attached original (message/rfc822).
    -> (message to analyze, 'attached' | 'inline')."""
    for part in msg.walk():
        if part.get_content_type() == "message/rfc822":
            inner = part.get_payload()
            inner = inner[0] if isinstance(inner, list) else inner
            if inner is not None:
                return inner, "attached"
        fn = (part.get_filename() or "").lower()
        if fn.endswith(".eml"):
            payload = part.get_payload(decode=True) or b""
            if looks_like_raw_email(payload):
                return message_from_bytes_robust(payload), "attached"
    return msg, "inline"


LLM_STATUS_TTL = 30.0      # seconds; the check is a network call - not on every page view
_llm_state = {"at": None, "ok": False}

AI_NO_ANSWER_NOTE = ("The AI check (Qwen) gave no answer – the model is unavailable or too slow. "
                     "A quick check was performed and charged as a quick one.")


def llm_ready() -> bool:
    if not config.WEB_ALLOW_LLM:
        return False
    now = time.monotonic()
    if _llm_state["at"] is not None and now - _llm_state["at"] < LLM_STATUS_TTL:
        return _llm_state["ok"]
    try:
        from antiphish.llm_judge import llm_status
        ok = bool(llm_status()[0])
    except Exception:
        ok = False
    _llm_state.update(at=now, ok=ok)
    return ok


AI_NO_ANSWER_NOTE_MAILBOX = ("The AI check (Qwen) gave no answer – the model is unavailable or too slow. "
                             "A quick check was performed.")


def run_scan(user, parsed: dict, source: str, mode: str, has_headers: bool = True,
             note: str = "", *, mailbox_id: int | None = None, msg_key: str | None = None,
             msg_date: float | None = None) -> str:
    """Charge credits, analyze, store. Returns scan id. Raises ScanError.

    With mailbox_id the message comes from a connected mailbox: it costs COST_MAILBOX
    whatever the mode, and the hourly limit is the mailbox worker's business (it
    postpones mail instead of refusing it)."""
    if user["disabled"]:
        raise ScanError("Nalog je deaktiviran.")
    automatic = mailbox_id is not None
    if automatic:
        cost = quick_cost = config.COST_MAILBOX
    else:
        quick_cost = config.COST_QUICK
        cost = config.COST_AI if mode == "ai" else quick_cost
        n = db.hit(f"scan:{user['id']}", 3600)
        if n > config.SCANS_PER_HOUR:
            raise ScanError(f"Too many checks in the last hour (limit {config.SCANS_PER_HOUR}). Try again later.")
    if not db.charge(user["id"], cost):
        raise NoCredits(f"Not enough credits (need {cost}).")
    if not _slots.acquire(timeout=120):
        db.refund(user["id"], cost)
        raise Busy("The server is busy right now. Try again in a minute.")
    try:
        result = analyze_email(parsed, use_url_intel=config.WEB_USE_URL_INTEL,
                               use_llm=(mode == "ai"))
    except Exception as e:
        db.refund(user["id"], cost)
        log.exception("scan failed")
        raise ScanError("The analysis failed. Credits have been refunded.") from e
    finally:
        _slots.release()

    if mode == "ai" and not any(sg["signal"].startswith("llm_") for sg in result["signals"]):
        # the model never answered (down, timed out, unusable reply - the reason is in the
        # log): this was a quick scan, so charge and label it as one
        db.refund(user["id"], max(0, cost - quick_cost))
        cost, mode = min(cost, quick_cost), "quick"
        note = f"{note} {AI_NO_ANSWER_NOTE_MAILBOX if automatic else AI_NO_ANSWER_NOTE}".strip()
        _llm_state["at"] = None          # re-check availability on the next page view

    result["has_headers"] = has_headers
    result["note"] = note
    result["attachments"] = list(parsed.get("attachments") or [])
    result["auth"] = {k: parsed.get(k) for k in ("spf", "dkim", "dmarc")}
    scan_id = secrets.token_urlsafe(12)
    # stored for feedback/retraining: the same recipient-neutral text the model scores
    # (the user's own address and name are replaced by placeholders)
    text = scrub_recipient(f"{parsed.get('subject', '')}\n{parsed.get('body', '')}".strip(),
                           parsed.get("to"))
    try:
        db.save_scan(scan_id, user["id"], source, mode, result,
                     parsed.get("subject", ""), parsed.get("sender", ""), text, cost,
                     mailbox_id=mailbox_id, msg_key=msg_key, msg_date=msg_date)
    except Exception:
        db.refund(user["id"], cost)          # e.g. this message was stored by another worker meanwhile
        raise
    try:
        db.purge_old_text(config.RETAIN_TEXT_HOURS)
    except Exception:
        pass
    return scan_id
