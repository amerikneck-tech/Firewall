"""Encryption of the mailbox secrets AntiPhish has to keep (app passwords, OAuth
refresh tokens).

What this protects against: a copy of the database alone (a backup, a stolen
data/antiphish.db) does not reveal any mailbox password - the key is not in the
database. It is derived from MAILBOX_KEY, or from SECRET_KEY when MAILBOX_KEY is
empty; both live in .env.

What it does NOT protect against: someone who controls the running server (and so
can read .env) can decrypt them. That is unavoidable for a service that has to log
in to the mailbox on its own.

AES-256-GCM; every value is bound to the mailbox it belongs to (the "aad"), so a
ciphertext copied into another row does not decrypt.
"""
from __future__ import annotations

import base64
import hashlib
import hmac
import os

from . import config

PREFIX = "v1:"


class SecretError(Exception):
    """The stored secret cannot be decrypted (key changed, value damaged or moved)."""


def available() -> bool:
    """False when there is no stable key: SECRET_KEY was generated at start-up and
    is gone after a restart, so nothing encrypted with it could be read again."""
    return bool(config.MAILBOX_KEY) or not config.SECRET_KEY_IS_RANDOM


def _hkdf_sha256(key_material: bytes, salt: bytes, info: bytes, length: int = 32) -> bytes:
    prk = hmac.new(salt, key_material, hashlib.sha256).digest()
    out, block, counter = b"", b"", 1
    while len(out) < length:
        block = hmac.new(prk, block + info + bytes([counter]), hashlib.sha256).digest()
        out += block
        counter += 1
    return out[:length]


def _key() -> bytes:
    material = (config.MAILBOX_KEY or config.SECRET_KEY).encode("utf-8")
    return _hkdf_sha256(material, b"antiphish-mailbox-secrets", b"aes-256-gcm v1")


def encrypt(plaintext: str, aad: str) -> str:
    from cryptography.hazmat.primitives.ciphers.aead import AESGCM
    nonce = os.urandom(12)
    ct = AESGCM(_key()).encrypt(nonce, plaintext.encode("utf-8"), aad.encode("utf-8"))
    return PREFIX + base64.urlsafe_b64encode(nonce + ct).decode("ascii")


def decrypt(token: str, aad: str) -> str:
    from cryptography.exceptions import InvalidTag
    from cryptography.hazmat.primitives.ciphers.aead import AESGCM
    if not (token or "").startswith(PREFIX):
        raise SecretError("unknown secret format")
    try:
        blob = base64.urlsafe_b64decode(token[len(PREFIX):].encode("ascii"))
        return AESGCM(_key()).decrypt(blob[:12], blob[12:], aad.encode("utf-8")).decode("utf-8")
    except (InvalidTag, ValueError) as e:
        raise SecretError("secret cannot be decrypted") from e
