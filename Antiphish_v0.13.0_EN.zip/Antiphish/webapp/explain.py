"""Human-friendly explanations of detector signals (shown to end users)."""
from __future__ import annotations

_HELP = {
    # authentication / sender
    "auth_dmarc_fail": "The sender's domain does not confirm this email was sent from its servers (DMARC failed). Typical of address spoofing.",
    "auth_spf_fail": "The server that sent this email is not authorized for the sender's domain (SPF failed).",
    "auth_dkim_fail": "The email's digital signature is invalid (DKIM failed) – the email may have been altered or forged.",
    "auth_compauth_fail": "Microsoft's composite authentication check did not pass – the sender's address is probably spoofed.",
    "auth_missing": "The sender's domain has no anti-spoofing protection configured (SPF/DKIM/DMARC) – a mild signal only.",
    "auth_all_pass": "SPF, DKIM and DMARC all passed – the sender really controls this domain. That does NOT mean the domain is trustworthy: most of today's phishing passes these checks.",
    "legit_bulk_sender": "Verified newsletter: authenticated sender, unsubscribe link, and no phishing signals.",
    "sender_verified_brand": "The email provably comes from the official domain of a known brand (DMARC aligned).",
    "reply_to_mismatch": "Replies to this email go to a different domain than the sender – a common scam trick.",
    "sender_displayname_spoof": "The sender's name impersonates a known brand, but the address is not on that brand's domain.",
    "sender_display_address_mismatch": "The sender's name contains one email address, but the email was actually sent from another.",
    "sender_lookalike_domain": "The sender's domain is spelled to LOOK LIKE a known brand (e.g. 'paypa1', 'rnicrosoft').",
    "sender_domain_brand_spoof": "The sender's domain contains a known brand's name but does not belong to that brand.",
    "sender_suspicious_tld": "The sender's domain uses an extension frequently abused by attackers.",
    "sender_ip_domain": "The sender's address uses an IP address instead of a domain.",
    "sender_mixed_alphabet": "The sender's address or name mixes scripts (e.g. Cyrillic 'а' inside a Latin word) to look legitimate.",
    "sender_freemail_role": "The email poses as IT/accounting/a director, but was sent from a free address (Gmail etc.).",
    "sender_generic_role": "A generic address (noreply, support...) instead of a person – a mild signal only.",
    "sender_urgent_word": "The sender's name contains a pressure word (urgent, immediately...).",
    "sender_impersonates_recipient_org": "The sender's name uses YOUR company/domain name, but the email comes from outside.",
    "sender_internal_role_external": "The sender poses as your IT department/administrator but writes from an external domain.",
    "subject_contains_recipient": "Your email address is embedded in the subject – typical of mass-personalized bait.",
    # text
    "text_credential_ask": "The text asks you to confirm your identity, password, card, or to sign in via a link.",
    "text_login_prompt": "The text directs you to click a link or sign in – common in legitimate emails too.",
    "text_urgency_high": "Strong urgency pressure (deadline, threat of closure) – a classic manipulation tactic.",
    "text_urgency_low": "Mild urgency pressure.",
    "text_money_pressure": "Mentions payments, invoices, refunds, or prizes.",
    "text_threat": "Threatens account suspension, a lawsuit, or unauthorized access.",
    "text_generic_greeting": "Generic greeting ('Dear customer') or being addressed by your email address instead of your name.",
    "text_excessive_caps": "Many words in ALL CAPS.",
    "text_gift_card_request": "Asks you to buy gift cards and send the codes – the classic fake-boss scam.",
    "text_bank_detail_change": "Announces 'new bank account details' for payments – an invoice fraud pattern. Verify by phone on a known number!",
    "text_payroll_change": "Asks for salary to be redirected to another account – a common HR/accounting fraud.",
    "text_payment_request": "Requests a payment or money transfer.",
    "text_bec_pretext": "Phrases typical of the fake-boss scam: 'are you free', 'I'm in a meeting, can't talk', 'keep this between us'.",
    "text_device_code_lure": "Asks you to enter a code on a device sign-in page – this gives the attacker access to your account without a password.",
    "text_clickfix": "Asks you to paste and run a command (Win+R, Ctrl+V) – this installs malware ('ClickFix').",
    "text_wallet_phrase": "Asks for your crypto wallet 'seed/recovery' phrase – no legitimate party ever asks for it.",
    "text_extortion": "Extortion: claims to have hacked/recorded you and demands cryptocurrency.",
    "text_advance_fee": "Advance-fee fraud pattern with an 'inheritance', a 'fund', or millions of dollars.",
    "text_prize_lure": "Prize bait or 'you have been selected'.",
    "text_qr_lure": "Asks you to scan a QR code – moving the link to your phone, past the protection.",
    "text_mailbox_lure": "Fake notice about a full mailbox, an expired password, or 'pending messages'.",
    "text_delivery_fee_lure": "'Your package is held' along with a request for a fee or address confirmation.",
    "text_refund_lure": "Promises a refund in exchange for your details.",
    "text_document_lure": "Notice about a 'shared document', e-signature, or voicemail – often legitimate, but also common bait.",
    "text_callback_lure": "A billing notice that asks you to CALL a number to 'cancel' – a phone-based scam.",
    "text_mixed_script": "Words in the text mix Latin with similar-looking Cyrillic/Greek letters to fool filters.",
    "text_spaced_letters": "Words are written with spaces between letters to fool filters.",
    "text_invisible_chars": "Invisible characters are inserted into words to fool filters.",
    "html_hidden_text": "The email contains far more hidden than visible text (filter stuffing).",
    # message body structure
    "html_body_credential_form": "The email itself contains a password input field.",
    "html_body_form": "The email contains a form that sends data to a web page.",
    "html_script_link": "A link doesn't lead to an ordinary web address but runs a script/embedded content.",
    "html_body_redirect": "The email attempts to automatically redirect the browser.",
    "html_body_active_content": "The email contains a script or an embedded frame (iframe).",
    "html_image_only_link": "The entire email is one clickable image with almost no text – hiding content from filters.",
    # urls
    "url_ip_host": "The link points to an IP address instead of a domain name – legitimate companies almost never do this.",
    "url_brand_spoof": "The link contains a known brand's name but is not on that brand's official domain.",
    "url_brand_mention": "A known brand's name appears in an unrelated domain – a mild signal only.",
    "url_lookalike_domain": "The domain in the link is spelled to LOOK LIKE a known brand (swapped letters, e.g. 'paypa1').",
    "url_brand_in_path": "The brand name is in the link's path on an unrelated site, alongside words like 'login' or 'verify'.",
    "url_embedded_domain": "The address impersonates another domain (e.g. 'bank.com.something.top') – the real domain is the one at the end.",
    "url_punycode": "The link uses characters that look like ordinary letters (homograph attack, e.g. 'pаypal' with a Cyrillic 'а').",
    "url_at_symbol": "The link uses the '@' trick that hides the real destination.",
    "url_suspicious_tld": "The link is on a domain with an extension frequently abused by attackers (.tk, .top, .xyz ...).",
    "url_uncommon_tld": "The link is on a less common domain extension – a mild signal only.",
    "url_shortener": "Shortened link – the real destination is hidden.",
    "url_open_redirect": "The link goes through a well-known site that then redirects you elsewhere (open-redirect abuse).",
    "url_text_mismatch": "The link text shows one address, but the link opens another.",
    "url_free_hosting": "The page is on free hosting/an app platform – a favorite place for fake login pages.",
    "url_ipfs_gateway": "The link leads to IPFS (anonymous hosting) – legitimate emails practically never use it.",
    "url_wildcard_dns": "The address is actually a disguised IP address (sslip.io/nip.io).",
    "url_dynamic_dns": "The link is on dynamic DNS or a tunnel – temporary infrastructure typical of attacks.",
    "url_credential_keywords": "The domain name is assembled from bait words (login, secure, verify...).",
    "url_download_executable": "The link directly downloads a program or script.",
    "url_nonstandard_port": "The link uses an unusual port.",
    "url_no_https": "The link is not encrypted (http instead of https).",
    "url_very_long": "Unusually long link – a mild signal only.",
    "url_many_subdomains": "Many subdomains in the address – a mild signal only.",
    "url_many_dashes": "Many dashes in the domain name – a mild signal only.",
    "url_vt_malicious": "VirusTotal: multiple antivirus vendors flag this link as malicious.",
    "url_vt_flagged": "VirusTotal: some vendors flag this link as dangerous.",
    "url_vt_suspicious": "VirusTotal: some vendors consider this link suspicious.",
    "url_urlscan_malicious": "urlscan.io flags this page as malicious.",
    # attachments
    "attachment_executable": "The attachment (or a file inside the archive) is a program/script – NEVER run it.",
    "attachment_double_extension": "A double extension (e.g. invoice.pdf.exe) hides the real file type.",
    "attachment_type_mismatch": "The extension lies: the file looks like a document but is actually a program.",
    "attachment_rtlo_trick": "The filename uses a hidden character that reverses the text to hide the real extension.",
    "attachment_disk_image": "The attachment is a disk image (.iso/.img) – often used to bypass Windows protection.",
    "attachment_shortcut_file": "The attachment is a shortcut or configuration file (.lnk, .url, .rdp, .library-ms...) that can launch the attacker's code or connection.",
    "attachment_risky": "This attachment type is often used to spread malware or fake login pages.",
    "attachment_phishing_content": "The text inside the attachment looks like phishing.",
    "attachment_too_large": "The attachment is too large to be scanned.",
    "attachment_scan_error": "The attachment could not be fully analyzed.",
    "attachment_scan_crash": "The attachment crashed the isolated scanner – files crafted to crash scanners are suspicious.",
    "archive_encrypted": "Password-protected archive – contents cannot be checked (a common trick to bypass filters).",
    "archive_encrypted_opened": "Archive protected with the password from the email text – opened and checked.",
    "archive_zip_bomb": "The archive is crafted to 'explode' when extracted (zip bomb).",
    "archive_too_deep": "An archive inside an archive inside an archive... – too many levels, typical for hiding content.",
    "office_macro": "The Office document contains macros – do not click 'Enable content'.",
    "office_remote_template": "The Word document downloads a template from the internet – a known attack technique.",
    "office_dde": "The document contains a DDE field that can run commands.",
    "office_activex": "The Office document contains ActiveX controls.",
    "office_embedded_object": "The Office document contains embedded objects.",
    "office_onenote_embedded": "The OneNote file contains an embedded program or script.",
    "pdf_active_content": "The PDF contains JavaScript or automatic actions.",
    "pdf_phishing_content": "The text in the PDF attachment looks like phishing.",
    "pdf_encrypted": "The PDF is password-protected – contents cannot be checked (a trick to bypass scanners).",
    "pdf_link_only": "The PDF has almost no text, just a link to click.",
    "html_credential_form": "The attachment is a fake sign-in page with a password field.",
    "html_external_form": "The HTML attachment sends entered data to an external page.",
    "html_smuggling": "The HTML attachment contains hidden code that builds a malicious file in the browser.",
    "html_redirect": "The HTML attachment automatically redirects you to another page.",
    "html_script": "The HTML attachment contains JavaScript.",
    "html_large_base64": "The attachment contains a large hidden (base64) payload.",
    "html_exfil_endpoint": "The attachment sends data to Telegram/Discord or a similar service – how phishing kits steal passwords.",
    "html_clickfix": "The attachment shows a fake check ('Verify you are human') that asks you to paste a command.",
    "html_fake_captcha": "The attachment shows a fake CAPTCHA/Cloudflare check before redirecting.",
    "svg_script": "The SVG 'image' contains JavaScript – an increasingly common attacker trick.",
    "svg_active_content": "The SVG 'image' contains an embedded web page or active content.",
    "rtf_embedded_object": "The RTF document contains an embedded object (a known attack vector).",
    "qr_code_url": "The QR code leads to a link – check it before scanning with your phone (quishing).",
    "calendar_invite_links": "The calendar invite contains links.",
    "attachment_scan_timeout": "The attachment stalled the scanner – files crafted to confuse scanners are suspicious.",
    # ai / overrides
    "llm_phishing_judged": "AI (Qwen) assessment: phishing.",
    "llm_clean_judged": "AI (Qwen) assessment: legitimate.",
    "llm_unsure": "AI (Qwen) has no clear assessment.",
    "hard_evidence_override": "Hard evidence of an attack was found – the score was raised to CRITICAL.",
}


def explain_signal(name: str) -> str:
    if name in _HELP:
        return _HELP[name]
    if name.startswith("attachment_vt"):
        return "VirusTotal: antivirus vendors flag this attachment."
    if name.startswith("pdf_ml") or name.startswith("attachment_ml"):
        return "The ML model assesses the attachment text as phishing."
    if name.startswith("archive_"):
        return "Problem with the attached archive."
    if name.startswith("auth_") and name.endswith("_missing"):
        return _HELP["auth_missing"]
    return ""


_LEVELS = {
    "LOW": ("Low risk", "low", "No strong phishing signals. Normal caution."),
    "SUSPICIOUS": ("Suspicious", "susp", "Verify the sender through another channel before clicking links or opening attachments."),
    "HIGH": ("High risk", "high", "Probably phishing. Don't click links, don't open attachments, don't reply."),
    "CRITICAL": ("CRITICAL", "crit", "Almost certainly phishing/malware. Delete or report the email and don't open anything."),
}


def level_info(level: str) -> tuple[str, str, str]:
    return _LEVELS.get(level, (level, "low", ""))
