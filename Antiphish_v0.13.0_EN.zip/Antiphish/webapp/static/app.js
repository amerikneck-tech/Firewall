// AntiPhish - small page helpers. Everything works without this file too.
(function () {
  "use strict";

  // Overview: notice when the mailbox check has produced new results.
  var live = document.getElementById("live");
  if (live && window.fetch) {
    var shown = parseFloat(live.getAttribute("data-latest")) || 0;
    var busy = live.getAttribute("data-busy") === "1";
    var fresh = document.getElementById("fresh");
    var firstPage = !/[?&]p=([2-9]|\d\d)/.test(location.search);
    var poll = function () {
      if (document.hidden) { return schedule(); }
      fetch("/api/status", { credentials: "same-origin", headers: { "Accept": "application/json" } })
        .then(function (r) { return r.ok && r.headers.get("content-type").indexOf("json") >= 0 ? r.json() : null; })
        .then(function (s) {
          if (!s) { return; }
          var changed = s.latest > shown + 0.0005 || (busy && !s.busy);
          if (changed && firstPage && window.scrollY < 300 && !document.querySelector("details[open]")) {
            location.reload();
            return;
          }
          if (changed && fresh) { fresh.classList.remove("hidden"); }
          busy = s.busy;
        })
        .catch(function () {})
        .then(schedule);
    };
    var schedule = function () { setTimeout(poll, busy ? 4000 : 20000); };
    schedule();
  }

  // Manual check: show the chosen file's name, accept a dropped file.
  var drop = document.getElementById("drop");
  if (drop) {
    var input = drop.querySelector("input[type=file]");
    var label = document.getElementById("drop-name");
    var show = function () {
      if (input.files && input.files.length && label) { label.textContent = input.files[0].name; }
    };
    input.addEventListener("change", show);
    ["dragenter", "dragover"].forEach(function (ev) {
      drop.addEventListener(ev, function (e) { e.preventDefault(); drop.classList.add("over"); });
    });
    ["dragleave", "drop"].forEach(function (ev) {
      drop.addEventListener(ev, function (e) { e.preventDefault(); drop.classList.remove("over"); });
    });
    drop.addEventListener("drop", function (e) {
      if (e.dataTransfer && e.dataTransfer.files.length) {
        try { input.files = e.dataTransfer.files; show(); } catch (err) { /* older browsers */ }
      }
    });
  }

  // A form that takes a few seconds (connecting a mailbox): show that something is happening.
  Array.prototype.forEach.call(document.querySelectorAll("form"), function (form) {
    form.addEventListener("submit", function () {
      var b = form.querySelector("button.wide");
      if (b) { setTimeout(function () { b.classList.add("disabled"); }, 0); }
    });
  });

  // Close an open "Disconnect" panel when clicking elsewhere.
  document.addEventListener("click", function (e) {
    Array.prototype.forEach.call(document.querySelectorAll("details.menu-more[open]"), function (d) {
      if (!d.contains(e.target)) { d.removeAttribute("open"); }
    });
  });
})();
