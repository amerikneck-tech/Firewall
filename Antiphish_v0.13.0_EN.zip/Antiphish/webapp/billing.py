"""Buying credit packages: checkout + payment webhook.

Two providers, selected with BILLING_PROVIDER in .env:

  "simulator"  a built-in fake checkout (test card prefilled) that runs the payment
               through the exact same crediting path as a real one. No account, no
               keys, no money - for trying the whole flow out.
  "stripe"     real Stripe Checkout + the checkout.session.completed webhook.
               Test mode works with sk_test_... keys and card 4242 4242 4242 4242;
               going live is just a key swap (sk_live_...), the code doesn't change.

Whichever provider it is, credits are added by ONE function (credit_purchase), which
is idempotent per payment event id: a retried webhook or a double-clicked Pay button
cannot add the same credits twice.
"""
from __future__ import annotations

import base64
import hashlib
import hmac
import json
import logging
import secrets
import time

import requests

from . import config, db

log = logging.getLogger("antiphish.billing")

STRIPE_API = "https://api.stripe.com/v1"
WEBHOOK_TOLERANCE_S = 300          # Stripe's own recommendation for the timestamp check

_DEFAULT_PACKAGES = [
    {"id": "starter",  "name": "Starter",  "credits": 100,  "price_cents": 500,  "currency": "EUR",
     "blurb": "For trying it out"},
    {"id": "standard", "name": "Standard", "credits": 500,  "price_cents": 2000, "currency": "EUR",
     "blurb": "The usual choice", "featured": True},
    {"id": "pro",      "name": "Pro",      "credits": 2000, "price_cents": 6000, "currency": "EUR",
     "blurb": "For heavy use"},
]


class BillingError(Exception):
    """A problem the admin can fix (bad keys, unreachable Stripe ...) - shown as a flash message."""


# ------------------------------------------------------------------ packages
def packages() -> list[dict]:
    """The packages on sale: BILLING_PACKAGES (JSON) from .env, or the built-in defaults."""
    raw = (config.BILLING_PACKAGES or "").strip()
    if raw:
        try:
            pkgs = json.loads(raw)
            out = []
            for p in pkgs:
                out.append({"id": str(p["id"]), "name": str(p["name"]),
                            "credits": int(p["credits"]), "price_cents": int(p["price_cents"]),
                            "currency": str(p.get("currency", "EUR")).upper(),
                            "blurb": str(p.get("blurb", "")), "featured": bool(p.get("featured"))})
            if out:
                return out
        except (ValueError, KeyError, TypeError) as e:
            log.error("BILLING_PACKAGES is not valid (%s) - using the built-in packages", e)
    return [dict(p) for p in _DEFAULT_PACKAGES]


def get_package(package_id: str) -> dict | None:
    for p in packages():
        if p["id"] == package_id:
            return p
    return None


def test_mode() -> bool:
    """True when no real money can move: the simulator, or Stripe with test keys."""
    return config.BILLING_PROVIDER == "simulator" or config.STRIPE_SECRET_KEY.startswith("sk_test_")


# ------------------------------------------------------------------ the one crediting path
def credit_purchase(event_id: str, user_id: int, pkg: dict, provider: str) -> bool:
    """Add the package's credits exactly once per payment event. True = added now."""
    if db.record_purchase(event_id, user_id, pkg["id"], int(pkg["credits"]), provider):
        log.info("credits purchased: user=%s package=%s +%s credits (%s)",
                 user_id, pkg["id"], pkg["credits"], provider)
        return True
    log.info("payment event %s already processed - ignored", event_id)
    return False


# ------------------------------------------------------------------ Stripe
def stripe_checkout_url(user, pkg: dict) -> str:
    """Create a Stripe Checkout Session and return its URL to redirect the user to.
    Plain HTTPS call - the 'stripe' library is not needed for this one request."""
    if not config.STRIPE_SECRET_KEY:
        raise BillingError("Stripe is not configured yet (STRIPE_SECRET_KEY is empty in .env).")
    try:
        r = requests.post(f"{STRIPE_API}/checkout/sessions",
                          auth=(config.STRIPE_SECRET_KEY, ""), timeout=20, data={
                              "mode": "payment",
                              "success_url": config.BASE_URL + "/billing/success",
                              "cancel_url": config.BASE_URL + "/billing",
                              "client_reference_id": str(user["id"]),
                              "customer_email": user["email"],
                              "line_items[0][quantity]": "1",
                              "line_items[0][price_data][currency]": pkg["currency"].lower(),
                              "line_items[0][price_data][unit_amount]": str(pkg["price_cents"]),
                              "line_items[0][price_data][product_data][tax_code]": config.STRIPE_TAX_CODE,
                              "line_items[0][price_data][product_data][name]":
                                  f"AntiPhish – {pkg['name']} ({pkg['credits']} credits)",
                              "metadata[user_id]": str(user["id"]),
                              "metadata[package_id]": pkg["id"],
                              "payment_intent_data[metadata][user_id]": str(user["id"]),
                              "payment_intent_data[metadata][package_id]": pkg["id"],
                          })
    except requests.RequestException as e:
        log.warning("stripe checkout unreachable: %s", e)
        raise BillingError("Stripe could not be reached – try again in a moment.") from e
    if r.status_code != 200:
        log.warning("stripe checkout refused: HTTP %s %s", r.status_code, r.text[:300])
        raise BillingError("Stripe refused the payment session – check the keys (test vs live).")
    return r.json()["url"]


def verify_stripe_webhook(payload: bytes, sig_header: str) -> dict | None:
    """Check Stripe's signature (https://docs.stripe.com/webhooks/signature) and return
    the event, or None if it isn't genuinely from Stripe with our secret."""
    secret = config.STRIPE_WEBHOOK_SECRET
    if not secret or not sig_header:
        return None
    ts, sigs = None, []
    for part in sig_header.split(","):
        k, _, v = part.partition("=")
        if k == "t":
            try:
                ts = int(v)
            except ValueError:
                return None
        elif k == "v1":
            sigs.append(v)
    if ts is None or not sigs or abs(time.time() - ts) > WEBHOOK_TOLERANCE_S:
        return None
    expected = hmac.new(secret.encode(), str(ts).encode() + b"." + payload, hashlib.sha256).hexdigest()
    if not any(hmac.compare_digest(expected, s) for s in sigs):
        return None
    try:
        return json.loads(payload)
    except json.JSONDecodeError:
        return None


def stripe_purchase_from_event(event: dict) -> tuple[int, str] | None:
    """(user_id, package_id) out of a checkout.session.completed event, or None to ignore it."""
    if event.get("type") != "checkout.session.completed":
        return None
    sess = (event.get("data") or {}).get("object") or {}
    if sess.get("payment_status") not in ("paid", "no_payment_required"):
        return None
    md = sess.get("metadata") or {}
    try:
        user_id = int(md.get("user_id") or sess.get("client_reference_id") or 0)
    except (TypeError, ValueError):
        return None
    return (user_id, str(md.get("package_id", ""))) if user_id else None


# ------------------------------------------------------------------ built-in simulator
def _sim_key() -> bytes:
    return (config.SECRET_KEY or "antiphish-simulator").encode()


def sim_create(user, pkg: dict) -> str:
    """A signed, stateless test-checkout session id (nothing is stored server-side)."""
    body = base64.urlsafe_b64encode(json.dumps(
        {"u": user["id"], "p": pkg["id"], "n": secrets.token_urlsafe(8)}).encode()).decode()
    sig = hmac.new(_sim_key(), body.encode(), hashlib.sha256).hexdigest()[:32]
    return f"{body}.{sig}"


def sim_validate(sid: str, user) -> dict | None:
    """The package of a test-checkout session - only for the user it was created for."""
    try:
        body, sig = sid.rsplit(".", 1)
    except ValueError:
        return None
    expected = hmac.new(_sim_key(), body.encode(), hashlib.sha256).hexdigest()[:32]
    if not hmac.compare_digest(expected, sig):
        return None
    try:
        data = json.loads(base64.urlsafe_b64decode(body.encode()))
    except (ValueError, json.JSONDecodeError):
        return None
    if data.get("u") != user["id"]:
        return None
    return get_package(str(data.get("p", "")))
