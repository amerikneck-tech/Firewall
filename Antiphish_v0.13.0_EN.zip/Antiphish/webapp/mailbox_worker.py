"""Checks the connected mailboxes for new mail and scans it.

Runs as a background thread of the web process (MAILBOX_WORKER=1, the default), or
on its own:

    python -m webapp.mailbox_worker

Rules it keeps:
* read-only - nothing in the mailbox is changed (see mailboxes.ImapReader / msgraph)
* a message is scanned once (IMAP UID / Graph id stored with the result)
* a wrong or revoked password is tried a few times with long pauses, then the
  mailbox waits for its owner ("reauth") - providers lock accounts that are hammered
* no credits / hourly limit reached -> the mail WAITS, it is not skipped
* one mailbox at a time per worker; a lease in the database keeps two processes
  from handling the same mailbox
"""
from __future__ import annotations

import logging
import os
import secrets
import socket
import threading
import time

from antiphish.email_parser import message_from_bytes_robust, parse_message

from . import config, crypto, db, mailboxes, msgraph, scanning
from .mailboxes import MailboxError

log = logging.getLogger("antiphish.mailbox")

OWNER = f"{socket.gethostname()}:{os.getpid()}:{secrets.token_hex(3)}"
TICK_SECONDS = 3
LEASE_SECONDS = 240              # renewed after every message; a crashed worker blocks a mailbox no longer than this
AUTH_RETRIES = 3                 # refused logins in a row before the owner has to reconnect
BEAT_KEY = "mailbox_worker_beat"

_stop = threading.Event()
_thread: threading.Thread | None = None
_tokens: dict[int, dict] = {}    # Microsoft access tokens, kept in memory only

MSG_NO_CREDITS = "Not enough credits – checking of new messages is paused until credits are topped up."
MSG_LIMIT = "The hourly check limit was reached – the remaining messages will be checked soon."
MSG_KEY_CHANGED = ("The stored access can no longer be read (the server key has changed). "
                   "Reconnect the mailbox.")
MSG_REAUTH = "The mail server no longer accepts the stored password (it was changed or revoked). Reconnect the mailbox."


class _Pause(Exception):
    """Stop this round for the mailbox without an error: status, text, seconds to wait."""

    def __init__(self, status: str, detail: str, delay: int):
        self.status, self.detail, self.delay = status, detail, delay


def _budget(user_id: int) -> int:
    used = db.count(f"mbscan:{user_id}", 3600)
    return max(0, min(config.MAILBOX_BATCH, config.MAILBOX_SCANS_PER_HOUR - used))


def _finish(mb, status: str, detail: str = "", delay: float | None = None, **extra):
    now = time.time()
    db.update_mailbox(mb["id"], status=status, status_detail=(detail or "")[:300], last_check=now,
                      next_check=now + (config.MAILBOX_POLL_SECONDS if delay is None else delay),
                      scan_requested=0, **extra)


def _scan_one(mb, raw: bytes, key: str, when: float | None) -> bool:
    """-> True when a result was stored. Raises _Pause when the rest has to wait."""
    user = db.get_user(mb["user_id"])                     # fresh credit balance
    if not user or user["disabled"]:
        raise _Pause(mb["status"], mb["status_detail"], 600)
    try:
        parsed = parse_message(message_from_bytes_robust(raw))
    except Exception:
        log.exception("mailbox %s: message %s cannot be parsed - skipped", mb["id"], key)
        return False
    mode = "ai" if config.MAILBOX_USE_LLM and scanning.llm_ready() else "quick"
    try:
        scanning.run_scan(user, parsed, "mailbox", mode, True, mailbox_id=mb["id"],
                          msg_key=key, msg_date=when)
    except scanning.NoCredits:
        raise _Pause("no_credits", MSG_NO_CREDITS, 600) from None
    except scanning.Busy:
        raise _Pause(mb["status"] if mb["status"] != "new" else "ok", "", 60) from None
    except scanning.ScanError:
        log.warning("mailbox %s: message %s could not be analysed - skipped", mb["id"], key)
        return False
    except Exception:
        if db.mailbox_scan_exists(mb["id"], key):          # stored by another worker meanwhile
            return False
        raise
    db.hit(f"mbscan:{mb['user_id']}", 3600)
    db.renew_lease(mb["id"], OWNER, LEASE_SECONDS)
    return True


# ------------------------------------------------------------------ IMAP
def _run_imap(mb, password: str, budget: int) -> tuple[int, bool]:
    """-> (messages scanned, more are waiting)."""
    limit = config.MAX_UPLOAD_MB * 1024 * 1024
    with mailboxes.ImapReader(mb["host"], mb["login"] or mb["email"], password, mb["port"],
                              mb["provider"]) as reader:
        last_uid = mb["last_uid"]
        if mb["uidvalidity"] is None:
            # first visit: the newest N messages are checked, everything older counts as seen
            first = reader.newest_uids(config.MAILBOX_INITIAL_SCAN)
            last_uid = (first[0] - 1) if first else reader.max_uid()
            db.update_mailbox(mb["id"], uidvalidity=reader.uidvalidity, last_uid=last_uid)
        elif mb["uidvalidity"] != reader.uidvalidity:
            # the server renumbered the folder: old positions mean nothing any more.
            # Start from its current end rather than checking (and charging) everything again.
            last_uid = reader.max_uid()
            db.update_mailbox(mb["id"], uidvalidity=reader.uidvalidity, last_uid=last_uid)
            log.info("mailbox %s: folder was renumbered by the server - continuing from its end", mb["id"])
            return 0, False
        pending = reader.uids_after(last_uid)
        batch = pending[:budget]
        info = reader.describe(batch)
        done = 0
        for uid in batch:
            if _stop.is_set():
                return done, True
            key = f"{reader.uidvalidity}:{uid}"
            meta = info.get(uid) or {}
            if meta.get("size", 0) > limit:
                log.info("mailbox %s: message %s is larger than %s MB - not checked", mb["id"], key,
                         config.MAX_UPLOAD_MB)
            elif not db.mailbox_scan_exists(mb["id"], key):
                raw = reader.fetch(uid, limit)
                if raw and len(raw) > limit:          # the server under-reported the size
                    log.info("mailbox %s: message %s is larger than %s MB - not checked", mb["id"], key,
                             config.MAX_UPLOAD_MB)
                elif raw and _scan_one(mb, raw, key, meta.get("date")):
                    done += 1
            db.update_mailbox(mb["id"], last_uid=uid)
        return done, len(pending) > len(batch)


# ------------------------------------------------------------------ Microsoft Graph
def _access_token(mb, refresh_token: str) -> str:
    tok = _tokens.get(mb["id"])
    if tok and tok["expires_at"] > time.time():
        return tok["access_token"]
    new = msgraph.refresh(refresh_token)
    if new["refresh_token"] != refresh_token:
        # Microsoft handed out a newer refresh token: keep that one
        db.update_mailbox(mb["id"], secret=crypto.encrypt(
            new["refresh_token"], mailboxes.secret_aad(mb["user_id"], mb["email"])))
    _tokens[mb["id"]] = new
    return new["access_token"]


def _run_graph(mb, refresh_token: str, budget: int) -> tuple[int, bool]:
    token = _access_token(mb, refresh_token)
    try:
        return _graph_round(mb, token, budget)
    except MailboxError as e:
        if e.kind != "token":
            raise
    _tokens.pop(mb["id"], None)                           # the token was refused: get a new one, once
    fresh = db.get_mailbox(mb["id"])
    current = crypto.decrypt(fresh["secret"], mailboxes.secret_aad(mb["user_id"], mb["email"]))
    try:
        return _graph_round(fresh, _access_token(fresh, current), budget)
    except MailboxError as e:
        if e.kind == "token":
            raise MailboxError("protocol", "Microsoft ne prihvata izdati pristupni token.") from None
        raise


def _graph_round(mb, token: str, budget: int) -> tuple[int, bool]:
    limit = config.MAX_UPLOAD_MB * 1024 * 1024
    cursor = mb["cursor"]
    if not cursor:
        items = msgraph.newest(token, config.MAILBOX_INITIAL_SCAN)
        if not items:
            db.update_mailbox(mb["id"], cursor=time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()))
            return 0, False
        asked = len(items)
    else:
        asked = min(budget + 10, 100)
        items = msgraph.since(token, cursor, asked)
    done = handled = 0
    for item in items:
        if _stop.is_set() or done >= budget:
            return done, True
        key = item["id"]
        if not db.mailbox_scan_exists(mb["id"], key):
            raw = msgraph.mime(token, key, limit)
            if raw is None:
                log.info("mailbox %s: a message is gone or larger than %s MB - not checked", mb["id"],
                         config.MAX_UPLOAD_MB)
            elif _scan_one(mb, raw, key, msgraph.parse_time(item["received"])):
                done += 1
            handled += 1
        if item["received"] and item["received"] > (cursor or ""):
            cursor = item["received"]
            db.update_mailbox(mb["id"], cursor=cursor)
    full_page = bool(mb["cursor"]) and len(items) >= asked
    if full_page and not handled and cursor == mb["cursor"]:
        # a whole page of already-checked mail with one and the same time stamp: step over it
        t = msgraph.parse_time(cursor) or time.time()
        db.update_mailbox(mb["id"], cursor=time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime(t + 1)))
    return done, full_page


# ------------------------------------------------------------------ one mailbox
def process_mailbox(mailbox_id: int) -> str:
    """One visit to one mailbox. Returns a short status word (for logs and tests)."""
    mb = db.get_mailbox(mailbox_id)
    if mb is None:
        return "gone"
    user = db.get_user(mb["user_id"])
    if not user or user["disabled"]:
        return "skip:user"
    if config.COST_MAILBOX > 0 and user["credits"] < config.COST_MAILBOX:
        _finish(mb, "no_credits", MSG_NO_CREDITS, 600)
        return "no_credits"
    budget = _budget(user["id"])
    if budget <= 0:
        _finish(mb, "ok" if mb["status"] in ("new", "ok", "no_credits") else mb["status"], MSG_LIMIT, 300)
        return "rate_limited"
    aad = mailboxes.secret_aad(mb["user_id"], mb["email"])
    try:
        secret = crypto.decrypt(mb["secret"], aad)
    except crypto.SecretError:
        _finish(mb, "reauth", MSG_KEY_CHANGED)
        log.warning("mailbox %s: stored secret cannot be decrypted (SECRET_KEY / MAILBOX_KEY changed?)", mb["id"])
        return "reauth:key"
    fails = mb["fail_count"] + 1
    try:
        if mb["kind"] == "graph":
            done, more = _run_graph(mb, secret, budget)
        else:
            done, more = _run_imap(mb, secret, budget)
    except _Pause as p:
        _finish(mb, p.status, p.detail, p.delay)
        return p.status if p.status == "no_credits" else "paused"
    except msgraph.Throttled as e:
        _finish(mb, "ok" if mb["status"] in ("new", "ok") else mb["status"], e.message, e.retry_after)
        return "throttled"
    except MailboxError as e:
        if e.kind == "auth":
            if mb["kind"] == "graph" or fails >= AUTH_RETRIES:
                # a refused refresh token never comes back; a refused password is given a
                # few spaced tries (providers answer "wrong password" to glitches too)
                _tokens.pop(mb["id"], None)
                _finish(mb, "reauth", e.message if mb["kind"] == "graph" else MSG_REAUTH, fail_count=fails)
                log.warning("mailbox %s (%s): access refused - waiting for the owner to reconnect",
                            mb["id"], mb["provider"])
                return "reauth"
            _finish(mb, "error", e.message, min(300 * 6 ** (fails - 1), 7200), fail_count=fails)
            return "error:auth"
        delay = min(60 * 2 ** min(fails, 6), 3600 if e.kind in ("tls", "host", "config") else 900)
        # one dropped connection is not worth alarming the user: say so from the third in a row
        status = "error" if (fails >= 3 or e.kind in ("tls", "host", "config")) else \
            ("ok" if mb["status"] in ("new", "ok") else mb["status"])
        _finish(mb, status, e.message if status == "error" else "", delay, fail_count=fails)
        log.info("mailbox %s (%s): %s problem, next try in %ss", mb["id"], mb["provider"], e.kind, delay)
        return f"error:{e.kind}"
    except Exception:
        log.exception("mailbox %s: unexpected error", mb["id"])
        _finish(mb, "error", "Unexpected error while checking the mailbox. Will try again.",
                min(120 * 2 ** min(fails, 5), 3600), fail_count=fails)
        return "error:unexpected"
    now = time.time()
    _finish(mb, "ok", "", 2 if more else None, fail_count=0, last_ok=now)
    if done:
        log.info("mailbox %s (%s): %s new message(s) checked%s", mb["id"], mb["provider"], done,
                 ", more waiting" if more else "")
    return f"ok:{done}"


# ------------------------------------------------------------------ loop
def tick() -> int:
    """Handle every mailbox whose turn it is. -> how many were visited."""
    n = 0
    for mailbox_id in db.due_mailboxes():
        if _stop.is_set():
            break
        if not db.lease_mailbox(mailbox_id, OWNER, LEASE_SECONDS):
            continue
        try:
            process_mailbox(mailbox_id)
            n += 1
        except Exception:
            log.exception("mailbox %s: visit failed", mailbox_id)
        finally:
            db.release_mailbox(mailbox_id, OWNER)
    return n


def run_forever(stop: threading.Event | None = None):
    stop = stop or _stop
    last_beat = last_purge = 0.0
    log.info("mailbox worker started (every %ss per mailbox, newest %s on connect)",
             config.MAILBOX_POLL_SECONDS, config.MAILBOX_INITIAL_SCAN)
    while not stop.is_set():
        try:
            now = time.time()
            if now - last_beat >= 20:
                db.set_meta(BEAT_KEY, f"{now:.0f}")
                last_beat = now
            if now - last_purge >= 6 * 3600:
                removed = db.purge_old_mailbox_scans(config.MAILBOX_RETAIN_DAYS)
                if removed:
                    log.info("removed %s mailbox results older than %s days", removed, config.MAILBOX_RETAIN_DAYS)
                last_purge = now
            tick()
        except Exception:
            log.exception("mailbox worker round failed")
        stop.wait(TICK_SECONDS)


def start_background() -> bool:
    """Start the worker thread inside the web process (once)."""
    global _thread
    if _thread is not None and _thread.is_alive():
        return False
    _stop.clear()
    _thread = threading.Thread(target=run_forever, name="mailbox-worker", daemon=True)
    _thread.start()
    return True


def stop_background(timeout: float = 8.0):
    _stop.set()
    if _thread is not None:
        _thread.join(timeout)


def heartbeat_age() -> float | None:
    """Seconds since the worker last reported in (None: never)."""
    try:
        beat = float(db.get_meta(BEAT_KEY) or 0)
    except ValueError:
        beat = 0.0
    return (time.time() - beat) if beat else None


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(name)s: %(message)s")
    db.init()
    if not crypto.available():
        raise SystemExit("Set SECRET_KEY (or MAILBOX_KEY) in .env - without it stored mailbox passwords "
                         "cannot be read.")
    try:
        run_forever()
    except KeyboardInterrupt:
        pass
