"""SQLite storage (WAL mode). Small, zero-maintenance, perfect for a test deployment.
Swap for PostgreSQL when you go multi-server."""
from __future__ import annotations

import json
import os
import sqlite3
import threading
import time
from contextlib import contextmanager

from . import config

_SCHEMA = """
CREATE TABLE IF NOT EXISTS users (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    email         TEXT NOT NULL UNIQUE COLLATE NOCASE,
    password_hash TEXT NOT NULL,
    is_admin      INTEGER NOT NULL DEFAULT 0,
    credits       INTEGER NOT NULL DEFAULT 0,
    created_at    REAL NOT NULL,
    disabled      INTEGER NOT NULL DEFAULT 0
);
CREATE TABLE IF NOT EXISTS scans (
    id          TEXT PRIMARY KEY,              -- random, unguessable
    user_id     INTEGER NOT NULL REFERENCES users(id),
    created_at  REAL NOT NULL,
    source      TEXT NOT NULL,                 -- upload | paste | email
    mode        TEXT NOT NULL,                 -- quick | ai
    subject     TEXT,
    sender      TEXT,
    score       REAL NOT NULL,
    level       TEXT NOT NULL,
    result_json TEXT NOT NULL,
    text        TEXT,                          -- wiped after RETAIN_TEXT_HOURS
    cost        INTEGER NOT NULL DEFAULT 0
);
CREATE INDEX IF NOT EXISTS ix_scans_user ON scans(user_id, created_at DESC);
CREATE TABLE IF NOT EXISTS feedback (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    scan_id     TEXT NOT NULL UNIQUE REFERENCES scans(id),
    user_id     INTEGER NOT NULL REFERENCES users(id),
    label       INTEGER NOT NULL,              -- 0 legit, 1 phishing
    text        TEXT NOT NULL,
    comment     TEXT,
    created_at  REAL NOT NULL,
    exported    INTEGER NOT NULL DEFAULT 0
);
CREATE TABLE IF NOT EXISTS events (           -- rate limiting / audit
    key         TEXT NOT NULL,
    ts          REAL NOT NULL
);
CREATE INDEX IF NOT EXISTS ix_events ON events(key, ts);
CREATE TABLE IF NOT EXISTS mailboxes (        -- a user's own mailbox that AntiPhish checks
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id       INTEGER NOT NULL REFERENCES users(id),
    email         TEXT NOT NULL COLLATE NOCASE,
    provider      TEXT NOT NULL,              -- gmail | yahoo | icloud | hostinger | imap | microsoft
    kind          TEXT NOT NULL,              -- imap (password) | graph (Microsoft sign-in)
    host          TEXT NOT NULL DEFAULT '',
    port          INTEGER NOT NULL DEFAULT 993,
    login         TEXT NOT NULL DEFAULT '',
    secret        TEXT NOT NULL,              -- ENCRYPTED app password / refresh token (crypto.py)
    status        TEXT NOT NULL DEFAULT 'new',  -- new | ok | error | reauth | no_credits
    status_detail TEXT NOT NULL DEFAULT '',
    uidvalidity   TEXT,                       -- IMAP position ...
    last_uid      INTEGER NOT NULL DEFAULT 0,
    cursor        TEXT,                       -- ... or Graph position (receivedDateTime)
    created_at    REAL NOT NULL,
    last_check    REAL,
    last_ok       REAL,
    next_check    REAL NOT NULL DEFAULT 0,
    fail_count    INTEGER NOT NULL DEFAULT 0,
    scan_requested INTEGER NOT NULL DEFAULT 0,
    lease_until   REAL NOT NULL DEFAULT 0,
    lease_owner   TEXT,
    UNIQUE(user_id, email)
);
CREATE TABLE IF NOT EXISTS meta (             -- small key/value notes (worker heartbeat ...)
    key         TEXT PRIMARY KEY,
    value       TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS billing_events ( -- every payment that added credits (idempotency)
    id          TEXT PRIMARY KEY,           -- "sim:<session>" / "stripe:<event id>"
    user_id     INTEGER NOT NULL REFERENCES users(id),
    package_id  TEXT NOT NULL,
    credits     INTEGER NOT NULL,
    provider    TEXT NOT NULL,              -- simulator | stripe
    created_at  REAL NOT NULL
);
CREATE TABLE IF NOT EXISTS devices (        -- DNS shield: a device the user protects
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id     INTEGER NOT NULL REFERENCES users(id),
    name        TEXT NOT NULL,
    token_hash  TEXT NOT NULL UNIQUE,       -- sha256 of the DoH token (never the token)
    active      INTEGER NOT NULL DEFAULT 1,
    created_at  REAL NOT NULL,
    last_seen   REAL,
    last_ip     TEXT NOT NULL DEFAULT ''
);
CREATE TABLE IF NOT EXISTS dns_rules (      -- per-user block/allow lists
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id     INTEGER NOT NULL REFERENCES users(id),
    pattern     TEXT NOT NULL,              -- "example.com" or "*.example.com"
    scope       TEXT NOT NULL,              -- exact | suffix
    action      TEXT NOT NULL,              -- block | allow
    created_at  REAL NOT NULL,
    UNIQUE(user_id, pattern)
);
CREATE TABLE IF NOT EXISTS dns_events (     -- the live per-device query log
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    device_id   INTEGER NOT NULL REFERENCES devices(id),
    domain      TEXT NOT NULL,
    qtype       INTEGER NOT NULL DEFAULT 1,
    action      TEXT NOT NULL,              -- allowed | blocked | error
    rule        TEXT NOT NULL DEFAULT '',
    created_at  REAL NOT NULL
);
CREATE INDEX IF NOT EXISTS ix_dns_events_dev ON dns_events(device_id, created_at DESC);
"""

# columns added after the first release: (table, column, declaration)
_MIGRATIONS = [
    ("scans", "mailbox_id", "INTEGER"),       # set for automatically checked messages
    ("scans", "msg_key", "TEXT"),             # which message of that mailbox (never scanned twice)
    ("scans", "msg_date", "REAL"),            # when the mail arrived (not when it was checked)
]
_POST_MIGRATION = """
CREATE UNIQUE INDEX IF NOT EXISTS ix_scans_mailbox_msg ON scans(mailbox_id, msg_key)
    WHERE mailbox_id IS NOT NULL;
"""


def _migrate(con: sqlite3.Connection):
    """Bring a database made by an older version up to date (adds columns only)."""
    for table, column, decl in _MIGRATIONS:
        have = {r[1] for r in con.execute(f"PRAGMA table_info({table})")}
        if column not in have:
            con.execute(f"ALTER TABLE {table} ADD COLUMN {column} {decl}")
    con.executescript(_POST_MIGRATION)


_init_lock = threading.Lock()
_initialized_for: str | None = None


def _connect() -> sqlite3.Connection:
    os.makedirs(os.path.dirname(config.DB_PATH) or ".", exist_ok=True)
    con = sqlite3.connect(config.DB_PATH, timeout=15, isolation_level=None)
    con.row_factory = sqlite3.Row
    con.execute("PRAGMA journal_mode=WAL")
    con.execute("PRAGMA foreign_keys=ON")
    con.execute("PRAGMA busy_timeout=15000")
    return con


def init():
    global _initialized_for
    with _init_lock:
        if _initialized_for == config.DB_PATH:
            return
        con = _connect()
        con.executescript(_SCHEMA)
        _migrate(con)
        con.close()
        _initialized_for = config.DB_PATH


@contextmanager
def conn():
    init()
    con = _connect()
    try:
        yield con
    finally:
        con.close()


@contextmanager
def tx():
    """Exclusive write transaction (atomic credit changes)."""
    with conn() as con:
        con.execute("BEGIN IMMEDIATE")
        try:
            yield con
            con.execute("COMMIT")
        except Exception:
            con.execute("ROLLBACK")
            raise


# ------------------------------------------------------------------ users
def create_user(email: str, password_hash: str, credits: int, is_admin: bool = False) -> int:
    with tx() as con:
        cur = con.execute(
            "INSERT INTO users(email, password_hash, is_admin, credits, created_at) VALUES (?,?,?,?,?)",
            (email.strip().lower(), password_hash, int(is_admin), credits, time.time()))
        return cur.lastrowid


def get_user(user_id: int):
    with conn() as con:
        return con.execute("SELECT * FROM users WHERE id=?", (user_id,)).fetchone()


def get_user_by_email(email: str):
    with conn() as con:
        return con.execute("SELECT * FROM users WHERE email=?", ((email or "").strip().lower(),)).fetchone()


def list_users():
    with conn() as con:
        return con.execute(
            "SELECT u.*, (SELECT COUNT(*) FROM scans s WHERE s.user_id=u.id) AS n_scans "
            "FROM users u ORDER BY u.id").fetchall()


def set_credits(user_id: int, credits: int):
    with tx() as con:
        con.execute("UPDATE users SET credits=? WHERE id=?", (max(0, credits), user_id))


def set_password(user_id: int, password_hash: str):
    with tx() as con:
        con.execute("UPDATE users SET password_hash=? WHERE id=?", (password_hash, user_id))


def set_disabled(user_id: int, disabled: bool):
    with tx() as con:
        con.execute("UPDATE users SET disabled=? WHERE id=?", (int(disabled), user_id))


def charge(user_id: int, amount: int) -> bool:
    """Atomically take credits. False if not enough."""
    with tx() as con:
        cur = con.execute("UPDATE users SET credits = credits - ? WHERE id=? AND credits >= ?",
                          (amount, user_id, amount))
        return cur.rowcount == 1


def refund(user_id: int, amount: int):
    with tx() as con:
        con.execute("UPDATE users SET credits = credits + ? WHERE id=?", (amount, user_id))


# ------------------------------------------------------------------ purchases (billing)
def record_purchase(event_id: str, user_id: int, package_id: str, credits: int, provider: str) -> bool:
    """Record the payment and add the credits - atomically, exactly once per event id."""
    with tx() as con:
        cur = con.execute(
            "INSERT OR IGNORE INTO billing_events(id,user_id,package_id,credits,provider,created_at) "
            "VALUES(?,?,?,?,?,?)",
            (event_id, user_id, package_id, int(credits), provider, time.time()))
        if cur.rowcount == 0:
            return False
        con.execute("UPDATE users SET credits = credits + ? WHERE id=?", (int(credits), user_id))
        return True


def list_purchases(user_id: int, limit: int = 20):
    with conn() as con:
        return con.execute(
            "SELECT * FROM billing_events WHERE user_id=? ORDER BY created_at DESC LIMIT ?",
            (user_id, limit)).fetchall()


# ------------------------------------------------------------------ scans
def save_scan(scan_id: str, user_id: int, source: str, mode: str, result: dict,
              subject: str, sender: str, text: str, cost: int, *, mailbox_id: int | None = None,
              msg_key: str | None = None, msg_date: float | None = None):
    with tx() as con:
        con.execute(
            "INSERT INTO scans(id,user_id,created_at,source,mode,subject,sender,score,level,"
            "result_json,text,cost,mailbox_id,msg_key,msg_date) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
            (scan_id, user_id, time.time(), source, mode, (subject or "")[:300],
             (sender or "")[:300], result["score"], result["level"],
             json.dumps(result, ensure_ascii=False), (text or "")[:6000], cost,
             mailbox_id, msg_key, msg_date))


def get_scan(scan_id: str, user_id: int | None = None):
    """user_id given -> only that user's scan (prevents viewing others' results)."""
    with conn() as con:
        if user_id is None:
            return con.execute("SELECT * FROM scans WHERE id=?", (scan_id,)).fetchone()
        return con.execute("SELECT * FROM scans WHERE id=? AND user_id=?", (scan_id, user_id)).fetchone()


_LEVEL_GROUPS = {"danger": ("HIGH", "CRITICAL"), "suspicious": ("SUSPICIOUS",), "low": ("LOW",)}


def _scan_filter(user_id: int, group: str | None, mailbox_id: int | None) -> tuple[str, list]:
    where, args = ["s.user_id=?"], [user_id]
    if group in _LEVEL_GROUPS:
        levels = _LEVEL_GROUPS[group]
        where.append("s.level IN (%s)" % ",".join("?" * len(levels)))
        args += list(levels)
    if mailbox_id is not None:
        where.append("s.mailbox_id=?")
        args.append(mailbox_id)
    return " AND ".join(where), args


def list_scans(user_id: int, limit: int = 100, offset: int = 0, group: str | None = None,
               mailbox_id: int | None = None, with_result: bool = False):
    """Newest first (by the time the mail arrived when known, else when it was checked)."""
    where, args = _scan_filter(user_id, group, mailbox_id)
    extra = ", s.result_json" if with_result else ""
    with conn() as con:
        return con.execute(
            "SELECT s.id, s.created_at, s.source, s.mode, s.subject, s.sender, s.score, s.level, "
            f"s.mailbox_id, s.msg_date, COALESCE(s.msg_date, s.created_at) AS shown_at{extra}, "
            "f.label AS feedback FROM scans s LEFT JOIN feedback f ON f.scan_id=s.id "
            f"WHERE {where} ORDER BY shown_at DESC, s.created_at DESC LIMIT ? OFFSET ?",
            (*args, limit, offset)).fetchall()


def count_scans(user_id: int, group: str | None = None, mailbox_id: int | None = None) -> int:
    where, args = _scan_filter(user_id, group, mailbox_id)
    with conn() as con:
        return con.execute(f"SELECT COUNT(*) FROM scans s WHERE {where}", args).fetchone()[0]


def level_counts(user_id: int, since: float = 0.0, mailbox_id: int | None = None) -> dict:
    """{'LOW': n, 'SUSPICIOUS': n, 'HIGH': n, 'CRITICAL': n} for the user's results."""
    where, args = _scan_filter(user_id, None, mailbox_id)
    with conn() as con:
        rows = con.execute(
            f"SELECT s.level, COUNT(*) AS n FROM scans s WHERE {where} "
            "AND COALESCE(s.msg_date, s.created_at) >= ? GROUP BY s.level", (*args, since)).fetchall()
    out = {"LOW": 0, "SUSPICIOUS": 0, "HIGH": 0, "CRITICAL": 0}
    out.update({r["level"]: r["n"] for r in rows})
    return out


def latest_scan_time(user_id: int) -> float:
    with conn() as con:
        row = con.execute("SELECT MAX(created_at) FROM scans WHERE user_id=?", (user_id,)).fetchone()
        return row[0] or 0.0


def mailbox_scan_exists(mailbox_id: int, msg_key: str) -> bool:
    with conn() as con:
        return con.execute("SELECT 1 FROM scans WHERE mailbox_id=? AND msg_key=?",
                           (mailbox_id, msg_key)).fetchone() is not None


def purge_old_mailbox_scans(days: int) -> int:
    """Results of automatically checked mail are not kept for ever. A result the user
    gave feedback on stays (the feedback points at it)."""
    if days <= 0:
        return 0
    cutoff = time.time() - days * 86400
    with tx() as con:
        cur = con.execute(
            "DELETE FROM scans WHERE mailbox_id IS NOT NULL AND created_at < ? "
            "AND id NOT IN (SELECT scan_id FROM feedback)", (cutoff,))
        return cur.rowcount


def purge_old_text(hours: int) -> int:
    """Privacy: wipe stored e-mail text after the retention window,
    except for scans the user explicitly sent as feedback."""
    cutoff = time.time() - hours * 3600
    with tx() as con:
        cur = con.execute("UPDATE scans SET text=NULL WHERE text IS NOT NULL AND created_at < ?",
                          (cutoff,))
        return cur.rowcount


# ------------------------------------------------------------------ feedback
def save_feedback(scan_id: str, user_id: int, label: int, text: str, comment: str = ""):
    with tx() as con:
        con.execute(
            "INSERT INTO feedback(scan_id,user_id,label,text,comment,created_at) VALUES (?,?,?,?,?,?) "
            "ON CONFLICT(scan_id) DO UPDATE SET label=excluded.label, comment=excluded.comment, "
            "exported=0", (scan_id, user_id, int(label), text, (comment or "")[:500], time.time()))


def feedback_stats():
    with conn() as con:
        return con.execute(
            "SELECT COUNT(*) AS total, SUM(label=1) AS phishing, SUM(label=0) AS legit, "
            "SUM(exported=0) AS pending FROM feedback").fetchone()


def unexported_feedback():
    with conn() as con:
        return con.execute("SELECT * FROM feedback WHERE exported=0 ORDER BY id").fetchall()


def mark_exported(ids: list[int]):
    if not ids:
        return
    with tx() as con:
        con.executemany("UPDATE feedback SET exported=1 WHERE id=?", [(i,) for i in ids])


def recent_feedback(limit: int = 50):
    with conn() as con:
        return con.execute(
            "SELECT f.*, u.email, s.subject, s.score, s.level FROM feedback f "
            "JOIN users u ON u.id=f.user_id JOIN scans s ON s.id=f.scan_id "
            "ORDER BY f.created_at DESC LIMIT ?", (limit,)).fetchall()


# ------------------------------------------------------------------ rate limit
def hit(key: str, window_s: int) -> int:
    """Record an event and return how many happened in the window (incl. this one)."""
    now = time.time()
    with tx() as con:
        con.execute("DELETE FROM events WHERE ts < ?", (now - 86400,))
        con.execute("INSERT INTO events(key, ts) VALUES (?,?)", (key, now))
        return con.execute("SELECT COUNT(*) FROM events WHERE key=? AND ts >= ?",
                           (key, now - window_s)).fetchone()[0]


def count(key: str, window_s: int) -> int:
    with conn() as con:
        return con.execute("SELECT COUNT(*) FROM events WHERE key=? AND ts >= ?",
                           (key, time.time() - window_s)).fetchone()[0]


def clear(key: str):
    with tx() as con:
        con.execute("DELETE FROM events WHERE key=?", (key,))


# ------------------------------------------------------------------ connected mailboxes
_MAILBOX_FIELDS = {"provider", "kind", "host", "port", "login", "secret", "status", "status_detail",
                   "uidvalidity", "last_uid", "cursor", "last_check", "last_ok", "next_check",
                   "fail_count", "scan_requested", "lease_until", "lease_owner"}


def create_mailbox(user_id: int, email: str, provider: str, kind: str, secret: str, *,
                   host: str = "", port: int = 993, login: str = "") -> int:
    """New connection, or - for an address this user already connected - new
    credentials for the existing one (its place in the mailbox is kept)."""
    email = email.strip().lower()
    with tx() as con:
        row = con.execute("SELECT id FROM mailboxes WHERE user_id=? AND email=?",
                          (user_id, email)).fetchone()
        if row:
            con.execute(
                "UPDATE mailboxes SET provider=?, kind=?, host=?, port=?, login=?, secret=?, "
                "status='new', status_detail='', fail_count=0, next_check=0, scan_requested=1 "
                "WHERE id=?", (provider, kind, host, port, login, secret, row["id"]))
            return row["id"]
        cur = con.execute(
            "INSERT INTO mailboxes(user_id,email,provider,kind,host,port,login,secret,created_at,"
            "scan_requested) VALUES (?,?,?,?,?,?,?,?,?,1)",
            (user_id, email, provider, kind, host, port, login, secret, time.time()))
        return cur.lastrowid


def get_mailbox(mailbox_id: int, user_id: int | None = None):
    with conn() as con:
        if user_id is None:
            return con.execute("SELECT * FROM mailboxes WHERE id=?", (mailbox_id,)).fetchone()
        return con.execute("SELECT * FROM mailboxes WHERE id=? AND user_id=?",
                           (mailbox_id, user_id)).fetchone()


def list_mailboxes(user_id: int):
    with conn() as con:
        return con.execute(
            "SELECT m.*, (SELECT COUNT(*) FROM scans s WHERE s.mailbox_id=m.id) AS n_scans "
            "FROM mailboxes m WHERE m.user_id=? ORDER BY m.id", (user_id,)).fetchall()


def count_mailboxes(user_id: int) -> int:
    with conn() as con:
        return con.execute("SELECT COUNT(*) FROM mailboxes WHERE user_id=?", (user_id,)).fetchone()[0]


def all_mailboxes():
    """For the admin overview - never includes the secret."""
    with conn() as con:
        return con.execute(
            "SELECT m.id, m.email, m.provider, m.kind, m.status, m.status_detail, m.last_check, "
            "m.last_ok, m.created_at, u.email AS owner, "
            "(SELECT COUNT(*) FROM scans s WHERE s.mailbox_id=m.id) AS n_scans "
            "FROM mailboxes m JOIN users u ON u.id=m.user_id ORDER BY m.id").fetchall()


def update_mailbox(mailbox_id: int, **fields):
    unknown = set(fields) - _MAILBOX_FIELDS
    if unknown:
        raise ValueError(f"unknown mailbox fields: {sorted(unknown)}")
    if not fields:
        return
    sets = ", ".join(f"{k}=?" for k in fields)
    with tx() as con:
        con.execute(f"UPDATE mailboxes SET {sets} WHERE id=?", (*fields.values(), mailbox_id))


def delete_mailbox(mailbox_id: int, user_id: int, delete_scans: bool = False) -> bool:
    """Forget the mailbox and its stored password/token. The results either go with
    it or stay in the user's history; results with feedback always stay."""
    with tx() as con:
        row = con.execute("SELECT id FROM mailboxes WHERE id=? AND user_id=?",
                          (mailbox_id, user_id)).fetchone()
        if not row:
            return False
        if delete_scans:
            con.execute("DELETE FROM scans WHERE mailbox_id=? AND id NOT IN "
                        "(SELECT scan_id FROM feedback)", (mailbox_id,))
        con.execute("UPDATE scans SET mailbox_id=NULL, msg_key=NULL WHERE mailbox_id=?", (mailbox_id,))
        con.execute("DELETE FROM mailboxes WHERE id=?", (mailbox_id,))
        return True


def request_mailbox_scan(mailbox_id: int, user_id: int) -> bool:
    with tx() as con:
        cur = con.execute("UPDATE mailboxes SET scan_requested=1 WHERE id=? AND user_id=? "
                          "AND status != 'reauth'", (mailbox_id, user_id))
        return cur.rowcount == 1


def due_mailboxes(now: float | None = None) -> list[int]:
    """Mailboxes whose turn it is: asked for by the user first, then the longest waiting.
    A mailbox that needs the password again is left alone until the user reconnects it."""
    now = time.time() if now is None else now
    with conn() as con:
        rows = con.execute(
            "SELECT m.id FROM mailboxes m JOIN users u ON u.id=m.user_id "
            "WHERE u.disabled=0 AND m.status != 'reauth' AND m.lease_until < ? "
            "AND (m.scan_requested=1 OR m.next_check <= ?) "
            "ORDER BY m.scan_requested DESC, m.next_check", (now, now)).fetchall()
        return [r["id"] for r in rows]


def lease_mailbox(mailbox_id: int, owner: str, seconds: int = 600) -> bool:
    """Only one worker handles a mailbox at a time (also across processes)."""
    now = time.time()
    with tx() as con:
        cur = con.execute("UPDATE mailboxes SET lease_until=?, lease_owner=? WHERE id=? AND lease_until < ?",
                          (now + seconds, owner, mailbox_id, now))
        return cur.rowcount == 1


def renew_lease(mailbox_id: int, owner: str, seconds: int = 600):
    """Still working on it (called between messages of a long batch)."""
    with tx() as con:
        con.execute("UPDATE mailboxes SET lease_until=? WHERE id=? AND lease_owner=?",
                    (time.time() + seconds, mailbox_id, owner))


def release_mailbox(mailbox_id: int, owner: str):
    with tx() as con:
        con.execute("UPDATE mailboxes SET lease_until=0, lease_owner=NULL WHERE id=? AND lease_owner=?",
                    (mailbox_id, owner))


def set_meta(key: str, value: str):
    with tx() as con:
        con.execute("INSERT INTO meta(key,value) VALUES (?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",
                    (key, value))


def get_meta(key: str, default: str = "") -> str:
    with conn() as con:
        row = con.execute("SELECT value FROM meta WHERE key=?", (key,)).fetchone()
        return row["value"] if row else default

# ------------------------------------------------------------------ DNS shield
def create_device(user_id: int, name: str, token_hash: str) -> int:
    with tx() as con:
        cur = con.execute(
            "INSERT INTO devices(user_id,name,token_hash,created_at) VALUES (?,?,?,?)",
            (user_id, name[:80], token_hash, time.time()))
        return cur.lastrowid


def get_device(device_id: int, user_id: int | None = None):
    with conn() as con:
        if user_id is None:
            return con.execute("SELECT * FROM devices WHERE id=?", (device_id,)).fetchone()
        return con.execute("SELECT * FROM devices WHERE id=? AND user_id=?",
                           (device_id, user_id)).fetchone()


def get_device_by_token(token_hash: str):
    with conn() as con:
        return con.execute("SELECT * FROM devices WHERE token_hash=?", (token_hash,)).fetchone()


def list_devices(user_id: int):
    """Devices with counters for the dashboard (last 24 h)."""
    since = time.time() - 86400
    with conn() as con:
        return con.execute(
            "SELECT d.*, "
            "(SELECT COUNT(*) FROM dns_events e WHERE e.device_id=d.id AND e.created_at>=?) "
            "AS queries_24h, "
            "(SELECT COUNT(*) FROM dns_events e WHERE e.device_id=d.id AND e.created_at>=? "
            "AND e.action='blocked') AS blocked_24h "
            "FROM devices d WHERE d.user_id=? ORDER BY d.id", (since, since, user_id)).fetchall()


def count_devices(user_id: int) -> int:
    with conn() as con:
        return con.execute("SELECT COUNT(*) FROM devices WHERE user_id=?", (user_id,)).fetchone()[0]


def set_device_active(device_id: int, user_id: int, active: bool) -> bool:
    with tx() as con:
        cur = con.execute("UPDATE devices SET active=? WHERE id=? AND user_id=?",
                          (int(active), device_id, user_id))
        return cur.rowcount == 1


def delete_device(device_id: int, user_id: int) -> bool:
    with tx() as con:
        cur = con.execute("SELECT id FROM devices WHERE id=? AND user_id=?",
                          (device_id, user_id)).fetchone()
        if not cur:
            return False
        con.execute("DELETE FROM dns_events WHERE device_id=?", (device_id,))
        con.execute("DELETE FROM devices WHERE id=?", (device_id,))
        return True


def touch_device(device_id: int, ip: str):
    with tx() as con:
        con.execute("UPDATE devices SET last_seen=?, last_ip=? WHERE id=?",
                    (time.time(), (ip or "")[:45], device_id))


def add_dns_rule(user_id: int, pattern: str, scope: str, action: str) -> bool:
    """False if the same pattern already exists for this user."""
    with tx() as con:
        cur = con.execute(
            "INSERT OR IGNORE INTO dns_rules(user_id,pattern,scope,action,created_at) "
            "VALUES (?,?,?,?,?)", (user_id, pattern, scope, action, time.time()))
        return cur.rowcount == 1


def delete_dns_rule(rule_id: int, user_id: int) -> bool:
    with tx() as con:
        cur = con.execute("DELETE FROM dns_rules WHERE id=? AND user_id=?", (rule_id, user_id))
        return cur.rowcount == 1


def list_dns_rules(user_id: int):
    with conn() as con:
        return con.execute("SELECT * FROM dns_rules WHERE user_id=? ORDER BY pattern",
                           (user_id,)).fetchall()


def log_dns_event(device_id: int, domain: str, qtype: int, action: str, rule: str = ""):
    with tx() as con:
        con.execute(
            "INSERT INTO dns_events(device_id,domain,qtype,action,rule,created_at) "
            "VALUES (?,?,?,?,?,?)",
            (device_id, domain[:253], int(qtype), action, (rule or "")[:253], time.time()))


def list_dns_events(device_id: int, limit: int = 100, action: str | None = None):
    with conn() as con:
        if action in ("allowed", "blocked", "error"):
            return con.execute(
                "SELECT * FROM dns_events WHERE device_id=? AND action=? "
                "ORDER BY id DESC LIMIT ?", (device_id, action, limit)).fetchall()
        return con.execute(
            "SELECT * FROM dns_events WHERE device_id=? ORDER BY id DESC LIMIT ?",
            (device_id, limit)).fetchall()


def dns_stats(user_id: int, since: float) -> dict:
    """Totals across all of the user's devices (for the shield overview)."""
    with conn() as con:
        row = con.execute(
            "SELECT COUNT(*) AS total, SUM(e.action='blocked') AS blocked "
            "FROM dns_events e JOIN devices d ON d.id=e.device_id "
            "WHERE d.user_id=? AND e.created_at>=?", (user_id, since)).fetchone()
        top = con.execute(
            "SELECT e.domain, COUNT(*) AS n FROM dns_events e JOIN devices d ON d.id=e.device_id "
            "WHERE d.user_id=? AND e.created_at>=? AND e.action='blocked' "
            "GROUP BY e.domain ORDER BY n DESC LIMIT 10", (user_id, since)).fetchall()
    return {"total": row["total"] or 0, "blocked": row["blocked"] or 0,
            "top_blocked": [dict(r) for r in top]}


def purge_old_dns_events(days: int) -> int:
    if days <= 0:
        return 0
    with tx() as con:
        cur = con.execute("DELETE FROM dns_events WHERE created_at < ?",
                          (time.time() - days * 86400,))
        return cur.rowcount

