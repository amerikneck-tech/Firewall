"""Web app configuration - everything comes from environment variables (.env)."""
from __future__ import annotations

import os
import secrets

from antiphish import config as _core  # noqa: F401  (loads project .env)

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
DATA_DIR = _core.DATA_DIR
DB_PATH = os.getenv("DB_PATH", os.path.join(DATA_DIR, "antiphish.db"))

# Session signing key. MUST be set in production (random 64+ chars).
SECRET_KEY = os.getenv("SECRET_KEY", "")
if not SECRET_KEY:
    SECRET_KEY = secrets.token_urlsafe(48)  # dev only: sessions reset on restart
    SECRET_KEY_IS_RANDOM = True
else:
    SECRET_KEY_IS_RANDOM = False

BASE_URL = os.getenv("BASE_URL", "http://localhost:8000").rstrip("/")
HTTPS_ONLY_COOKIES = os.getenv("HTTPS_ONLY_COOKIES", "1" if BASE_URL.startswith("https") else "0") == "1"
SESSION_DAYS = int(os.getenv("SESSION_DAYS", "7"))

# Scanning
MAX_UPLOAD_MB = int(os.getenv("MAX_UPLOAD_MB", "15"))
SCAN_CONCURRENCY = int(os.getenv("SCAN_CONCURRENCY", "2"))   # protect VPS RAM/CPU
WEB_USE_URL_INTEL = os.getenv("WEB_USE_URL_INTEL", "1") == "1"
WEB_ALLOW_LLM = os.getenv("WEB_ALLOW_LLM", "1") == "1"       # offer "AI scan" if Qwen reachable

# Credits
COST_QUICK = int(os.getenv("COST_QUICK", "1"))
COST_AI = int(os.getenv("COST_AI", "3"))
DEFAULT_CREDITS = int(os.getenv("DEFAULT_CREDITS", "50"))

# Abuse limits
LOGIN_MAX_ATTEMPTS = int(os.getenv("LOGIN_MAX_ATTEMPTS", "8"))      # per IP+email / 15 min
# per e-mail across ALL addresses: stops password guessing spread over many IPs
# (or behind a proxy that lets the client forge X-Forwarded-For)
LOGIN_MAX_ATTEMPTS_PER_ACCOUNT = int(os.getenv("LOGIN_MAX_ATTEMPTS_PER_ACCOUNT", "30"))
SCANS_PER_HOUR = int(os.getenv("SCANS_PER_HOUR", "60"))             # per user

# Privacy: e-mail text is kept only this long (for feedback), then wiped.
RETAIN_TEXT_HOURS = int(os.getenv("RETAIN_TEXT_HOURS", "72"))

# Forward-to-scan mailbox (e.g. scan@yourdomain.com on Hostinger Email)
INTAKE_IMAP_HOST = os.getenv("INTAKE_IMAP_HOST", "imap.hostinger.com")
INTAKE_IMAP_PORT = int(os.getenv("INTAKE_IMAP_PORT", "993"))
INTAKE_SMTP_HOST = os.getenv("INTAKE_SMTP_HOST", "smtp.hostinger.com")
INTAKE_SMTP_PORT = int(os.getenv("INTAKE_SMTP_PORT", "465"))
INTAKE_USER = os.getenv("INTAKE_USER", "")          # scan@yourdomain.com
INTAKE_PASSWORD = os.getenv("INTAKE_PASSWORD", "")
INTAKE_POLL_SECONDS = int(os.getenv("INTAKE_POLL_SECONDS", "20"))
INTAKE_USE_LLM = os.getenv("INTAKE_USE_LLM", "0") == "1"

# ------------------------------------------------------------------ connected mailboxes
# Users connect their own mailbox (Gmail, Yahoo, iCloud, any IMAP; Outlook through
# Microsoft sign-in) and AntiPhish checks every new message - see webapp/mailbox_worker.py.
MAILBOX_ENABLED = os.getenv("MAILBOX_ENABLED", "1") == "1"
# the checker runs inside the web process; set 0 to run it yourself with
#   python -m webapp.mailbox_worker
MAILBOX_WORKER = os.getenv("MAILBOX_WORKER", "1") == "1"
# Key that encrypts the stored mailbox passwords / tokens. Empty = derived from SECRET_KEY.
# Changing either one makes every connected mailbox ask for the password again.
MAILBOX_KEY = os.getenv("MAILBOX_KEY", "")
MAILBOX_POLL_SECONDS = int(os.getenv("MAILBOX_POLL_SECONDS", "120"))    # how often each mailbox is checked
MAILBOX_INITIAL_SCAN = int(os.getenv("MAILBOX_INITIAL_SCAN", "20"))     # newest N messages on connect
MAILBOX_BATCH = int(os.getenv("MAILBOX_BATCH", "25"))                   # messages per mailbox per round
MAILBOXES_PER_USER = int(os.getenv("MAILBOXES_PER_USER", "3"))
MAILBOX_SCANS_PER_HOUR = int(os.getenv("MAILBOX_SCANS_PER_HOUR", "120"))  # per user; the rest waits
COST_MAILBOX = int(os.getenv("COST_MAILBOX", "0"))                      # credits per automatically checked message
MAILBOX_USE_LLM = os.getenv("MAILBOX_USE_LLM", "0") == "1"
# results of automatically checked messages are deleted after this many days (0 = keep);
# results the user gave feedback on are kept
MAILBOX_RETAIN_DAYS = int(os.getenv("MAILBOX_RETAIN_DAYS", "90"))
# A user-supplied IMAP server must have a public address. Only for a mail server in your
# own (private) network: 1
MAILBOX_ALLOW_PRIVATE_HOSTS = os.getenv("MAILBOX_ALLOW_PRIVATE_HOSTS", "0") == "1"
MAILBOX_PORT = 993                                                      # IMAP over TLS only

# Outlook / Hotmail / Microsoft 365: Microsoft sign-in (OAuth 2.0) + Microsoft Graph.
# Needs an app registration of your own - see deploy/DEPLOY.md.
MS_CLIENT_ID = os.getenv("MS_CLIENT_ID", "")
MS_CLIENT_SECRET = os.getenv("MS_CLIENT_SECRET", "")
MS_TENANT = os.getenv("MS_TENANT", "common")
MS_LOGIN_BASE = os.getenv("MS_LOGIN_BASE", "https://login.microsoftonline.com").rstrip("/")
MS_GRAPH_BASE = os.getenv("MS_GRAPH_BASE", "https://graph.microsoft.com/v1.0").rstrip("/")

# ------------------------------------------------------------------ buying credits (billing)
# "simulator": a built-in test checkout - no account, no keys, no real money; the whole
# purchase flow runs exactly as with a real provider. "stripe": real Stripe Checkout
# (test mode: sk_test_... keys + card 4242 4242 4242 4242). See deploy/DEPLOY.md.
BILLING_ENABLED = os.getenv("BILLING_ENABLED", "1") == "1"
BILLING_PROVIDER = os.getenv("BILLING_PROVIDER", "simulator")
STRIPE_SECRET_KEY = os.getenv("STRIPE_SECRET_KEY", "")          # sk_test_... or sk_live_...
STRIPE_WEBHOOK_SECRET = os.getenv("STRIPE_WEBHOOK_SECRET", "")  # whsec_... from the webhook registration
STRIPE_TAX_CODE = os.getenv("STRIPE_TAX_CODE", "txcd_10000000")   # electronically supplied services; accounts with Stripe Tax / managed payments refuse checkout without it
# optional: your own packages as JSON on one line, e.g.
# BILLING_PACKAGES='[{"id":"starter","name":"Starter","credits":100,"price_cents":500,"currency":"EUR"}]'
BILLING_PACKAGES = os.getenv("BILLING_PACKAGES", "")

# ------------------------------------------------------------------ DNS shield
# A DNS firewall for the user's devices. An agent on the device (or any DoH client)
# sends queries to <BASE_URL>/dns-query/<device-token> (DNS-over-HTTPS, RFC 8484);
# blocked domains get NXDOMAIN straight away, the rest is forwarded to the upstream
# resolver. Without a valid device token the server answers nothing - it is never
# an open resolver.
DNSFW_ENABLED = os.getenv("DNSFW_ENABLED", "1") == "1"
DNSFW_UPSTREAM = os.getenv("DNSFW_UPSTREAM", "1.1.1.1")      # resolver for allowed queries
DNSFW_UPSTREAM_PORT = int(os.getenv("DNSFW_UPSTREAM_PORT", "53"))
DNSFW_TIMEOUT = float(os.getenv("DNSFW_TIMEOUT", "5"))       # upstream wait, seconds
DNSFW_DEVICES_PER_USER = int(os.getenv("DNSFW_DEVICES_PER_USER", "5"))
DNSFW_QUERIES_PER_MIN = int(os.getenv("DNSFW_QUERIES_PER_MIN", "600"))   # per device
DNSFW_LOG_RETENTION_DAYS = int(os.getenv("DNSFW_LOG_RETENTION_DAYS", "14"))
