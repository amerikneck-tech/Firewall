# AntiPhish DNS Shield — Windows agent

The little program that connects a Windows PC to your AntiPhish DNS shield. The user
pastes one address, clicks **Turn ON**, and every program on the PC is protected.

## What the user does

1. On the website: **DNS shield → Add device** → copy the DoH address
   (`https://antiphish.YOURDOMAIN.com/dns-query/apdns_...`).
2. Start `AntiPhishShield.exe` (it asks for Administrator rights once — Windows requires
   that for changing DNS settings).
3. Paste the address into the window that pops up → **Save**.
4. Click **Turn ON**. Done — status should say **PROTECTED**.

The **Test connection** button asks the server about a domain that is always blocked;
"OK" means the whole path works.

## What it does (and what it never does)

* Sets the DNS of every active network adapter to `127.0.0.1`, where the agent listens.
* Every DNS query goes over HTTPS to the personal DoH address (only the domain name —
  the agent never sees or sends anything else).
* Blocked domains answer "does not exist" (NXDOMAIN) — for the browser, games, every app.
* **Fail-open:** if the server is unreachable (deploy, outage), the agent quietly answers
  via a public resolver (1.1.1.1) until it comes back. The PC's internet never stops
  because of the shield.
* **Closing the window = protection off + your old DNS settings restored.** The previous
  settings are saved before anything is changed and put back on exit.
* "Start with Windows" makes it launch (and re-protect) on every login.

## If the DNS ever seems stuck at 127.0.0.1

Can only happen if the PC crashes hard while protected. Fix: start the agent again (it
restores on exit), or manually: Settings → Network → your adapter → Edit DNS → Automatic,
or in PowerShell: `Set-DnsClientServerAddress -InterfaceAlias 'Wi-Fi' -ResetServerAddresses`.

## Files and settings

Everything lives in `%APPDATA%\AntiPhishShield\` (`config.json` — your address;
`previous-dns.json` — the DNS backup). Delete the folder + the .exe to uninstall.

## Building the .exe yourself

On any Windows PC with Python 3.10+ (python.org):

```
build-agent.bat
```

→ `dist\AntiPhishShield.exe` — a single standalone file; Python is **not** needed on the
PCs you copy it to. (`--uac-admin` bakes in the admin prompt; `--windowed` = no console.)

For testing without building: `python shield_agent.py` from an **Administrator** terminal.

## Without the agent

Browsers (Chrome/Firefox "Secure DNS") and iOS/macOS (a .mobileconfig profile) can use the
same DoH address directly — protects that browser/device without any program. The agent is
the way to protect a whole Windows PC.
