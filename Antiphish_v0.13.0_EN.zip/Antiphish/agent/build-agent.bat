@echo off
REM Builds AntiPhishShield.exe from shield_agent.py.
REM Needs Python 3.10+ from python.org (tick "Add Python to PATH" during install).
cd /d "%~dp0"
python --version || (echo Python not found - install it from python.org first. & pause & exit /b 1)
python -m pip install --upgrade pyinstaller || (echo pip failed. & pause & exit /b 1)
python -m PyInstaller --noconfirm --onefile --windowed --uac-admin --name AntiPhishShield shield_agent.py || (echo Build failed. & pause & exit /b 1)
echo.
echo Done: %cd%\dist\AntiPhishShield.exe
echo The exe is standalone - Python is NOT needed on the PCs you copy it to.
pause
