"""Honest evaluation - see antiphish/evaluation.py for the protocol.

    python evaluate.py                    text model on held-out slices + probe sets + scenario suite
    python evaluate.py --e2e              + the FULL detector on held-out raw mail (needs data/raw)
    python evaluate.py --e2e --max 800    cap raw messages per slice (faster)
    python evaluate.py --json report.json save every number
"""
from antiphish.evaluation import main

if __name__ == "__main__":
    main()
