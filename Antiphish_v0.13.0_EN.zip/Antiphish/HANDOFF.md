# HANDOFF – project status after v0.11.0

*Written 22.11.2026 (v0.9 → v0.10), extended 23.11.2026 (v0.10.1: deployment check) and
once more 23.11.2026 (v0.11.0: connected mailboxes and the new look).*
*This file did not exist in the repo or in `Antiphish_v0.9.zip` (it was looked for and not found) – this is the first version.*
*Rule for the next session: read this file first, then the README sections "v0.10", "v0.10.1" and "v0.11".*

---

## 1. Where we are

| | |
|---|---|
| Version | **0.11.0** (`antiphish/__init__.py`) – deliberately not "1.0": not yet verified on real current mail |
| Starting point | `Antiphish_v0.9.zip` from the repo (same content as the `Antiphish/` subfolder, plus `.env.example`, `.gitignore`, `.dockerignore`) |
| Tests | **347 passing** (79 old + 112 from v0.10 + 45 from v0.10.1 + 111 from v0.11); without the corpus 4 are skipped. Plus `tests/e2e/` – checks against a running system (not run by `pytest`) |
| Model | linear SVM (calibrated) on ~22,300 texts; training ~35 s; file + `.sha256` + `.meta.json`. v0.10.1 changes neither the model nor the rules – a model from v0.10.0 still works |
| Docker | `docker compose up -d --build` with Caddy, the intake and the Qwen profile tried end to end (see 4.) |
| Server | **deployed**: on 23.11. the user reported v0.10.1 running on his Google Cloud VM (site and domain stayed at Hostinger). v0.11.0 is not on the server yet – upgrade: `deploy/DEPLOY.md`, "Upgrade to v0.11" |
| New in v0.11 | the user **connects their own mailbox** and the server checks new mail itself; new look of all pages; fixed the bug that made pages "hang" (see 4.) |

## 2. What was done (short – details and evidence are in README "v0.10")

1. **New measurement**: the whole detector on raw mail it had never seen (`python evaluate.py --e2e`),
   both versions on exactly the same messages.
2. **Parser** (`html_extract.py`, `email_parser.py`): keeps link targets (v0.9 threw them away), hidden text,
   forms, inline images, calendar, authentication alignment.
3. **Rules** (`checks.py`, `domains.py`, `brands.py`, `features.py`): brand registry, redirect unwrapping,
   platform abuse, BEC / device-code / ClickFix / callback / QR, BS-HR-SR and Swedish,
   Cyrillic, recipient context.
4. **Scoring** (`scorer.py`): three tiers of evidence; fixed the bug that gave authenticated phishing a LOW.
5. **Data and model** (`scripts/build_corpus.py`, `model.py`, `synth_*.py`): new sources, removed the corpus
   owner's address "leak", resilience to failed downloads, class-balance guard.
6. **Operational safety**: retraining gate + rollback (`learn.py`), refusal of a model from another version,
   bounded processing time for large mails, nginx `X-Forwarded-For`, per-account login limit.
7. **Web**: explanations of the new signals (Bosnian), display of the score arithmetic, loading a new model
   without a restart.
8. **v0.10.1 – deployment check** (README "v0.10.1" has the table of findings and evidence): everything was run
   the way it will run on the VPS, and what that turned up was fixed –
   mail server certificate verification (IMAP went without it), intake worker behaviour on a wrong password,
   the AI check (new prompt, a guard so the model's opinion cannot topple a high score, charging when the model
   doesn't answer), quarantine only on technical evidence, pinned library versions, the `deploy/provjera.sh` script.
9. **v0.11 – connected mailboxes** (README "v0.11"). The user asked: instead of uploading a .eml file, connect
   a mail account (Gmail, Outlook, any) and have the app scan the mailbox itself; he also disliked the look.
   Done:
   - `webapp/mailboxes.py` – the offered providers and reading over IMAP, strictly read-only;
   - `webapp/msgraph.py` – Microsoft sign-in (OAuth with PKCE) and reading through Microsoft Graph;
   - `webapp/mailbox_worker.py` – background checking (a thread in the web process), state and back-off on errors;
   - `webapp/crypto.py` – encryption of stored passwords/tokens; `webapp/netguard.py` – which mail server
     a user may enter;
   - new templates and `static/style.css` + `static/app.js`: Dashboard, Mailboxes, connecting, Manual check;
   - `antiphish/attachment_scan.py` – the attachment scanner's worker process no longer holds the web server's connections.

## 3. Measured (22.11.2026)

Same raw mails, each version trained with its own recipe on its own training split (phishing up to 2023).

| Set the model never saw | n | v0.9 | v0.10 |
|---|---|---|---|
| Phishing Nazario 2024–2025: rated HIGH/CRITICAL | 884 | 52.8% | **90.2%** |
| … rated LOW (missed) | | 27.0% | **3.3%** |
| phishing_pot 2022–2026 (another collector, sample): HIGH/CRITICAL | 1500 | 33.0% | **78.5%** |
| … LOW | | 20.4% | **7.5%** |
| Legitimate, SpamAssassin: flagged SUSPICIOUS+ | 317 | 17.7% | **1.3%** |
| Legitimate, Enron (mailboxes the model never saw): SUSPICIOUS+ | 601 | 9.0% | **1.5%** |
| Legitimate, Apache lists 2024–2026 (lists it never saw): SUSPICIOUS+ | 339 | 27.1% | **0.6%** |
| Legitimate rated HIGH+ (all three sets) | 1257 | 2 | **0** |
| Scenarios dev (30 legit / 30 phishing): LOW / HIGH+ | | 27 / 12 | **30 / 30** |
| Scenarios holdout (20 / 21): LOW / HIGH+ | | 16 / 9 | **19 / 21** |

Text model alone (v0.10): ROC-AUC 0.996; Nazario 2024–25 93.0% at p ≥ 0.5 with 0.29% false; 96.5% at 1% false.

Raw results: `docs/evaluation_2026-11-22.json`.

**How to read it (important):**
- phishing_pot is honeypot mail: besides phishing it contains ordinary spam (casino, health, dating) and a few
  normal messages. That row therefore understates real phishing recall. License CC BY-NC → measurement only.
- The public legitimate corpora are from 2000–2002 or are developer lists. They say little about today's
  personal/business mail.
- The scenarios and probes were written by the same author who wrote the rules. The holdout part was written
  after the rules were frozen and run once (result: 19/20 and 21/21 with the production model; 20/21 with the
  stricter evaluation model). The only false alarm: a real Microsoft 365 password-expiry notice (SUSPICIOUS).
- Without the generated modern legitimate examples the same model flags 73% of the old probes as phishing. Good
  behaviour on today's mail currently rests on generated examples → **step 1 in section 6**.

## 4. What HAS been verified and what has NOT

Verified 22.11. (v0.10): all tests; training; evaluation (text + e2e + scenarios); the gate (honest feedback
passes, 400 wrong labels fail, rollback restores the model); `docker build` + `docker run` with the full
feedback → export → `antiphish.learn` → new model loaded without a restart flow; simulated upgrade from v0.9.

Verified 23.11. (v0.10.1), all of it on the image built from this release's zip:
- **`docker compose up -d --build`** with the real compose file and Caddy (HTTPS with Caddy's internal CA for
  the name `antiphish.localhost`): http → https redirect, security headers, Secure + HttpOnly cookie;
- **web application through HTTPS**: 38 scripted checks (login, CSRF, upload and paste, attachments,
  credits, feedback, admin, access rights, password change, size limits) – all pass;
- a forged `X-Forwarded-For` does not bypass the login limit (Caddy: 10 attempts, each with a different forged
  address – the lock-out still kicks in; real nginx with our config: the app sees the true address, not the forged one);
- HTML/scripts in the subject, sender, links and comment are not executed (escaped on all pages);
- **persistence**: `down`/`up`, Docker daemon restart – accounts, history and model survive, containers come back on their own;
- **small server**: build with 1 core – corpus ~215 s (network), training ~40 s and ~1.2 GB RAM (fails with a
  1 GB limit); `antiphish.learn` in the container ~45 s and up to 1.45 GB;
- **intake (`scan@`)** against a real IMAP/SMTP server over TLS (GreenMail in Docker, own test CA):
  attachment, `.eml` file, plain forward, unknown sender, auto-reply, spoofed sender,
  deactivated account; then wrong certificate, wrong server name, wrong password, `MAIL_TLS_VERIFY=0`;
- **desktop monitor** against the same server: quarantine via IMAP MOVE for mail with technical evidence, a
  gift-card request stays in the inbox with a CRITICAL alert, legitimate mail stays unread;
- **Qwen live**: Ollama + `qwen2.5:3b`, all 101 scenarios, three prompt versions (numbers in 5.7);
- Streamlit `app.py` (AppTest + server start) and `demo.py`;
- upgrade over an existing folder (`rsync` from the zip, `data/` and `.env` untouched);
- `deploy/provjera.sh prije|poslije` – correct and incorrect setups, with and without `ss`/`dig`, and on a server without Docker;
- **plain Ubuntu (no Docker template)**: the guide's commands typed into clean Ubuntu 24.04 and 26.04 install
  Docker 29.10.0 and Compose 5.8.0 – the same versions everything above ran on. The only thing that could not
  be checked there was the Docker service starting under systemd. Same on clean Debian 12 and 13 (the usual Google Cloud images);
- **small machine (Google Cloud e2-small / e2-micro)**: training with 0.5 core and 1.5 GB – 95 s; with 0.25 core,
  0.7 GB RAM and 2 GB swap – 216 s (with 1 GB and no swap it fails); the swap command from the guide executed verbatim;
- **Docker MTU**: the test machine itself has an uplink MTU of 1400 against Docker's 1500 and everything worked;
  the guide's setting (`daemon.json`) was tried with a real Docker service – the default network, the compose
  network and the build steps take the configured MTU, the app runs.

*Deviation:* in the verification environment HTTPS goes through a local proxy, so its CA certificate was added
to the test Dockerfile (the only difference from `Dockerfile`). It is not part of the project and is not needed on a VPS.
*Clarified in v0.11 (previously "observed, unexplained"):* in v0.10.1 a single request to Caddy went unanswered
three times, minutes after the web container was recreated, and I could not reproduce it. The cause was found
when the pages were driven with a real browser: the attachment scanner starts a worker process (`fork`), and
that process kept a copy of every connection the web server had open at that moment. When the server later
closed such a connection, the other side (the browser or Caddy) never learned of it and sent its next request
into a connection nobody read. Proof (same image, only `attachment_scan.py` swapped, through Caddy/HTTPS): with
the file from v0.10.1, after one mail with an attachment **7 of 12** page loads go unanswered; with v0.11 none
(`tests/e2e/keepalive_ab.py`). **This affects the v0.10.1 that is currently on the server** – one more reason to upgrade.

Verified 23.11. (v0.11.0), on the image built from this release's zip, through Caddy and HTTPS:
- **111 new tests** with stand-in IMAP and Microsoft servers that record every request; additionally 39
  deliberate faults were put into the code one at a time (e.g. "don't check the mailbox owner", "don't check
  `state`", "open the folder for writing") – three were not caught in the first round, the tests were extended,
  now they all fail;
- **real IMAP server** (GreenMail, TLS with a test CA; certificate and name are verified): connecting, first
  check, new mail, periodic check, disconnecting;
- **pages in a real browser** (Chromium, 13 checks): wrong password, disallowed server name, results appear on
  their own, "Check now", the result page, disconnecting, no CSP or script errors;
- **Microsoft sign-in** in a browser against a stand-in server speaking Microsoft's documented protocol over
  real HTTP (14 checks): redirect with PKCE, return with the session intact, refused consent, results, new
  mail, each message downloaded once, revoked access, disconnecting;
- **harder situations**: server restarted right after a mailbox was connected; 30 messages (exactly the newest
  20 checked, none twice); a 16 MB message (skipped, the next one checked); mail server silent for a minute (no
  alarm on the page, recovers on its own). At the end, all 33 messages in the mailbox were still unread;
- **upgrade** per the guide over a running v0.10.1 with its data: database extended in place, the user stayed
  signed in, old results and credits intact, the model identical (same SHA-256); during the build the site
  answered with the old version and returned 502 for ~2.5 s when the container was replaced;
- **everything from v0.10.1 again**: the scripted HTTPS checks, extended to 51; `deploy/provjera.sh poslije`
  with the new section (mailbox checking, outbound port 993).

NOT verified:
- **a real Gmail, Yahoo, iCloud or Hostinger mailbox** – the verification environment has no outbound IMAP
  (port 993). The protocol was verified against a real IMAP server, but not against theirs. The first
  connection of a real Gmail is therefore the first real test;
- **real Microsoft** (sign-in and Graph) – written from the documentation and verified against a stand-in
  server. It also needs an app registration that only the user can do (`deploy/DEPLOY.md`);
- **volume**: one thread walks the mailboxes in turn (about a second per mailbox); dozens are fine, hundreds
  were not measured;
- **a real server**: I ran nothing on a real Google Cloud VM or a Hostinger VPS; that v0.10.1 works there I
  know only from the user's message. Public DNS, Let's Encrypt and the firewall are checked by
  `deploy/provjera.sh`;
- Hostinger's mail servers (`imap.hostinger.com` / `smtp.hostinger.com`) – intake was tried with another real
  server, not theirs;
- DashScope (no key); `qwen2.5:7b` was run only once (numbers in 5.7), DashScope models never;
- the desktop monitor with Gmail/Outlook and on Windows;
- anything on real current mail.

## 5. Things to know / decisions waiting for you

1. **Scores differ from v0.9.** The same mail can score higher or lower. In particular: much more phishing now
   reaches ≥ 90 (56% of the Nazario test; in v0.9 the whole CRITICAL class was 14%). The desktop monitor at ≥ 90
   **moves mail to quarantine**, so a second condition was added: at least 40 points of *firm technical* evidence
   (`QUARANTINE_MIN_FIRM=40`: dangerous attachment, fake or look-alike domain, failed authentication, sender
   impersonation). Text patterns, the text model and the AI model's opinion can raise the alarm but cannot move
   mail. With both conditions, 26% of the Nazario test is moved. Across 1257 legitimate test mails the highest
   score was 59, but that is not your mail: in the first days regularly check the
   `AntiPhish-Quarantine` folder (or set `QUARANTINE=0`).
2. **The GitHub repo is messy and public.** The root has the old v0.6 (with `models/model.joblib` without
   `.sha256`), v0.9 is in the `Antiphish/` subfolder, plus the zip. Suggestion: repo root = the contents of
   `Antiphish_v0.10.zip`, delete the old stuff. `deploy/DEPLOY.md` already warns the repo should be private
   before production. Nothing was pushed – I have no access and it wasn't asked for.
3. **Data licenses** (NOTICE.md): Nazario is CC BY 4.0 (commercial use allowed with attribution). For
   SpamAssassin, Enron and the Apache lists the text copyright stays with the senders – before commercial use
   ask a lawyer or leave them out (`--no-enron --no-lists`, with a weaker model on business mail).
   phishing_pot is non-commercial and is used for measurement only.
4. **Privacy** (resolved in v0.11): the "Privacy" page now states that a stored result also contains the links
   from the mail, attachment names and short attachment findings, and that the administrator can open a result.
   The mail text is still deleted after 72 h. Manual check results are not deleted automatically (automatic
   ones: after 90 days).
5. **Feedback** is now stored in the database without the recipient's address and name (replaced with tokens).
   Old rows in `data/feedback.csv` from v0.9 still count.
6. **Build time** is longer: ~450 MB is downloaded (~30 MB remains). Faster variant:
   `CORPUS_FLAGS="--no-enron --no-lists" docker compose up -d --build`.
7. **The AI check (Qwen) is a second pair of hands, not a judge.** Measured live through Ollama, 101 scenarios, 4 cores:
   - `qwen2.5:3b` with the old prompt: the model itself recognised 2 of 51 phishing scenarios, and with its
     "legitimate" opinion knocked 12 points off nine of them – two from HIGH to SUSPICIOUS. The AI check was, in
     other words, *making results worse*.
   - `qwen2.5:3b` with the new prompt and context: 45 of 51; falsely accused legitimate 0 of 50; with the HIGH
     guard no phishing loses points anymore (51/51 stays HIGH+, legitimate LOW 50/50).
     Median 9.3 s, slowest 22 s per mail; with Ollama on 2 cores 16–37 s.
   - `qwen2.5:7b`, same prompt, one run: 46 of 51, one legitimate mail falsely accused (an internal IT password
     reminder, LOW → SUSPICIOUS), median 24 s. Not better than the small one, and 2–3 times slower.
   - A third prompt version, which caught one more phishing mail but accused three legitimate ones, was rejected.
   Raw answers are in `docs/llm_eval_2026-11-23/`; the same measurement for any model: `python scripts/eval_llm.py`.
   We wrote the scenarios ourselves, and the scanner catches them without AI – on them AI can only show harm, not benefit.
   Decision for you: whether to offer the AI check to testers at all (Ollama with the 3b model uses ~2.7 GB RAM and
   ~10 GB disk). My suggestion: keep `WEB_ALLOW_LLM=0` for the first round of testing.
8. **Mail servers are now verified** (certificate and name). If intake or the monitor reports
   `certificate ... could not be verified` after the upgrade, the server name in the settings is not the one the
   certificate is issued to (use `imap.hostinger.com`, not `mail.yourdomain.com`). Emergency escape: `MAIL_TLS_VERIFY=0`.
9. **Quarantine (desktop monitor)** since v0.10.1 requires 40 points of *technical* evidence; a gift-card request
   from a Gmail address raises a CRITICAL alert, but the mail stays in the inbox.
10. **Libraries are pinned** to the versions everything here was tested with (`constraints-server.txt`). When you
    want newer ones: instructions are in that file's header.
11. **The server now stores access to other people's mailboxes** (v0.11). App passwords and Microsoft tokens are
    encrypted in the database, the key is in `.env`. That protects against a leak of the database itself, not
    against whoever runs the server. An app password (Gmail, Yahoo, iCloud) technically grants access to the
    whole mailbox; the program uses it only for reading. The "Privacy" page now tells the user this openly (which
    also resolved point 4 above: it also says the result contains links and attachment names). **Do not change
    `SECRET_KEY`** – otherwise everyone has to connect their mailboxes again.
12. **Automatic checks are free** (`COST_MAILBOX=0`), with a limit of 120 checks per user per hour and 3
    mailboxes per account. Reason: at a price of 1, a user with 50 credits runs out of checking within a day or
    two and the mailbox goes silent. If credits should limit this too, change it in `.env` – the pages already
    know how to show it.
13. **Automatic check results are deleted after 90 days** (`MAILBOX_RETAIN_DAYS`; except those with feedback).
14. **Gmail goes through an app password, deliberately without "Sign in with Google".** To read Gmail, Google
    requires a public app to pass verification and a yearly paid security assessment; without that, at most 100
    manually listed users and access that expires every 7 days. If the project ever goes commercial, that's a
    decision (and a cost) for then.
15. **Outlook needs your app registration with Microsoft** (free, steps in DEPLOY.md). Personal accounts
    (outlook.com, hotmail.com) then work; work accounts of other companies must be approved by their
    administrator until the app has Microsoft's "publisher verification".
16. **The program does nothing in the mailbox and sends no warnings.** A dangerous message is visible only on
    the Dashboard page. Sending warning mail and moving mail to a special folder were deliberately left for the
    next step: the first needs outbound mail from the server, the second write access to other people's mailboxes.

## 6. Next steps (by importance)

0. **Upgrade the server to v0.11 and connect your own Gmail** (DEPLOY.md: "Upgrade to v0.11", then "Testing
   plan" item 10). That is the first test on a real provider. What to watch: that the newest 20 messages appear
   within a minute, that new mail arrives on its own, that nothing in Gmail is marked as read. If something
   doesn't work: `docker compose logs --tail 100 web | grep -i mailbox` and `python -m webapp.manage mailboxes`.
   Then the Microsoft registration and one Outlook account – the first test on real Microsoft.
1. **Measure on your own mail.** Easiest now: connect a mailbox and on the Dashboard page mark every wrong
   verdict ("This is legitimate email" / "This is phishing"). For a larger batch at once: export known-good mails
   (Gmail Takeout `.mbox` or a folder of `.eml`):
   `python scripts/scan_folder.py export.mbox --expect legit` → you see the false-alarm rate and which signals
   cause it. Then `--add-feedback` and `python -m antiphish.learn`. Same for a phishing folder (`--expect phishing`).
   This is the only way to learn the real accuracy.
2. Deploy to the VPS per `deploy/DEPLOY.md` ("Shortest path" at the top; `bash deploy/provjera.sh before` then `after`)
   and go through the testing plan (step 10). What could not be verified here – public DNS, Let's Encrypt,
   the Hostinger firewall and mail – is verified exactly then.
3. When tester feedback accumulates: `antiphish.learn` (the gate protects against wrong labels); watch
   `quality_checks` in `model.joblib.meta.json`.
4. The holdout scenarios are now "spent": develop new rules on the dev scenarios, and for the next honest
   measurement write new holdout cases (best from real, anonymised mails).
5. Qwen: before giving the AI check to testers, run `python scripts/eval_llm.py` on the model you actually use
   (in Docker: `docker compose exec -u app web python scripts/eval_llm.py`); if you have a DashScope key, try
   that variant too (untried). Change the prompt only together with that measurement, and only on the "dev" half.
6. Known gaps: (a) fake invoices that are only an image – needs OCR; (b) abuse of real platforms (a real
   PayPal/Microsoft invoice with a fake phone number); (c) languages outside EN / BS-HR-SR / SV rely on the text
   model alone; (d) BEC without any technical trace from a compromised real account.
7. **E-mail warning** when a dangerous message arrives in a connected mailbox (currently visible only on the
   page). Needs a sending account (can be the same as intake) and loop protection: our warning arrives in the
   same mailbox and will be checked – it must not be skipped based on a header an attacker can forge.
8. **Moving dangerous mail** to a special folder (like the desktop monitor): needs write access to the mailbox
   (IMAP without `readonly`, Microsoft `Mail.ReadWrite`) – a conscious decision, not a technical problem. The
   monitor's condition (score ≥ 90 and 40 points of technical evidence) can be taken over.
9. Connected mailboxes, smaller items: IMAP IDLE instead of checking every 2 minutes; more threads when there
   are many mailboxes; checking the Spam folder too (that's where the phishing the provider already caught is –
   a good source of labels).
10. Older roadmap still standing: learning the "normal" style per company, a multilingual transformer (needs
    more RAM than KVM 1). (Microsoft Graph was done in v0.11.)

## 7. How to continue the work (for the next session)

```bash
pip install -r requirements-server.txt pytest httpx
python scripts/build_corpus.py --with-phishing-pot   # ~1.5 GB with phishing_pot; without that option ~450 MB
python train.py
python -m pytest tests/ -q
PROTOCOL_MODEL_CACHE=/tmp/protocol.joblib python evaluate.py --e2e --max 1500 --json out.json
```

- **Verify the web application with a real browser too**, not only `pytest`: no test with the `TestClient`
  could see the "hanging" page bug. Scripts and environment description are in `tests/e2e/README.md`
  (GreenMail as a real IMAP server, `fake_ms.py` as a Microsoft stand-in, playwright + Chromium).
- Look: pages must not have `style=` or `<script>` in the HTML (CSP `default-src 'self'`; a test checks
  this) – everything goes into `webapp/static/style.css` and `app.js`. Icons are in `templates/_icons.html`.
- A new provider for "Connect email" → `PROVIDERS` in `webapp/mailboxes.py` (server, user steps).
- Measure every rule change with `evaluate.py --e2e` (legitimate sets: no HIGH+; as little SUSPICIOUS as
  possible) and with `run_scenarios(group="dev")`.
- **Do not tune rules against the holdout scenarios** (`scenarios_holdout.py`) or the probes in `eval_sets.py`.
- Changing `normalize_text()` or the vectorizer → bump `FEATURE_VERSION` in `model.py`.
- A new signal → add an explanation in `webapp/explain.py`, and if it's not "firm evidence" put it in
  `SOFT_SIGNALS` / `CONTEXT_SIGNALS` in `scorer.py`.
- A new brand → `BRAND_DEFS` in `brands.py` (names, tokens in the domain, real domains; `exact=True` for short or
  ordinary words).

## 8. Map of new and significantly changed files

| File | Status |
|---|---|
| `antiphish/html_extract.py`, `domains.py`, `brands.py`, `evaluation.py`, `scenarios.py`, `scenarios_holdout.py`, `synth_phish.py` | new |
| `scripts/scan_folder.py`, `tests/test_v010.py`, `HANDOFF.md`, `docs/evaluation_2026-11-22.json` | new |
| `antiphish/email_parser.py`, `checks.py`, `features.py`, `scorer.py`, `detector.py`, `model.py`, `learn.py`, `scripts/build_corpus.py` | rewritten |
| `antiphish/attachment_scan.py`, `synth_legit.py`, `eval_sets.py`, `config.py`, `webapp/explain.py`, `webapp/main.py`, `webapp/scanning.py`, `webapp/config.py`, `webapp/templates/result.html`, `Dockerfile`, `deploy/entrypoint.sh`, `deploy/nginx-antiphish.conf`, `deploy/DEPLOY.md`, `README.md`, `NOTICE.md`, `train.py`, `evaluate.py`, `parse_eml.py` | extended |
| `antiphish/monitor.py` | quarantine condition (`should_quarantine`); v0.10.1: certificate verification, technical evidence only |
| v0.10.1 new: `deploy/provjera.sh`, `constraints-server.txt`, `.gitattributes`, `tests/test_v0101.py` | |
| v0.10.1 changed: `antiphish/llm_judge.py` (prompt, DashScope address, logging), `detector.py` (context for the LLM, HIGH score guard), `providers.py` (TLS), `model.py` (file permissions), `webapp/mail_intake.py`, `webapp/scanning.py`, `webapp/main.py`, `templates/result.html`, `explain.py`, `docker-compose.yml`, `Dockerfile`, `.env.example`, `deploy/DEPLOY.md`, `app.py` | |
| v0.11 new: `webapp/mailboxes.py`, `msgraph.py`, `mailbox_worker.py`, `crypto.py`, `netguard.py`, `static/app.js`, `templates/_icons.html`, `dashboard.html`, `mailboxes.html`, `connect.html`, `check.html`, `tests/test_v011.py`, `tests/e2e/` | |
| v0.11 changed: `webapp/main.py` (new routes), `db.py` (`mailboxes` table, three columns in `scans`, migration), `scanning.py`, `config.py`, `manage.py` (`mailboxes` command), all templates and `static/style.css` (new look), `antiphish/attachment_scan.py` (closing inherited connections), `deploy/provjera.sh`, `deploy/DEPLOY.md`, `.env.example`, `requirements-server.txt` (`cryptography`) | |
| v0.11 removed: `templates/index.html` (now `check.html`), `templates/history.html` (now Dashboard) | |
| `antiphish/urlintel.py`, `demo.py`, `webapp/security.py` | unchanged |
